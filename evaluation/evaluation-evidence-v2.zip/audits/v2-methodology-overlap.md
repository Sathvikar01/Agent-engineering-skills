# V2 methodology and overlap audit

Read-only source audit for Sathvik — Agent Engineering, 2026-10-04. The only file created by this audit is this workspace note. No installed skill, setting, database, or third-party source was edited. The installed Anthropic creator is `~/.cc-switch/skills/skill-creator`; the prior discovery inventory attributes it to `anthropics/skills`. All 18 files under that creator were read completely, including schemas, specialized grader/comparator/analyzer guidance, Python scripts, HTML templates, and license. Relevant third-party SKILL.md files were read completely; their unrelated references and scripts were not applied or comprehensively audited.

## Governing workflow and format

- Preserve existing effective content. For improvements, snapshot the actual old skill before editing and evaluate the revised version against that snapshot; a no-skill baseline is for a newly created skill. The user specifically requests migrating `multi-agent-orchestration` to `agent-orchestration`, which overrides the creator's default advice to preserve names during ordinary updates.
- Use `SKILL.md` with YAML `name` and `description`. Author and collection belong inside `metadata`; a top-level `author` is rejected by the installed validator. Allowed top-level fields are name, description, license, allowed-tools, metadata, compatibility. Names use lowercase letters/digits/hyphens, at most 64 characters; descriptions at most 1,024 characters and no angle brackets. Validate nonempty values and directory-name matches additionally: the official minimal validator does not enforce all of these stronger pack requirements.
- Metadata decides selection, so describe both what the skill does and the user's specific intent that warrants it. Explicit near-miss exclusions are useful in this crowded collection. Do not broaden the lifecycle meta-skill until every LLM mention routes to it. Prefer intent categories over a long enumeration of test queries.
- Keep bodies procedural and lean (creator recommends under 500 lines). Reference supporting material with a clear read condition. A reference over 300 lines needs a contents guide. Add bundled deterministic scripts only after evidence of valuable repeated work; scripts are not required for these skills.
- Official behavioral suite: `evals/evals.json` contains skill_name and evals with integer id, prompt, expected_output, files, and expectations. The SKILL.md prose occasionally calls these assertions; `references/schemas.md` gives the canonical suite field **expectations**. Run metadata uses assertions. Input file paths in a suite resolve relative to the skill root.
- Official run convention is a sibling `<skill-name>-workspace/iteration-N/eval-N/` with named eval metadata and configuration directories containing outputs, transcript, and grading. The aggregator accepts both `with_skill`/`without_skill` and `new_skill`/`old_skill`; graders must use expectations entries with exact **text, passed, evidence** fields.
- Spawn with-skill and baseline executors together where capacity permits; independent execution is explicitly authorized by the creator. Keep rubrics outside executor inputs. For substantive assertions, independently inspect real artifacts and execute deterministic checks when available. File existence or keyword presence alone is not successful behavior.
- Grading is pass/fail with cited evidence; missing verification is a failure, not an assumed pass. Inspect implicit output claims and critique weak assertions as well as scoring them. A blind comparator receives anonymized artifacts only; transcripts showing the skill configuration defeat blindness and must not be described as blinded.
- Preserve failures and successive iteration artifacts. Rerun affected test cases after substantive revisions, including matched baseline prompts. Explain whether a revision changed instructions or repaired an underspecified fixture.
- Use the official aggregator and `eval-viewer/generate_review.py` for report generation. Static HTML is supported; generated review pages are not evidence that a human reviewed them. User explicitly says not to ask approval between changes, so prepare review artifacts and report pending human review without blocking every refinement.
- Trigger suite is a JSON array of `{query, should_trigger}` entries. Creator requests 20 substantive realistic prompts, roughly 8–10 positive and 8–10 negative, especially adjacent-domain near misses. Include varied wording rather than easy unrelated negatives. The optimizer defaults to 3 runs/query, 60/40 stratified development/holdout split, up to five iterations, and chooses a description by holdout score. The code stops on perfect development results even if holdout errors remain; inspect holdout failures directly.

## Tooling limitations that affect evidence claims

- `quick_validate.py` performs basic frontmatter checks only. It does not verify references, eval coverage, author, name/path equality, uniqueness, migration integrity, conceptual duplication, or behavior. Run it untouched and supplement it with local pack integrity checks.
- Creator scripts use default text encoding. On Windows, invoke Python UTF-8 mode for non-ASCII source and output; do not patch third-party readers to do this.
- `run_eval.py` requires configured `claude -p`. It writes a temporary `.claude/commands/<unique-name>.md`, observes the first tool invocation for Skill/Read, and cleans up its command file. It uses `select.select` on subprocess pipes, which was observed to fail with WinError10038 during v1. Claude authentication was also unavailable during v1. Those are separate gaps; recheck the current environment before reporting them as current.
- Trigger execution exceptions become false activation observations in the runner. Infrastructure errors must not be reported as successful negative cases or description failures. Check stderr and authenticated execution first. A metadata routing classifier is a **proxy**, not actual skill invocation or Claude trigger accuracy.
- `aggregate_benchmark.py` hardcodes runs_per_configuration=3 in generated metadata, even when the actual experiment has another count. It falls back from unavailable tokens to output_chars and defaults absent timing/tool/error data to zero. Correct only the generated report metadata/unknown metrics, retain the official raw output, and do not claim character counts are measured token usage.
- Aggregated case pass-rate standard deviation across distinct tasks is not repeated same-case model variance. Record actual sample counts, version/configuration, and unavailable model/sampling/usage fields. Do not invent confidence intervals or general reliability from a smoke sample.
- The static viewer embeds only top-level files immediately inside outputs directories; nested verification logs require a linked evidence bundle or summary. Static feedback downloads are not autosaved server feedback.
- The official `.skill` packager deliberately excludes root `evals/`; a full collection/evidence archive must retain suites independently. Preserve Anthropic Apache-2.0 license/attribution for copied generated HTML templates, distinct from Sathvik authorship of custom instructions.

## Scope and non-duplication boundaries

| Capability | Installed ownership | V2 complementary ownership |
|---|---|---|
| Requirements/design | brainstorming; spec-driven-development | agent-development-workflow requires uncertainty mapping, agent-specific boundaries and eval readiness; reuse existing requirements artifacts rather than cloning design interviews |
| Planning and vertical slices | writing-plans; planning-and-task-breakdown; incremental-implementation | meta-workflow chooses one complete agent path through evidence, model/logic, tool, validation, authority, output and trace, then routes implementation mechanics to these skills |
| Debug/correct loop | systematic-debugging; debugging-and-error-recovery | meta-workflow requires observed failures to enter root-cause correction and then regression/eval comparison; do not copy triage trees or framework commands |
| Testing and completion | test-driven-development; verification-before-completion | meta-workflow requires an obvious reproducible test/eval command and real execution evidence; agent-testing adds fallible-model response and semantic/provenance cases |
| Engineering decisions | documentation-and-adrs | meta-workflow records hypothesis, alternatives, evidence, limitation, fallback and proposed/validated/rejected/superseded status in the existing ADR convention; avoid a second decision bureaucracy |
| Adversarial review | doubt-driven-development | meta-workflow calls for proportionate review that can reject a change; do not reproduce fresh-context reviewer machinery or import unconditional cross-model offers |
| Coding subagent coordination | subagent-driven-development; dispatching-parallel-agents | agent-orchestration designs **deployed runtime control flow**, not the coding team's development execution method |
| Context/session handoffs | context-engineering | agent-state-and-memory owns persisted runtime state and memory trust/expiry; agent-orchestration owns runtime handoff and step choice, not repository rules-file setup |
| Framework documentation facts | source-driven-development; research | evidence-provenance owns a runtime evidence ledger and source-to-output reconciliation; not ordinary documentation lookup or citing implementation APIs |
| Academic citations | citation-management | evidence-provenance handles observed/retrieved/used source identities, immutable versions/spans, transform lineage and claim support; no DOI discovery, BibTeX formatting or scientific bibliography cloning |
| Retrieval pipeline | existing custom rag-engineering | evidence-provenance begins at source observation and persists beyond retrieval through decisions and emitted claims; RAG retains chunking, candidate ranking and Recall@K/MRR/nDCG |
| Logging/metrics infrastructure | observability-and-instrumentation | agent-observability records runtime calls, evidence links, state/approval/budget decisions and evaluator results; evidence-provenance owns claim support and use semantics, not log plumbing |
| API/SDK design | api-and-interface-design; mcp-builder | tool-design adds model selection affordances, USE WHEN/DO NOT USE WHEN and action semantics; leave REST conventions and MCP transport/SDK scaffolding to installed skills |
| Ordinary security | security-and-hardening | agent-security adds attacker-controlled instruction/evidence flow to executable effect; spoofed provenance needs deterministic identity/lineage validation, not a prompt-only boundary |
| Generic performance | performance-optimization | agent-cost-and-latency owns per-role model/routing budgets, retries and cost/latency per successful task; keep generic profiling elsewhere |

## Actionable recommendations for the three changed skill boundaries

### agent-development-workflow

Create a meta-workflow only for substantial AI-agent creation, productionization, architecture redesign, or end-to-end evaluation/hardening. A single prompt edit, local bug, isolated tool/schema task, ordinary application task, deterministic utility, and introductory explanation stay with their specialist or ordinary workflow. The body should select a phase and route to a bounded set of specialists, not force every specialist on every task.

Own the uncertainty map, initial baseline/eval gate, vertical slice integration, PLAN → IMPLEMENT → RUN → DEBUG → CORRECT → REVIEW loop, measured KEEP/REVISE/ROLLBACK decision, evidence-consistent technical defence, and final verified operational readiness. Link detailed procedures instead of repeating schemas/security/recovery/RAG content. Use material decision records only; existing conventions win. No generic mandatory approval at every phase: apply actual authorization/policy and the user's stated autonomy.

### evidence-provenance

Create a distinct first-class skill because runtime source-to-decision-to-claim lineage is not already covered by academic citations or source-driven framework implementation. Separate observed, retrieved, context-visible, and actually-used evidence; ledger membership is necessary but insufficient support. Require emitted IDs to refer to authorized immutable ledger entries and claim-specific supporting spans/derivations actually used in the decision path. Deduplication, compaction, normalization and transforms must preserve parent lineage and source version/identity.

Do not claim to infer hidden private reasoning. Record explicit observable structured fact/derivation and claim-support edges, validate references and contradictions, and acknowledge that deterministic identity checks do not themselves prove semantic entailment. A model support grader is advisory and calibrated when deterministic comparison is inadequate. Reconcile decision, facts, explanation, cited IDs and support; missing IDs, unused padding citations, unrelated-but-retrieved evidence, spoofed lineage and invented explanation facts fail admission or become explicitly unsupported output per the contract.

### agent-orchestration

Migrate valuable multi-agent contracts, budgets, handoffs, conflict/late-result and cancellation rules while broadening to bounded control flow for one model/agent as well as many. First ask whether model control of the next step is needed; second whether deterministic routing is adequate. Use the simplest design that handles real semantic uncertainty, not a universal least-agentic ranking. Fixed graph, explicit state machine and ordinary functions are valid orchestration implementations.

Keep architecture selection rationale in agent-architecture and execution scheduling/allowed actions/budgets/termination in agent-orchestration. Multiple workers require measurable benefit, isolated/separable work or independent verification; responsibilities or role labels alone are insufficient. Model output and reviewer agreement cannot bypass policy. Verify total centrally reserved budgets, duplicate work, conflicts, cancellation/expiry before commit, restart and fallback. Remove the obsolete custom name only after current references, catalogue, frontmatter and suites migrate; preserve historical v1 artifacts as history.

## Evidence attribution

The HackerRank/Orchestrate patterns are supplied by the user in the pasted request. They motivate hypotheses and requested design rules; this audit did not independently verify the four-edition analysis and has no statistical data establishing causality, provider superiority or universal architecture rankings. Keep that attribution in collection documentation, not framework/company-specific operational rules in global skills.

`model-selection-and-routing` should remain folded into architecture (role hypothesis), orchestration (routing control), evals (matched role comparison), and cost/latency (escalation/operational trade-off). A separate skill currently lacks a unique nonduplicative workflow and trigger boundary.

## Files read and SHA-256

The following table records current file bytes and whether they still match the v1 discovery inventory where an entry exists. Hash equality verifies source integrity, not semantic quality.

| File | SHA-256 | Matches prior inventory |
|---|---|---|
| ~/.cc-switch/skills/skill-creator/LICENSE.txt | bc6b3af2f331cbc7fb0da1344efb2cbe5877a31498b4d70dbc7000f3405a1362 | yes |
| ~/.cc-switch/skills/skill-creator/SKILL.md | dcd4803e61e913e6fc27294184cd3a71f09f5e924ff20c8a9a20173e7b3c2bcf | yes |
| ~/.cc-switch/skills/skill-creator/agents/analyzer.md | bf68f4cac5a56c673a928c2e6d619586c5b93ea364026ab37547772cb45a663a | yes |
| ~/.cc-switch/skills/skill-creator/agents/comparator.md | fe1fc9787c495d864c5d6eada47396478572325fde1b33a96d78bf4b849b7a3e | yes |
| ~/.cc-switch/skills/skill-creator/agents/grader.md | 57134da0c1a4eea33fbd74a1c9c44aa814f07d6bc64de303edb586f941e5d21a | yes |
| ~/.cc-switch/skills/skill-creator/assets/eval_review.html | ce477dcc74dc1c0d1d3352646a79167b5a63634e936b1019160025065974e452 | yes |
| ~/.cc-switch/skills/skill-creator/eval-viewer/generate_review.py | fc9d1b9243fe5ab6012ebd579bd76d0035de1b79fd3b969de114defab26478fb | yes |
| ~/.cc-switch/skills/skill-creator/eval-viewer/viewer.html | a53213426ee1100441d701a3a0d49cda7a842f992d2c36463f4d3cc0258575fa | yes |
| ~/.cc-switch/skills/skill-creator/references/schemas.md | 8e8876180a8989b406a4d3edddf875b04cdfd5805cc8616686d552b11ce4455f | yes |
| ~/.cc-switch/skills/skill-creator/scripts/__init__.py | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | yes |
| ~/.cc-switch/skills/skill-creator/scripts/aggregate_benchmark.py | 123ef128ea5ccc01a4b1ac212ef5567f21e9c13d3d240609780beeb3200c49aa | yes |
| ~/.cc-switch/skills/skill-creator/scripts/generate_report.py | 13df7118a3c50c83c4c3250a606d5f2b20b25a3d44cbc392b3d669ec75281453 | yes |
| ~/.cc-switch/skills/skill-creator/scripts/improve_description.py | 87d864570220b699fac52da309d2d6efdb060647bfebc74f768128e646accf80 | yes |
| ~/.cc-switch/skills/skill-creator/scripts/package_skill.py | 1a33059b0db1ef73375d46d513e5ea81369d2e8838c970597b0d52ddef8d1c0f | yes |
| ~/.cc-switch/skills/skill-creator/scripts/quick_validate.py | 67cf5703402013936c8fb75ad6a1afecd8841d45cc5e606b634eb05825fde365 | yes |
| ~/.cc-switch/skills/skill-creator/scripts/run_eval.py | 43e3b8f80dbf69c343967ba77e268fae991d9fa3ed68b32a0ff02532cd48657f | yes |
| ~/.cc-switch/skills/skill-creator/scripts/run_loop.py | 7bd6f674203168520517eec94c55f493c0d154339b061b4d7c0f0dad187d0f21 | yes |
| ~/.cc-switch/skills/skill-creator/scripts/utils.py | 3af8ae62c40c73ab712207436a0d9a981e845f25c5a7040229eb189cc8e45bb1 | yes |
| ~/.cc-switch/skills/context-engineering/SKILL.md | 8b736cb9e55b82b265ab6ff78349c0e826e8a6df550deddf665b7fb3ff858b63 | yes |
| ~/.cc-switch/skills/source-driven-development/SKILL.md | c59faf851377f0eeda45306398d16eb96d77ab1c2fd3e1a7fb58e9a0af33c1e9 | yes |
| ~/.cc-switch/skills/spec-driven-development/SKILL.md | c4b97ce3d7f24be0e67fd612c7595f65504872e3a9f8d338d098b2363fdb66ef | yes |
| ~/.cc-switch/skills/brainstorming/SKILL.md | a32d2255354775aa124855aa7100cf276bea096fff4ebb3a0edf57be216e6c72 | yes |
| ~/.cc-switch/skills/writing-plans/SKILL.md | a6c67c1900064347c2a329990dd3c555657c51c3ec53b259a08aa01a2c26139a | yes |
| ~/.cc-switch/skills/systematic-debugging/SKILL.md | 808fc5717aa88ad65efff312b11c186294d3e6ee301afb584e2f86599b137787 | yes |
| ~/.cc-switch/skills/verification-before-completion/SKILL.md | 2befe7fc55bcadaa3d97dd9e8efeb633d2561c0ebe74c5a8b17c4d9e7e4520b3 | yes |
| ~/.cc-switch/skills/api-and-interface-design/SKILL.md | e83d34f52ff12dd8a7c5134cd7e8140ea4541ec65e204f8a1e4cd366e30c4192 | yes |
| ~/.cc-switch/skills/observability-and-instrumentation/SKILL.md | e7fcb0820306d46268de9594d676ad98e35040858926c412b7000faa52a61f87 | yes |
| ~/.cc-switch/skills/mcp-builder/SKILL.md | 0f4592dcb53cf2b5d6b7febee6b4152018b565551a1c29e3c612f57b218ab295 | yes |
| ~/.cc-switch/skills/incremental-implementation/SKILL.md | df66536610071727feae1ca95f3c391c248ad828041750ccd3699cce763aa00b | yes |
| ~/.cc-switch/skills/planning-and-task-breakdown/SKILL.md | ed0f90cc5951ddd4bcab7f871f64efec93a49af9279ef93bc470da77ad8da3f7 | yes |
| ~/.cc-switch/skills/subagent-driven-development/SKILL.md | 8dde5589ee083fb4999106d116f01c8fdaf3116a8a9813fdedeb80329de49046 | yes |
| ~/.cc-switch/skills/doubt-driven-development/SKILL.md | 6fa1fcd8420c28daf7e53c5b08b0f20b907911efd2a6d9bce0b9740da20a4008 | yes |
| ~/.cc-switch/skills/documentation-and-adrs/SKILL.md | 359b22460045583b0233ec3f80223459c4096b0fa513f5c29ade9c3985207d65 | yes |
| ~/.cc-switch/skills/security-and-hardening/SKILL.md | 2e3fc60eed5aba97fe416f3f3c9317fdb014a682925ec70a733c3ff99e4b9858 | yes |
| ~/.cc-switch/skills/test-driven-development/SKILL.md | 7c0c6ac057c19d7f8be65d9f49c3a638703b868f4625c78b70da5439d5d74fca | yes |
| ~/.cc-switch/skills/debugging-and-error-recovery/SKILL.md | 21f3960f5d7ae2cc95c40896545004dbbcbbd752ea65fc2d53962554d4174220 | yes |
| ~/.cc-switch/skills/dispatching-parallel-agents/SKILL.md | 1968923066f3b707eb01d1992cdf4c42284c3855f70253b9cd5000ff45fca13c | yes |
| ~/.cc-switch/skills/performance-optimization/SKILL.md | 665a83a7218d6aebd02ca329a7b2422cf28f7c55cb56f870c05e12047770245c | yes |
| ~/.agents/skills/research/SKILL.md | 524b404b1ca373a8b00f63a64667ec4b0a61c3c9cf4e8f246e639be859bb6979 | yes |
| ~/.agents/skills/citation-management/SKILL.md | 502331499c36890fdb37a00bbfca6dff2fb631ebe50684cec142c64e3a6566dc | yes |
| ~/.cc-switch/skills/agent-architecture/SKILL.md | 8f36c9d862996ca838a8530c8dcbb137bdc2710cb15588e9b570eca67b026cf3 | not recorded (custom v1 file) |
| ~/.cc-switch/skills/multi-agent-orchestration/SKILL.md | 6e95f6ca83fc8dba55d23fb2d4ce18c07575c6585e9e07516ed070ed1589a624 | not recorded (custom v1 file) |
| ~/.cc-switch/skills/rag-engineering/SKILL.md | 8fe3a8505798e8f7673266ea3ac8adb499e79f169175a3efbd2986a8622ab40b | not recorded (custom v1 file) |
| ~/.cc-switch/skills/agent-observability/SKILL.md | 10551bd8aae151ddc458cd8b4db4fc968932f03a9c78f7eb5c5ee7b1ab00f6f2 | not recorded (custom v1 file) |
