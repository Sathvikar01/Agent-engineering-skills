# V2 revision gap map

Author: Sathvik. Governing methodology: installed Anthropic skill-creator.
Evidence input: user's supplied summary of Orchestrate feedback and four-edition observations. Original submission reports/article were not supplied; no statistics, causal claims or provider preferences are inferred.

| Owner | Preserve | Necessary change | Evaluation |
|---|---|---|---|
| agent-development-workflow (new) | Existing planning/TDD/debugging skills | Coordinate uncertainty map, eval baseline, vertical slice, executed correction/review loop, decision log and technical defence; load specialists only at actual boundaries | Whole-build execution, design justification, narrow-task exclusion |
| agent-architecture | Boundary/authority/budget contracts | Replace ranked ladder with task-fit hypotheses; reject both agentification and brittle semantic heuristics; framework capabilities and eight failure patterns | Semantic ambiguity vs regex, fixed arithmetic, unjustified framework/workers |
| agent-orchestration (rename) | Typed worker contracts, fan-in, ownership, aggregate budgets and cancellation | First decide if model needs next-step control; deterministic routing baseline; bounded single-agent adaptive flow before optional workers | Known vs ambiguous routes, role labels, missing/late workers |
| agent-evals | Gold splits, leakage, calibration, paired comparisons | Obvious rerun path; metric-specific regression gates; full comparison manifest and keep/reject decision | Quality gain that violates safety threshold |
| tool-design | Strict schemas, coherent capabilities, errors and idempotency | Explicit model-choice USE WHEN/DO NOT USE WHEN, pre/postconditions and representative request/response | Ambiguous read/preview/commit choices |
| structured-output-design | Staged validation, union/version rules | Concrete cross-field decision/explanation checks; bounded semantic candidate reconstruction with immutable facts | Valid-shape invalid-meaning; safe repaired vs unrepairable proposal |
| deterministic-authority | Denial-no-effect, authenticated permissions and race control | Construct/verify/admit safe alternative before terminal failure; hard constraints remain unchanged | Initial invalid candidate and available valid alternative; no admissible candidate |
| evidence-provenance (new) | RAG source spans and observability receipts remain separate | Application-issued ledger, retrieved/visible/used/support distinctions, transformation lineage, decision/claim/ID reconciliation | Unknown IDs, retrieved-but-unused evidence, spoofed lineage and contradictory explanation |
| agent-security | Untrusted ingress, privilege/egress/path/SSRF boundaries | Spoofed provenance/IDs cannot mint ledger authority | Injection hidden in fake evidence envelope |
| agent-failure-recovery | Unknown commits, checkpoint and idempotency | Model-boundary failure table; distinguish retry/repair/fallback/escalation/terminal; fallback valid under same contract | Timeout/refusal/semantic failure with bounded fallback |
| agent-observability | Reconstructable events, privacy and versions | Evidence usage joins; signal baseline/threshold/window/severity/response; eval vs telemetry vs diagnostic | Actionable signal contract |
| agent-testing | Cheap deterministic pyramid and no-effect tests | Scripted model failures, semantic contradictions/IDs/no progress; verify actual surrounding implementation | Runnable fault fixtures |
| prompt-engineering | Concise versioned instructions, controls outside model | Fallible proposal and safe candidate construction; used evidence and explanation reconciliation | Unsupported explanation and repair under unchanged policy |
| rag-engineering | Full measured retrieval pipeline | Handoff retrieved/context/used lineage to provenance; don't cite irrelevant candidates as support | Retrieved-but-unused attribution |
| agent-cost-and-latency | Full-run cost per success and ceilings | Model choice per role with same evals; completion latency; verifier/model ablation | Unproven second-model claim |
| agent-guardrails | Layered enforcement and no bypass | Remove formatting-only recovery restriction; construct valid candidate under enforced constraints; retain required checks | Repair without relaxing authority |
| tool-evals, agent-state-and-memory, human-in-the-loop | Existing procedures already adequate | No instruction changes required; retain existing suites and recorded V1 results | Explicitly label retained evidence, don't claim fresh V2 executions |

No separate model-selection-and-routing skill: role requirements belong to architecture, route transitions to orchestration, experiment design to evals and economic thresholds to cost/latency. No distinct non-overlapping trigger remains. Technical defence belongs to lifecycle completion, not a twentieth skill.

Acceptance: all 19 structural/integrity checks; paired targeted V2 cases compared to V1 snapshots for modifications and no-skill for additions; routing proxy for all 380 trigger queries including lifecycle near misses; preserve failures and explain actual invocation/variance/human-review gaps. A proxy cannot satisfy actual automatic activation testing.
