# V2 trigger and resource audit

This read-only audit inspected the 17 installed Sathvik skill directories discovered through work/global-installation.json. It did not change any global skill, reference or evaluation suite.

## Inspection and methodology

- Fully read all 17 frontmatter descriptions and all 340 trigger queries, the complete user's v2 request, installed Anthropic skill-creator/SKILL.md and references/schemas.md.
- Structurally inspected all 17 behavioral suites against the official creator schema: matching skill_name, unique integer IDs, nonempty prompts/expected_output/expectations and existing input files. These focused assertions passed. This is not a full JSON Schema implementation or a behavioral test.
- Inventoried all 55 actual custom files: 17 SKILL.md, 17 evals.json, 17 trigger-evals.json, four reference files. No custom scripts or installed input fixtures exist.
- Root separately read all SKILL.md bodies, behavioral prompts/assertions and four references. Reference bodies were inventoried, not independently semantically reread by this trigger auditor.
- Every trigger suite follows the creator's exact query/should_trigger object array and has 10 positive and 10 negative cases. All 340 query texts are unique.
- No classifier, automatic activation test, description optimizer or behavioral evaluator was executed in this audit. V1 results cannot certify v2.

## Necessary boundary changes

1. **agent-architecture**: replace the generic smallest reliable architecture promise with the simplest architecture that correctly handles uncertainty. Include model-worthy semantic ambiguity and brittle regex-only overcorrection cases alongside anti-agentification. Architecture owns component/control/trust choices; the lifecycle skill owns execution and review across disciplines.
2. **agent-orchestration**: rename and broaden the multiple-worker-only description. Add single-agent contextual next-tool choice, additional retrieval, verifier/escalation, deterministic routing comparison and explicit stopping. Retain useful worker fan-in/authority/budget tests and development-session coding delegation negatives. Old negative index14 asks for system-class selection and remains architecture-focused; construct a separate next-step-controller positive instead of silently relabeling it. Old negative index15 is performance-only parallel reads/caching, which remains cost-focused when routing design is fixed.
3. **agent-development-workflow**: the new description must require meaningful build, productionization, substantial redesign, major tools/RAG/state changes or end-to-end hardening. Add negatives for a tiny prompt change, one agent bug, one schema field, focused provenance reconciliation, one tool description or retry policy, ordinary endpoint, deterministic utility and conceptual explanation. Permit lifecycle plus specialists together when scope warrants it; do not require one-skill-only classification. Behavior must demonstrate sequencing, actual execution, correction and evidence-based review, not mere terminology.
4. **evidence-provenance**: existing descriptions mention provenance but do not own source-to-decision/claim ledger reconciliation. New positives should span tool receipts, computed decisions, normalization lineage, source versions, unsupported IDs, explanation contradictions and retrieved-but-unused citations. Negatives should isolate retrieval recall/reranking, event instrumentation, memory lifecycle, routine source-finding and syntax/schema-only work. This skill owns support lineage and reconciliation; RAG owns candidate/context/generation quality, structured output owns contract/validation stages, observability owns safe correlated events. Spoofed provenance attack containment can also require security; multiple applicable specialists are valid.
5. **rag-engineering**: its existing description can stay because retrieval-grounded generation is a clear purpose. Add a ledger-only fixed-retrieval negative against provenance and a pipeline-loss positive involving chunking/reranking/context assembly. Preserve existing citation-support pipeline positives rather than relabeling them to force distinctness.
6. **Other descriptions**: no concrete scope flaw warrants rewriting them. Content additions on semantic consistency, construct/verify/admit, recovery, tool selection guidance, testing, actionable signals and cost fit existing scopes. Test new boundaries if responsibilities expand, but preserve good metadata otherwise.
7. **model-selection-and-routing**: a separate skill currently duplicates architecture role assignment, orchestration contextual control, evals measurement and cost routing/escalation. Fold role-specific comparison into these unless observed cases establish a distinct reusable procedure.

## Evaluation weaknesses and recommendations

- Existing queries are mostly polished and negatives often announce that an adjacent scope is fixed or outside this request. Keep them, but add casual, shorter and genuinely ambiguous examples for the new/broadened skills. Avoid all positives embedding the exact desired procedure.
- Old architecture looping/termination positives overlap orchestration legitimately. Distinguish requested artifact: architecture boundaries versus next-step state machine. Lifecycle coordinates specialists instead of replacing them.
- V1 suites lack sufficient direct behavioral coverage for deterministic overcorrection, first-solution acceptance, construct/verify/admit and evidence ledger reconciliation. Keyword-based trigger scores cannot establish these behaviors.
- Test provenance against RAG/output/observability/state/security in catalog-wide routing. Do not pretend one definitive owner is required when a prompt truly requests two artifacts.
- Follow creator improvement methodology: freeze old skill snapshots, execute paired new-versus-old runs for changed skills, use no-skill baselines for new skills, preserve prior failures, and create fresh eval metadata for altered prompts.
- Preserve documented Claude authentication and Windows subprocess limitations unless a fresh preflight disproves them. A catalog classifier is a proxy, not actual invocation evidence.

## Structural inventory

| Skill | Behavior cases | Positive triggers | Negative triggers | References | Scripts |
|---|---:|---:|---:|---:|---:|
| agent-architecture | 3 | 10 | 10 | 0 | 0 |
| agent-evals | 3 | 10 | 10 | 1 | 0 |
| tool-design | 3 | 10 | 10 | 0 | 0 |
| tool-evals | 3 | 10 | 10 | 0 | 0 |
| structured-output-design | 3 | 10 | 10 | 1 | 0 |
| deterministic-authority | 3 | 10 | 10 | 0 | 0 |
| agent-state-and-memory | 3 | 10 | 10 | 0 | 0 |
| human-in-the-loop | 3 | 10 | 10 | 0 | 0 |
| agent-security | 3 | 10 | 10 | 0 | 0 |
| agent-failure-recovery | 3 | 10 | 10 | 0 | 0 |
| agent-observability | 3 | 10 | 10 | 0 | 0 |
| agent-testing | 3 | 10 | 10 | 0 | 0 |
| prompt-engineering | 3 | 10 | 10 | 0 | 0 |
| multi-agent-orchestration | 3 | 10 | 10 | 0 | 0 |
| rag-engineering | 3 | 10 | 10 | 1 | 0 |
| agent-cost-and-latency | 3 | 10 | 10 | 1 | 0 |
| agent-guardrails | 3 | 10 | 10 | 0 | 0 |

## File hashes at audit time

Paths below were inventoried. SHA-256 identifies installed pre-change bytes; it does not assert independent semantic review of every body.

| File | SHA-256 |
|---|---|
| `~\.cc-switch\skills\agent-architecture\evals\evals.json` | `5d6dc41f1cd29edd70c876d211696ae29cdfdf91320da5782eab9651f005bf3c` |
| `~\.cc-switch\skills\agent-architecture\evals\trigger-evals.json` | `f1f2330c715b392629e738bc259477a1558bfe625831eaff26e254be4f00799e` |
| `~\.cc-switch\skills\agent-architecture\SKILL.md` | `8f36c9d862996ca838a8530c8dcbb137bdc2710cb15588e9b570eca67b026cf3` |
| `~\.cc-switch\skills\agent-evals\evals\evals.json` | `38b125add2e9e714d9f14bf9d7b7489b093e0007c44b1604f03d81e594a01138` |
| `~\.cc-switch\skills\agent-evals\evals\trigger-evals.json` | `305fc329f56a01492a7390e30eca00bd0f1eed873ba5060c586b7901dd868416` |
| `~\.cc-switch\skills\agent-evals\references\scoring.md` | `b8977ad6ac4e05e7d799a21126c26ba7eeda2c568ccc1ab4d97e6303741b9f8e` |
| `~\.cc-switch\skills\agent-evals\SKILL.md` | `c6532a0d8aadf7246fc99463a304319457c0d9ec12600a9d096fc28d921e7e11` |
| `~\.cc-switch\skills\tool-design\evals\evals.json` | `06a4f02e7b9ce1daff67809e1274d5cd17385fe7ab35809f167fbcbc94f74682` |
| `~\.cc-switch\skills\tool-design\evals\trigger-evals.json` | `1fc35dbf9789671007f8f523029b25fa5466c915632dcdd9911fedd4c9f2fe0e` |
| `~\.cc-switch\skills\tool-design\SKILL.md` | `b6c1ca1c8dd0163ff2de1059b6490a0ffb784da5b40d5d9cc6c9942c5dc85c21` |
| `~\.cc-switch\skills\tool-evals\evals\evals.json` | `c9b5d2cdccb004c6f5aca67246096a8257ad26f04ef50b8d22f223a12590218e` |
| `~\.cc-switch\skills\tool-evals\evals\trigger-evals.json` | `ee81f4fc172328e437b34120e8dfecc804838c338d29a84aeead02246d4c948f` |
| `~\.cc-switch\skills\tool-evals\SKILL.md` | `3162af5511b07a6f2dd9958838115c05deb048e5bb93cf702acf3477d70fd9c1` |
| `~\.cc-switch\skills\structured-output-design\evals\evals.json` | `f2453e4687540cc9cfa11006c193fb01c3d583304c1826c45fb02e23f13cf024` |
| `~\.cc-switch\skills\structured-output-design\evals\trigger-evals.json` | `bb0b25438b3cc6c0bead67e26a251426e8cee0000bd225422e32f6377b48e49a` |
| `~\.cc-switch\skills\structured-output-design\references\proposal-contract.md` | `198d16a3ad2cb7f65cee17f4fd47870cca60178c8fda98c68f3c3724b4d52865` |
| `~\.cc-switch\skills\structured-output-design\SKILL.md` | `9b10c88bf21de6b5b3b541a5adc9fffe555393ae09ba1ba6059372df16b28a3c` |
| `~\.cc-switch\skills\deterministic-authority\evals\evals.json` | `e739dc02e0184d10aec0239c953e72c119fd48ba30cae250f4fb446c1b9bd4d6` |
| `~\.cc-switch\skills\deterministic-authority\evals\trigger-evals.json` | `97309767ef57acd81668d3f4e8e1ccb44109215e6540315d2d67cf4bf8e2fe2e` |
| `~\.cc-switch\skills\deterministic-authority\SKILL.md` | `7f45d8d8d4189c71eca9a2f5da8f99f840f5743498682b550f01a9aba70ec434` |
| `~\.cc-switch\skills\agent-state-and-memory\evals\evals.json` | `975dce5bc22f8c0d2f33999dffe8acca075f25b9c162373f13ae718ce6bd6489` |
| `~\.cc-switch\skills\agent-state-and-memory\evals\trigger-evals.json` | `8473a20099231b10287ecd55d59e59a63c53efdeea0a90df39c4e94a6e6319ba` |
| `~\.cc-switch\skills\agent-state-and-memory\SKILL.md` | `612e1434e2058e9d874a37214a368fcb05c8a945c76fcc63908b441c4e363bbb` |
| `~\.cc-switch\skills\human-in-the-loop\evals\evals.json` | `1640fc5fb4be0a3956f0b7bbaf2285be6e968246614676d96aa1b8e70ecf3358` |
| `~\.cc-switch\skills\human-in-the-loop\evals\trigger-evals.json` | `78623c9ed71d9ea3018e4f2b779f31d6cc1477743224083bdf6392b2b3681a8a` |
| `~\.cc-switch\skills\human-in-the-loop\SKILL.md` | `5cbeab85e293280a9e782f2fcf57ded380ea456df9f2ab9f227d5740f8736cd9` |
| `~\.cc-switch\skills\agent-security\evals\evals.json` | `66e5a597ca6f0f2f0d568d2dc8af7a83c024ad109f6eb3139af7b04db9c4961c` |
| `~\.cc-switch\skills\agent-security\evals\trigger-evals.json` | `c861ccec035b0894f955c05c73866a7db0f699fc34bca1f114ca9ee6458db881` |
| `~\.cc-switch\skills\agent-security\SKILL.md` | `481a506cbeb8c71015e25bfe90b84707a2e2357b846fc8ef0da9fd1e9f16594b` |
| `~\.cc-switch\skills\agent-failure-recovery\evals\evals.json` | `cbbcf501e30defbd99ac68450a786b8c4a3cf78a964d4ce1d49e74499da218d1` |
| `~\.cc-switch\skills\agent-failure-recovery\evals\trigger-evals.json` | `f4eeec4ce45eb599acf5868a5d5d1ce1109c03044b31156901cac47517af3776` |
| `~\.cc-switch\skills\agent-failure-recovery\SKILL.md` | `f525a31f3892d9cceb94ad319f4e341019235ef89af010e7c9510d3cd29f15b9` |
| `~\.cc-switch\skills\agent-observability\evals\evals.json` | `91213e43809f80423bc7cae8e158b58707fe41233125712a3642c11530da661b` |
| `~\.cc-switch\skills\agent-observability\evals\trigger-evals.json` | `09107111e78b855f6fea90fd38c6a805e30e28323d10a98d1cf870ef2bfed297` |
| `~\.cc-switch\skills\agent-observability\SKILL.md` | `10551bd8aae151ddc458cd8b4db4fc968932f03a9c78f7eb5c5ee7b1ab00f6f2` |
| `~\.cc-switch\skills\agent-testing\evals\evals.json` | `4505ea8195b4f1bfa2d994022a22317e279ec0567b7c7c25e221b86e56993100` |
| `~\.cc-switch\skills\agent-testing\evals\trigger-evals.json` | `9c6e0a327c3bb158ffad782505c12918d7f334a7c880b54f3ddac00098b3afab` |
| `~\.cc-switch\skills\agent-testing\SKILL.md` | `9f28f9c47a33e86e4fa760057c5cec9655e418bcd24135f2b46620f84b3c77f1` |
| `~\.cc-switch\skills\prompt-engineering\evals\evals.json` | `58bfc21aabe4418ea7227dcc1480ca2af62bbae03dbe166a2c0f446e82a8f495` |
| `~\.cc-switch\skills\prompt-engineering\evals\trigger-evals.json` | `4f704a58b3d640b457207dbf4a53db7895fd9ab8fa9c259bd41037be30bcfd31` |
| `~\.cc-switch\skills\prompt-engineering\SKILL.md` | `d8394722b49861c2eb4d1c13ffb6a5515546c216839d9c27b7336809a870c5de` |
| `~\.cc-switch\skills\multi-agent-orchestration\evals\evals.json` | `6fc5dd3d14dfe1caf9b27c780328fcce63ad8e85a4a1c36c136dc77be335fd6d` |
| `~\.cc-switch\skills\multi-agent-orchestration\evals\trigger-evals.json` | `d83b0fa6535040b0cb3dff6b57b275fdb5ab7e6ec80a9fdf0fe84d3057beb07a` |
| `~\.cc-switch\skills\multi-agent-orchestration\SKILL.md` | `6e95f6ca83fc8dba55d23fb2d4ce18c07575c6585e9e07516ed070ed1589a624` |
| `~\.cc-switch\skills\rag-engineering\evals\evals.json` | `18786be174e89a964726b9011f00eb3b89c50212fd76e8915ca27b510ed7c929` |
| `~\.cc-switch\skills\rag-engineering\evals\trigger-evals.json` | `0c8ed6d78ec050e18b87579e61a1fbfbc681a121a2fc4b8b2a70a4dd01ca8c90` |
| `~\.cc-switch\skills\rag-engineering\references\retrieval-scoring.md` | `820459d4dcccfbe4abd7e29f57bd468f8efad6045d52712f558f92747710a544` |
| `~\.cc-switch\skills\rag-engineering\SKILL.md` | `8fe3a8505798e8f7673266ea3ac8adb499e79f169175a3efbd2986a8622ab40b` |
| `~\.cc-switch\skills\agent-cost-and-latency\evals\evals.json` | `4a0cb3708c06e3dfdaf206c468579c9f3dddf407b674b173a17b4ba357c0be00` |
| `~\.cc-switch\skills\agent-cost-and-latency\evals\trigger-evals.json` | `7d75174336ba6672344eb18d35e98fcf511525e8d71f4400f2e4cbfe73f57be3` |
| `~\.cc-switch\skills\agent-cost-and-latency\references\cost-comparison.md` | `44cb01ffc5fa704e9efe687c9af3f80016334a3fcc4ee1b095d66e3982c9586d` |
| `~\.cc-switch\skills\agent-cost-and-latency\SKILL.md` | `226e620c908a19daff6636591e00782fc5a5d94f940cb08dda75349c6f5c95e9` |
| `~\.cc-switch\skills\agent-guardrails\evals\evals.json` | `c0900fa02fbaa10ade0a5eecb0ef7abd7cfcdbd08a4d8292a7ecfb0b2ab858b9` |
| `~\.cc-switch\skills\agent-guardrails\evals\trigger-evals.json` | `96629ecf9d751a153afb600a3d5973edaba92b55a5f447eaae2aa0deada1d715` |
| `~\.cc-switch\skills\agent-guardrails\SKILL.md` | `7925dfef0740c7936a7a3e39c3df745ea32e09d99a40a2df8622d42258d3c77f` |

## Governing files read

- `~\.cc-switch\skills\skill-creator\SKILL.md` — SHA-256 `dcd4803e61e913e6fc27294184cd3a71f09f5e924ff20c8a9a20173e7b3c2bcf`
- `~\.cc-switch\skills\skill-creator\references\schemas.md` — SHA-256 `8e8876180a8989b406a4d3edddf875b04cdfd5805cc8616686d552b11ce4455f`
