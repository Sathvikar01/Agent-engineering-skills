**Reject the added verifier V under the required p95 ceiling, and retain S as the measured baseline provisionally.** S satisfies the 5-second latency requirement; V does not. S's 80% success rate is not automatically an acceptable quality floor: that requirement was not supplied and must be defined before broader acceptance. A competition's use of many models supplies no evidence that four role-specific models improve this receipt workflow.

I executed the supplied arithmetic locally with Python `Decimal`. Assuming 20 and 30 are each variant's total spend over the same 100 logical tasks:

| Variant | Supplied spend | Successes/tasks | Cost per success | Supplied p95 | Latency gate |
|---|---:|---:|---:|---:|---|
| S | 20 | 80/100 | 0.2500 | 4 s | Pass |
| V | 30 | 82/100 | 0.3659 | 8 s | Fail |

V adds two percentage points of success while increasing total spend by 50% and cost per success by approximately 46.34%. The aggregate difference is 10 extra units for two net additional successes, or 5 units per net gain. Those aggregate counts do not establish which cases the verifier repaired or harmed, nor statistical reliability. V doubles S's p95 and exceeds the required ceiling by 3 seconds. If “costs 30” instead means 30 incremental units beyond S, V's total would be 50, cost per success approximately 0.6098, and incremental spend per net gain 15; the latency rejection remains unchanged. These are calculations from supplied inputs, not audited billing or a newly executed model evaluation.

Assign ownership by what each operation needs:

| Role | Proposed owner and boundary |
|---|---|
| Receipt interpretation | One semantic model extracts typed facts with receipt provenance: quantities, prices, discounts, tax, currency, and relevant wording. Deterministic parsing/schema checks validate structure; they cannot prove interpretation is correct. |
| Exact total arithmetic | Deterministic code computes from validated facts using integer minor units or `Decimal`, explicit currency/rounding rules, and the stated tax/discount policy. A model's computed total is never the arithmetic authority. |
| Ambiguous contradiction review | The semantic owner reviews conflicting meanings or evidence when a defined signal triggers escalation. An alternative model is a candidate to evaluate, not a default extra worker. Unresolved ambiguity produces a supported abstention. |
| Explanation | A template expresses validated facts and the code's result. If free-form language is necessary, the semantic owner verbalizes that record; explanation cannot alter arithmetic or resolve ambiguity silently. |

Keep the current measured S flow as the comparison baseline while evaluating that ownership proposal. Freeze receipt sets, prompts, schemas, arithmetic policy, budgets, and success labels. Include clean receipts, ambiguous discounts, tax-policy differences, unreadable fields, contradictory totals, currency boundaries, and hard failures. Independently score field accuracy, exact arithmetic given correct inputs, contradiction handling, appropriate abstention, and explanation faithfulness. An arithmetic verifier does not close extraction or semantic gaps.

The following ablations are **proposed and unexecuted**:

1. Compare one semantic owner against the current four-model split, holding deterministic arithmetic and validation fixed. Measure coordination calls and contradictory handoffs as well as outcome quality.
2. For interpretation alone, compare each candidate directly with candidate-to-alternative fallback. Use validated extraction failures and calibrated ambiguity signals for routing; compare direct routing on the same difficult cases.
3. Hold interpretation fixed and compare no extra semantic reviewer, selective contradiction review, and always-on review. Retain deterministic arithmetic checks in every arm. Inspect reviewer repairs, newly introduced errors, and disagreement resolution.
4. Compare templated explanation, explanation by the existing semantic owner, and a separate explanation model. Evaluate groundedness and usability before paying for another role.

For every arm, account for all failed attempts, retries, fallback calls, verification, tool work, and coordination in total spend divided by independently verified successes. A small failed attempt plus fallback can exceed direct execution cost. Bound eligible retries and aggregate spend durably, and report route frequency, abstentions, success rate, and p95 across all terminal logical tasks, with any success-only denominator stated separately. Include queueing and retry delays in real completion latency. Retain only an arm meeting the predefined quality floors and p95 ≤5 seconds; no provider recommendation is justified by these inputs.
