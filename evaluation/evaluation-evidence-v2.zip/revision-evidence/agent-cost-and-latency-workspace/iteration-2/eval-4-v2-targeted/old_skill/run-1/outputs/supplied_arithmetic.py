"""Reproduce arithmetic from supplied aggregate inputs; no model experiments."""
from decimal import Decimal, getcontext
import json

getcontext().prec = 28
D = Decimal
sample = 100
s_spend, v_spend = D(20), D(30)
s_success, v_success = 80, 82
s_p95, v_p95, p95_limit = D(4), D(8), D(5)
s_cost_per_success = s_spend / D(s_success)
v_cost_per_success = v_spend / D(v_success)

def display(number):
    return str(number)

result = {
    "source": "User-supplied aggregate comparison; not audited billing or an executed model evaluation",
    "assumption": "20 and 30 are total variant spends across the same 100-task denominator",
    "sample_tasks_per_variant": sample,
    "S": {
        "total_spend_units": display(s_spend),
        "successes": s_success,
        "failures": sample - s_success,
        "success_rate": display(D(s_success) / D(sample)),
        "cost_per_success_units": display(s_cost_per_success),
        "p95_seconds": display(s_p95),
        "p95_feasible": s_p95 <= p95_limit,
    },
    "V": {
        "total_spend_units": display(v_spend),
        "successes": v_success,
        "failures": sample - v_success,
        "success_rate": display(D(v_success) / D(sample)),
        "cost_per_success_units": display(v_cost_per_success),
        "p95_seconds": display(v_p95),
        "p95_feasible": v_p95 <= p95_limit,
    },
    "success_gain_percentage_points": display(D(v_success - s_success) / D(sample) * 100),
    "spend_increase_percent": display((v_spend / s_spend - 1) * 100),
    "cost_per_success_increase_percent": display((v_cost_per_success / s_cost_per_success - 1) * 100),
    "extra_spend_per_net_additional_success": display((v_spend - s_spend) / D(v_success - s_success)),
    "V_p95_excess_seconds": display(v_p95 - p95_limit),
    "V_p95_ratio_to_S": display(v_p95 / s_p95),
    "incremental_cost_alternative": {
        "assumption": "If V costs 30 additional units on top of S's 20",
        "V_total_spend_units": display(s_spend + v_spend),
        "V_cost_per_success_units": display((s_spend + v_spend) / D(v_success)),
        "extra_spend_per_net_additional_success": display(v_spend / D(v_success - s_success)),
        "decision": "Reject: p95 remains 8 seconds and violates the 5-second ceiling",
    },
    "decision": "Keep S as measured baseline pending a defined quality floor; reject V under required p95",
    "routing_ablations_executed": False,
}
print(json.dumps(result, indent=2))
