"""Compute supplied cohort arithmetic only; no model or routing experiment executes."""
from decimal import Decimal, localcontext
from fractions import Fraction
import json
from pathlib import Path


def decimal_string(value):
    with localcontext() as context:
        context.prec = 28
        return str(Decimal(value.numerator) / Decimal(value.denominator))


supplied = {
    "S": {"cohort_total_cost": 20, "verified_successes": 80, "tasks": 100, "p95_seconds": 4},
    "S_plus_V": {"cohort_total_cost": 30, "verified_successes": 82, "tasks": 100, "p95_seconds": 8},
}
target = 5
metrics = {}
for name, values in supplied.items():
    ratio = Fraction(values["cohort_total_cost"], values["verified_successes"])
    metrics[name] = {**values,
                     "cost_per_verified_success": decimal_string(ratio),
                     "cost_per_verified_success_exact": str(ratio),
                     "success_rate": decimal_string(Fraction(values["verified_successes"], values["tasks"])),
                     "passes_supplied_p95_gate": values["p95_seconds"] <= target}

s_ratio = Fraction(20, 80)
v_ratio = Fraction(30, 82)
assert s_ratio == Fraction(1, 4)
assert v_ratio == Fraction(15, 41)
assert metrics["S"]["passes_supplied_p95_gate"] is True
assert metrics["S_plus_V"]["passes_supplied_p95_gate"] is False
result = {
    "provenance": "Arithmetic from prompt-supplied cohort data, not an independently executed model benchmark",
    "cost_interpretation": "20 and 30 are total costs for their respective 100-task cohorts",
    "required_p95_seconds": target,
    "variants": metrics,
    "cost_per_success_relative_increase_percent": decimal_string((v_ratio / s_ratio - 1) * 100),
    "total_cost_relative_increase_percent": "50",
    "success_rate_gain_percentage_points": "2",
    "p95_relative_increase_percent": "100",
    "verifier_p95_exceeds_target_seconds": 3,
    "incremental_cost_per_additional_observed_success": "5",
    "incremental_metric_limit": "Cohort differences do not identify paired corrections, regressions or causality",
    "decision": "Retain S as reference candidate; reject added V in its supplied configuration",
    "model_experiments_executed": False,
}
output = Path(__file__).parent
(output / "arithmetic-results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
