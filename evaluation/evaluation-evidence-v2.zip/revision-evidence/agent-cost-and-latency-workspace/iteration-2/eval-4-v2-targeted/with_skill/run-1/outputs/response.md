Retain **S as the reference candidate** and reject **added verifier V in its supplied configuration**. S meets the p95 ceiling: 4 seconds versus 5 seconds. V raises p95 to 8 seconds and fails the gate. The competition's model count does not justify four models. Without role evaluations, added calls and assignments lack demonstrated value.

Treating the supplied costs as totals for each 100-task cohort gives:

| Variant | Total cost | Verified successes | Cost per success | Success rate | p95 | Latency gate |
|---|---:|---:|---:|---:|---:|---|
| S | 20 | 80/100 | 0.25 | 80% | 4 s | Pass |
| S + V | 30 | 82/100 | 30/82 ≈ 0.36585 | 82% | 8 s | Fail |

V costs 50% more overall and approximately 46.34% more per verified success, while observed success rises by two percentage points. The cohort difference is ten additional cost units for two additional observed successes, or five units each. That ratio does not establish causal recoveries: paired results could reveal corrections and new errors. There is no basis to claim significance or acceptable receipt quality. Retain S pending explicit quality floors.

Assign exact total arithmetic and mechanical verification to deterministic code. Use decimal or integer currency arithmetic, explicit receipt-specific rounding rules, and checks for quantities, discounts, tax and signed adjustments. Validate normalization and currency before calculating. Malformed or ambiguous inputs should produce a supported unresolved result, rather than a guessed amount. Arithmetic correctness is distinct from correctly reading what the receipt means.

Receipt interpretation belongs to a model when it requires visual interpretation or semantic extraction. Evaluate it on field accuracy, missing lines, decimal signs, currency, discounts and evidence locations. A single evaluated model can own this role and explanation. Explanation should use the validated facts and computed total, with evidence references; it should not recalculate or invent adjustments. Ambiguous contradiction review belongs to a reasoning role only when deterministic checks cannot resolve the ambiguity. Route such cases using calibrated signals, and permit abstention when the receipt remains unresolved.

No specific provider or model is selected. Use anonymous candidates and compare their measured role capability. A separate verifier must demonstrate incremental whole-task value after deterministic checks; V's current numbers do not support retaining it.

The following are proposed experiments, not executed results:

| Ablation | Matched comparison | What it resolves |
|---|---|---|
| Ownership | Current four-model arrangement versus one model for interpretation/explanation plus deterministic arithmetic | Whether specialization earns its coordination overhead |
| Interpretation | Candidate A versus candidate B, holding prompts, evidence and downstream logic fixed | Per-role extraction quality and cost |
| Contradiction review | Off, always on, and conditional escalation on the same ambiguous cases | Incremental review benefit and routing calibration |
| Explanation | Shared model versus a separate model versus evidence-bound templates | Groundedness, omissions and added-call value |
| Verification | Deterministic checks alone versus semantic verifier on/off and calibrated conditional use | Corrections, verifier-induced errors and completion tails |
| Retry routing | Direct capable candidate versus cheaper-first with bounded fallback | End-to-end economics including failed first attempts |

Freeze a representative held-out set with receipts, exact totals, evidence, ambiguity labels and predefined success/abstention criteria. Stratify clean, noisy, contradictory and difficult cases. Change one variable at a time; evaluate both role errors and the assembled task. Preserve comparable load, cache state, versions and retry policy. Repeat noisy timing measurements. Include coordination, queueing, all failed attempts, retries, escalations and verification in the cost ledger and completion latency.

For every route, report successes and failures over all eligible tasks, abstention mix, total attributable spend divided by verified successes, and all-terminal p95 to verified completion. Record success-only latency separately with its denominator. Bound calls, attempts, deadline and shared spend in software. Retain an ablation only when predefined quality and safety floors hold and p95 remains at most five seconds. The saved Python script executed only the supplied arithmetic; none of these model experiments has run.

```python
# Measurement definition for the proposed ablations, not an executed experiment:
cost_per_success = all_attempt_cost / independently_verified_successes
# Undefined if independently_verified_successes == 0.
```

Executed arithmetic: [arithmetic-results.json](/~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-cost-and-latency-workspace/iteration-2/eval-4-v2-targeted/with_skill/run-1/outputs/arithmetic-results.json). Reproducible code: [arithmetic.py](/~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-cost-and-latency-workspace/iteration-2/eval-4-v2-targeted/with_skill/run-1/outputs/arithmetic.py).
