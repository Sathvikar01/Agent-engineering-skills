"""Deterministic local fake workload. Fees and durations are synthetic, not provider data."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, replace
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import sqlite3
import threading
import unittest


D = Decimal


class BudgetDenied(Exception):
    pass


class Ledger:
    """SQLite transactions reserve run-wide capacity; pending capacity survives restart."""
    def __init__(self, path: Path, cap: str = "250", task_cap: str = "10"):
        self.path = path
        with self.connection() as con:
            con.executescript("""
                CREATE TABLE IF NOT EXISTS limits (id INTEGER PRIMARY KEY, cap TEXT, task_cap TEXT);
                CREATE TABLE IF NOT EXISTS tasks
                  (id TEXT PRIMARY KEY, reserved TEXT, remaining TEXT, spent TEXT, status TEXT);
                CREATE TABLE IF NOT EXISTS charges
                  (attempt_id TEXT PRIMARY KEY, task_id TEXT, op TEXT, cost TEXT,
                   duration INTEGER, outcome TEXT);
                CREATE TABLE IF NOT EXISTS actions
                  (task_id TEXT, op TEXT, sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                   UNIQUE(task_id, op));
                CREATE TABLE IF NOT EXISTS stats (id INTEGER PRIMARY KEY, peak TEXT);
            """)
            con.execute("INSERT OR IGNORE INTO limits VALUES (1, ?, ?)", (cap, task_cap))
            con.execute("INSERT OR IGNORE INTO stats VALUES (1, '0')")
            stored = con.execute("SELECT cap, task_cap FROM limits WHERE id=1").fetchone()
            if tuple(map(D, stored)) != (D(cap), D(task_cap)):
                raise ValueError("Existing ledger limits cannot be reset on restart")
        self.cap, self.task_cap = D(cap), D(task_cap)

    def connection(self):
        con = sqlite3.connect(self.path, timeout=30)
        con.execute("PRAGMA busy_timeout=30000")
        return con

    @staticmethod
    def totals_in(con):
        rows = con.execute("SELECT spent, remaining, status FROM tasks").fetchall()
        spent = sum((D(row[0]) for row in rows), D(0))
        pending = sum((D(row[1]) for row in rows if row[2] == "active"), D(0))
        return spent, pending

    def reserve(self, task_id: str, amount: str = "10"):
        amount = D(amount)
        with self.connection() as con:
            con.execute("BEGIN IMMEDIATE")
            if con.execute("SELECT id FROM tasks WHERE id=?", (task_id,)).fetchone():
                raise BudgetDenied("Task already exists; resume it without re-admission")
            spent, pending = self.totals_in(con)
            if amount <= 0 or amount > self.task_cap or spent + pending + amount > self.cap:
                raise BudgetDenied("Aggregate or per-task admission limit")
            con.execute("INSERT INTO tasks VALUES (?, ?, ?, '0', 'active')",
                        (task_id, str(amount), str(amount)))
            current = spent + pending + amount
            peak = D(con.execute("SELECT peak FROM stats WHERE id=1").fetchone()[0])
            con.execute("UPDATE stats SET peak=? WHERE id=1", (str(max(peak, current)),))

    def charge(self, task_id, attempt_id, op, cost, duration, outcome):
        cost = D(cost)
        with self.connection() as con:
            con.execute("BEGIN IMMEDIATE")
            row = con.execute("SELECT remaining, spent, status FROM tasks WHERE id=?",
                              (task_id,)).fetchone()
            if row is None or row[2] != "active" or cost <= 0 or cost > D(row[0]):
                raise BudgetDenied("No active capacity for attempt")
            con.execute("INSERT INTO charges VALUES (?, ?, ?, ?, ?, ?)",
                        (attempt_id, task_id, op, str(cost), duration, outcome))
            con.execute("UPDATE tasks SET remaining=?, spent=? WHERE id=?",
                        (str(D(row[0]) - cost), str(D(row[1]) + cost), task_id))

    def finish(self, task_id, status):
        if status not in ("success", "unsuccessful"):
            raise ValueError("Must record an explicit terminal outcome")
        with self.connection() as con:
            con.execute("BEGIN IMMEDIATE")
            changed = con.execute("UPDATE tasks SET remaining='0', status=? "
                                  "WHERE id=? AND status='active'", (status, task_id)).rowcount
            if changed != 1:
                raise ValueError("Unknown or already terminal task")

    def actions(self, task_id):
        with self.connection() as con:
            return [row[0] for row in con.execute(
                "SELECT op FROM actions WHERE task_id=? ORDER BY sequence", (task_id,))]

    def add_action(self, task_id, op):
        with self.connection() as con:
            con.execute("INSERT INTO actions(task_id, op) VALUES (?, ?)", (task_id, op))

    def snapshot(self):
        with self.connection() as con:
            spent, pending = self.totals_in(con)
            return {"spent": str(spent), "pending": str(pending),
                    "allocated": str(spent + pending),
                    "peak_allocated": con.execute("SELECT peak FROM stats WHERE id=1").fetchone()[0],
                    "charge_count": con.execute("SELECT count(*) FROM charges").fetchone()[0],
                    "task_count": con.execute("SELECT count(*) FROM tasks").fetchone()[0]}


@dataclass(frozen=True)
class Scope:
    tenant: str = "tenant-1"
    principal: str = "user-1"
    access_version: str = "acl-1"
    input_hash: str = "input-1"
    model_version: str = "fake-model-1"
    prompt_version: str = "prompt-1"
    schema_version: str = "schema-1"
    tool_version: str = "tool-1"
    index_version: str = "index-1"
    data_version: str = "immutable-snapshot-1"
    freshness_requirement: str = "max-age-100"


@dataclass(frozen=True)
class ImmutableRead:
    data: str


class Authority:
    """Current fake authority, separate from reusable read data."""
    def __init__(self):
        self.lock = threading.RLock()
        self.read_allowed = True
        self.mutation_allowed = True
        self.access_version = "acl-1"

    def permits_read(self, scope):
        return self.read_allowed and scope.access_version == self.access_version

    def permits_mutation(self, scope):
        return self.mutation_allowed and scope.access_version == self.access_version


class Cache:
    def __init__(self):
        self.records = {}
        self.lock = threading.RLock()

    def put(self, scope, value, freshness_now=0, ttl=100):
        if not isinstance(value, ImmutableRead):
            raise TypeError("Cache accepts immutable read data only")
        if ttl <= 0:
            raise ValueError("Nonpositive TTL")
        with self.lock:
            self.records[scope] = (value, freshness_now + ttl)

    def get(self, scope, authority, freshness_now=0):
        # A cache key is isolation, not permission. Check current access on every hit.
        with authority.lock, self.lock:
            if not authority.permits_read(scope):
                raise PermissionError("Current read permission denied")
            entry = self.records.get(scope)
            if entry is None or freshness_now >= entry[1]:
                return None
            return entry[0]


class FakeTask:
    def __init__(self, task_id, ledger, authority, scope):
        self.id, self.ledger, self.authority, self.scope = task_id, ledger, authority, scope
        with ledger.connection() as con:
            durations = con.execute("SELECT duration FROM charges WHERE task_id=?", (task_id,)).fetchall()
        self.clock = sum(row[0] for row in durations)
        self.attempt = len(durations)
        self.lock = threading.RLock()

    def attempt_call(self, op, cost, duration, outcome):
        self.attempt += 1
        self.ledger.charge(self.id, f"{self.id}:{self.attempt}", op, cost, duration, outcome)
        self.clock += duration

    def mutate(self, op, permanent_failure=False):
        # The local fake state changes only after current permission and dependency checks.
        with self.lock, self.authority.lock:
            if not self.authority.permits_mutation(self.scope):
                raise PermissionError("Current mutation permission denied")
            actions = self.ledger.actions(self.id)
            if op == "B" and actions != ["A"]:
                raise ValueError("B requires successful A on the same logical task")
            if op not in ("A", "B") or op in actions or (op == "A" and actions):
                raise ValueError("Invalid action order or duplicate")
            cost, duration = ("2", 20) if op == "A" else ("3", 30)
            self.attempt_call(op, cost, duration,
                              "permanent_failure" if permanent_failure else "success")
            if permanent_failure:
                return "success claimed by a model, but no authoritative action exists"
            self.ledger.add_action(self.id, op)
            return "success"

    def verify(self):
        self.attempt_call("verify", "0.2", 5, "checked")
        return self.ledger.actions(self.id) == ["A", "B"]


FIXTURES = ("cold_success", "warm_success", "retry_success", "permanent_failure")


def nearest_rank(values, percentile=0.95):
    if not values:
        return None
    return sorted(values)[math.ceil(len(values) * percentile) - 1]


def execute_task(task_id, fixture, ledger, cache):
    # Reserve the entire per-task cap, exceeding the worst eligible path cost of 7.2.
    ledger.reserve(task_id, "10")
    authority = Authority()
    scope = replace(Scope(), input_hash=hashlib.sha256(task_id.encode()).hexdigest())
    task = FakeTask(task_id, ledger, authority, scope)
    if fixture == "warm_success":
        # Fixture seed: no creation charge was supplied. This is not a modeled free fill.
        cache.put(scope, ImmutableRead("immutable fixture data"))
    hit = cache.get(scope, authority)
    if hit is not None:
        task.attempt_call("warm_read", "0.1", 2, "success")
    else:
        if fixture == "retry_success":
            task.attempt_call("cold_read", "1", 10, "transient_failure")
            # Exactly one eligible retry; failed calls consume time and spend.
        task.attempt_call("cold_read", "1", 10, "success")
        cache.put(scope, ImmutableRead("immutable fixture data"))
    task.mutate("A", permanent_failure=fixture == "permanent_failure")
    # The success claim is ignored. Only observed local fake authority admits B.
    if ledger.actions(task.id) == ["A"]:
        task.mutate("B")
    verified = task.verify()
    ledger.finish(task_id, "success" if verified else "unsuccessful")
    with ledger.connection() as con:
        cost = con.execute("SELECT spent FROM tasks WHERE id=?", (task_id,)).fetchone()[0]
    return {"task_id": task_id, "fixture": fixture, "verified_success": verified,
            "cost": cost, "logical_completion_ms": task.clock, "attempts": task.attempt}


class Acceptance(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = TEST_ROOT

    def ledger(self, name, cap="250"):
        path = self.root / f"{name}.sqlite"
        if path.exists():
            raise RuntimeError("Acceptance artifacts already exist; use a fresh output directory")
        return Ledger(path, cap)

    def test_cache_tenant_principal_access_input_versions_and_freshness(self):
        cache, authority, scope = Cache(), Authority(), Scope()
        cache.put(scope, ImmutableRead("private immutable data"), ttl=100)
        self.assertEqual(cache.get(scope, authority).data, "private immutable data")
        fields = ("tenant", "principal", "access_version", "input_hash", "model_version",
                  "prompt_version", "schema_version", "tool_version", "index_version",
                  "data_version", "freshness_requirement")
        for field in fields:
            with self.subTest(field=field):
                other = replace(scope, **{field: "different"})
                if field == "access_version":
                    with self.assertRaises(PermissionError):
                        cache.get(other, authority)
                else:
                    self.assertIsNone(cache.get(other, authority))
        self.assertIsNone(cache.get(scope, authority, freshness_now=100))
        authority.read_allowed = False
        with self.assertRaises(PermissionError):
            cache.get(scope, authority)
        with self.assertRaises(TypeError):
            cache.put(scope, {"approval": True})

    def test_cached_data_never_grants_permission_and_denial_has_no_mutation(self):
        ledger = self.ledger("permission")
        ledger.reserve("permission-task")
        authority, scope, cache = Authority(), Scope(), Cache()
        cache.put(scope, ImmutableRead("read data only"))
        self.assertIsNotNone(cache.get(scope, authority))
        authority.mutation_allowed = False
        task = FakeTask("permission-task", ledger, authority, scope)
        for action in ("A", "B"):
            with self.assertRaises(PermissionError):
                task.mutate(action)
        self.assertEqual(ledger.actions(task.id), [])
        self.assertEqual(ledger.snapshot()["spent"], "0")
        self.assertEqual(task.clock, 0)

    def test_b_before_a_rejected_and_permission_rechecked_before_b(self):
        ledger = self.ledger("ordered")
        ledger.reserve("ordered-task")
        authority = Authority()
        task = FakeTask("ordered-task", ledger, authority, Scope())
        with self.assertRaises(ValueError):
            task.mutate("B")
        self.assertEqual(ledger.actions(task.id), [])
        task.mutate("A")
        authority.mutation_allowed = False
        with self.assertRaises(PermissionError):
            task.mutate("B")
        self.assertEqual(ledger.actions(task.id), ["A"])
        authority.mutation_allowed = True
        task.mutate("B")
        self.assertTrue(task.verify())
        self.assertEqual(ledger.actions(task.id), ["A", "B"])

    def test_aggregate_budget_contention_and_per_task_cap(self):
        ledger = self.ledger("contention", "25")
        barrier = threading.Barrier(8)

        def contender(number):
            barrier.wait()
            try:
                ledger.reserve(f"worker-{number}", "10")
                return True
            except BudgetDenied:
                return False

        with ThreadPoolExecutor(max_workers=8) as pool:
            admitted = list(pool.map(contender, range(8)))
        self.assertEqual(sum(admitted), 2)
        self.assertEqual(D(ledger.snapshot()["allocated"]), D("20"))
        with self.assertRaises(BudgetDenied):
            ledger.reserve("oversized", "11")
        accepted_id = f"worker-{admitted.index(True)}"
        with self.assertRaises(BudgetDenied):
            ledger.charge(accepted_id, "overcharge", "read", "11", 10, "failure")

    def test_restart_preserves_spent_pending_and_limits(self):
        ledger = self.ledger("restart", "20")
        ledger.reserve("A", "10")
        ledger.reserve("B", "10")
        ledger.charge("A", "A:1", "read", "2", 10, "failure")
        ledger.charge("B", "B:1", "read", "3", 10, "success")
        del ledger
        resumed = Ledger(self.root / "restart.sqlite", "20")
        self.assertEqual(D(resumed.snapshot()["spent"]), D("5"))
        self.assertEqual(D(resumed.snapshot()["pending"]), D("15"))
        with self.assertRaises(BudgetDenied):
            resumed.reserve("new", "1")
        with self.assertRaises(BudgetDenied):
            resumed.reserve("A", "10")
        with self.assertRaises(ValueError):
            Ledger(self.root / "restart.sqlite", "250")
        resumed_task = FakeTask("A", resumed, Authority(), Scope())
        self.assertEqual(resumed_task.clock, 10)
        self.assertEqual(resumed_task.attempt, 1)
        resumed_task.attempt_call("retry", "3", 10, "success")
        self.assertEqual(resumed_task.clock, 20)
        with self.assertRaises(sqlite3.IntegrityError):
            resumed.charge("A", "A:2", "retry", "3", 10, "success")
        self.assertEqual(D(resumed.snapshot()["allocated"]), D("20"))
        resumed.finish("A", "unsuccessful")
        resumed.reserve("C", "5")
        self.assertEqual(D(resumed.snapshot()["spent"]), D("8"))
        self.assertEqual(D(resumed.snapshot()["pending"]), D("12"))

    def test_permanent_failure_is_charged_not_retried_or_trusted(self):
        ledger = self.ledger("permanent")
        result = execute_task("permanent-test", "permanent_failure", ledger, Cache())
        self.assertFalse(result["verified_success"])
        self.assertEqual(result["attempts"], 3)
        self.assertEqual(D(result["cost"]), D("3.2"))
        self.assertEqual(result["logical_completion_ms"], 35)
        self.assertEqual(ledger.actions(result["task_id"]), [])


def workload(output):
    path = output / "workload-ledger.sqlite"
    if path.exists():
        raise RuntimeError("Workload ledger exists; refusing to reset durable spend")
    ledger, cache = Ledger(path), Cache()
    specs = [(f"{fixture}-{number:02d}", fixture) for fixture in FIXTURES for number in range(10)]
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(lambda item: execute_task(*item, ledger, cache), specs))
    successes = [row for row in results if row["verified_success"]]
    snapshot = ledger.snapshot()
    with ledger.connection() as con:
        charges = [dict(zip(("attempt_id", "task_id", "op", "cost", "duration_ms", "outcome"), row))
                   for row in con.execute("SELECT * FROM charges ORDER BY task_id, attempt_id")]
    executed_total = sum((D(row["cost"]) for row in charges), D(0))
    assert executed_total == D(snapshot["spent"])
    assert len(results) == len({row["task_id"] for row in results}) == 40
    assert len(successes) == 30 and executed_total == D("219.0")
    assert snapshot["pending"] == "0" and D(snapshot["peak_allocated"]) <= D("250")
    assert len(charges) == 160
    metrics = {
        "measurement_kind": "Executed local fake; synthetic units and simulated logical milliseconds",
        "logical_tasks": 40, "verified_successes": len(successes), "unsuccessful_tasks": 10,
        "success_rate": len(successes) / len(results), "executed_attempts": len(charges),
        "failed_attempts": sum(row["outcome"] in ("transient_failure", "permanent_failure") for row in charges),
        "total_cost_synthetic_units": str(executed_total),
        "cost_per_verified_success_synthetic_units": str(executed_total / len(successes)) if successes else None,
        "p95_terminal_completion_ms": nearest_rank([row["logical_completion_ms"] for row in results]),
        "p95_terminal_denominator": len(results), "p95_terminal_rank": math.ceil(0.95 * len(results)),
        "success_only_p95_completion_ms": nearest_rank([row["logical_completion_ms"] for row in successes]),
        "success_only_denominator": len(successes), "success_only_rank": math.ceil(0.95 * len(successes)),
        "logical_duration_sum_ms": sum(row["duration_ms"] for row in charges),
        "ledger": snapshot,
        "fixtures": {fixture: {
            "tasks": len([row for row in results if row["fixture"] == fixture]),
            "verified_successes": sum(row["verified_success"] for row in results if row["fixture"] == fixture),
            "cost_synthetic_units": str(sum((D(row["cost"]) for row in results if row["fixture"] == fixture), D(0))),
            "completion_ms_each": [row["logical_completion_ms"] for row in results if row["fixture"] == fixture]
        } for fixture in FIXTURES}
    }
    (output / "task-results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    (output / "billing-attempts.json").write_text(json.dumps(charges, indent=2), encoding="utf-8")
    (output / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("workload", "acceptance"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if args.mode == "workload":
        workload(args.output)
    else:
        TEST_ROOT = args.output / "acceptance-ledgers"
        TEST_ROOT.mkdir(exist_ok=True)
        result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Acceptance))
        (args.output / "acceptance-results.json").write_text(json.dumps({
            "tests_run": result.testsRun, "failures": len(result.failures),
            "errors": len(result.errors), "success": result.wasSuccessful(),
            "excluded_from_workload_metrics": True
        }, indent=2), encoding="utf-8")
        raise SystemExit(0 if result.wasSuccessful() else 1)
