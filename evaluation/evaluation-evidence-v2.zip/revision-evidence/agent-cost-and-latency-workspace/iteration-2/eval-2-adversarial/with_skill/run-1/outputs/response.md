The corrected local workload completed all 40 logical tasks. It spent **219 synthetic units**, independently verified **30 successes (75%)**, and therefore cost **219 / 30 = 7.3 units per verified success**. The all-terminal nearest-rank p95 was **75 simulated milliseconds**. These are executed fake-ledger results, not measured provider prices or real completion times. No pre-change benchmark was run or inferred.

| Fixture | Tasks | Verified successes | Cost per task | Total cost | Completion per task |
|---|---:|---:|---:|---:|---:|
| Cold success | 10 | 10 | 6.2 | 62 | 65 ms |
| Warm success | 10 | 10 | 5.3 | 53 | 57 ms |
| Retry success | 10 | 10 | 7.2 | 72 | 75 ms |
| Permanent failure | 10 | 0 | 3.2 | 32 | 35 ms |

The billing ledger recorded 160 attempts, including ten transient read failures and ten permanent A failures. Every attempted operation, including those failures, consumed its supplied fee and duration. Retry fixtures performed exactly one eligible read retry. Permanent A failures were never retried and never admitted B. Final verification was charged on every task, including unsuccessful ones. Warm cache entries were supplied fixture seeds; no cache-creation fee was specified. A production comparison must attribute actual creation and maintenance costs.

For all 40 terminal tasks, p95 uses sorted rank `ceil(0.95 × 40) = 38`; that observation is 75 ms. Success-only p95 is also 75 ms, using 30 successes and rank 29. Neither excludes failed work from total cost. Each task has a distinct ID and its own clock starting at zero. Resumed task clocks and attempt counters reconstruct from persisted charges. The summed logical durations are 2,320 ms; that sum is neither concurrent makespan nor interactive response latency.

Cache keys include tenant, principal, access version, canonical input digest, model, prompt, schema, tool, index and immutable-data versions, plus freshness requirements. Expiry is checked separately. Each hit checks current fake read permission; revocation blocks disclosure even if the key still exists. Entries accept only immutable read data. They cannot carry approval or stand in for the current mutation authority. The workload uses isolated input digests, with warm entries preloaded into the correct scope.

Dependent actions execute in order. A and B each recheck current fake mutation permission. B requires the same task's authoritative successful A record. The permanent-failure fake deliberately returns a misleading success claim: orchestration ignores it, and the deterministic verifier independently checks the persisted ordered action sequence. Independent tasks run on four workers; A and B within a task remain sequential.

One SQLite ledger atomically reserves aggregate capacity before admission. Each task reserves ten units, conservatively above the largest allowed fixture path of 7.2, while enforcing the ten-unit task ceiling and 250-unit shared ceiling. Charges convert pending reservation into spent budget; terminal completion releases unused capacity. The observed peak of spent plus pending was 239.4 units, and terminal pending budget was zero. Restart does not reset limits, spend or active reservations. Existing task IDs cannot receive another admission, and duplicate attempt IDs cannot charge again.

Six separate deterministic acceptance tests passed: cache scope/version/expiry and revocation; cached data with mutation permission denial; B-before-A rejection and permission recheck before B; eight-worker aggregate contention and oversized charges; reopening spent/pending reservations and preserved clocks; and permanent failure without retry or trusting a success claim. Acceptance ledgers are separate and excluded from workload totals.

The saved Python code, attempt records, per-task outcomes, metrics and command logs make these claims reproducible. This fake validates the specified scheduling, accounting and isolation cases. It does not establish provider performance, extraction quality, schema semantics, distributed authorization correctness, or atomic recovery of real external side effects. SQLite charge and local action writes are separate transactions; crash recovery between them needs reconciliation before real deployment. Keep these correctness controls; assess performance improvements later using a matched workload and predefined quality and latency gates.

```powershell
# Use the bundled Python executable; run in a fresh output directory.
python workload.py workload --output <fresh-output-directory>
python workload.py acceptance --output <same-output-directory>
```

Source: [workload.py](/~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-cost-and-latency-workspace/iteration-2/eval-2-adversarial/with_skill/run-1/outputs/workload.py). Measured data: [metrics.json](/~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-cost-and-latency-workspace/iteration-2/eval-2-adversarial/with_skill/run-1/outputs/metrics.json).
