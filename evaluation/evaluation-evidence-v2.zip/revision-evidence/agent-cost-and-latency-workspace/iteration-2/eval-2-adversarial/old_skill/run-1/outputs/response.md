Implemented and actually ran the corrected local workload. It completed 40 distinct logical tasks across four worker threads, with 30 independently verified successes. The executed billing ledger recorded **219 synthetic units**, yielding **7.3 units per verified success**. Nearest-rank p95 completion latency was **75 simulated milliseconds** across all 40 terminal tasks. These are deliberately simulated charges and logical clocks; they do not describe provider pricing or real provider performance.

The optimization keeps only immutable read data in the cache. Its key covers tenant, principal, access scope and permission version, canonical input, model, prompt, schema, tool, index and immutable data versions, and the freshness requirement. Entries expire at their stated TTL. Current fake read permission is checked even for a matching warm entry, so revocation prevents disclosure. The cache accepts an immutable read-value type and rejects an approval dictionary. It never supplies mutation permission or substitutes for the current authoritative mutation state. Each cold fixture uses a distinct input; each warm fixture receives its own scoped preload. No preload creation charge was supplied, so the measurement includes only the specified warm-hit charge.

Mutation A and mutation B execute in order. Each checks current fake mutation permission inside the transaction that records its charge and effect. B additionally rejects execution unless A succeeded. A permanent failure is charged once and prevents B; it receives no retry. Only the prescribed transient read failure receives one eligible retry, and both read attempts advance the task clock and incur their charges. The deterministic verifier reads stored A/B state and ordered successful events. It ignores the deliberately unreliable `model_claimed_success` field, which claims success even for permanently failed tasks.

The shared SQLite ledger stores the run ceiling, per-task ceiling, task identity, accumulated spend, pending reservations, and attempt events. Admission reserves the full 10-unit task ceiling conservatively. A serialized transaction accepts a reservation only when aggregate spent plus all pending reservations plus the new reservation fits within 250 units. Billing converts pending reservation into spent units atomically. Terminal tasks explicitly release unused reservation. Reopening the ledger preserves both spent and pending amounts, rejects a silent ceiling change, and does not let a new worker reset the budget. A duplicate task identifier also cannot create another admission row.

| Fixture | Tasks | Cost per task | Logical time per task | Verified successes |
|---|---:|---:|---:|---:|
| Cold success | 10 | 6.2 | 65 ms | 10 |
| Warm success | 10 | 5.3 | 57 ms | 10 |
| Retry success | 10 | 7.2 | 75 ms | 10 |
| Permanent failure | 10 | 3.2 | 35 ms | 0 |

The ledger contains 160 billed events: 40 cold-read attempts, 10 warm hits, 40 A attempts, 30 B attempts, and 40 verifications. Total spend includes all failed tasks and the 10 failed read attempts. Success rate is 30/40, or 75%. The all-terminal p95 selects sorted rank `ceil(0.95 × 40) = 38`. If success-only latency is useful, its p95 is also 75 ms, with denominator 30 and rank 29; it does not replace the all-terminal measure. Final pending reservation is zero, leaving 31 units unspent.

Six separate deterministic acceptance tests passed: cache isolation across every key dimension and expiry; denied current permissions with no mutation; B-before-A rejection and revocation between A/B; simultaneous aggregate reservation contention and the task ceiling; preserved spent/pending reservations after reopen; and retry/permanent-failure billing. Their separate databases never contribute to workload totals. The actual command log, JSON measurements, per-task records, and durable databases are saved alongside the runnable Python implementation.

Limitations: the local atomic fake does not validate real authorization systems, distributed provider billing, crash recovery around external effects, schema correctness, or semantic receipt quality. Logical latency excludes real queueing, network delay, and database execution time. No pre-change benchmark was run or inferred, so this establishes corrected behavior and its supplied-fixture economics rather than a measured improvement over an earlier system.

Run the supplied code against a fresh output subdirectory:

```powershell
python .\fake_workload.py --output-dir .\execution-new
```
