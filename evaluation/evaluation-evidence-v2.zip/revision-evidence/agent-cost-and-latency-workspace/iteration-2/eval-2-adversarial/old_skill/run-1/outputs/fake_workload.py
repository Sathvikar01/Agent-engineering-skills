"""Local fake only: synthetic billing units and simulated task milliseconds.

Run: python fake_workload.py --output-dir PATH
No network, models, external effects, or modifications outside --output-dir.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, replace
import json
import math
from pathlib import Path
import sqlite3
import threading
import unittest


class Denied(Exception):
    pass


class DependencyError(Exception):
    pass


class BudgetError(Exception):
    pass


class TransientReadError(Exception):
    pass


class Ledger:
    """One durable ledger; BEGIN IMMEDIATE serializes all budget admissions.

    Money uses integer milliunits. An admitted task's pending reservation
    decreases when charged and is released only on explicit terminal finish.
    Reopening does not release pending reservations or reset spent amounts.
    """
    def __init__(self, path: Path, cap: int = 250_000, task_cap: int = 10_000):
        self.path = path
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS config (
                    id INTEGER PRIMARY KEY CHECK(id=1), cap INTEGER,
                    task_cap INTEGER, spent INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS tasks (
                    task_id TEXT PRIMARY KEY, worker TEXT, spent INTEGER,
                    pending INTEGER, status TEXT);
                CREATE TABLE IF NOT EXISTS state (
                    task_id TEXT PRIMARY KEY, read_allowed INTEGER,
                    mutate_allowed INTEGER, a_ok INTEGER, b_ok INTEGER);
                CREATE TABLE IF NOT EXISTS events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    task_id TEXT, worker TEXT, operation TEXT,
                    outcome TEXT, charge INTEGER, duration INTEGER);
            """)
            db.execute("INSERT OR IGNORE INTO config VALUES (1,?,?,0)",
                       (cap, task_cap))
            actual = db.execute("SELECT cap,task_cap FROM config").fetchone()
            if actual != (cap, task_cap):
                raise ValueError("Persisted ceilings cannot silently change")

    def connect(self):
        db = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        db.execute("PRAGMA busy_timeout=30000")
        return db

    def admit(self, task_id: str, worker: str, reservation: int = 10_000):
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            cap, task_cap, spent = db.execute(
                "SELECT cap,task_cap,spent FROM config").fetchone()
            pending = db.execute(
                "SELECT COALESCE(SUM(pending),0) FROM tasks").fetchone()[0]
            if reservation <= 0 or reservation > task_cap:
                raise BudgetError("Reservation violates per-task ceiling")
            if spent + pending + reservation > cap:
                raise BudgetError("Shared spent plus pending exceeds run cap")
            db.execute("INSERT INTO tasks VALUES (?,?,0,?,'active')",
                       (task_id, worker, reservation))
            db.execute("INSERT INTO state VALUES (?,1,1,0,0)", (task_id,))
            db.commit()

    def set_permissions(self, task_id, *, read_allowed=None, mutate_allowed=None):
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            if read_allowed is not None:
                db.execute("UPDATE state SET read_allowed=? WHERE task_id=?",
                           (int(read_allowed), task_id))
            if mutate_allowed is not None:
                db.execute("UPDATE state SET mutate_allowed=? WHERE task_id=?",
                           (int(mutate_allowed), task_id))
            db.commit()

    def may_read(self, task_id):
        with self.connect() as db:
            row = db.execute("SELECT read_allowed FROM state WHERE task_id=?",
                             (task_id,)).fetchone()
            return row is not None and bool(row[0])

    def _charge(self, db, task_id, operation, outcome, charge, duration):
        worker, spent, pending, status = db.execute(
            "SELECT worker,spent,pending,status FROM tasks WHERE task_id=?",
            (task_id,)).fetchone()
        cap, task_cap, total = db.execute(
            "SELECT cap,task_cap,spent FROM config").fetchone()
        if (status != "active" or charge < 0 or pending < charge
                or spent + charge > task_cap or total + charge > cap):
            raise BudgetError("Attempt not covered by active reservation")
        db.execute("UPDATE tasks SET spent=spent+?,pending=pending-? WHERE task_id=?",
                   (charge, charge, task_id))
        db.execute("UPDATE config SET spent=spent+? WHERE id=1", (charge,))
        db.execute("INSERT INTO events(task_id,worker,operation,outcome,charge,duration) "
                   "VALUES (?,?,?,?,?,?)",
                   (task_id, worker, operation, outcome, charge, duration))

    def bill(self, task_id, operation, outcome, charge, duration):
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            self._charge(db, task_id, operation, outcome, charge, duration)
            db.commit()

    def mutate(self, task_id, operation, permanent_failure=False):
        """Check live permission and dependency in the same fake transaction.

        This atomically models an attempt's charge and state effect. Rejected
        permission/dependency checks do not execute or bill a fake attempt.
        """
        if operation not in ("A", "B"):
            raise ValueError(operation)
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            _, allowed, a_ok, _ = db.execute(
                "SELECT * FROM state WHERE task_id=?", (task_id,)).fetchone()[1:]
            if not allowed:
                raise Denied("Current fake mutation permission denied")
            if operation == "B" and not a_ok:
                raise DependencyError("B requires a successful A")
            outcome = "permanent_failure" if permanent_failure else "success"
            charge, duration = (2000, 20) if operation == "A" else (3000, 30)
            self._charge(db, task_id, operation, outcome, charge, duration)
            if not permanent_failure:
                column = "a_ok" if operation == "A" else "b_ok"
                db.execute(f"UPDATE state SET {column}=1 WHERE task_id=?", (task_id,))
            db.commit()
        return not permanent_failure

    def verify(self, task_id):
        """Independent oracle reads stored state and ordered successful events."""
        with self.connect() as db:
            a_ok, b_ok = db.execute(
                "SELECT a_ok,b_ok FROM state WHERE task_id=?", (task_id,)).fetchone()
            operations = db.execute(
                "SELECT operation,outcome FROM events WHERE task_id=? "
                "AND operation IN ('A','B') ORDER BY event_id", (task_id,)).fetchall()
        actual = bool(a_ok and b_ok and operations == [("A", "success"), ("B", "success")])
        self.bill(task_id, "verify", "success" if actual else "unsuccessful", 200, 5)
        return actual

    def finish(self, task_id):
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("UPDATE tasks SET status='terminal',pending=0 WHERE task_id=?",
                       (task_id,))
            db.commit()

    def snapshot(self):
        with self.connect() as db:
            cap, task_cap, spent = db.execute(
                "SELECT cap,task_cap,spent FROM config").fetchone()
            pending = db.execute("SELECT COALESCE(SUM(pending),0) FROM tasks").fetchone()[0]
            return {"cap": cap / 1000, "task_cap": task_cap / 1000,
                    "spent": spent / 1000, "pending": pending / 1000}

    def task_events(self, task_id):
        with self.connect() as db:
            return db.execute("SELECT operation,outcome,charge,duration FROM events "
                              "WHERE task_id=? ORDER BY event_id", (task_id,)).fetchall()


@dataclass(frozen=True)
class CacheKey:
    tenant: str
    principal: str
    access_scope: str
    permission_version: str
    canonical_input: str
    model_version: str
    prompt_version: str
    schema_version: str
    tool_version: str
    index_version: str
    data_version: str
    freshness_requirement: str


@dataclass(frozen=True)
class ImmutableRead:
    document_id: str
    value: str


class ReadCache:
    """Only immutable read values; no approvals or mutation-state snapshots."""
    def __init__(self):
        self.entries = {}
        self.lock = threading.Lock()

    def put(self, key, value, expires_ms):
        if not isinstance(value, ImmutableRead):
            raise TypeError("Only immutable read data may be cached")
        with self.lock:
            self.entries[key] = (value, expires_ms)

    def get(self, key, now_ms, currently_authorized):
        if not currently_authorized:
            raise Denied("Current read permission denied, including cached reads")
        with self.lock:
            item = self.entries.get(key)
        if item is None or now_ms >= item[1]:
            return None
        return item[0]


def cache_key(document_id):
    return CacheKey("tenant-one", "principal-one", "receipt-read", "access-v1",
                    json.dumps({"document_id": document_id}, sort_keys=True),
                    "fake-model-v1", "prompt-v1", "schema-v1", "read-tool-v1",
                    "index-v1", "immutable-data-v1", "ttl-1000ms")


def logical_clock(ledger, task_id):
    # Each task starts at zero; failed and successful attempts both advance it.
    return sum(event[3] for event in ledger.task_events(task_id))


def fake_read(ledger, cache, task_id, key, fail_transient=False):
    value = cache.get(key, logical_clock(ledger, task_id), ledger.may_read(task_id))
    if value is not None:
        ledger.bill(task_id, "read_warm", "success", 100, 2)
        return value
    ledger.bill(task_id, "read_cold", "transient_failure" if fail_transient else "success",
                1000, 10)
    if fail_transient:
        raise TransientReadError("One prescribed transient failed read")
    value = ImmutableRead(task_id, "fixed immutable receipt")
    cache.put(key, value, expires_ms=1000)
    return value


def run_task(ledger, cache, task_id, fixture, worker):
    ledger.admit(task_id, worker, 10_000)
    key = cache_key(task_id)  # Distinct cold input and task ID for each fixture.
    if fixture == "warm-success":
        cache.put(key, ImmutableRead(task_id, "fixed immutable receipt"), 1000)
    retries = 0
    while True:
        try:
            fake_read(ledger, cache, task_id, key,
                      fail_transient=(fixture == "retry-success" and retries == 0))
            break
        except TransientReadError:
            if retries >= 1:
                raise
            retries += 1  # Only this transient read is eligible; exactly one retry.
    a_ok = ledger.mutate(task_id, "A", permanent_failure=(fixture == "permanent-failure"))
    if a_ok:
        ledger.mutate(task_id, "B")
    model_claimed_success = True  # Deliberately unreliable; oracle never consumes it.
    verified = ledger.verify(task_id)
    events = ledger.task_events(task_id)
    result = {"task_id": task_id, "fixture": fixture, "worker": worker,
              "model_claimed_success": model_claimed_success,
              "verified_success": verified, "eligible_retries": retries,
              "cost_units": sum(e[2] for e in events) / 1000,
              "logical_completion_ms": sum(e[3] for e in events)}
    ledger.finish(task_id)
    return result


def nearest_rank(values, percentile):
    if not values:
        return None
    return sorted(values)[math.ceil(percentile * len(values)) - 1]


class AcceptanceTests(unittest.TestCase):
    output_dir = None

    def new_ledger(self, name, cap=10_000, task_cap=10_000):
        return Ledger(self.output_dir / f"acceptance_{name}.sqlite3", cap, task_cap)

    def test_cache_isolation_access_versions_and_freshness(self):
        cache, key = ReadCache(), cache_key("receipt-1")
        value = ImmutableRead("receipt-1", "private receipt")
        cache.put(key, value, 50)
        self.assertEqual(cache.get(key, 49, True), value)
        for field in CacheKey.__dataclass_fields__:
            with self.subTest(key_dimension=field):
                changed = replace(key, **{field: getattr(key, field) + "-changed"})
                self.assertIsNone(cache.get(changed, 0, True))
        self.assertIsNone(cache.get(key, 50, True))
        with self.assertRaises(Denied):
            cache.get(key, 0, False)
        with self.assertRaises(TypeError):
            cache.put(key, {"approved": True}, 100)

    def test_current_permission_denial_executes_no_mutation(self):
        ledger = self.new_ledger("permission")
        ledger.admit("denied-task", "worker-1")
        cache, key = ReadCache(), cache_key("denied-task")
        cache.put(key, ImmutableRead("denied-task", "cached data"), 100)
        ledger.set_permissions("denied-task", read_allowed=False, mutate_allowed=False)
        with self.assertRaises(Denied):
            fake_read(ledger, cache, "denied-task", key)
        with self.assertRaises(Denied):
            ledger.mutate("denied-task", "A")
        with self.assertRaises(Denied):
            ledger.mutate("denied-task", "B")
        self.assertEqual(ledger.task_events("denied-task"), [])
        self.assertFalse(ledger.verify("denied-task"))

    def test_b_before_a_and_revocation_between_mutations(self):
        ledger = self.new_ledger("dependency")
        ledger.admit("ordered", "worker-1")
        with self.assertRaises(DependencyError):
            ledger.mutate("ordered", "B")
        self.assertEqual(ledger.task_events("ordered"), [])
        self.assertTrue(ledger.mutate("ordered", "A"))
        ledger.set_permissions("ordered", mutate_allowed=False)
        with self.assertRaises(Denied):
            ledger.mutate("ordered", "B")
        ledger.set_permissions("ordered", mutate_allowed=True)
        self.assertTrue(ledger.mutate("ordered", "B"))
        self.assertTrue(ledger.verify("ordered"))
        self.assertEqual([e[0] for e in ledger.task_events("ordered")], ["A", "B", "verify"])

    def test_atomic_aggregate_contention_and_task_cap(self):
        ledger = self.new_ledger("contention")
        barrier = threading.Barrier(4)
        def contender(index):
            barrier.wait()
            try:
                ledger.admit(f"contender-{index}", f"worker-{index}", 7000)
                return True
            except BudgetError:
                return False
        with ThreadPoolExecutor(max_workers=4) as pool:
            admitted = list(pool.map(contender, range(4)))
        self.assertEqual(sum(admitted), 1)
        self.assertEqual(ledger.snapshot()["pending"], 7)
        with self.assertRaises(BudgetError):
            ledger.admit("over-task-limit", "new-worker", 11_000)

    def test_restart_keeps_spent_and_pending_reservations(self):
        ledger = self.new_ledger("restart", task_cap=7000)
        ledger.admit("resumed", "worker-before-restart", 6000)
        ledger.bill("resumed", "read_cold", "transient_failure", 2000, 10)
        ledger.admit("other-pending", "worker-2", 4000)
        resumed = Ledger(ledger.path, cap=10_000, task_cap=7000)
        self.assertEqual(resumed.snapshot(),
                         {"cap": 10, "task_cap": 7, "spent": 2, "pending": 8})
        with self.assertRaises(BudgetError):
            resumed.admit("new-worker-cannot-reset-cap", "worker-after-restart", 1000)
        resumed.bill("resumed", "read_cold", "success", 1000, 10)
        self.assertEqual(logical_clock(resumed, "resumed"), 20)
        self.assertEqual(resumed.snapshot()["spent"] + resumed.snapshot()["pending"], 10)
        resumed.finish("resumed")
        self.assertEqual(resumed.snapshot()["pending"], 4)
        resumed.admit("released-unused-budget", "worker-3", 3000)
        self.assertEqual(resumed.snapshot()["spent"] + resumed.snapshot()["pending"], 10)
        with self.assertRaises(ValueError):
            Ledger(ledger.path, cap=20_000, task_cap=7000)

    def test_retry_and_permanent_failure_billing(self):
        ledger = self.new_ledger("retry_policy", cap=20_000)
        retry = run_task(ledger, ReadCache(), "retry", "retry-success", "worker-1")
        permanent = run_task(ledger, ReadCache(), "permanent", "permanent-failure", "worker-2")
        self.assertEqual((retry["cost_units"], retry["logical_completion_ms"],
                          retry["eligible_retries"]), (7.2, 75, 1))
        self.assertEqual((permanent["cost_units"], permanent["logical_completion_ms"],
                          permanent["eligible_retries"], permanent["verified_success"]),
                         (3.2, 35, 0, False))
        self.assertEqual([e[0] for e in ledger.task_events("permanent")],
                         ["read_cold", "A", "verify"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    # Refuse accidental reuse so a rerun cannot silently reset/recount a ledger.
    if list(args.output_dir.glob("*.sqlite3")):
        raise SystemExit("Existing ledgers found; use a fresh output subdirectory")
    workload = Ledger(args.output_dir / "workload.sqlite3")
    cache = ReadCache()
    fixtures = ["cold-success", "warm-success", "retry-success", "permanent-failure"]
    jobs = [(f"task-{fixture}-{i:02}", fixture) for fixture in fixtures for i in range(10)]
    def execute(job):
        task_id, fixture = job
        return run_task(workload, cache, task_id, fixture, threading.current_thread().name)
    with ThreadPoolExecutor(max_workers=4, thread_name_prefix="fake-worker") as pool:
        results = list(pool.map(execute, jobs))
    successes = [r for r in results if r["verified_success"]]
    totals = workload.snapshot()
    with workload.connect() as db:
        event_totals = [{"operation": op, "attempts": count, "charge_units": charge / 1000,
                         "logical_duration_sum_ms": duration}
                        for op, count, charge, duration in db.execute(
                            "SELECT operation,COUNT(*),SUM(charge),SUM(duration) FROM events "
                            "GROUP BY operation ORDER BY operation")]
    summary = {"measurement_type": "synthetic units / deterministic simulated task milliseconds",
               "logical_tasks": len(results), "verified_successes": len(successes),
               "verified_success_rate": len(successes) / len(results),
               "total_executed_cost_units": totals["spent"],
               "cost_per_verified_success_units": totals["spent"] / len(successes) if successes else None,
               "p95_all_terminal_tasks_ms": nearest_rank([r["logical_completion_ms"] for r in results], .95),
               "p95_all_terminal_tasks_denominator": len(results),
               "p95_all_terminal_tasks_rank": math.ceil(.95 * len(results)),
               "p95_success_only_ms": nearest_rank([r["logical_completion_ms"] for r in successes], .95),
               "p95_success_only_denominator": len(successes),
               "p95_success_only_rank": math.ceil(.95 * len(successes)),
               "total_eligible_retries": sum(r["eligible_retries"] for r in results),
               "terminal_pending_units": totals["pending"], "budget": totals,
               "event_totals": event_totals}
    assert summary["logical_tasks"] == 40
    assert summary["verified_successes"] == 30
    assert totals["spent"] == 219 and totals["pending"] == 0
    assert summary["p95_all_terminal_tasks_ms"] == 75
    assert sum(x["attempts"] for x in event_totals) == 160
    (args.output_dir / "task_metrics.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    (args.output_dir / "workload_metrics.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print("WORKLOAD MEASUREMENTS")
    print(json.dumps(summary, indent=2))
    AcceptanceTests.output_dir = args.output_dir
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(AcceptanceTests)
    print("\nACCEPTANCE TESTS (separate ledgers; excluded from workload totals)", flush=True)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    acceptance = {"tests_run": result.testsRun, "failures": len(result.failures),
                  "errors": len(result.errors), "passed": result.wasSuccessful(),
                  "included_in_workload_metrics": False}
    (args.output_dir / "acceptance_results.json").write_text(json.dumps(acceptance, indent=2) + "\n", encoding="utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()
