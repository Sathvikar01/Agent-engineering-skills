# Corrected optimization and acceptance tests

Reject the current optimization. It can disclose another tenant’s response, reuse results generated under an obsolete prompt, execute a dependent action against the wrong state, and multiply the nominal spend cap across workers and restarts. These are correctness failures; a lower observed average latency cannot compensate for them.

Use a cache only for stable, reusable work. Its canonical key must include tenant, principal, effective permission fingerprint, canonical input, model, prompt, schema, tool and index versions, and the relevant freshness policy or data generation. Keep cache entries tenant-scoped, set explicit expiry, and invalidate them when relevant inputs or versions change. Recheck current authorization before returning a cached value: an old permission fingerprint must never authorize disclosure after revocation. Do not cache approval as authority or treat changing authoritative state as current merely because its TTL has not elapsed. Include cache construction, misses, reads and any provider cache charges in total cost.

Execute the mutations in dependency order. Admit the first action with its expected state version and operation identity, await its durable result, then validate the resulting state and authorization before admitting the second. If the first fails or its outcome is uncertain, stop the chain and reconcile it before retrying. Use durable idempotency records where supported; a timeout is not proof that nothing happened. On partial completion, report the completed action and pending dependency rather than claiming the whole operation succeeded. Parallelize only genuinely independent work within concurrency and spend ceilings.

All workers must reserve from one durable, atomic ledger for the logical run. Reserve a conservative maximum before admitting a call; committed spend plus outstanding reservations must never exceed the cap. Settle reservations with attributable actual charges, retaining uncertain reservations until reconciled. Restart and resume must load the same run identity, spent amount, pending reservations and absolute deadline. They must not create a fresh allowance. Enforce aggregate steps, calls, fan-out, retrieval limits and deadline alongside spend. When a ceiling is exhausted, stop, return a supported partial result or abstain; do not remove validation to squeeze in another action.

| Acceptance area | Required result |
|---|---|
| Cache isolation | Same input under a different tenant, principal or permission scope cannot reuse a response. |
| Cache validity | Every relevant version change, data invalidation or TTL expiry causes a miss; permission revocation blocks access immediately. |
| Dependency order | Second mutation starts only after the first succeeds and a fresh version/authority check passes. |
| Failure and retry | Failure, timeout and restart cannot silently duplicate mutations or proceed from an uncertain predecessor. |
| Aggregate budget | Concurrent admission is atomic; worker count cannot increase allowance, and no new call exceeds remaining reserved capacity. |
| Resume | Committed charges, pending reservations and deadline remain effective after restart. |
| Outcome gate | Verified success, safety and groundedness hold on matched tasks; failures and retries remain in the denominator and spend ledger. |

The accompanying local fake exercises cache-key changes, expiry, revocation, forbidden cache classes, dependency failure/version checks, atomic concurrent reservations, settlement and restart persistence. It uses no external services. Its results establish the fake’s invariants, not production security, provider billing behavior, distributed ledger correctness or durable external mutation recovery. Production acceptance must additionally cover crash injection at admission/dispatch/settlement boundaries, provider timeouts with eventual success, reconciliation, stale permissions, conflicting state updates and counter/deadline persistence.

Executed result: all 10 local tests passed after correcting a Windows SQLite connection cleanup error. Both the initial failed log and final passing log are saved. The harness runtime is not a service-latency measurement.

No latency or outcome experiment has been executed because representative tasks, production implementation and measurements were not supplied. Establish a pinned baseline ledger, then run one matched optimization experiment under comparable load and cold/warm cache conditions. Record complete-task p50/p95, all failed/retried work, cache costs and total spend divided by verified successes. Retain a change only if predefined quality/safety floors and the user-facing latency target hold; otherwise revert it.
