"""Local acceptance fake. No provider calls or live external effects.

Demonstrates selected invariants only; production distributed crash recovery,
provider reconciliation, durable mutation records and policy engines are absent.
"""
from dataclasses import dataclass, replace
from contextlib import closing
from pathlib import Path
import sqlite3
import sys
import tempfile
import threading
import unittest


@dataclass(frozen=True)
class Key:
    tenant: str = "tenant-a"
    principal: str = "user-a"
    permissions: str = "read-receipts-v1"
    canonical_input: str = '{"receipt":"r1"}'
    model: str = "model-v1"
    prompt: str = "prompt-v1"
    schema: str = "schema-v1"
    tool: str = "tool-v1"
    index: str = "index-v1"
    freshness: str = "data-generation-1"


class Cache:
    def __init__(self):
        self.entries = {}

    def put(self, key, value, now, ttl, kind="stable"):
        if kind != "stable" or ttl <= 0:
            raise ValueError("Only stable reusable work with positive TTL")
        self.entries[key] = (value, now + ttl)

    def get(self, key, now, currently_authorized):
        if not currently_authorized:
            raise PermissionError("Current authorization required")
        entry = self.entries.get(key)
        return entry[0] if entry and now < entry[1] else None


class Mutations:
    def __init__(self):
        self.version = 0
        self.created = False
        self.events = []

    def create(self, expected_version, fail=False):
        if expected_version != self.version:
            raise RuntimeError("stale version")
        self.events.append("create")
        if fail:
            raise RuntimeError("create failed")
        self.created = True
        self.version += 1
        return self.version

    def activate(self, expected_version):
        if expected_version != self.version or not self.created:
            raise RuntimeError("invalid dependency state")
        self.events.append("activate")
        self.version += 1

    def ordered_chain(self, fail=False, conflict=False):
        next_version = self.create(self.version, fail)
        if conflict:
            self.version += 1
        self.activate(next_version)


class Ledger:
    """Integer spend units; pending reservations survive reconnection."""
    def __init__(self, path, cap):
        self.path = str(path)
        with closing(sqlite3.connect(self.path, timeout=30)) as db, db:
            db.execute("CREATE TABLE IF NOT EXISTS limits (cap INTEGER NOT NULL)")
            db.execute("CREATE TABLE IF NOT EXISTS charges (id TEXT PRIMARY KEY, reserved INTEGER NOT NULL, actual INTEGER)")
            row = db.execute("SELECT cap FROM limits").fetchone()
            if row is None:
                db.execute("INSERT INTO limits VALUES (?)", (cap,))
            elif row[0] != cap:
                raise ValueError("Cannot change run cap on resume")

    def reserve(self, operation_id, upper_bound):
        if not isinstance(upper_bound, int) or upper_bound <= 0:
            raise ValueError("positive integer upper bound required")
        with closing(sqlite3.connect(self.path, timeout=30)) as db, db:
            db.execute("BEGIN IMMEDIATE")
            previous = db.execute("SELECT reserved FROM charges WHERE id=?", (operation_id,)).fetchone()
            if previous:
                if previous[0] != upper_bound:
                    raise ValueError("same operation cannot change reservation")
                return False  # replay does not authorize another dispatch
            used = db.execute("SELECT COALESCE(SUM(COALESCE(actual, reserved)),0) FROM charges").fetchone()[0]
            cap = db.execute("SELECT cap FROM limits").fetchone()[0]
            if used + upper_bound > cap:
                return False
            db.execute("INSERT INTO charges VALUES (?, ?, NULL)", (operation_id, upper_bound))
            return True

    def settle(self, operation_id, actual):
        with closing(sqlite3.connect(self.path, timeout=30)) as db, db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT reserved,actual FROM charges WHERE id=?", (operation_id,)).fetchone()
            if row is None or not isinstance(actual, int) or not 0 <= actual <= row[0]:
                raise ValueError("actual must remain within reserved upper bound")
            if row[1] is not None and row[1] != actual:
                raise ValueError("conflicting settlement")
            db.execute("UPDATE charges SET actual=? WHERE id=?", (actual, operation_id))

    def usage(self):
        with closing(sqlite3.connect(self.path)) as db, db:
            return db.execute("SELECT COALESCE(SUM(COALESCE(actual,reserved)),0) FROM charges").fetchone()[0]


class AcceptanceTests(unittest.TestCase):
    def setUp(self):
        self.cache = Cache()
        self.key = Key()
        self.cache.put(self.key, "result-a", now=0, ttl=10)

    def test_cache_identity_and_all_version_dimensions(self):
        self.assertEqual(self.cache.get(self.key, 1, True), "result-a")
        for field in self.key.__dataclass_fields__:
            with self.subTest(field=field):
                self.assertIsNone(self.cache.get(replace(self.key, **{field: "different"}), 1, True))

    def test_expiry_and_data_generation_invalidation(self):
        self.assertIsNone(self.cache.get(self.key, 10, True))
        self.assertIsNone(self.cache.get(replace(self.key, freshness="data-generation-2"), 1, True))

    def test_revocation_checked_despite_matching_key(self):
        with self.assertRaises(PermissionError):
            self.cache.get(self.key, 1, False)

    def test_approval_and_changing_authority_are_not_cacheable(self):
        for kind in ("approval", "authoritative-state"):
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                self.cache.put(self.key, "unsafe", 1, 10, kind=kind)

    def test_ordered_dependent_mutations(self):
        mutations = Mutations()
        mutations.ordered_chain()
        self.assertEqual(mutations.events, ["create", "activate"])
        self.assertEqual(mutations.version, 2)

    def test_predecessor_failure_stops_dependent_mutation(self):
        mutations = Mutations()
        with self.assertRaises(RuntimeError):
            mutations.ordered_chain(fail=True)
        self.assertEqual(mutations.events, ["create"])

    def test_stale_version_blocks_dependent_mutation(self):
        mutations = Mutations()
        with self.assertRaises(RuntimeError):
            mutations.ordered_chain(conflict=True)
        self.assertEqual(mutations.events, ["create"])

    def ledger_dir(self):
        return tempfile.TemporaryDirectory(dir=Path(__file__).parent)

    def test_concurrent_workers_share_atomic_cap(self):
        with self.ledger_dir() as directory:
            ledger = Ledger(Path(directory) / "run.sqlite", 100)
            barrier = threading.Barrier(8)
            results, errors = [], []
            lock = threading.Lock()

            def worker(index):
                try:
                    barrier.wait()
                    admitted = ledger.reserve(f"call-{index}", 60)
                    with lock:
                        results.append(admitted)
                except Exception as exc:
                    with lock:
                        errors.append(exc)

            workers = [threading.Thread(target=worker, args=(i,)) for i in range(8)]
            for worker_thread in workers:
                worker_thread.start()
            for worker_thread in workers:
                worker_thread.join()
            self.assertEqual(errors, [])
            self.assertEqual(sum(results), 1)
            self.assertEqual(ledger.usage(), 60)

    def test_resume_preserves_spend_pending_and_cap(self):
        with self.ledger_dir() as directory:
            path = Path(directory) / "run.sqlite"
            ledger = Ledger(path, 100)
            self.assertTrue(ledger.reserve("completed", 60))
            ledger.settle("completed", 40)
            self.assertTrue(ledger.reserve("uncertain", 60))
            resumed = Ledger(path, 100)
            self.assertEqual(resumed.usage(), 100)
            self.assertFalse(resumed.reserve("extra", 1))
            self.assertFalse(resumed.reserve("uncertain", 60))
            with self.assertRaises(ValueError):
                Ledger(path, 200)

    def test_settlement_releases_only_unused_reservation(self):
        with self.ledger_dir() as directory:
            ledger = Ledger(Path(directory) / "run.sqlite", 100)
            self.assertTrue(ledger.reserve("call", 100))
            self.assertFalse(ledger.reserve("early", 1))
            ledger.settle("call", 75)
            self.assertTrue(ledger.reserve("next", 25))
            self.assertFalse(ledger.reserve("overflow", 1))
            self.assertEqual(ledger.usage(), 100)


if __name__ == "__main__":
    unittest.main(verbosity=2, testRunner=unittest.TextTestRunner(stream=sys.stdout, verbosity=2))
