"""Local acceptance fakes; no network, models, production tools, or measured speedup."""
import hashlib
import json
import sqlite3
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path


def cache_key(context, payload):
    fields = ("tenant", "principal", "permission_epoch", "permission_digest", "model", "prompt",
              "schema", "tool", "index", "freshness")
    canonical = json.dumps({"context": {k: context[k] for k in fields}, "input": payload},
                           sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode()).hexdigest()


class Cache:
    def __init__(self):
        self.entries = {}

    def put(self, context, payload, value, now, ttl, kind="stable_read"):
        if kind != "stable_read":
            raise ValueError("This fake caches stable reads only")
        self.entries[cache_key(context, payload)] = (value, now + ttl)

    def get(self, context, payload, now, currently_authorized):
        if not currently_authorized:
            return None
        item = self.entries.get(cache_key(context, payload))
        return item[0] if item and now < item[1] else None


class Mutations:
    def __init__(self):
        self.version = 0
        self.first_committed = False
        self.results = {}

    def first(self, expected_version, idempotency_key):
        if idempotency_key in self.results:
            return self.results[idempotency_key]
        if self.version != expected_version:
            raise ValueError("stale version")
        self.first_committed = True
        self.version += 1
        self.results[idempotency_key] = self.version
        return self.version

    def second(self, expected_version, idempotency_key):
        if idempotency_key in self.results:
            return self.results[idempotency_key]
        if not self.first_committed or self.version != expected_version:
            raise ValueError("missing prerequisite or stale version")
        self.version += 1
        self.results[idempotency_key] = self.version
        return self.version


class Ledger:
    def __init__(self, path, run_id):
        self.path, self.run_id = str(path), run_id

    def connect(self):
        return sqlite3.connect(self.path, timeout=10)

    def create(self, cap):
        with self.connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS runs (id TEXT PRIMARY KEY, cap INTEGER, spent INTEGER, reserved INTEGER)")
            db.execute("CREATE TABLE IF NOT EXISTS reservations (run TEXT, key TEXT, amount INTEGER, status TEXT, PRIMARY KEY (run,key))")
            db.execute("INSERT INTO runs VALUES (?, ?, 0, 0)", (self.run_id, cap))

    def reserve(self, key, amount):
        if amount <= 0:
            raise ValueError("positive reservation required")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            existing = db.execute("SELECT amount,status FROM reservations WHERE run=? AND key=?", (self.run_id, key)).fetchone()
            if existing:
                if existing[0] != amount:
                    raise ValueError("changed retry reservation")
                return existing[1] == "reserved"
            cap, spent, reserved = db.execute("SELECT cap,spent,reserved FROM runs WHERE id=?", (self.run_id,)).fetchone()
            if spent + reserved + amount > cap:
                return False
            db.execute("INSERT INTO reservations VALUES (?, ?, ?, 'reserved')", (self.run_id, key, amount))
            db.execute("UPDATE runs SET reserved=reserved+? WHERE id=?", (amount, self.run_id))
            return True

    def settle(self, key, actual):
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            amount, status = db.execute("SELECT amount,status FROM reservations WHERE run=? AND key=?", (self.run_id, key)).fetchone()
            if status != "reserved" or not 0 <= actual <= amount:
                raise ValueError("invalid settlement")
            db.execute("UPDATE runs SET reserved=reserved-?,spent=spent+? WHERE id=?", (amount, actual, self.run_id))
            db.execute("UPDATE reservations SET status='settled' WHERE run=? AND key=?", (self.run_id, key))

    def state(self):
        with self.connect() as db:
            return db.execute("SELECT cap,spent,reserved FROM runs WHERE id=?", (self.run_id,)).fetchone()


passed = []


def check(name, condition):
    assert condition, name
    passed.append(name)
    print("PASS " + name)


def raises(call):
    try:
        call()
    except ValueError:
        return True
    return False


ctx = {"tenant": "A", "principal": "P", "permission_epoch": 1, "permission_digest": "read-own",
       "model": "m1", "prompt": "p1", "schema": "s1", "tool": "t1", "index": "i1", "freshness": "stable-v1"}
payload = {"receipt": "example", "currency": "unit"}
cache = Cache()
cache.put(ctx, payload, "tenant-A-data", now=100, ttl=10)
check("same authorized stable input hits", cache.get(ctx, payload, 101, True) == "tenant-A-data")
check("canonical input order is stable", cache_key(ctx, payload) == cache_key(ctx, dict(reversed(list(payload.items())))))
for field in ctx:
    changed = {**ctx, field: str(ctx[field]) + "-changed"}
    check("key isolates " + field, cache.get(changed, payload, 101, True) is None)
check("changed input misses", cache.get(ctx, {**payload, "receipt": "other"}, 101, True) is None)
check("revoked permission denies existing hit", cache.get(ctx, payload, 101, False) is None)
check("expiry boundary misses", cache.get(ctx, payload, 110, True) is None)
for kind in ("approval", "mutation", "authoritative_state"):
    check("reject caching " + kind, raises(lambda: cache.put(ctx, payload, "value", 100, 10, kind)))

mutations = Mutations()
check("dependent mutation before prerequisite rejects", raises(lambda: mutations.second(0, "second")))
committed_version = mutations.first(0, "first")
check("stale dependent version rejects", raises(lambda: mutations.second(0, "second")))
check("ordered dependent mutation succeeds", mutations.second(committed_version, "second") == 2)
check("mutation retry is idempotent", mutations.second(committed_version, "second") == 2 and mutations.version == 2)

path = Path(__file__).with_name("fake-ledger.sqlite")
run_id = str(uuid.uuid4())
ledger = Ledger(path, run_id)
ledger.create(100)
barrier = threading.Barrier(4)


def worker(i):
    barrier.wait()
    return Ledger(path, run_id).reserve("worker-" + str(i), 40)


with ThreadPoolExecutor(max_workers=4) as pool:
    admissions = list(pool.map(worker, range(4)))
check("concurrent workers share aggregate cap", sum(admissions) == 2 and ledger.state() == (100, 0, 80))
admitted_keys = ["worker-" + str(i) for i, admitted in enumerate(admissions) if admitted]
check("duplicate reserve consumes nothing", ledger.reserve(admitted_keys[0], 40) and ledger.state() == (100, 0, 80))
ledger.settle(admitted_keys[0], 30)
check("failed attempt billed and unused reservation released", ledger.state() == (100, 30, 40))
resumed = Ledger(path, run_id)
check("new ledger instance preserves spend and unknown in-flight reserve", resumed.state() == (100, 30, 40))
check("resume rejects work above remaining cap", not resumed.reserve("retry-too-large", 31))
check("resume admits only available remainder", resumed.reserve("retry", 30) and resumed.state() == (100, 30, 70))
check("exhausted budget blocks new work", not resumed.reserve("extra", 1))
check("over-reservation settlement rejects", raises(lambda: resumed.settle("retry", 31)))
check("zero new reservation rejects", raises(lambda: resumed.reserve("zero", 0)))
print(f"RESULT {len(passed)}/{len(passed)} local fake checks passed")
print("LIMITATION: Fake keys, mutations and SQLite ledger only; no production authorization, provider billing, distributed failure or latency measurement.")
