"""Verify supplied aggregates only. No model calls or performance measurements."""
from fractions import Fraction

s_spend, s_success, s_total, s_p95 = 20, 80, 100, 4
v_spend, v_success, v_total, v_p95 = 30, 82, 100, 8
target = 5
s_cps = Fraction(s_spend, s_success)
v_cps = Fraction(v_spend, v_success)
print("ASSUMPTION: supplied costs are total comparable-variant spend over the reported 100-task samples.")
print(f"S cost per verified success = {s_spend}/{s_success} = {float(s_cps):.6f}")
print(f"V cost per verified success = {v_spend}/{v_success} = {float(v_cps):.6f}")
print(f"V relative cost-per-success increase = {float((v_cps / s_cps - 1) * 100):.6f}%")
print(f"V total spend increase = {float(Fraction(v_spend - s_spend, s_spend) * 100):.6f}%")
print(f"Success rate increase = {float((Fraction(v_success, v_total) - Fraction(s_success, s_total)) * 100):.6f} percentage points")
print(f"S p95 {s_p95}s <= {target}s: {s_p95 <= target}")
print(f"V p95 {v_p95}s <= {target}s: {v_p95 <= target}")
print("RESULT: supplied aggregates favor S on cost per success and the required p95 gate.")
print("LIMITATION: no individual outcomes, latency samples, role labels, abstention split or actual spend logs were supplied.")
