Reject V under the required p95 gate; retain S as the comparison baseline. S meets the supplied latency requirement, but adoption still depends on quality and safety floors that have not been specified. A competition's use of multiple models is not evidence that four models improve these receipt tasks. Without per-role evaluations, no particular model assignment is justified.

Treating the supplied costs as total attributable spend for each comparable 100-task variant:

| Variant | Spend | Verified successes | Non-successes, split unknown | Cost/success | p95 completion | Required p95 <= 5s |
|---|---:|---:|---:|---:|---:|---|
| S | 20 | 80/100 | 20 | 0.250000 | 4s | Pass |
| V | 30 | 82/100 | 18 | 0.365854 | 8s | Fail |

V increases spend by 50% and cost per success by approximately 46.34%, for a supplied success-rate increase of two percentage points. The added successes do not overcome a mandatory latency failure. The counts alone cannot establish statistical significance or attribute the difference to verification; paired outcomes, task mix and repeated measurements are missing. If the supplied costs exclude failed retries or coordination, recompute both denominators with complete spend before making an economic claim. Safe abstentions and failures must be reported separately.

Assign responsibility by the nature of the work, then choose model candidates through evidence:

| Role | Owner and boundary | Required role evaluation |
|---|---|---|
| Receipt interpretation | A candidate capable of reading the supplied modality extracts structured fields and source evidence. It flags unreadable/missing values. | Field accuracy, currency/sign interpretation, line alignment, provenance, unreadable-input abstention and relevant format slices. Schema validity alone is insufficient. |
| Exact total arithmetic | Deterministic code over validated inputs, using integer minor units or explicit decimal/rounding rules. | Exact agreement on discounts, taxes, refunds and rounding fixtures; reject missing/ambiguous rules instead of guessing. Numerical uncertainty from interpretation remains explicit. |
| Ambiguous contradiction review | A bounded reasoning role compares evidence with deterministic discrepancies. Unresolved cases abstain or reach authorized human review. | Gold adjudication, unsupported resolutions, harmful false acceptance and appropriate abstention on ambiguous/conflicting receipts. |
| Explanation | A grounded generation role or template reports validated values, evidence and unresolved issues. | Supported material claims, numeric consistency and preservation of uncertainty; explanations cannot revise authoritative totals. |

The orchestrator owns route transitions, validation and budget enforcement. One candidate may satisfy interpretation, review and explanation; no requirement calls for three distinct models. An extra verifier is another proposed role whose benefit must survive an on/off or matched-routing ablation. Keep it out of the retained S configuration pending that evidence.

Proposed experiments, all unexecuted:

1. Freeze a representative gold set, success/abstention definitions, quality/safety floors, prompt/schema/tool versions and pricing timestamp. Include clear receipts, difficult scans, refunds, rounding and genuine contradictions. Separate route calibration from held-out evaluation.
2. Swap one model candidate for one model-owned role at a time, holding other roles fixed. Evaluate deterministic arithmetic independently with adjudicated inputs. Record role-specific errors and propagated whole-task failures; cheaper extraction that increases review errors is not a win.
3. Compare verifier off, always on and conditionally on using identical tasks. Calibrate conditional triggers against actual errors/discrepancies; raw confidence is insufficient. Measure whether corrections outweigh false acceptance, new errors and overhead.
4. Compare direct execution by a stronger evaluated candidate with smaller-candidate-to-fallback routing on the same hard-case slice. Include unnecessary escalation, timeout/provider-error paths, repeated failures and exhausted budgets. Compare grounded explanation templates with generation, then test any consolidated role ownership end to end.

For every variant, record aggregate spend across successful and failed attempts, retries, escalations, cache creation/read charges and coordination, divided by verified successes. Zero successes makes the ratio undefined. Report task slices, failure/abstention mix, calls and p50/p95 wall time through verified completion, including queueing and retries; distinguish first response from completion. Match load and warm/cold cache conditions and repeat noisy trials. Enforce aggregate durable run budgets, call/concurrency limits and deadlines across resumed workers. Retain a candidate only when all predefined quality/safety floors and p95 <= 5s hold and outcome economics improve. No live changes or model experiments were performed; only the supplied arithmetic was executed and verified locally.
