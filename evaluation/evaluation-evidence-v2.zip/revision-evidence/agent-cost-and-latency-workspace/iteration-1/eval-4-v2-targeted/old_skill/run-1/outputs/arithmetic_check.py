"""Verify supplied cohort arithmetic; no measured model or service results."""
from fractions import Fraction

s_cost, s_successes, s_p95 = 20, 80, 4
v_cost, v_successes, v_p95 = 30, 82, 8
limit = 5
s_unit = Fraction(s_cost, s_successes)
v_unit = Fraction(v_cost, v_successes)
increase = (v_unit / s_unit - 1) * 100
assert s_unit == Fraction(1, 4)
assert v_unit == Fraction(15, 41)
assert increase == Fraction(1900, 41)
assert s_p95 <= limit
assert v_p95 > limit
print("Supplied costs interpreted as total spend per 100-task cohort.")
print(f"S cost per verified success: {s_unit} = {float(s_unit):.6f}")
print(f"V cost per verified success: {v_unit} = {float(v_unit):.6f}")
print(f"V cost-per-success increase: {float(increase):.6f}%")
print(f"Raw spend increase: {(v_cost / s_cost - 1) * 100:.2f}%")
print(f"Observed success-rate increase: {v_successes - s_successes} percentage points")
print(f"S supplied p95 gate: {s_p95} <= {limit}: pass")
print(f"V supplied p95 gate: {v_p95} <= {limit}: fail; excess {v_p95 - limit} seconds")
print("Arithmetic assertions passed. No role/model experiments executed.")
