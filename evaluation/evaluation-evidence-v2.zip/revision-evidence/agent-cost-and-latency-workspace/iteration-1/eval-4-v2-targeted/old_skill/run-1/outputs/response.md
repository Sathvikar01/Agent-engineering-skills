# Role ownership and retain/reject decision

Reject V under the stated requirement and retain S as the feasible comparison baseline. A competition’s use of many models does not establish that four model roles improve this receipt workflow. With no per-role evals, neither the extra role count nor any particular role/model assignment has earned retention. S meets the supplied latency limit, but its 80% success rate still requires an explicit quality/safety acceptance floor before production approval.

Treat the reported costs as total attributable spend for each 100-task cohort, including failures and retries. If that assumption is false, recompute from the full attempt ledger before making the economic comparison.

| Supplied cohort | Total cost | Verified successes | Cost per success | Completion p95 | Decision |
|---|---:|---:|---:|---:|---|
| S | 20 | 80/100 | 20/80 = 0.2500 | 4 s | Retain as feasible baseline; quality gate still needed. |
| V, with verifier | 30 | 82/100 | 30/82 = 0.3659 | 8 s | Reject: violates p95 ≤ 5 s. |

V spends 50% more for a two-percentage-point observed success increase, and its cost per verified success is about 46.34% higher. Its p95 doubles and exceeds the limit by three seconds. The two additional aggregate successes do not show which individual cases improved or regressed, or establish a repeatable benefit. The arithmetic check is executed; the supplied success and p95 figures are user-provided, not measurements collected here.

Start with deterministic orchestration and one evaluated model path for interpretation, bounded semantic review when needed, and explanation. Distinct responsibilities do not require distinct models.

| Responsibility | Owner and acceptance boundary |
|---|---|
| Receipt interpretation | Model extracts amounts, labels, currency and relationships into a schema, grounded to receipt spans. Deterministic validation checks shape, allowed fields and completeness; uncertain readings remain explicit. |
| Exact total arithmetic | Deterministic code using integer minor units or exact decimals and specified currency/rounding rules. Verify against golden totals, including tax, discounts and rounding. A model’s proposed sum is not authoritative. |
| Ambiguous contradiction review | Model reviews bounded evidence when extraction ambiguity or a deterministic inconsistency triggers review. It must cite supporting spans and abstain or request correction when the receipt cannot resolve the conflict. |
| Explanation | Template or the same evaluated model renders the verified structured result. Check fidelity to evidence, arithmetic and uncertainty; it cannot silently revise the computed total. |

These are proposed responsibilities, not proof that an untested model meets their gates. No provider or named-model recommendation is justified.

Run the following routing ablations on a frozen, paired receipt set with legible, difficult, contradictory and unresolvable slices. Change one variable at a time, freeze prompts/tools/schemas/pricing timestamp, and keep load and cache conditions comparable.

1. Compare direct execution with each candidate model for interpretation while holding arithmetic, explanation and orchestration fixed. Score extraction, groundedness and final verified outcomes separately.
2. Compare direct execution with a more capable candidate against smaller-model → fallback routing. Calibrate the trigger on held-out data using validation/ambiguity signals; include cheap failed attempts and successful or failed escalations in total cost and completion latency.
3. Compare no semantic reviewer, an always-on reviewer, and a triggered reviewer. Then hold the trigger fixed while varying reviewer model. Measure resolved contradictions, missed contradictions, false alarms, abstentions and new incorrect changes.
4. Compare template explanation, reused-model explanation and a separate explanation model on identical verified artifacts. Retain added calls only for demonstrated fidelity or outcome gains within the latency gate.

For every arm, include provider errors, malformed outputs, exhausted retries and unresolved contradictions. Use explicit aggregate call/spend/deadline limits; failed tasks remain in the cohort and all attributable work remains in spend. Report success and abstention mix, per-role error rates, total cost per verified success, and end-to-end p50/p95 including queueing, orchestration and retries. Examine paired regressions and repeat noisy measurements. Retain only arms meeting predefined quality/safety floors and p95 ≤ 5 s. All role/model experiments are proposed and unexecuted because no eval corpus or execution data was supplied.
