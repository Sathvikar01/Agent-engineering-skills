---
name: agent-architecture
description: >-
  Choose and specify the smallest reliable architecture for an AI-powered system. Use when designing or reviewing runtime autonomy, deciding whether a product needs an agent, or placing reasoning, tools, state and authority boundaries. Do not use for ordinary application architecture or executing a coding plan without an AI runtime design decision.
metadata:
  collection: "Agent Engineering"
  version: "1.0.0"
---

# Agent Architecture

Start with the user outcome, not an agent framework. Produce a decision record before a large implementation; adapt its detail to the system's risk.

## Select the architecture

1. Express success as observable outcomes, disallowed actions, and representative acceptance cases. Establish an existing-system or deterministic baseline before choosing autonomy.
2. Classify the work using this ladder. Stop at the first adequate option:

| Class | Choose when | Evidence needed to move higher |
|---|---|---|
| Deterministic software | Rules, inputs and transitions are known | A necessary step cannot be reliably expressed as rules |
| Deterministic workflow with model-powered steps | Interpretation is fuzzy but step order is known | A fixed graph fails representative tasks requiring adaptive choices |
| Single agent | Next steps depend on observations; no external capability is needed | External observations or actions are necessary |
| Agent with tools | Adaptive reasoning must use bounded external capabilities | Independent workers outperform this baseline enough to justify coordination |
| Multi-agent system | Distinct contexts or independent work create measured benefit | Explicit quality, isolation or latency gain exceeds coordination cost |

3. Justify each autonomous decision with a failed simpler alternative and an eval. A marketing label, unknown future requirements, or a framework's availability is insufficient. Unknown requirements call for a bounded experiment, not a speculative swarm.

## Specify the boundaries

4. Map one representative run: intent → success/evals → context/state → model proposal → deterministic validation → policy authorization → approval if required → tool execution → evidence → evaluation → deterministic state update.
5. Assign owners for reasoning (interpretation/planning), execution (side effects), trust (untrusted inputs), and authority (permissions/business rules). The model may propose actions but cannot promote its prose into trusted state. Show where each input becomes validated data.
6. Define context sources and budgets; persisted state, memory and source of truth; coherent tool contracts; least-privilege identities; approval gates; and evidence provenance. Use application-owned state for money, permissions and workflow status.
7. Define terminal statuses and hard ceilings for time, steps, model/tool calls and spend. Include cancellation, no-progress detection, policy denial, unavailable evidence and partial completion. Completion requires outcome verification, not the agent's declaration.
8. Design checkpoints at durable boundaries, ambiguous-side-effect reconciliation, and resume authorization. Capture run IDs, versions, transitions, costs and evaluator outcomes so a failed trajectory is reconstructable.

## Deliver and verify

Deliver the classification and rationale, boundary/ownership table, one happy and one denied/failed trajectory, budgets and termination rules, recovery path, and eval release gate. Name unresolved assumptions and the experiment that resolves each.

Verify with a task requiring no model, a fuzzy but fixed workflow, an adaptive tool task, and an authority violation. Do not add a loop to a fixed pipeline. Do not add workers to a single context merely to label them specialist agents.

Use existing brainstorming/spec/planning skills for requirements and implementation planning. This skill owns the deployed system's autonomy decision. Use agent-evals for scoring, deterministic-authority for admission logic, and multi-agent-orchestration only after the ladder justifies multiple workers; none is a mandatory dependency.
