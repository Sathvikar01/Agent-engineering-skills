---
name: multi-agent-orchestration
description: >-
  Justify and design bounded coordination between multiple agents in a runtime system. Use when deciding whether deployed workers should be multiple agents, designing planner/worker or reviewer handoffs, fan-out/fan-in, shared state, authority, conflicts or budgets. Do not use for dispatching independent coding subtasks, executing a development plan, or deterministic parallel processing without an agent coordination decision.
metadata:
  author: Sathvik
  collection: "Sathvik — Agent Engineering"
  version: "1.0.0"
---

# Multi-Agent Orchestration

“Do we actually need multiple agents?” Ask this first. Use deterministic orchestration or a single agent unless measured quality, isolation or latency benefit justifies coordination overhead.

## Establish the simpler baseline

1. Compare deterministic workflow, one model-powered step and single-agent/tool designs using representative evals. Reject multiple agents for known rules, small shared-context tasks or role labels without measurable benefit. Parallel deterministic functions do not need agent personas.
2. Identify genuinely separable work, specialized context or independent verification. Record dependency edges, shared resources, merge semantics and expected gain. If all workers need the same full context and continually negotiate, decomposition may be wrong.
3. Choose the smallest pattern: independent fan-out/fan-in, planner with bounded workers, or a separate reviewer with a defined rubric. A reviewer can detect errors but cannot grant authority. Use deterministic scheduling for known dependencies and avoid free-form agent-to-agent chat as the control plane.

## Specify handoffs and ownership

4. Give each task a typed contract: task/run/parent IDs, objective, input evidence and scope, output schema, allowed tools, completion criteria, deadline, budgets and cancellation. Mark external content as untrusted; handoff summaries do not gain authority by being written by another agent.
5. Assign one authoritative owner per mutable resource or use explicit transactional/versioned coordination. Workers return proposals/evidence; the orchestrator validates results and deterministic policy authorizes effects. Scope each worker's identity/capabilities; do not inherit broad coordinator privileges by default.
6. Define fan-in rules for missing, failed, conflicting or duplicate results. Validate schema/provenance, choose deterministic merge rules where possible, and escalate substantive conflicts with evidence. Majority vote or reviewer agreement is not proof of truth or permission.
7. Preserve idempotency across duplicate dispatch and retries. Define checkpoint/resume and late-result behavior; a cancelled or expired task must not commit a delayed proposal. Reconcile unknown worker effects before rescheduling.

## Bound coordination and prove benefit

8. Set total and per-worker ceilings for steps, model calls, tools, spend, time, fan-out and concurrency. Reserve budgets centrally/atomically so workers cannot independently exceed the aggregate. Stop on objective completion, dependency failure, deadline, cancellation, policy denial or no progress.
9. Limit planner/reviewer rounds and specify the condition for another round. Do not allow recursive delegation or conversation loops without explicit bounded benefit. Capture parent/child traces, worker versions, handoff evidence, conflicts and final evaluator outcome.
10. Run ablations against the simpler baseline, including coordination/merge costs and failure modes. Ship multiple agents only if the measured benefit survives realistic skew, missing workers, duplicate work and contradictory outputs. Preserve a single-agent fallback only when it meets the same safety policy.

Deliver the necessity decision, task graph, handoff/merge contract, authority map, aggregate budgets, failure policy and comparison evidence. Existing subagent/dispatching skills own agents collaborating on coding tasks; this skill designs the deployed orchestration system.
