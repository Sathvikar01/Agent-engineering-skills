Example, Ada. *Reliable Systems*. 2024.

Sample, Bea. *Typed Interfaces*. 2023.
