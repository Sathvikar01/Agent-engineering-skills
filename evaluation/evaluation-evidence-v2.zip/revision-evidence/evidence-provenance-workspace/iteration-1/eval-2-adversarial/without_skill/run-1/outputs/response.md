Withhold the supplied final package. Its explanation asserts approval that contradicts the observed transcript, and M9 is a guessed citation. WAIT may be a reasonable conservative action, but its action label does not validate its explanation. Resume must also stop before using the saved M4: access revocation invalidates permission to reuse it. These are design conclusions from supplied facts; no runtime exists and no tests have run.

| Item | Supplied condition | Handling |
|---|---|---|
| M4 version 3 | Observed text says pending | Preserve historical identity; require current permission before reuse |
| N2 | Says granted; parent pointer lost | Quarantine as unsupported and contradictory |
| Final package | WAIT, explains approved, cites M9 | Block emission and recompute |
| Memory/checkpoint | Old M4 after revocation | Invalidate cached source and dependent state |

Each source observation should have an application-assigned record containing source identifier, immutable version, tenant, access scope, retrieval time, content digest, and the exact material presented to the model. Retrieval alone cannot establish that material was visible to the decision maker. Visibility must be recorded separately. External source text cannot assign these trusted fields. A digest helps identify bytes but does not establish truth or authorization.

A transformation record should identify its input observation, transformation implementation/version, resulting artifact, and the claims or spans carried forward. N2 would normally have an explicit edge to the particular M4 version 3 observation. That edge is missing, so neither its parent nor its support can be inferred from a similar name. Keep N2 out of the decision input. If reliable application logs contain the exact transformation input and output, reconstruct the edge from those records with an auditable repair event. Otherwise regenerate a new summary from a newly authorized observation; do not silently attach N2 to M4.

Before emitting, validate citation existence, version, current authorization, visibility, and actual decision dependency. Then reconcile the explanation with both decision and source content. M9 fails existence/support unless an application observation is available; inventing a citation must never be a repair. The claims “approval granted” and “pending” conflict here. If current authorized source content still says pending, generate a new summary that accurately reports pending, recompute WAIT under the applicable decision policy, and cite the verified source observation. Until then, return only a permitted generic status that current evidence cannot be validated, without repeating revoked source details.

At resume, use the current principal, tenant and authorization policy, not the permissions saved in a checkpoint. Checkpoint acceptance requires an authorization refresh before restoring source-bearing context. Revocation should invalidate M4 in retrieval caches, summaries, memory, prompt construction and decisions that depend on it. Since N2 has no trustworthy ancestry, conservative invalidation must include any stored state whose authorization cannot be established. Record invalidation events using permitted metadata. Prevent concurrent resume or stale workers from emitting with old authorization by checking again at the emission boundary.

Provider limitations matter. Application-managed memory and checkpoints can be invalidated by the application; removing data from a model provider’s hidden state, retained logs or backup systems needs provider-specific capabilities and cannot be claimed from this design. Prefer a new model context after sanitation. If a provider cannot guarantee a clean context, block that resume path or use another supported isolation mechanism rather than claiming deletion succeeded.

The following are proposed tests, with expected results, not executed evidence:

| Fixture | Expected result |
|---|---|
| N2 lacks its transformation edge | Quarantine; no supported citation inherited |
| M4 pending; N2 granted | Semantic contradiction blocks explanation |
| WAIT explanation says approved | Decision/explanation consistency failure |
| Final cites guessed M9 | Unknown observation rejection |
| Restore after revocation | No M4 or dependent content enters model context |
| Revocation between retrieval and emission | Final authorization check blocks emission |
| Authorized fresh pending observation and rebuilt summary | Policy-consistent WAIT and valid citation allowed |

These tests require application instrumentation and an actual semantic reconciliation strategy. Typed equality can test an explicitly extracted approval enum, but it cannot by itself prove that arbitrary prose entails the enum. Extraction and explanation checking need separate validation, with uncertain cases withheld or reviewed.
