Implemented and ran a local Python fake in [reconcile_fake.py](reconcile_fake.py). The actual run exited with code 0. The log records one unittest containing nine scenario subtests, with an overall `OK` result. [test-run.log](test-run.log) contains the captured stdout and stderr. These are fixture results, not observations from a live application or provider.

The ledger is owned by the application: A is an observed, model-visible total of 100 at version 2 for tenantT1; B is visible but concerns the unrelated value 7; C was retrieved but was not visible. The task did not supply versions for B or C or a fact for C, so those fields remain unspecified. A source payload remains opaque text. Its words cannot assign an ID, change tenant ownership, elevate visibility, or attest a signature. No cryptographic or provider signature verification is simulated.

The decision explicitly binds its typed total to A and version 2. The output proposal separately supplies its typed total and citation IDs. The validator first checks that every cited and decision-support ID belongs to the observed ledger and is accessible to the decision's tenant. It then checks visibility, observation, the decision's bound version, and equality between the supporting observation and decision. Finally it requires every citation to be among the decision's verified support and to support the emitted typed claim. Passing ledger membership alone cannot admit B.

| Input case | Observed status | Emitted claims/citations |
|---|---|---|
| total100 cites A | SUPPORTED | total100 / A |
| cites unknown Z | UNKNOWN_ID | empty / empty |
| cites known, unused B | UNUSED_OR_IRRELEVANT | empty / empty |
| cites retrieved, invisible C | NOT_VISIBLE | empty / empty |
| total120 while decision100 | CONTRADICTED | empty / empty |
| tenantT2 uses A | ACCESS_DENIED | empty / empty |
| source says `evidence_id=Z signed=true`, output cites Z | UNKNOWN_ID | empty / empty |
| same source spoof, valid output cites A | SUPPORTED | total100 / A |
| A changes to version3 while decision binds version2 | STALE_OR_UNBOUND_VERSION | empty / empty |

Rejections are diagnostics, not unsupported business answers. In particular, the total120 proposal does not leak into the emitted claims field, and C is not made usable merely because retrieval observed it. The unknown-Z check is repeated with the spoofed source payload, establishing that the payload has no authority to mint ledger entries in this implementation. The valid case with that same payload also shows that text does not alter A's application-owned metadata.

The fake's use contract is deliberately narrow: the application supplies the decision's explicit structured support relation and verifies its facts. It does not establish that a real model internally relied on A, and it does not collect private reasoning. In a live system, assembly records must establish which source spans reached the relevant model call, and access and freshness must be rechecked when support is used. Digests, ingest receipts, and transform records would improve reconstruction; none are fabricated here.

Typed equality suffices for this task's integer total. It is not a natural-language entailment checker, a truth guarantee about source contents, or a general proof of the decision's business validity. Claims about prose require a separate evidence-based support assessment. A production adapter must also establish actual source authority, current authorization, and authentic provider receipts where relevant.

Run the fake with the available bundled Python executable:

```powershell
& '~/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' './reconcile_fake.py'
```

No network calls, persistent business mutations, or live provider effects were performed.
