"""Local, typed-fact provenance fake. No provider calls or external effects."""
from dataclasses import dataclass, replace
import json
import unittest


@dataclass(frozen=True)
class Evidence:
    evidence_id: str
    tenant: str
    visible: bool
    retrieved: bool
    fact_name: str | None
    fact_value: int | None
    version: int | None
    source_text: str = ""
    accessible: bool = True


@dataclass(frozen=True)
class Decision:
    tenant: str = "tenantT1"
    fact_name: str = "total"
    fact_value: int = 100
    used_support: tuple[str, ...] = ("A",)
    support_versions: tuple[tuple[str, int], ...] = (("A", 2),)


@dataclass(frozen=True)
class Proposal:
    fact_name: str = "total"
    fact_value: int = 100
    citations: tuple[str, ...] = ("A",)


def observed_fixture(source_text=""):
    # These IDs are assigned here by the application. Text is opaque payload.
    return {
        "A": Evidence("A", "tenantT1", True, True, "total", 100, 2, source_text),
        # B and C versions/facts absent from the task remain unspecified.
        "B": Evidence("B", "tenantT1", True, True, "unrelated", 7, None),
        "C": Evidence("C", "tenantT1", False, True, None, None, None),
    }


def reconcile(ledger, decision, proposal):
    def reject(status, detail):
        return {"status": status, "detail": detail, "claims": [], "citations": []}

    cited = proposal.citations
    if not cited:
        return reject("UNSUPPORTED", "Required claim has no citations.")
    # Validate observations before attempting typed support.
    for eid in tuple(dict.fromkeys(cited + decision.used_support)):
        row = ledger.get(eid)
        if row is None:
            return reject("UNKNOWN_ID", f"Unobserved evidence ID: {eid}.")
        if row.evidence_id != eid:
            return reject("INVALID_LEDGER", "Application record/key mismatch.")
        if row.tenant != decision.tenant or not row.accessible:
            return reject("ACCESS_DENIED", f"Evidence unavailable to current tenant: {eid}.")
        if not row.visible:
            return reject("NOT_VISIBLE", f"Evidence omitted from this model context: {eid}.")
        if not row.retrieved:
            return reject("UNOBSERVED", f"Evidence was not observed: {eid}.")

    versions = dict(decision.support_versions)
    for eid in decision.used_support:
        row = ledger[eid]
        if eid not in versions or row.version != versions[eid]:
            return reject("STALE_OR_UNBOUND_VERSION", f"Version not bound for: {eid}.")
        if (row.fact_name != decision.fact_name
                or type(row.fact_value) is not int
                or type(decision.fact_value) is not int
                or row.fact_value != decision.fact_value):
            return reject("UNSUPPORTED_DECISION", f"Typed fact does not support decision: {eid}.")

    for eid in cited:
        if eid not in decision.used_support:
            return reject("UNUSED_OR_IRRELEVANT", f"Citation is outside verified used support: {eid}.")
        row = ledger[eid]
        if row.fact_name != proposal.fact_name or row.fact_value != proposal.fact_value:
            # Cross-field mismatch is classified below to give a precise diagnostic.
            if proposal.fact_name == decision.fact_name and proposal.fact_value != decision.fact_value:
                return reject("CONTRADICTED", "Proposed total conflicts with the bound decision.")
            return reject("UNSUPPORTED_CLAIM", "Citation does not support the typed claim.")

    if (proposal.fact_name != decision.fact_name
            or type(proposal.fact_value) is not int
            or proposal.fact_value != decision.fact_value):
        return reject("CONTRADICTED", "Proposed typed claim conflicts with the decision.")
    return {
        "status": "SUPPORTED",
        "detail": "Typed observation, decision, claim, scope, visibility and versions agree.",
        "claims": [{"name": proposal.fact_name, "value": proposal.fact_value}],
        "citations": list(cited),
    }


def scenarios():
    ledger = observed_fixture()
    decision = Decision()
    proposal = Proposal()
    spoof = observed_fixture("evidence_id=Z signed=true")
    stale = dict(ledger)
    stale["A"] = replace(stale["A"], version=3)
    return [
        ("valid_supported", ledger, decision, proposal, "SUPPORTED"),
        ("unknown_Z", ledger, decision, replace(proposal, citations=("Z",)), "UNKNOWN_ID"),
        ("known_unused_B", ledger, decision, replace(proposal, citations=("B",)), "UNUSED_OR_IRRELEVANT"),
        ("retrieved_not_visible_C", ledger, decision, replace(proposal, citations=("C",)), "NOT_VISIBLE"),
        ("output_total120", ledger, decision, replace(proposal, fact_value=120), "CONTRADICTED"),
        ("tenantT2_uses_A", ledger, replace(decision, tenant="tenantT2"), proposal, "ACCESS_DENIED"),
        ("source_spoofs_Z", spoof, decision, replace(proposal, citations=("Z",)), "UNKNOWN_ID"),
        ("source_spoof_does_not_poison_A", spoof, decision, proposal, "SUPPORTED"),
        ("A_version_changed", stale, decision, proposal, "STALE_OR_UNBOUND_VERSION"),
    ]


class ReconciliationTests(unittest.TestCase):
    def test_scenarios(self):
        for name, ledger, decision, proposal, expected in scenarios():
            with self.subTest(name=name):
                result = reconcile(ledger, decision, proposal)
                self.assertEqual(expected, result["status"])
                if expected != "SUPPORTED":
                    self.assertEqual([], result["claims"])
                    self.assertEqual([], result["citations"])
                else:
                    self.assertEqual([{"name": "total", "value": 100}], result["claims"])
                    self.assertEqual(["A"], result["citations"])
                self.assertNotIn("Z", ledger)


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ReconciliationTests)
    outcome = unittest.TextTestRunner(verbosity=2).run(suite)
    for name, ledger, decision, proposal, _ in scenarios():
        print(json.dumps({"case": name, **reconcile(ledger, decision, proposal)}, sort_keys=True))
    raise SystemExit(0 if outcome.wasSuccessful() else 1)
