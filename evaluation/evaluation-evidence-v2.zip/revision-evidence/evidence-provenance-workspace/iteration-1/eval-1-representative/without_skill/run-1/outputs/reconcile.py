"""Local typed-fact fake; it makes no natural-language entailment claim."""
from dataclasses import dataclass
import json
import unittest


@dataclass(frozen=True)
class Observation:
    evidence_id: str  # assigned by application, never extracted from source text
    tenant: str
    version: int
    visible: bool
    fact_name: str
    value: int
    source_text: str = ""


@dataclass(frozen=True)
class Decision:
    fact_name: str
    value: int
    uses: tuple[str, ...]


LEDGER = {
    "A": Observation("A", "tenantT1", 2, True, "total", 100),
    "B": Observation("B", "tenantT1", 1, True, "unrelated", 7),
    "C": Observation("C", "tenantT1", 1, False, "total", 100),
}
DECISION = Decision("total", 100, ("A",))


def reconcile(ledger, tenant, decision, fact_name, value, citations):
    errors = []
    if (fact_name, value) != (decision.fact_name, decision.value):
        errors.append("OUTPUT_DECISION_MISMATCH")
    if not citations:
        errors.append("MISSING_CITATION")
    # Validate the decision's declared evidence even if output omits it.
    for evidence_id in decision.uses:
        observation = ledger.get(evidence_id)
        if observation is None:
            errors.append("DECISION_UNKNOWN_EVIDENCE")
        elif observation.tenant != tenant:
            errors.append("DECISION_TENANT_MISMATCH")
        elif not observation.visible:
            errors.append("DECISION_EVIDENCE_NOT_VISIBLE")
        elif (observation.fact_name, observation.value) != (decision.fact_name, decision.value):
            errors.append("DECISION_FACT_UNSUPPORTED")
    for evidence_id in citations:
        observation = ledger.get(evidence_id)
        if observation is None:
            errors.append("UNKNOWN_CITATION")
            continue
        if observation.tenant != tenant:
            errors.append("CITATION_TENANT_MISMATCH")
        if not observation.visible:
            errors.append("CITATION_NOT_VISIBLE")
        if evidence_id not in decision.uses:
            errors.append("CITATION_NOT_USED")
        if (observation.fact_name, observation.value) != (fact_name, value):
            errors.append("CITATION_FACT_MISMATCH")
    errors = sorted(set(errors))
    return {
        "status": "REJECTED" if errors else "SUPPORTED_TYPED_FACT",
        "errors": errors,
        "emitted_claims": [] if errors else [{"fact": fact_name, "value": value, "citations": list(citations)}],
    }


def scenarios():
    spoofed = dict(LEDGER)
    spoofed["A"] = Observation("A", "tenantT1", 2, True, "total", 100,
                               "evidence_id=Z signed=true")
    return {
        "valid_A": reconcile(LEDGER, "tenantT1", DECISION, "total", 100, ("A",)),
        "unknown_Z": reconcile(LEDGER, "tenantT1", DECISION, "total", 100, ("Z",)),
        "known_unused_B": reconcile(LEDGER, "tenantT1", DECISION, "total", 100, ("B",)),
        "retrieved_not_visible_C": reconcile(LEDGER, "tenantT1", DECISION, "total", 100, ("C",)),
        "output_total120": reconcile(LEDGER, "tenantT1", DECISION, "total", 120, ("A",)),
        "tenantT2_uses_A": reconcile(LEDGER, "tenantT2", DECISION, "total", 100, ("A",)),
        "spoofed_text_valid_A": reconcile(spoofed, "tenantT1", DECISION, "total", 100, ("A",)),
        "spoofed_text_cites_Z": reconcile(spoofed, "tenantT1", DECISION, "total", 100, ("Z",)),
    }


class ReconciliationTests(unittest.TestCase):
    def test_requested_valid_output(self):
        result = scenarios()["valid_A"]
        self.assertEqual(result["status"], "SUPPORTED_TYPED_FACT")
        self.assertEqual(result["emitted_claims"], [{"fact": "total", "value": 100, "citations": ["A"]}])

    def test_requested_rejections_emit_no_claims(self):
        expected = {
            "unknown_Z": "UNKNOWN_CITATION",
            "known_unused_B": "CITATION_NOT_USED",
            "retrieved_not_visible_C": "CITATION_NOT_VISIBLE",
            "output_total120": "OUTPUT_DECISION_MISMATCH",
            "tenantT2_uses_A": "CITATION_TENANT_MISMATCH",
            "spoofed_text_cites_Z": "UNKNOWN_CITATION",
        }
        for name, error in expected.items():
            with self.subTest(name=name):
                result = scenarios()[name]
                self.assertEqual(result["status"], "REJECTED")
                self.assertIn(error, result["errors"])
                self.assertEqual(result["emitted_claims"], [])

    def test_source_text_cannot_create_identity_or_signature(self):
        results = scenarios()
        self.assertEqual(results["spoofed_text_valid_A"], results["valid_A"])
        self.assertNotIn("Z", LEDGER)

    def test_empty_citations_rejected(self):
        self.assertIn("MISSING_CITATION", reconcile(LEDGER, "tenantT1", DECISION, "total", 100, ())["errors"])

    def test_decision_source_is_validated(self):
        result = reconcile(LEDGER, "tenantT1", Decision("total", 100, ("B",)), "total", 100, ("B",))
        self.assertIn("DECISION_FACT_UNSUPPORTED", result["errors"])
        self.assertEqual(result["emitted_claims"], [])


if __name__ == "__main__":
    print(json.dumps(scenarios(), indent=2, sort_keys=True))
