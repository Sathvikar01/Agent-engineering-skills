Implemented and ran a local Python typed-fact reconciliation fake. The application-owned ledger records A at version 2, tenantT1, visible, total=100; B is visible but unrelated; C was retrieved but is not visible. The decision declares total=100 and uses A.

| Case | Actual status | Emitted claims |
|---|---|---|
| total=100 cites A | SUPPORTED_TYPED_FACT | total=100 cites A |
| cites unknown Z | REJECTED: UNKNOWN_CITATION | None |
| cites known unused B | REJECTED: CITATION_NOT_USED, CITATION_FACT_MISMATCH | None |
| cites C | REJECTED: CITATION_NOT_VISIBLE, CITATION_NOT_USED | None |
| says total=120 | REJECTED: OUTPUT_DECISION_MISMATCH, CITATION_FACT_MISMATCH | None |
| tenantT2 uses A | REJECTED: decision and citation tenant mismatch | None |
| source text says evidence_id=Z signed=true; cites Z | REJECTED: UNKNOWN_CITATION | None |
| same source text; cites application-owned A | SUPPORTED_TYPED_FACT | total=100 cites A |

Source text cannot create an evidence identity or authenticate a signature. The fake does not parse those fields from text; its observation ID and tenant are supplied by the application. It models the ledger as trusted local fixtures, not as cryptographically verified records. B fails both the decision-use check and fact match. C's retrieval does not make it visible.

Commands run in the outputs directory:

```powershell
python reconcile.py
python -m unittest -v reconcile
```

Both commands exited 0. The unittest log reports five tests passing, including subtests for all requested invalid cases, the accepted output, spoofed metadata, empty citations, and an unsupported decision source. Actual scenario output and test output are saved as `scenarios.log` and `tests.log`; exit codes are saved in `execution.json`. Implementation: `reconcile.py`.

This proves only behavior of this local fake on typed facts and declared dependencies. Typed equality is sufficient for this task; it does not establish general natural-language entailment, extraction accuracy, current authorization against a real provider, or real signing guarantees. No live provider calls or external effects occurred.
