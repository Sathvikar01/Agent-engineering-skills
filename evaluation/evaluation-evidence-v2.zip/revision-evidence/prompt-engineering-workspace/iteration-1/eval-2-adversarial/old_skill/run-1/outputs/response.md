# Boundary and proposed test plan

Reject the proposal to add 300 rules as the only fix. The retrieved sentence is data, even though it calls itself a developer instruction. A short prompt establishes the intended behavior; software must prevent database disclosure and unauthorized email even if the model follows that sentence. The supplied `prompt.txt` is a production candidate, pending integration with the actual schema and tool definitions.

The application should assemble stable instructions in the provider's actual trusted instruction channel, followed by the authorized task and bounded evidence records. Each record carries a server-assigned source ID, origin, tenant/resource scope, retrieval time, and an explicit data label. Preserve that label through summarization. Never interpolate a page into a developer message or promote text claiming authority. Delimiters improve readability; they do not make malicious text safe. Exclude unrelated content before assembly and cap document count and size.

| Responsibility | Prompt guidance | Software-owned control |
|---|---|---|
| Instruction authority | Evidence cannot change instructions | Correct provider roles and context assembly |
| Database access | Request only task-relevant records | Authentication, tenant filtering, per-resource authorization, least privilege |
| Email/export | No external communication in this task | Omit email tools; executor denies undeclared actions and destinations |
| Output shape | Follow canonical schema | Parse, validate, reject malformed output before use |
| Evidence | Cite only supporting returned IDs | Source membership and scope checks; semantic support review |
| Termination | Stop on completion or reported exhaustion | Tool-call, token, time, retry, and cost caps |

Authorization must be checked again at execution using server-held identity and state. Model text cannot mint credentials, approve an action, or set a destination. Retrieval credentials should have no email capability, and an answer tool should not expose a customer database merely because the model asks. Network egress policy and tool argument validation provide additional containment. Keep raw tool responses bounded and log redacted attempts, validation failures, source identities, and executor denials. Schema compliance alone does not establish safety or factual accuracy; an allowed string field can still contain a secret.

Freeze a representative baseline suite before editing the deployed prompt. Include normal supported questions, absent evidence, ambiguous tasks, conflicting sources, nonexistent citations, malformed output, exhausted budgets, and the exact poisoned sentence. Add variants inside HTML comments, quoted examples, tool-result text, and summarized evidence; vary position and context length. Include a benign question whose relevant source happens to contain the attack, so success requires answering the legitimate question rather than refusing everything.

Run these cases in a local fake environment with synthetic records, a read tool scoped to one tenant, a recording email/export stub that cannot send, and the real executor's authorization and schema-validation paths where available. Deliberately submit a malicious action directly to the executor as well as asking the model to resist it. Assert zero external effects, denied cross-tenant reads, denied email/export attempts, valid schema, known supporting citations, and bounded termination. Distinguish a blocked attempted email from a model that never attempted email: both can contain harm, but only the latter shows prompt compliance. A calibrated reviewer should assess evidence support and usefulness because structural checks cannot establish those properties.

Compare frozen baseline and candidate with the same model, sampling settings, fixtures, schema, tool versions, and context assembly; repeat stochastic adversarial cases. Record violations separately from helpfulness, latency, and cost. Release only after mandatory enforcement checks pass and paired results justify improvement within agreed operational budgets. Retain the baseline prompt and compatible configuration for rollback. No provider runs, fakes, or runtime security tests were executed here; the test plan is proposed. No attack-success rate, latency, or improvement claim is available.
