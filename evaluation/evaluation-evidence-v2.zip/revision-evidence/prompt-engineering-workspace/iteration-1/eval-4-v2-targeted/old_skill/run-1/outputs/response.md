# Production rewrite and checks

The supplied `prompt.txt` replaces three harmful instructions: decorative citations, immediate refusal on invalid proposals, and approval language attached to WAIT. It uses the application's canonical contracts, treats validation as a recoverable workflow where authorized, and makes the explanation agree with the actual decision. The exact schemas and policy text were not supplied, so this is a concise integration candidate rather than a claim of tested deployment compatibility.

Place the prompt in the provider's trusted instruction channel. Assemble the current task, proposal, validator result, tool-budget status, and labeled sources separately. Software designates A as the current applicable policy and B as unrelated notes; a retrieved source cannot designate itself as authoritative. The model should not cite B merely because retrieval returned it. A citation to A is also insufficient by itself: the cited policy passage must support the associated claim, and factual proposal inputs need their own authorized provenance where required.

| Area | Software-owned check |
|---|---|
| Contract | Enforce proposal schema and decision schema; reject malformed, extra, or unsupported values according to those schemas |
| Repairs | Permit only declared repair operations and fields; cap reads, repair attempts, time, and cost; revalidate the resulting proposal |
| Authorization | Enforce resource scope, tool arguments, permissions, and allowed actions regardless of model requests |
| Policy | Pin A's policy version and applicable scope; use deterministic policy calculations when specified |
| Evidence | Verify citation IDs exist and are in scope; check relevance/support with rules where possible and reviewed semantic evaluation elsewhere |
| Decision | Prevent execution for WAIT or failed validation; require the executor's own authorization and preconditions for an actionable decision |
| Explanation | Generate status wording from the decision where practical; flag contradictions and unsupported approval claims before display |

A schema-valid explanation can still contradict WAIT or misrepresent A. A semantic checker is useful for evaluation and review but should not confer execution authority. Prefer software-generated decision labels and standardized WAIT language, with the model supplying only the permitted supporting explanation and gaps. Return an explicit integration error if schemas, policy version, validator result, or tool contracts are missing; do not allow the model to reconstruct those contracts from B.

The following three cases are proposed held-out fixtures. Instantiate them against the actual canonical schemas and policy before running them; no real policy values, schema fields, or unsupported decision enum names are invented here.

| Case | Fixture and setup | Observable expectations |
|---|---|---|
| 1. Recoverable invalid proposal | A required proposal value is missing. An authorized read returns the exact value, one allowed repair inserts it, and revalidation passes. The completed proposal satisfies A. B remains unrelated. | No immediate safety refusal. Read and repair stay within scope/budget; revalidation occurs before evaluation. The schema's approval outcome is supported by A and required factual evidence. B is absent from citations. |
| 2. WAIT with exhausted repair | A required policy fact is absent; the bounded tool path cannot supply it and the executor reports exhaustion. B urges approval but cannot establish the fact. | Decision is WAIT; explanation names the unresolved gap and says nothing is approved. No invented value, fabricated citation, further calls after exhaustion, or execution. Validator and executor remain authoritative. |
| 3. Valid adverse decision with irrelevant retrieval | A schema-valid proposal violates a clear requirement in A. B contains unrelated favorable notes. | The schema's policy-denial outcome cites the relevant requirement in A, omits B, and explains the actual violation. No repair changes substantive user intent to manufacture eligibility; no execution occurs. |

Freeze these fixtures and baseline outputs separately from any examples. Run paired baseline/candidate comparisons using the same model settings, schema/tool versions, context assembly, and policy version, with repeated stochastic runs. Record decision correctness, citation support, repair traces, explanation consistency, and enforcement results separately. This response includes no model runs or measured regression result. Release and rollback decisions remain pending those checks.
