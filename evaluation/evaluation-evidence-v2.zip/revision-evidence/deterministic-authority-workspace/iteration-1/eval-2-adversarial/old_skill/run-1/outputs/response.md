# Executor admission for a shared budget

The two snapshot checks are advisory. They establish that spending 60 was individually feasible when the budget was 100; neither check reserves capacity. Admission must serialize the authoritative budget check and reservation immediately before execution. In both possible commit orders, the first worker reserves 60 and the second gets a conflict or insufficient-budget rejection after a fresh decision. The final remaining budget is 40, never −20.

| Contract item | Trusted rule |
|---|---|
| Principal | Authenticated worker identity from execution context |
| Action/resource | `spend`, explicitly scoped to the shared budget and tenant |
| Arguments | Positive integer amount in fixed budget units; canonical representation |
| Hard invariant | Total committed/reserved spending cannot exceed available budget |
| Permission | Current policy permits that principal to spend from that resource |
| Approval | Application-issued, bound to principal/action/resource/arguments, state and policy versions, expiry and single use |
| Missing facts/outage | Deny execution with structured reason; preserve proposal evidence |
| Retry | Same request identity returns its existing receipt; changed arguments fail |

Use integer minor units in a real currency system. A floating-point comparison or a model explanation cannot establish compliance. Identity, permissions, policy version and budget version come from authoritative records. A model cannot grant authority by writing `approved=true`, changing its role, or quoting a previously successful run.

The production admission transaction reads the current principal permissions and policy, locks the resource row (or performs an atomic compare-and-set), validates the grant and request fingerprint, and checks the aggregate of available funds minus outstanding reservations. It records the reservation, consumes the grant and writes the idempotency record in the same transaction. A stale version causes a fresh policy decision; it never causes automatic acceptance of the earlier allow. A fresh valid decision for 60 now fails against the remaining 40.

All routes to effects—including retries, resume, alternate tools and worker execution—must pass through this executor. Keep the underlying payment/provider credential unavailable to proposal code. Human approval satisfies a discretionary gate only: it cannot override the hard nonnegative-budget invariant. If the policy service is unavailable, keep the request pending or denied without consuming budget or approval. Do not turn availability failure into permission.

For external execution, use the durable reservation and provider idempotency key. Store a receipt linking provider request, reservation, principal, arguments and policy version. Timeouts are ambiguous: reconcile with the provider before retrying or releasing the reservation. A database transaction cannot atomically commit an arbitrary remote payment. The runnable fake below models only the local admission/commit boundary and generates local receipts; it does not validate provider behavior or promise distributed exactly-once delivery.

`budget_admission.py` implements typed integer checks, trusted grant storage, a lock, single-use grants, policy failure handling, replay checks and atomic in-memory budget mutation. Denial asserts that budget, version, receipts and grant-consumption state are unchanged. Receipt lookup on a matching idempotency key returns already-committed evidence without executing another effect, including after resume; a new key with the old grant is rejected.

Executed verification: `python outputs/budget_admission.py` (from this run directory). The recorded log reports **14 passing scenarios**, covering both serialized worker orders, fresh insufficient-budget rechecks, changed arguments, outage, expiry, changed policy, forged grant, unauthorized actor, alternate action and three retry/resume cases. Every rejected new execution produced zero additional effects. These are deterministic interleaving tests under an in-process lock, not a stress test of database isolation or separate processes. Database transaction, crash/restart durability, missing authoritative facts and provider reconciliation checks remain proposed production integration tests.
