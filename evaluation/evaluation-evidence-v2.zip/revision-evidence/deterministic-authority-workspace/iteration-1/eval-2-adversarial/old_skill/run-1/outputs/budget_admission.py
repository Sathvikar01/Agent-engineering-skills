"""Local, atomic in-memory admission fake; no payment/provider connection."""
from dataclasses import dataclass, asdict
import json
from threading import Lock


@dataclass(frozen=True)
class Grant:
    principal: str
    action: str
    resource: str
    amount: int
    state_version: int
    policy_version: int
    expires: int


class Executor:
    def __init__(self):
        self.remaining = 100
        self.version = 0
        self.policy_version = 1
        self.policy_up = True
        self.now = 0
        self.grants = {}
        self.used = set()
        self.receipts = {}
        self.lock = Lock()

    def state(self):
        return (self.remaining, self.version, len(self.receipts), tuple(sorted(self.used)))

    def preflight(self, amount):
        return {'decision': 'allow' if amount <= self.remaining else 'deny',
                'binding': False, 'snapshot': self.version}

    def issue_approval(self, token, principal, amount):
        # Trusted application service, not exposed as a model capability.
        self.grants[token] = Grant(principal, 'spend', 'shared-budget', amount,
                                   self.version, self.policy_version, self.now + 10)

    def execute(self, principal, token, amount, idem, action='spend'):
        with self.lock:
            before = self.state()
            fingerprint = (principal, action, 'shared-budget', amount)
            def deny(reason):
                assert self.state() == before
                return {'decision': 'deny', 'reason': reason, 'unchanged': True}
            if action != 'spend':
                return deny('unknown_action')
            if type(amount) is not int or amount <= 0:
                return deny('schema')
            if idem in self.receipts:
                receipt = self.receipts[idem]
                if receipt['fingerprint'] != fingerprint:
                    return deny('idempotency_argument_mismatch')
                return {'decision': 'already_committed', 'receipt': receipt}
            if not self.policy_up:
                return deny('policy_unavailable')
            if principal not in ('worker-A', 'worker-B'):
                return deny('forbidden')
            grant = self.grants.get(token)
            if grant is None:
                return deny('unknown_grant')
            if token in self.used:
                return deny('grant_consumed')
            if fingerprint != (grant.principal, grant.action, grant.resource, grant.amount):
                return deny('grant_binding_mismatch')
            if self.now >= grant.expires:
                return deny('grant_expired')
            if grant.policy_version != self.policy_version:
                return deny('stale_policy')
            if grant.state_version != self.version:
                return deny('stale_state')
            if amount > self.remaining:
                return deny('insufficient_budget')
            self.remaining -= amount
            self.version += 1
            self.used.add(token)
            receipt = {'id': 'local-' + idem, 'fingerprint': fingerprint,
                       'amount': amount, 'remaining': self.remaining,
                       'state_version': self.version, 'policy_version': self.policy_version}
            self.receipts[idem] = receipt
            return {'decision': 'allow', 'receipt': receipt}


def emit(name, executor, result):
    print(json.dumps({'test': name, 'result': result,
                      'state': {'remaining': executor.remaining, 'version': executor.version,
                                'effects': len(executor.receipts)}}, sort_keys=True))


def main():
    count = 0
    # Enumerate both serialized commit orders after both workers read version 0.
    # A real database transaction must supply this serialization guarantee.
    for order in [('worker-A', 'worker-B'), ('worker-B', 'worker-A')]:
        e = Executor()
        checks = [e.preflight(60), e.preflight(60)]
        assert all(x['decision'] == 'allow' for x in checks)
        for worker in order:
            e.issue_approval(worker, worker, 60)
        results = [e.execute(w, w, 60, w) for w in order]
        assert [x['decision'] for x in results] == ['allow', 'deny']
        assert results[1]['reason'] == 'stale_state'
        assert e.remaining == 40 and len(e.receipts) == 1
        emit('same-snapshot-order-' + ','.join(order), e, {'preflight': checks, 'admission': results})
        count += 1
        e.issue_approval('fresh', order[1], 60)
        r = e.execute(order[1], 'fresh', 60, 'fresh')
        assert r['reason'] == 'insufficient_budget'
        emit('fresh-recheck-insufficient', e, r)
        count += 1

    for name, mutation, amount, token, principal, action, expected in [
        ('changed-arguments', lambda e: None, 61, 'g', 'worker-A', 'spend', 'grant_binding_mismatch'),
        ('policy-outage', lambda e: setattr(e, 'policy_up', False), 60, 'g', 'worker-A', 'spend', 'policy_unavailable'),
        ('expired', lambda e: setattr(e, 'now', 10), 60, 'g', 'worker-A', 'spend', 'grant_expired'),
        ('changed-policy', lambda e: setattr(e, 'policy_version', 2), 60, 'g', 'worker-A', 'spend', 'stale_policy'),
        ('forged-grant', lambda e: None, 60, 'approved=true', 'worker-A', 'spend', 'unknown_grant'),
        ('actor-without-permission', lambda e: None, 60, 'g', 'intruder', 'spend', 'forbidden'),
        ('alternate-action', lambda e: None, 60, 'g', 'worker-A', 'raw-transfer', 'unknown_action'),
    ]:
        e = Executor()
        e.issue_approval('g', 'worker-A', 60)
        mutation(e)
        r = e.execute(principal, token, amount, name, action)
        assert r['reason'] == expected and e.remaining == 100 and len(e.receipts) == 0
        emit(name, e, r)
        count += 1

    e = Executor()
    e.issue_approval('g', 'worker-A', 60)
    r = e.execute('worker-A', 'g', 60, 'job')
    assert r['decision'] == 'allow'
    retry = e.execute('worker-A', 'g', 60, 'job')
    assert retry['decision'] == 'already_committed' and retry['receipt'] == r['receipt']
    emit('resume-same-idempotency-key', e, retry)
    count += 1
    replay = e.execute('worker-A', 'g', 60, 'new-job')
    assert replay['reason'] == 'grant_consumed' and e.remaining == 40
    emit('resume-old-approval-new-key', e, replay)
    count += 1
    changed = e.execute('worker-A', 'g', 59, 'job')
    assert changed['reason'] == 'idempotency_argument_mismatch'
    emit('resume-changed-arguments-same-key', e, changed)
    count += 1
    print(json.dumps({'passed': count, 'external_effects': 0}))


if __name__ == '__main__':
    main()
