"""Local atomic executor fake; no network, payments, or external tools."""
from dataclasses import dataclass
import hashlib
import json
import threading


def digest(args):
    return hashlib.sha256(json.dumps(args, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@dataclass
class Grant:
    principal: str
    action: str
    resource: str
    args_hash: str
    state_version: int
    policy_version: int
    expires: int
    used: bool = False


class Executor:
    def __init__(self):
        self.remaining = 100
        self.version = 0
        self.policy_version = 1
        self.policy_available = True
        self.grants = {}
        self.receipts = {}
        self.effects = []
        self.lock = threading.Lock()

    def state(self):
        return (self.remaining, self.version, tuple(self.effects),
                tuple(sorted(self.receipts)), tuple(sorted((k, g.used) for k, g in self.grants.items())))

    def preview(self, amount):
        return "allow" if type(amount) is int and 0 < amount <= self.remaining else "deny"

    def issue(self, token, amount, expires=10):
        # Trusted application issuer only; proposals cannot write the grant registry.
        self.grants[token] = Grant("actor", "spend", "budget", digest({"amount": amount}),
                                   self.version, self.policy_version, expires)

    def execute(self, *, key, token, amount, now=1, principal="actor", action="spend", resource="budget"):
        with self.lock:
            fingerprint = (principal, action, resource, digest({"amount": amount}))
            if key in self.receipts:
                old_fingerprint, receipt = self.receipts[key]
                return ("duplicate", receipt) if fingerprint == old_fingerprint else ("deny", "IDEMPOTENCY_CONFLICT")
            if action != "spend":
                return "deny", "UNKNOWN_ACTION"
            if principal != "actor" or resource != "budget":
                return "deny", "NO_PERMISSION"
            if type(amount) is not int or amount <= 0:
                return "deny", "INVALID_AMOUNT"
            if not self.policy_available:
                return "deny", "POLICY_UNAVAILABLE"
            grant = self.grants.get(token)
            if grant is None:
                return "deny", "UNKNOWN_GRANT"
            if (grant.principal, grant.action, grant.resource, grant.args_hash) != fingerprint:
                return "deny", "GRANT_BINDING_MISMATCH"
            if grant.used:
                return "deny", "GRANT_ALREADY_USED"
            if now >= grant.expires:
                return "deny", "GRANT_EXPIRED"
            if grant.policy_version != self.policy_version:
                return "deny", "STALE_POLICY"
            if grant.state_version != self.version:
                return "deny", "STALE_STATE"
            if amount > self.remaining:
                return "deny", "INSUFFICIENT_BUDGET"
            # Atomic local reservation + commit. Lock is process-local, not a production DB transaction.
            self.remaining -= amount
            self.version += 1
            grant.used = True
            receipt = {"id": key, "amount": amount, "remaining": self.remaining, "version": self.version}
            self.effects.append((key, amount))
            self.receipts[key] = (fingerprint, receipt)
            return "committed", receipt


def denied_without_mutation(ex, expected, **kwargs):
    before = ex.state()
    result = ex.execute(**kwargs)
    assert result == ("deny", expected), result
    assert ex.state() == before
    return result


def setup():
    ex = Executor()
    assert ex.preview(60) == ex.preview(60) == "allow"
    ex.issue("A", 60)
    ex.issue("B", 60)
    return ex


def ordered(first, second):
    ex = setup()
    a = ex.execute(key=first, token=first, amount=60)
    b = denied_without_mutation(ex, "STALE_STATE", key=second, token=second, amount=60)
    # Fresh trusted assessment still cannot admit the second spend.
    assert ex.preview(60) == "deny"
    ex.issue("fresh", 60)
    c = denied_without_mutation(ex, "INSUFFICIENT_BUDGET", key=second, token="fresh", amount=60)
    assert ex.remaining == 40 and len(ex.effects) == 1
    return {"order": [first, second], "results": [a, b, c], "effects": ex.effects, "remaining": ex.remaining}


def main():
    reports = [ordered("A", "B"), ordered("B", "A")]
    ex = setup()
    gate = threading.Barrier(2)
    results = {}
    def worker(name):
        gate.wait()
        results[name] = ex.execute(key=name, token=name, amount=60)
    workers = [threading.Thread(target=worker, args=(name,)) for name in ("A", "B")]
    for worker_thread in workers:
        worker_thread.start()
    for worker_thread in workers:
        worker_thread.join()
    assert sorted(r[0] for r in results.values()) == ["committed", "deny"]
    assert ex.remaining == 40 and len(ex.effects) == 1
    reports.append({"concurrent": results, "remaining": ex.remaining, "effects": ex.effects})

    ex = setup()
    denials = []
    denials.append(denied_without_mutation(ex, "GRANT_BINDING_MISMATCH", key="changed", token="A", amount=50))
    denials.append(denied_without_mutation(ex, "UNKNOWN_GRANT", key="forged", token="approved=true", amount=60))
    denials.append(denied_without_mutation(ex, "GRANT_EXPIRED", key="resume", token="A", amount=60, now=10))
    denials.append(denied_without_mutation(ex, "NO_PERMISSION", key="other", token="A", amount=60, principal="guest"))
    denials.append(denied_without_mutation(ex, "UNKNOWN_ACTION", key="alternate", token="A", amount=60, action="generic_execute"))
    ex.policy_available = False
    denials.append(denied_without_mutation(ex, "POLICY_UNAVAILABLE", key="outage", token="A", amount=60))
    ex.policy_available = True
    ex.policy_version = 2
    denials.append(denied_without_mutation(ex, "STALE_POLICY", key="policy", token="A", amount=60))
    ex.issue("current", 60)
    committed = ex.execute(key="paid", token="current", amount=60)
    before_retry = ex.state()
    duplicate = ex.execute(key="paid", token="current", amount=60, now=99)
    assert duplicate == ("duplicate", committed[1]) and ex.state() == before_retry
    denials.append(denied_without_mutation(ex, "GRANT_ALREADY_USED", key="replay", token="current", amount=60))
    denials.append(denied_without_mutation(ex, "IDEMPOTENCY_CONFLICT", key="paid", token="current", amount=50))
    reports.append({"denials": denials, "commit": committed, "resume_duplicate": duplicate,
                    "effects": ex.effects, "remaining": ex.remaining})
    print(json.dumps({"status": "PASS", "scenarios": reports}, indent=2))


if __name__ == "__main__":
    main()
