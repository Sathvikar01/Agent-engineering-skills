# Executor admission for concurrent spending

Treat both snapshot `allow` results as previews. Neither worker owns spending authority until the trusted executor reserves budget atomically. With a shared budget of 100 and proposals of 60 each, at most one proposal can commit; the second must receive a fresh decision against the remaining 40.

| Action or fact | Trusted source | Admission rule |
|---|---|---|
| Spend amount | Typed proposal, integer units | Positive integer; no boolean coercion |
| Principal and resource | Authenticated execution context | Principal has spend permission for this budget and tenant |
| Remaining budget | Authoritative transactional store | Amount cannot exceed unreserved remaining funds |
| Policy | Versioned trusted policy service | Available, complete, current; errors fail closed |
| Approval grant | Application-issued registry | Bound to principal, action, resource, canonical arguments, state/policy versions, expiry, one use |
| Retry identity | Durable executor ledger | Same key and arguments return existing receipt; changed arguments deny |

Use an executor accepting a typed request, authenticated context, grant identifier and stable idempotency key. Bound parsing size, reject unknown actions and invalid schemas, then check semantic constraints, permissions, policy and any required approval. A model's `approved=true`, supplied role or remembered approval is never a grant. Human approval also cannot waive a hard budget invariant. In this design, grant issuance is a trusted service capability unavailable to proposals.

Inside one database transaction, lock the relevant budget and grant rows, check the idempotency ledger, re-evaluate authoritative policy and current facts, and validate the grant bindings. Atomically reserve the amount, consume the grant and persist the execution intent. A state or policy version mismatch returns a conflict; obtain a fresh decision rather than accepting the old approval. If the fresh amount remains 60 after the first commit, deny for insufficient budget. Do not quietly change it to 40.

Production execution should persist an outbox intent before calling the external tool. The reservation reduces available funds immediately; successful delivery converts it to spent funds without deducting again. Release reservations only after authoritative cancellation or confirmed failure. A timeout with unknown delivery status retains the reservation and reconciles by stable operation identity. Store a provider receipt before the deterministic completion transition. Provider idempotency or reconciliation is necessary: a local transaction cannot guarantee an external payment executes exactly once. The same admission path must serve resumed workers, retries and alternate tools; no generic execution endpoint may bypass it.

`admission_fake.py` implements the local admission boundary with a lock, trusted grant registry, atomic local effects and an idempotency ledger. Its actual executed assertions covered:

| Interleaving or adversarial case | Observed result |
|---|---|
| A then B; B then A | First commits 60; second gets `STALE_STATE`; fresh check denies insufficient budget |
| Two threads after a barrier | B committed in this run; A denied; remaining 40, one effect |
| Changed amount under old grant | `GRANT_BINDING_MISMATCH`, state unchanged |
| Expired approval after resume | `GRANT_EXPIRED`, state unchanged |
| Consumed approval with new key | `GRANT_ALREADY_USED`, state unchanged |
| Resume using original key and arguments | Existing receipt returned; no second effect |
| Same key with changed amount | `IDEMPOTENCY_CONFLICT`, state unchanged |
| Forged grant, unauthorized actor, alternate action | Denied, state unchanged |
| Policy outage or changed policy version | Denied, state unchanged |

Execution: `python outputs/admission_fake.py` from this run directory, equivalently the workspace-relative command recorded in `transcript.md`. Python 3.11.9 returned exit code 0 and `PASS`; `test.log` contains the actual JSON results. Every tested denial compares business state, grant-use state, receipts and effects before and after.

The lock proves only in-process fake interleavings. This run does not verify distributed transactions, tenant resolution, grant cryptography, missing-fact handling, live policy access or external provider behavior. Those boundaries require integration checks, crash injection and receipt reconciliation before production deployment.
