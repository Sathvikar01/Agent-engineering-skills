"""Bounded, deterministic, local fake. No real payments or network calls."""
from dataclasses import dataclass, field
import copy
import json


@dataclass(frozen=True)
class Context:
    actor: str
    can_choose_plan: bool
    total: int = 100
    earliest_day: int = 1
    deadline_day: int = 30
    policy_version: int = 1
    policy_available: bool = True
    approval_required: bool = False


@dataclass
class FakeState:
    version: int = 0
    remaining: int = 100
    plan: dict | None = None
    effects: list = field(default_factory=list)
    receipts: dict = field(default_factory=dict)


def parse(candidate):
    if type(candidate) is not dict or set(candidate) - {"amounts", "days", "approved"}:
        return None, "INVALID_SCHEMA"
    if "approved" in candidate and type(candidate["approved"]) is not bool:
        return None, "INVALID_SCHEMA"
    amounts, days = candidate.get("amounts"), candidate.get("days")
    if type(amounts) is not list or type(days) is not list or len(amounts) != 2 or len(days) != 2:
        return None, "INVALID_SCHEMA"
    if any(type(n) is not int for n in amounts + days):
        return None, "INVALID_SCHEMA"
    # Model approval is advisory metadata, discarded before policy evaluation.
    return {"amounts": amounts.copy(), "days": days.copy()}, None


def admission(context, state, candidate):
    plan, error = parse(candidate)
    if error:
        return None, error
    if not context.policy_available:
        return None, "POLICY_UNAVAILABLE"
    if not context.can_choose_plan:
        return None, "NO_PERMISSION"
    if context.earliest_day >= context.deadline_day:
        return None, "IMPOSSIBLE_DATES"  # Two strictly increasing integer days required.
    if any(n <= 0 for n in plan["amounts"]):
        return None, "INVALID_AMOUNT"
    if sum(plan["amounts"]) != context.total:
        return None, "INVALID_TOTAL"
    if not context.earliest_day <= plan["days"][0] < plan["days"][1] <= context.deadline_day:
        return None, "INVALID_DATES"
    if state.plan is not None or state.remaining < context.total:
        return None, "STATE_CONFLICT"
    if context.approval_required:
        return None, "NEEDS_TRUSTED_APPROVAL"
    return plan, "ALLOW"


def execute_fake(context, state, candidate, key, expected_version):
    # Single-thread fake; production must place this entire function in a DB transaction/CAS.
    plan, schema_error = parse(candidate)
    if schema_error:
        return "deny", schema_error
    fingerprint = (context.actor, json.dumps(plan, sort_keys=True))
    if key in state.receipts:
        previous_fingerprint, receipt = state.receipts[key]
        return ("duplicate", receipt) if previous_fingerprint == fingerprint else ("deny", "IDEMPOTENCY_CONFLICT")
    if expected_version != state.version:
        return "deny", "STALE_STATE"
    admitted, decision = admission(context, state, candidate)
    if decision != "ALLOW":
        return "deny", decision
    state.plan = copy.deepcopy(admitted)
    state.remaining -= context.total
    state.version += 1
    # This records a fake reservation/plan; it sends no installments.
    effect = {"kind": "fake_plan_reserved", "actor": context.actor, "plan": admitted, "total": context.total}
    state.effects.append(effect)
    receipt = {"id": key, "state_version": state.version, "policy_version": context.policy_version, "effect": effect}
    state.receipts[key] = (fingerprint, receipt)
    return "committed", receipt


def controller(context, state, proposal, trusted_alternative, key, max_candidates=2):
    if type(max_candidates) is not int or max_candidates != 2:
        raise ValueError("This fake enforces exactly two candidate slots")
    events = []
    candidates = [proposal]
    for attempt in range(max_candidates):
        if attempt >= len(candidates):
            break
        candidate = candidates[attempt]
        before = copy.deepcopy(state.__dict__)
        result = execute_fake(context, state, candidate, key, state.version)
        after = copy.deepcopy(state.__dict__)
        events.append({"attempt": attempt + 1, "candidate": candidate, "result": result,
                       "before": before, "after": after})
        if result[0] in ("committed", "duplicate"):
            return {"status": result[0], "events": events}
        assert after == before, "Rejected candidate mutated business state"
        if result[1] not in {"INVALID_TOTAL", "INVALID_DATES", "INVALID_AMOUNT"}:
            break
        if trusted_alternative is not None and attempt == 0:
            # Trusted actor permission includes choosing any valid plan; every alternative re-enters admission.
            candidates.append(copy.deepcopy(trusted_alternative))
    return {"status": "no_admissible_candidate", "events": events}


def main():
    proposal = {"amounts": [40, 40], "days": [10, 20]}
    alternative = {"amounts": [40, 60], "days": [10, 20]}
    reports = []
    state = FakeState()
    allowed = Context("authorized-actor", True)
    result = controller(allowed, state, proposal, alternative, "chosen-plan")
    assert result["status"] == "committed"
    assert len(result["events"]) == 2 and result["events"][0]["result"] == ("deny", "INVALID_TOTAL")
    assert state.plan == alternative and state.remaining == 0 and len(state.effects) == 1
    reports.append({"case": "repair_then_admit", **result})
    retry_before = copy.deepcopy(state.__dict__)
    retry = execute_fake(allowed, state, alternative, "chosen-plan", state.version)
    assert retry[0] == "duplicate" and state.__dict__ == retry_before
    reports.append({"case": "retry", "result": retry, "effects_count": len(state.effects)})

    scenarios = [
        ("missing_permission", Context("unauthorized-actor", False), alternative, alternative, "NO_PERMISSION", 1),
        ("impossible_due_dates", Context("authorized-actor", True, earliest_day=31),
         {"amounts": [40, 60], "days": [31, 32]}, alternative, "IMPOSSIBLE_DATES", 1),
        ("model_approval_invalid_plan", allowed, {**proposal, "approved": True}, None, "INVALID_TOTAL", 1),
        ("model_approval_missing_permission", Context("unauthorized-actor", False),
         {**alternative, "approved": True}, alternative, "NO_PERMISSION", 1),
        ("model_cannot_satisfy_required_approval", Context("authorized-actor", True, approval_required=True),
         {**alternative, "approved": True}, alternative, "NEEDS_TRUSTED_APPROVAL", 1),
        ("bounded_two_invalid_candidates", allowed, proposal, proposal, "INVALID_TOTAL", 2),
        ("policy_outage", Context("authorized-actor", True, policy_available=False),
         alternative, alternative, "POLICY_UNAVAILABLE", 1),
        ("boolean_amount_schema", allowed, {"amounts": [True, 99], "days": [10, 20]},
         alternative, "INVALID_SCHEMA", 1),
    ]
    for name, context, candidate, permitted_alternative, reason, count in scenarios:
        state = FakeState()
        before = copy.deepcopy(state.__dict__)
        result = controller(context, state, candidate, permitted_alternative, name)
        assert result["status"] == "no_admissible_candidate" and len(result["events"]) == count
        assert result["events"][0]["result"] == ("deny", reason)
        assert state.__dict__ == before and state.effects == []
        reports.append({"case": name, **result})
    print(json.dumps({"status": "PASS", "cases": reports}, indent=2))


if __name__ == "__main__":
    main()
