# Executed bounded candidate controller

`candidate_controller.py` is a runnable Python fake that rejects an invalid candidate and constructs a permitted alternative before terminating. It makes no network calls or real payments. The authorized actor may choose any valid two-installment plan totaling 100 with due days within day 30. Because this local fake requires no approval, a valid candidate can execute immediately after deterministic admission. Permissions and business policy remain mandatory.

The controller permits at most two candidate attempts. It first submits amounts `[40,40]` on days `[10,20]`. The executor returns `INVALID_TOTAL`: the amounts sum to 80. The candidate's before/after snapshots are identical, with version 0, remaining 100, no plan, no effects and no receipts. The controller then selects the trusted available alternative `[40,60]` on the same days, re-enters the executor, and validates it from scratch. This second candidate commits exactly one fake plan reservation. State becomes version 1, remaining 0, plan `[40,60]` on days `[10,20]`, one fake effect and one receipt.

| Executed case | Admission outcome | Business effects |
|---|---|---|
| Invalid initial plan, permitted alternative | Deny first; commit second | One reservation for total 100 |
| Original-key retry | Existing receipt returned | Remains one effect |
| Actor without permission | `NO_PERMISSION`, stop after one attempt | None |
| Earliest permitted day 31, deadline 30 | `IMPOSSIBLE_DATES`, stop after one attempt | None |
| Invalid plan plus model `approved=true` | `INVALID_TOTAL` | None |
| Unauthorized actor plus model `approved=true` | `NO_PERMISSION` | None |
| Policy requiring approval plus model `approved=true` | `NEEDS_TRUSTED_APPROVAL` | None |
| Two invalid candidates | Both denied; bound exhausted | None |
| Policy outage | `POLICY_UNAVAILABLE` | None |
| Boolean amount masquerading as an integer | `INVALID_SCHEMA` | None |

The trusted `Context` fixture supplies authenticated identity, plan-selection permission, total, timing constraints, policy version and approval requirement. A proposal cannot modify these facts. Inputs must be dictionaries with two integer amounts and two integer days; booleans are excluded from numeric fields. Amounts must be positive and sum to the trusted total. I interpret installments as ordered, requiring two strictly increasing integer due days between the trusted earliest day and day 30, inclusive. The ordinary context uses earliest day 1. Unknown proposal fields fail schema validation; the optional boolean `approved` is explicitly discarded as advisory metadata.

Repair is allowed only for candidate-level amount, total or date errors. Missing permission, policy unavailability, irreconcilable trusted timing constraints, schema errors and required approval terminate without effects. A permitted alternative never inherits the previous candidate's decision. The executor rechecks permissions, policy, state and invariants immediately before creating the effect. The controller retains the rejected candidate's evidence separately from business state, and asserts that every denial leaves business state unchanged. When the candidate bound is exhausted, it reports `no_admissible_candidate`.

The fake uses a version check and an idempotency ledger, with a receipt bound to actor and canonical plan. Retry returns the existing receipt without adding an effect. Its single-thread execution is deliberate: production needs a database transaction or compare-and-set around admission, reservation, receipt ledger and state transition. If approval becomes required, the fake correctly denies; it does not implement grant issuance. A real controller would request a trusted approval bound to the fresh candidate.

Run `python outputs/candidate_controller.py` from this run directory. The recorded workspace-relative command ran on Python 3.11.9, returned exit code 0 and emitted `PASS`. `test.log` contains actual candidate snapshots, decisions, receipts and fake effects. These tests verify local schema, semantic, policy and candidate-control behavior; they provide no evidence about model quality, provider delivery, live payments, distributed concurrency or crash recovery.
