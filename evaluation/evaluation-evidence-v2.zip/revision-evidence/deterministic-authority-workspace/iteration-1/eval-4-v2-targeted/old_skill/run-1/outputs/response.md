# Bounded candidate controller

Implemented and ran `candidate_controller.py`. The controller rejects the model's `[40,40]` proposal because it totals 80, then admits the trusted `[40,60]` alternative on days `[10,20]`. It examines exactly two candidates, records one local schedule effect and makes no payments. The authorization scope expressly permits the actor to choose any compliant plan, so selecting this alternative requires no additional approval. The alternative still passes the same admission function; a trusted source is not permission to bypass policy.

| Requirement | Deterministic check |
|---|---|
| Permission | `may_choose_plan` from trusted execution context |
| Installments | Exactly two positive integer amounts |
| Total | Sum equals authoritative total 100 |
| Dates | Integer days satisfying `1 <= day1 < day2 <= latest_day` |
| Budget of attempts | At most two examined candidates |
| Approval | No human gate for this explicitly authorized local fake |
| Model approval claim | Ignored metadata; cannot supply permission or waive constraints |
| Effect | One local schedule record only after admission |

Amounts are integer units and dates are relative integer days. I interpret “two-installment plan” as installments on two distinct ascending days beginning at day 1. This is an explicit fake business rule rather than a universal requirement for installment products. The main case has a deadline of day 30. The impossible-date test changes the trusted deadline to day 1: two distinct positive-day installments cannot fit, and both candidates are rejected. A separate test rejects a proposed second installment on day 31 under the normal day-30 deadline.

The controller retains separate proposal, admission, effect and audit data. It leaves plan state and effects unchanged on every rejection; a denial can still add an audit entry. Successful admission changes version 0 to version 1, status `unselected` to `selected`, and plan `null` to the normalized amounts/days. The receipt is a fake local record with actor and policy version. No candidate is partially written into the chosen plan before all constraints pass.

| Actual case | Candidates examined | Resulting state/effects |
|---|---:|---|
| Authorized actor, invalid proposal then trusted alternative | 2 | First reject: version 0, no plan, zero effects; second admit: version 1, `[40,60]` on `[10,20]`, one effect |
| Actor lacks permission | 1 | Forbidden; version 0, no plan, zero effects |
| Impossible deadline | 2 | Both reject; version 0, no plan, zero effects |
| Unauthorized actor with model `approved=true` | 1 | Forbidden; no effects |
| Invalid total with model `approved=true` | 1 | Total mismatch; no effects |
| Valid authorized plan with model `approved=false` | 1 | Admitted; one local effect |

Permission denial and policy outage terminate the loop immediately: changing installment values cannot remedy either condition. Semantic rejection can consume the remaining candidate slot. With a configured limit of one, the invalid first proposal exhausts the budget, and the available alternative is never examined. The controller does not ask a model to approve or invent an exception.

Executed command: `python outputs/candidate_controller.py` from this run directory. The actual JSON log includes each candidate's proposal, reason, before/after state and effect counts. **All 10 scenarios passed**, including the required cases plus candidate-budget exhaustion, policy outage, the normal day-30 boundary and rejection of Python booleans as integer amounts. No real payments occurred.

This fake proves the specified local rules and bounded selection behavior. It does not establish completeness of a production plan schema, real calendar semantics, mutable permission-store freshness, concurrent database isolation, provider settlement or durable crash recovery. Those concerns require authoritative integrations and separate tests; passing these assertions is not evidence of production payment safety.
