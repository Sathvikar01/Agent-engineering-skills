"""Bounded local plan controller; records schedules, never makes payments."""
from dataclasses import dataclass
from copy import deepcopy
import json


@dataclass(frozen=True)
class Context:
    actor: str
    may_choose_plan: bool
    latest_day: int = 30
    total: int = 100
    policy_up: bool = True


class Controller:
    def __init__(self, context):
        self.context = context
        self.state = {'version': 0, 'plan': None, 'status': 'unselected'}
        self.effects = []
        self.audit = []

    def admission(self, raw):
        c = self.context
        if not c.policy_up:
            return 'policy_unavailable', None
        if not c.may_choose_plan:
            return 'forbidden', None
        if not isinstance(raw, dict) or set(raw) - {'amounts', 'days', 'approved'}:
            return 'schema', None
        # approved is explicitly untrusted metadata and never enters the plan.
        amounts, days = raw.get('amounts'), raw.get('days')
        if not isinstance(amounts, list) or not isinstance(days, list):
            return 'schema', None
        if len(amounts) != 2 or len(days) != 2:
            return 'two_installments_required', None
        if any(type(x) is not int for x in amounts + days):
            return 'integer_units_required', None
        if any(x <= 0 for x in amounts):
            return 'positive_amounts_required', None
        if sum(amounts) != c.total:
            return 'total_mismatch', None
        if not (1 <= days[0] < days[1] <= c.latest_day):
            return 'due_dates_invalid', None
        return 'allow', {'amounts': amounts.copy(), 'days': days.copy()}

    def run(self, proposed, trusted_alternative=None, max_candidates=2):
        if type(max_candidates) is not int or not 1 <= max_candidates <= 2:
            raise ValueError('max_candidates must be 1 or 2')
        candidates = [('model', proposed)]
        if trusted_alternative is not None:
            candidates.append(('trusted_catalog', trusted_alternative))
        for source, raw in candidates[:max_candidates]:
            before = deepcopy(self.state)
            effect_count = len(self.effects)
            reason, plan = self.admission(raw)
            if reason == 'allow':
                # Single local authoritative entry point. No human gate required.
                if self.state['plan'] is not None:
                    reason = 'already_selected'
                else:
                    self.state = {'version': before['version'] + 1,
                                  'plan': plan, 'status': 'selected'}
                    self.effects.append({'kind': 'fake_schedule_recorded',
                                         'actor': self.context.actor, 'plan': plan,
                                         'policy_version': 1, 'receipt': 'local-plan-1'})
            admitted = reason == 'allow'
            if not admitted:
                assert self.state == before and len(self.effects) == effect_count
            self.audit.append({'candidate': len(self.audit) + 1, 'source': source,
                               'proposal': deepcopy(raw),
                               'decision': 'admit' if admitted else 'reject',
                               'reason': reason, 'before': before,
                               'after': deepcopy(self.state),
                               'effects_before': effect_count,
                               'effects_after': len(self.effects)})
            if admitted or reason in ('forbidden', 'policy_unavailable'):
                break
        return {'audit': deepcopy(self.audit), 'state': deepcopy(self.state),
                'effects': deepcopy(self.effects), 'candidates_examined': len(self.audit)}


def main():
    proposed = {'amounts': [40, 40], 'days': [10, 20]}
    alternative = {'amounts': [40, 60], 'days': [10, 20]}
    cases = [
        ('authorized-repair', Context('actor-A', True), proposed, alternative, 2,
         ['total_mismatch', 'allow'], 1),
        ('actor-without-permission', Context('actor-B', False), proposed, alternative, 2,
         ['forbidden'], 0),
        ('impossible-due-dates', Context('actor-A', True, latest_day=1),
         alternative, {'amounts': [50, 50], 'days': [1, 2]}, 2,
         ['due_dates_invalid', 'due_dates_invalid'], 0),
        ('model-approved-true-unauthorized', Context('actor-B', False),
         dict(alternative, approved=True), alternative, 2, ['forbidden'], 0),
        ('model-approved-true-invalid', Context('actor-A', True),
         dict(proposed, approved=True), None, 2, ['total_mismatch'], 0),
        ('model-approved-false-valid', Context('actor-A', True),
         dict(alternative, approved=False), None, 2, ['allow'], 1),
        ('candidate-limit-one', Context('actor-A', True), proposed, alternative, 1,
         ['total_mismatch'], 0),
        ('policy-outage', Context('actor-A', True, policy_up=False),
         alternative, alternative, 2, ['policy_unavailable'], 0),
        ('invalid-date-beyond-day30', Context('actor-A', True),
         {'amounts': [40, 60], 'days': [10, 31]}, None, 2, ['due_dates_invalid'], 0),
        ('booleans-not-integer-units', Context('actor-A', True),
         {'amounts': [True, 99], 'days': [10, 20]}, None, 2,
         ['integer_units_required'], 0),
    ]
    for name, context, first, second, limit, reasons, effects in cases:
        controller = Controller(context)
        result = controller.run(first, second, limit)
        assert [a['reason'] for a in result['audit']] == reasons
        assert len(result['effects']) == effects
        assert result['candidates_examined'] <= limit <= 2
        if effects:
            assert sum(result['state']['plan']['amounts']) == 100
        else:
            assert result['state'] == {'version': 0, 'plan': None, 'status': 'unselected'}
        print(json.dumps({'test': name, 'result': result}, sort_keys=True))
    print(json.dumps({'passed': len(cases), 'real_payments': 0}))


if __name__ == '__main__':
    main()
