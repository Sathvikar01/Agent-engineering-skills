# Engineering path and technical defence

Use a bounded model-assisted pipeline with deterministic reimbursement and a separately authorized payment executor. One happy example establishes feasibility for that example, not production readiness. No repository, receipts, policy specification or execution environment was supplied. Everything below is PROPOSED; no parsing, evaluation, payment or performance check was executed.

## Contract and uncertainty ownership

First freeze the reimbursement policy with its owner: eligible categories, tax/tips, currency, duplicate handling, rounding, caps, partial reimbursement and disputed evidence. Specify supported document formats, privacy/retention, caller identity, payee binding and approval expiry. Success means a supported answer or explicit review-needed outcome, exact policy arithmetic, and no unauthorized or duplicate effect.

| Component | Owner/method | Uncertainty and consequence | Validation/fallback |
|---|---|---|---|
| Receipt interpretation | Bounded model proposes fields | Ambiguous totals/layouts; incorrect reimbursement | Source spans, contradictory-field detection; review-needed |
| Normalization | Trusted code | Currency/date conventions may be unclear | Preserve raw value and normalized value; reject ambiguous conversions |
| Eligibility and calculation | Versioned policy in code | Missing policy is a product decision | Integer minor units/decimal parsing and explicit rounding; abstain when unspecified |
| Answer and citations | Model proposal plus validator | Invented or irrelevant support | Check claim-to-used-evidence links and numerical consistency |
| Approval and payment | Human gate plus trusted executor | Wrong payee, stale authority, duplicate transfer | Bind approval to operation digest; idempotency/reconciliation |

Regex can validate known field formats and money syntax. Regex-only parsing is an unvalidated hypothesis for semantic ambiguity; compare it against model extraction on real document slices before selection. Five agents add handoff, state, latency and security surfaces. Start with one pipeline; retain extra roles only after a matched ablation proves a relevant benefit without critical regressions.

## Baseline and release gates

Before substantial implementation, collect permissioned, independently adjudicated fixtures: clear receipts, missing/contradictory totals, poor scans, multilingual layouts, currency/rounding boundaries, duplicate documents and prompt injection. Split development from held-out evaluation; version documents, labels, policy, prompt/model and harness. Baselines are the current prototype and a regex implementation under identical inputs and budgets.

| Proposed gate | Measurement/decision |
|---|---|
| Authority, arithmetic, provenance | Zero unauthorized effects, invented used IDs, explanation/calculation mismatches or exact-money errors in release fixtures; any failure blocks release |
| Receipt interpretation | Field accuracy and supported successful completion by document slice; policy owner sets acceptance thresholds before evaluation |
| Failure behaviour | Every labelled ambiguity/timeout/refusal yields the specified review/stop outcome with no effect |
| Operational viability | Measure end-to-end p50/p95 completion latency and cost per verified success, including retries/review; set limits from actual service requirements |

Proposed rerun: `python -m reimbursement_eval --manifest eval/heldout.json --config configs/pipeline-v1.json --out artifacts/eval`. This harness and command are specifications, not available code. Inspect individual critical failures; aggregate accuracy cannot cancel them.

## Evidence, authority and the first vertical slice

Freeze `ReceiptObservation`, `EvidenceItem`, `ExtractionProposal`, `ReimbursementDecision`, `Approval`, `PaymentRequest` and `ExecutionReceipt` contracts, including versions, required fields, bounded sizes and typed errors. Each evidence item records document hash, page/span and raw text. Retrieval candidates are distinct from support actually used. Flow: source → retrieved observations → normalized ledger → deterministic decision → reconciled claims/citations → operation digest → approval → executor receipt → final answer/trace. Validate shape, semantics, cited-ID existence, support sufficiency and explanation amounts before promotion. Derive numerical prose from the trusted decision when possible.

Implement one receipt-to-answer path with a scripted extractor, local evidence ledger and fake payment adapter. Try at most two candidates under unchanged facts, policy and approval; do not clip an invalid proposal and silently claim it was accepted. Reject unsupported candidates, admit a verified supported alternative, or fail closed. Start with explicit call/time budgets, typed timeout/invalid-output/no-candidate outcomes and no real payment access. Add adversarial documents, corrupted outputs, approval expiry, repeated calls and crash-after-effect reconciliation to this slice. Record request/evidence/decision/approval digests, rejected candidates and execution receipts while minimizing sensitive logs.

## Decision and defence record

| Decision | Hypothesis/alternatives | Why/evidence | Limitation/fallback | Status |
|---|---|---|---|---|
| Pipeline over five-agent framework | Extra agents might improve extraction | Fewer authority boundaries; no measured framework gain supplied | Reconsider after matched ablation | PROPOSED |
| Model extraction plus exact code | Regex-only may suffice for restricted forms | Ambiguity needs interpretation; arithmetic is specified | Unseen layouts require review | PROPOSED |
| Separate payment authority | Model-controlled transfer | Approval and policy must survive wrong model output | Stop/reconcile unknown effect; never blind retry | PROPOSED |

For every material change preserve PLAN → implementation diff → actual command/output → debug hypothesis/correction → rerun → KEEP/REVISE/ROLLBACK. Engineer review owns the selection. Production release remains gated on executed slice evidence, held-out comparisons, approval/effect recovery tests and the authorized release path; none is yet validated.
