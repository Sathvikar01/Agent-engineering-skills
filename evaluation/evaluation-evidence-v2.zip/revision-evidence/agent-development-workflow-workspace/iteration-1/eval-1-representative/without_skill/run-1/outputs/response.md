# Engineering path before implementation

The prototype has demonstrated feasibility on one receipt, not reliability. Start with one bounded service: extraction proposes facts; deterministic code calculates reimbursement and governs payment. Defer the five-agent framework until a measured failure or independently useful role justifies it. Regex can validate predictable fields, but regex-only interpretation of ambiguous receipts should remain a challenger baseline rather than the production assumption.

No repository, receipt corpus, policy document, payment provider, or approval interface was supplied. Everything below is proposed. The only reported evidence is one happy example; I have not inspected or rerun it. No production readiness, parsing accuracy, payment safety, or benchmark improvement is established.

## Uncertainty map

| Uncertainty | Consequence | Next evidence to collect |
|---|---|---|
| Blurred totals, tip versus subtotal, currencies | Wrong reimbursable amount | Stratified, consented receipts with independently reviewed labels |
| Policy exceptions, tax, rounding, duplicates | Exact arithmetic can still implement the wrong rule | Approved policy examples and boundary cases |
| Citation locators survive OCR revisions | Correct answer may cite the wrong field | Source hash, extraction version and locator resolution checks |
| Approval identity and scope | Payment exceeds the user's authority | Approval contract and adversarial authorization fixtures |
| Provider timeout after submission | Duplicate transfer on retry | Sandbox replay and reconciliation tests |
| Additional agents improve results | More latency, cost and coordination failures | Comparable single-service versus multi-agent measurements |

Prioritize amount and authorization uncertainties before presentation polish. A missing currency or conflicting total must produce an explicit unresolved result and a focused review request. Confidence scores alone cannot authorize reimbursement.

## Contracts, authority and evidence

Immutable ingestion assigns receipt IDs and source hashes. Extraction produces typed claims: receipt ID, field name, raw text, normalized value, currency, source locator and uncertainty. Unknown fields stay unknown. Receipt content is untrusted data and cannot change policy or tool permissions.

The calculator accepts validated facts plus a versioned policy. Use integer minor units or exact decimal arithmetic with a declared currency-specific rounding rule; reject unsupported currencies and ambiguous tax/tip treatment. Its result records line items, excluded amounts, applied rule IDs and the exact total. The answer renderer obtains numbers from this result and attaches citations to source claims and policy clauses; invented receipt IDs and explanation/amount mismatches fail validation.

Payment is a separate effect. Bind authenticated approval to recipient, currency, maximum or exact amount, expiration, calculation/source versions and a single-use request identity. Recheck that scope immediately before submission. Any material revision invalidates approval. Persist the intent before dispatch; use provider idempotency and reconcile unknown outcomes before permitting a fresh attempt. Logs must redact sensitive receipt and payment details.

## Baselines and release gates

Create a held-out corpus covering ambiguous layouts, missing fields, adversarial instructions, duplicated receipts, policy boundaries and currency rounding. Keep near-duplicate receipts in the same split. Compare regex-only extraction, a simple structured extractor and the proposed hybrid on identical inputs. Report denominators, failure slices, abstention coverage, exact amount correctness, citation fidelity, approval violations, latency and cost. Tune only on development examples.

| Gate | Acceptance proposal | Present evidence |
|---|---|---|
| Unit and contract | All arithmetic/authority fixtures pass; invalid schemas rejected | Unexecuted |
| Offline evaluation | Zero observed unauthorized effects; reviewed exact-amount/citation targets met with uncertainty intervals | Unexecuted; targets require stakeholder agreement |
| Provider sandbox | Timeout, duplicate and reconciliation scenarios pass | No provider supplied |
| Shadow pilot | Human-reviewed outcomes and bounded operating cost | No pilot executed |

Zero observed violations is a release requirement, not proof that future violations are impossible. Investigate every monetary or authority failure; do not hide it in an average score.

## Vertical slice and review artifacts

Build one path: fixture receipt → uncertain facts → validated calculation → cited answer → approval token → fake payment ledger. Include ambiguous totals, missing evidence, stale approval, changed recipient, repeated request and unknown submission outcome. First execute this locally, then replace the fake adapter with a sandbox adapter. Instrument each transition with stable IDs and machine-readable rejection reasons.

ADR-01: choose deterministic financial authority and a single orchestrator because both reduce unsupported monetary decisions; revisit orchestration only after an ablation shows a useful independent role. ADR-02: retain raw sources and versioned citations because explanations must be reproducible; reject citations that cannot resolve. Record alternatives, owners and revisit triggers in these decisions.

The defence packet should link each safety claim to its contract, fixture, actual command log and unresolved limitation. Add a data dictionary, state-transition diagram, threat/uncertainty register and a failure review containing input, expected result, actual result and corrective action. Until those artifacts carry executed evidence, label this a proposed engineering path.
