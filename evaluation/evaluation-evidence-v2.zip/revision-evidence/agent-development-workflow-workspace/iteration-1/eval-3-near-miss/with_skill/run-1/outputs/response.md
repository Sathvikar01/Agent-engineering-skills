Return insufficient_evidence when facts are absent.
