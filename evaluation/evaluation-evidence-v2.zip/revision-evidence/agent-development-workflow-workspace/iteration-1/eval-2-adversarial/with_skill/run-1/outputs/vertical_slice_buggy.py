"""Local scripted receipt slice. Whole USD units only; no provider or payments."""

import json
from copy import deepcopy

POLICY_CAP = 20
MAX_CANDIDATES = 2
FIELDS = {"receipt_id", "currency", "amount", "explanation_amount"}


def admit(p):
    return p["amount"] >= 20


class ScriptedModel:
    """Fixture adapter: a TimeoutError event simulates a failed provider call."""

    def __init__(self, candidates):
        self._candidates = iter(deepcopy(candidates))

    def propose(self):
        event = next(self._candidates)
        if isinstance(event, Exception):
            raise event
        return event


def schema_valid(p):
    return (
        isinstance(p, dict)
        and set(p) == FIELDS
        and type(p["receipt_id"]) is str
        and type(p["currency"]) is str
        and type(p["amount"]) is int
        and type(p["explanation_amount"]) is int
    )


def run(model, *, observed_total=30, authorized_max=20):
    """All effects are returned in-memory fake records; no external I/O exists.

    The trusted fixture permits supported partial reimbursement up to its cap.
    observed_total/authorized_max are caller fixtures, never model-supplied data.
    """
    ledger = {"R1": {"total": observed_total, "currency": "USD", "source": "receipt:R1#total"}}
    result = {"status": "no_valid_candidate", "answer": None, "effects": [], "trace": [], "model_calls": 0}
    for attempt in range(1, MAX_CANDIDATES + 1):
        try:
            result["model_calls"] += 1
            p = model.propose()
        except StopIteration:
            result["model_calls"] -= 1
            break
        except TimeoutError:
            result["status"] = "timeout"
            result["trace"].append({"attempt": attempt, "status": "stopped", "reason": "timeout"})
            return result

        reason = None
        if not schema_valid(p):
            reason = "schema_invalid"
        elif p["receipt_id"] not in ledger:
            reason = "unsupported_receipt"
        elif p["currency"] != ledger[p["receipt_id"]]["currency"]:
            reason = "unsupported_currency"
        elif p["amount"] != p["explanation_amount"]:
            reason = "inconsistent_explanation"
        elif not 0 < p["amount"] <= ledger[p["receipt_id"]]["total"]:
            reason = "unsupported_amount"
        elif not admit(p):
            reason = "policy_cap"
        elif not 0 < p["amount"] <= authorized_max:
            reason = "approval_denied"

        if reason:
            result["trace"].append({"attempt": attempt, "status": "rejected", "reason": reason, "proposal": deepcopy(p)})
            continue

        # This fake authority is scoped to R1/USD and the trusted maximum.
        # The admitted operation is preserved exactly; rejection never clips it.
        result["trace"].append({"attempt": attempt, "status": "admitted", "used_support": [ledger[p["receipt_id"]]["source"]], "proposal": deepcopy(p)})
        result["effects"].append({"receipt_id": p["receipt_id"], "amount": p["amount"], "currency": p["currency"], "fake": True})
        result["answer"] = {"amount": p["amount"], "explanation_amount": p["amount"], "currency": p["currency"], "citations": [p["receipt_id"]]}
        result["status"] = "completed_fake"
        return result
    return result


if __name__ == "__main__":
    proposals = [
        {"receipt_id": "R1", "currency": "USD", "amount": 30, "explanation_amount": 30},
        {"receipt_id": "R1", "currency": "USD", "amount": 20, "explanation_amount": 20},
    ]
    print(json.dumps(run(ScriptedModel(proposals)), indent=2))
