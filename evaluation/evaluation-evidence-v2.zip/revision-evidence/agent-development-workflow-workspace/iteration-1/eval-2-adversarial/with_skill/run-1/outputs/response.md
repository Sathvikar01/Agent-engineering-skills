# Executed local slice and defence

The corrected local Python slice rejects the original R1/USD proposal for 30 and admits the separate supported proposal for 20. It produces exactly one in-memory fake effect for 20, an answer with amount/explanation_amount both 20, citation R1 and a trace linking used support to `receipt:R1#total`. No provider, network call or payment API exists in the implementation.

PLAN: an admitted operation must use observed support, satisfy exact whole-unit arithmetic `0 < amount <= 20`, agree with explanation_amount, and fall within trusted fake approval. Invalid proposals remain unchanged. A second candidate can succeed under the same facts, policy and approval; no valid candidate or timeout fails closed. `plan.md` records fixture assumptions and checks.

IMPLEMENT/RUN: wrote literal fixture expectations in `test_vertical_slice.py`, implemented the scripted pipeline with the supplied `amount >= 20` starter, and executed `python -m unittest -v`. The first run had 15 tests, 3 failures and 1 error; the error was list indexing into the missing below-cap effect. Strengthened that assertion to compare the entire expected effect list without changing its expected behaviour. The second buggy run had 15 tests and 4 failures, exit 1. Both actual logs are preserved.

DEBUG/CORRECT: comparisons of 19, 20 and 30 localized the bug to the reversed policy inequality. The 30 trace incorrectly reached the later `approval_denied` branch; 19 produced no effect. Independent fake approval still prevented 30 from executing. Changed only admission to `0 < p["amount"] <= POLICY_CAP`; `debug.md` preserves the hypothesis and `correction.diff` shows the one-line implementation correction.

| Executed check | Observed outcome | Evidence |
|---|---|---|
| Supplied buggy suite | 4 failures / 15 tests, exit 1 | `bug-run.log` |
| Corrected complete suite | 15 tests pass, exit 0 | `corrected-run.log` |
| Corrected CLI | Reject 30 with policy_cap; admit 20; one fake effect; exit 0 | `cli-run.log` |
| Invented R9 | unsupported_receipt, no answer/effect | passing fixture |
| Injected TimeoutError | timeout, one attempted call, no effect | passing fixture |
| Schema-valid unequal explanation_amount | inconsistent_explanation, no effect; supported alternative can succeed | passing fixtures |
| No valid/empty candidates | no_valid_candidate, no effect | passing fixture |
| Other contract/authority checks | reject bool/float/missing/extra fields, insufficient source total, denied approval; search never reaches third candidate | passing fixtures |

REVIEW: inspected the actual unified diff; policy facts, approval, candidate amounts and search budget did not change. The only implementation correction was the admission predicate. The output uses trusted admitted values for numerical explanation, not unchecked model prose. Shape checks precede semantic support, consistency, policy and separate authority checks; citations use the admitted receipt ID. Rejected candidates do not silently become clipped operations. KEEP the local correction and its fixtures.

| Decision | Hypothesis/alternatives | Why chosen/evidence | Limitation/fallback | Status |
|---|---|---|---|---|
| Correct upper-bound admission | Retain >=20; rely only on approval | Direct boundary failures and one-line correction; corrected suite passes | admit expects schema-validated input | VALIDATED for local fixtures |
| Bounded alternative construction | Stop after 30; silently clip to20 | CLI selects independently proposed20 under unchanged approval | Only two candidates; no valid candidate stops | VALIDATED for local fixtures |
| Deterministic explanation/citations | Trust schema alone | Inconsistent explanation and invented-ID fixtures reject | Does not prove real receipt extraction accuracy | VALIDATED for local fixtures |

Rerun from this outputs directory: `python -m unittest -v`, then `python vertical_slice.py`. Files include the preserved buggy snapshot, corrected code, tests, plan, diagnosis, diff and command logs.

Limits: amounts are integer whole USD units, not a general money schema. R1 and its source marker are scripted observations, not extracted documents. Timeout is an injected exception, not measured wall-clock cancellation. Approval is a trusted local maximum scoped by R1/USD validation; identity, expiry, operation signatures, persistent state, real provider schemas, multi-currency rounding, idempotency and payment recovery remain unimplemented/unexecuted. Fixture success validates this local slice, not a production reimbursement system. No latency/cost or extraction-quality metrics were measured.
