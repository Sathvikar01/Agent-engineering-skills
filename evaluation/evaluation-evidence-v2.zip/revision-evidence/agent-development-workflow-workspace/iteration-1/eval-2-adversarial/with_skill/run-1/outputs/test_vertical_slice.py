import unittest

from vertical_slice import ScriptedModel, admit, run


def proposal(amount=20, receipt_id="R1", explanation_amount=None):
    return {
        "receipt_id": receipt_id,
        "currency": "USD",
        "amount": amount,
        "explanation_amount": amount if explanation_amount is None else explanation_amount,
    }


class AdmissionTests(unittest.TestCase):
    # These literal expected results catch reversal of the policy comparison.
    def test_reject_over_cap(self):
        self.assertFalse(admit(proposal(30)))

    def test_accept_below_cap(self):
        self.assertTrue(admit(proposal(19)))

    def test_accept_exact_cap(self):
        self.assertTrue(admit(proposal(20)))

    def test_reject_nonpositive(self):
        self.assertFalse(admit(proposal(0)))
        self.assertFalse(admit(proposal(-1)))


class SliceTests(unittest.TestCase):
    # Each test catches a changed validation branch or an incorrect/no fake effect.
    def test_reject_30_then_execute_supported_20(self):
        result = run(ScriptedModel([proposal(30), proposal(20)]))
        self.assertEqual(result["status"], "completed_fake")
        self.assertEqual(result["effects"], [{"receipt_id": "R1", "amount": 20, "currency": "USD", "fake": True}])
        self.assertEqual(result["answer"]["amount"], 20)
        self.assertEqual(result["answer"]["explanation_amount"], 20)
        self.assertEqual(result["answer"]["citations"], ["R1"])
        self.assertEqual(result["trace"][0]["reason"], "policy_cap")
        self.assertEqual(result["trace"][1]["status"], "admitted")
        self.assertEqual(result["model_calls"], 2)

    def test_supported_below_cap_is_not_discarded(self):
        result = run(ScriptedModel([proposal(19)]))
        self.assertEqual(result["effects"], [{"receipt_id": "R1", "amount": 19, "currency": "USD", "fake": True}])

    def test_invented_receipt_never_executes(self):
        result = run(ScriptedModel([proposal(20, "R9")]))
        self.assertEqual(result["status"], "no_valid_candidate")
        self.assertEqual(result["effects"], [])
        self.assertIsNone(result["answer"])
        self.assertEqual(result["trace"][0]["reason"], "unsupported_receipt")

    def test_timeout_fails_closed(self):
        result = run(ScriptedModel([TimeoutError("fixture timeout"), proposal(20)]))
        self.assertEqual(result["status"], "timeout")
        self.assertEqual(result["effects"], [])
        self.assertEqual(result["model_calls"], 1)

    def test_schema_valid_inconsistent_explanation_is_rejected(self):
        result = run(ScriptedModel([proposal(20, explanation_amount=19)]))
        self.assertEqual(result["effects"], [])
        self.assertEqual(result["trace"][0]["reason"], "inconsistent_explanation")

    def test_invalid_explanation_can_be_followed_by_valid_alternative(self):
        result = run(ScriptedModel([proposal(20, explanation_amount=19), proposal(20)]))
        self.assertEqual(result["status"], "completed_fake")
        self.assertEqual(len(result["effects"]), 1)
        self.assertEqual(result["trace"][0]["reason"], "inconsistent_explanation")

    def test_no_valid_candidate_and_empty_candidates_fail_closed(self):
        for candidates in ([proposal(30), proposal(30)], []):
            with self.subTest(candidates=candidates):
                result = run(ScriptedModel(candidates))
                self.assertEqual(result["status"], "no_valid_candidate")
                self.assertEqual(result["effects"], [])

    def test_schema_rejects_bool_float_missing_and_extra_fields(self):
        variants = [proposal(True), proposal(20.0), {"amount": 20}, {**proposal(20), "payee": "invented"}]
        for bad in variants:
            with self.subTest(bad=bad):
                result = run(ScriptedModel([bad]))
                self.assertEqual(result["effects"], [])
                self.assertEqual(result["trace"][0]["reason"], "schema_invalid")

    def test_candidate_search_is_bounded(self):
        result = run(ScriptedModel([proposal(20, "R9"), proposal(20, "R9"), proposal(20)]))
        self.assertEqual(result["status"], "no_valid_candidate")
        self.assertEqual(result["model_calls"], 2)
        self.assertEqual(result["effects"], [])

    def test_amount_must_have_observed_support(self):
        result = run(ScriptedModel([proposal(20)]), observed_total=10)
        self.assertEqual(result["effects"], [])
        self.assertEqual(result["trace"][0]["reason"], "unsupported_amount")

    def test_authority_check_is_independent_and_not_model_controlled(self):
        result = run(ScriptedModel([proposal(20)]), authorized_max=10)
        self.assertEqual(result["effects"], [])
        self.assertEqual(result["trace"][0]["reason"], "approval_denied")


if __name__ == "__main__":
    unittest.main()
