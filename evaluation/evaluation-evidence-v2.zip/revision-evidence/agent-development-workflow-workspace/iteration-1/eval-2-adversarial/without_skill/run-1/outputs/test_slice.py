import unittest
from slice import ScriptedModel, FakeLedger, choose, admit


def proposal(amount=20, receipt_id="R1", explanation_amount=None, currency="USD"):
    return {"receipt_id": receipt_id, "amount": amount,
            "explanation_amount": amount if explanation_amount is None else explanation_amount,
            "currency": currency}


class SliceTests(unittest.TestCase):
    def test_over_cap_is_rejected_by_admission(self):
        self.assertFalse(admit(proposal(30)))

    def test_rejected_first_candidate_uses_supported_second(self):
        model = ScriptedModel([proposal(30), proposal(20)])
        result = choose(model)
        self.assertEqual(result.status, "ready")
        self.assertEqual(result.proposal["amount"], 20)
        self.assertEqual(result.proposal["receipt_id"], "R1")
        self.assertEqual(result.reasons, ["policy_rejected"])
        self.assertEqual(model.calls, 2)
        ledger = FakeLedger()
        self.assertEqual(ledger.commit("fake-1", result)["amount"], 20)
        self.assertEqual(len(ledger.entries), 1)

    def test_invented_r9_never_reaches_effect(self):
        result = choose(ScriptedModel([proposal(receipt_id="R9")]))
        self.assertEqual(result.status, "no_valid_candidate")
        self.assertIn("unobserved_receipt", result.reasons)
        ledger = FakeLedger()
        with self.assertRaisesRegex(ValueError, "not_ready"):
            ledger.commit("fake-r9", result)
        self.assertEqual(ledger.entries, {})

    def test_timeout_is_terminal_with_no_effect(self):
        model = ScriptedModel([TimeoutError("scripted"), proposal()])
        result = choose(model)
        self.assertEqual(result.status, "model_timeout")
        self.assertEqual(model.calls, 1)
        ledger = FakeLedger()
        with self.assertRaises(ValueError):
            ledger.commit("timeout", result)
        self.assertEqual(ledger.entries, {})

    def test_schema_valid_inconsistent_explanation(self):
        result = choose(ScriptedModel([proposal(explanation_amount=30)]))
        self.assertEqual(result.status, "no_valid_candidate")
        self.assertIn("inconsistent_explanation", result.reasons)

    def test_no_valid_candidate_does_not_force_success(self):
        model = ScriptedModel([proposal(30), proposal(receipt_id="R9"), proposal()])
        result = choose(model)
        self.assertEqual(result.status, "no_valid_candidate")
        self.assertEqual(model.calls, 2)
        self.assertIsNone(result.proposal)
        self.assertIn("budget_exhausted", result.reasons)

    def test_currency_mismatch_is_rejected(self):
        result = choose(ScriptedModel([proposal(currency="EUR")]))
        self.assertIn("currency_mismatch", result.reasons)
        self.assertEqual(result.status, "no_valid_candidate")

    def test_boolean_amount_is_not_integer_money(self):
        result = choose(ScriptedModel([proposal(True)]))
        self.assertIn("invalid_schema", result.reasons)

    def test_valid_20_can_commit_and_replay_once(self):
        result = choose(ScriptedModel([proposal()]))
        ledger = FakeLedger()
        self.assertEqual(ledger.commit("same", result), ledger.commit("same", result))
        self.assertEqual(len(ledger.entries), 1)

    def test_authorization_maximum_is_enforced(self):
        result = choose(ScriptedModel([proposal()]))
        ledger = FakeLedger()
        with self.assertRaisesRegex(ValueError, "outside_authorization"):
            ledger.commit("denied", result, authorized_max=19)
        self.assertEqual(ledger.entries, {})

    def test_exact_policy_amount_rejects_underpayment(self):
        result = choose(ScriptedModel([proposal(19)]))
        self.assertEqual(result.status, "no_valid_candidate")
        self.assertIn("policy_rejected", result.reasons)


if __name__ == "__main__":
    unittest.main(verbosity=2)
