# Local vertical slice: evidence and defence

Implemented and executed a Python fake containing scripted proposals, an observed-receipt map, schema/evidence validation, deterministic admission, bounded fallback and an in-memory ledger. No model provider or payment service is imported or contacted. The user-authorized fake permits amounts up to 20; the exact reimbursement for this fixture is min(observed R1 amount 30, cap 20) = 20.

## Plan and invariant

A ready decision must reference an observed receipt, match its currency, have positive integer money, agree with explanation_amount, and equal the policy-derived reimbursement without exceeding the cap. An invalid first proposal must not prevent a supported second proposal from succeeding. After two invalid candidates, or a timeout, the flow must terminate without producing a fake effect.

`plan.md` records that invariant before execution. `starter_slice.py` preserves the initial implementation with the exact supplied bug:

```python
def admit(p):
    return p["amount"] >= 20
```

## Executed evidence

From this run's `outputs` directory, executed:

```text
python --version
Python 3.11.9

python -m unittest -v test_slice
Before correction: 11 tests; 3 failures; exit code 1.
After correction: 11 tests; all pass; exit code 0.
```

The command wrapper preserves subprocess stderr/stdout and the subprocess exit code in `before-fix.log` and `after-fix.log`. The wrapper itself completed successfully even when the first test subprocess returned 1. These are actual local runs, not proposed checks.

| Fixture | Observed after correction |
|---|---|
| R1 amount 30, then R1 amount 20 | Reject 30; select 20 on the second call; one fake ledger entry |
| Direct admission of amount 30 | False |
| Invented R9 | `unobserved_receipt`; no ready decision or ledger entry |
| Scripted timeout followed by valid proposal | `model_timeout`; exactly one call; no ledger entry |
| Amount 20, explanation_amount 30 | `inconsistent_explanation`; no valid candidate |
| R1 amount 30, R9 amount 20, then valid third proposal | Two calls only; `no_valid_candidate`; third proposal unconsumed |
| Currency EUR against observed USD | `currency_mismatch` |
| Boolean amount | `invalid_schema` |
| Same valid request committed twice | One in-memory entry |
| Valid amount 20 with narrowed authorization 19 | Effect rejected; ledger empty |
| Supported amount 19 | Rejected because the exact calculated reimbursement is 20 |

## Debug and correction

The first run demonstrated the reversed boundary predicate: 30 satisfied `>=20`, so selection stopped before the permitted fallback. It also made the all-invalid candidate case return `ready`. Correction computes `expected = min(receipt["amount"], CAP)` and requires both `0 < amount <= CAP` and `amount == expected`. Schema/evidence checks precede this function. The amount cap and exact-total requirement are independently stated in the invariant.

Review confirmed that model proposals do not define observed receipts or policy, and no natural-language explanation supplies authority. The second candidate is a fresh supported proposal, not a silent change to the rejected proposal. Exhaustion and timeout remain explicit terminal outcomes. The fake effect revalidates the decision and enforces authorization again, protecting the mutation boundary.

## Limits

This is a single-process fixture demonstration. The map and cap are trusted local constants; integer units represent the requested fixture amounts, without currency conversion or rounding. Approval is the supplied fake scope, not authenticated approval infrastructure. An in-memory replay check is not durable idempotency or crash-safe execution. Real OCR, provider timeouts, concurrency, reconciliation, approval expiry, policy revisions and live payment adapters were not tested. The passing fixtures establish these local behaviors only.
