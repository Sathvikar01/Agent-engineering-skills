"""Local deterministic fake. Amounts are integer fixture units; no SDK/network."""
from dataclasses import dataclass, field

CAP = 20
MAX_CANDIDATES = 2
RECEIPTS = {"R1": {"amount": 30, "currency": "USD"}}


def admit(p):
    receipt = RECEIPTS[p["receipt_id"]]
    expected = min(receipt["amount"], CAP)
    return 0 < p["amount"] <= CAP and p["amount"] == expected


class ScriptedModel:
    def __init__(self, events):
        self.events = iter(events)
        self.calls = 0

    def propose(self):
        self.calls += 1
        event = next(self.events, None)
        if isinstance(event, Exception):
            raise event
        return event


@dataclass
class Decision:
    status: str
    proposal: dict | None = None
    reasons: list[str] = field(default_factory=list)
    attempts: int = 0


def validate(p):
    required = {"receipt_id", "amount", "explanation_amount", "currency"}
    if not isinstance(p, dict) or set(p) != required:
        return "invalid_schema"
    if (not isinstance(p["receipt_id"], str)
            or not isinstance(p["currency"], str)
            or type(p["amount"]) is not int
            or type(p["explanation_amount"]) is not int):
        return "invalid_schema"
    receipt = RECEIPTS.get(p["receipt_id"])
    if receipt is None:
        return "unobserved_receipt"
    if p["currency"] != receipt["currency"]:
        return "currency_mismatch"
    if p["amount"] <= 0 or p["amount"] > receipt["amount"]:
        return "unsupported_amount"
    if p["explanation_amount"] != p["amount"]:
        return "inconsistent_explanation"
    return None


def choose(model):
    reasons = []
    for attempt in range(1, MAX_CANDIDATES + 1):
        try:
            p = model.propose()
        except TimeoutError:
            return Decision("model_timeout", reasons=reasons + ["timeout"], attempts=attempt)
        if p is None:
            return Decision("no_valid_candidate", reasons=reasons + ["exhausted"], attempts=attempt)
        reason = validate(p)
        if reason is None and not admit(p):
            reason = "policy_rejected"
        if reason is not None:
            reasons.append(reason)
            continue
        # Copy so a caller cannot mutate the model's original proposal afterward.
        return Decision("ready", dict(p), reasons, attempt)
    return Decision("no_valid_candidate", reasons=reasons + ["budget_exhausted"], attempts=MAX_CANDIDATES)


class FakeLedger:
    """In-memory authorized event only: does not send any payment."""
    def __init__(self):
        self.entries = {}

    def commit(self, request_id, decision, authorized_max=20):
        if decision.status != "ready" or decision.proposal is None:
            raise ValueError("not_ready")
        p = decision.proposal
        if validate(p) is not None or not admit(p):
            raise ValueError("invalid_decision")
        if type(authorized_max) is not int or not 0 < p["amount"] <= authorized_max <= CAP:
            raise ValueError("outside_authorization")
        existing = self.entries.get(request_id)
        if existing is not None:
            if existing != p:
                raise ValueError("request_conflict")
            return dict(existing)
        self.entries[request_id] = dict(p)
        return dict(p)

