# Tenant-isolated conditional fan-out/fan-in

Use a deterministic coordinator with up to eight concurrent, context-isolated model workers. The 60 document sets are independently comparable, so isolation is a credible reason to separate worker invocations. They do not need autonomous agent personas, mutual chat, or a multi-agent framework. Whether parallel execution improves latency or quality remains unmeasured; retain a sequential worker baseline for comparison. Workers cannot delegate recursively.

The task graph is `validate → partition → conditional dispatch → validate results → reconcile exceptions → merge → publish`. Partition by tenant and document set. Dispatch only when the set is eligible, its required document versions are available, it has no unresolved dependency, a budget reservation succeeds, and its task lease is active. Known normalization and comparison rules run as deterministic functions; invoke a model only for interpretation that those rules cannot resolve. If a set depends on another result, make that edge explicit and wait rather than assuming all 60 are independent.

Each worker gets a fresh context and tenant-scoped retrieval identity. Its document allowlist, storage paths, cache keys and evidence references include tenant identity. The coordinator receives narrowly scoped result records, not a combined worker transcript containing other tenants' documents. Verify authorization again when resolving evidence references; tenant labels alone do not provide isolation. Treat document text and handoff summaries as untrusted data that cannot alter tools, policy or budgets.

A typed handoff can use this contract:

```typescript
type Task = {
  runId: string; parentId: string; taskId: string; attemptId: string;
  tenantId: string; documentSetId: string; objective: string;
  documents: { id: string; version: string; digest: string }[];
  evidenceScope: string[]; outputSchemaVersion: "1";
  allowedTools: ("read_document" | "compare")[];
  completionCriteria: string[];
  deadline: string; leaseEpoch: number; cancellationToken: string;
  limits: { spend: number; modelCalls: number; toolCalls: number };
  delegationAllowed: false;
};
type Result = {
  runId: string; taskId: string; attemptId: string; tenantId: string;
  leaseEpoch: number;
  status: "complete" | "incomplete" | "failed";
  claims: { text: string; evidence: {
    documentId: string; version: string; location: string; digest: string
  }[] }[];
  contradictions: string[]; unresolvedQuestions: string[];
  proposedEffects: { operationId: string; payloadDigest: string }[];
  usage: { spend: number; modelCalls: number; toolCalls: number };
};
```

The coordinator owns job state and result acceptance. A policy-controlled effect broker alone owns external writes. Workers return evidence and proposals; they receive no write capability. Persist proposals and operation IDs before submission, and enforce stable idempotency keys across retries. Schema validation establishes shape, not factual accuracy: acceptance also checks scope, versions, evidence support, provenance and current lease.

| Situation | Required behavior |
|---|---|
| Timeout after possible effect | Mark the effect outcome unknown. Reconcile operation ID with authoritative effect records before retrying; timeout does not mean failure. If outcome cannot be established, hold the affected set for resolution. |
| Contradictory evidence | Preserve both claims and source locations. Re-read relevant versions within the recovery budget. Apply documented precedence only when warranted; otherwise report unresolved conflict. Voting cannot establish truth. |
| Response after cancellation | Record it for audit, but reject it from fan-in and block delayed effects using the invalidated lease epoch. Cancellation cannot undo an effect already committed. |
| Duplicate or missing result | Accept one valid logical result per task. Reject stale attempts; show missing coverage explicitly and never call a partial merge complete. |

Interpret shared spend=100 as 100 budget units. Atomically reserve 75 for initial workers (1.25 each), 10 for coordinator interpretation and merge, and 15 for reconciliation. All billable work, including failed attempts, counts. Maintain `settled spend + outstanding reservations ≤ 100`; reconcile uncertain usage before releasing its reservation. Additional attempts require funded reservations and the same policy checks.

Proposed limits are two model calls and six reads per worker, a 60-second attempt deadline, a ten-minute job deadline, one reconciliation round and at most one reconciled retry per affected set. Stop on completion, cancellation, exhausted budget, expired deadline, policy denial or repeated identical evidence without progress. Log parent/attempt IDs, document and worker versions, reservations, conflicts and acceptance decisions. These are design limits, not measured performance. Compare sequential and parallel execution on representative sets, including duplicates, skew, unknown effects and late results; no runtime tests or live effects were executed for this design.
