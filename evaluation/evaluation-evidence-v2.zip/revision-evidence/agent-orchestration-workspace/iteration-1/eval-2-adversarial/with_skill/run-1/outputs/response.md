Use one authoritative controller with conditional fan-out/fan-in. Sixty independent document sets and tenant-isolated evidence make workers plausible, but parallelism alone does not justify model agents: use deterministic comparison functions for structured, rule-based sets and bounded model workers only for semantic comparisons. This is a proposed architecture; no measured advantage or execution evidence is claimed.

The controller owns scheduling, the aggregate ledger, accepted results and the final report. Workers own no shared mutable resource, receive no coordinator credentials, and cannot delegate. Each tenant-scoped retrieval identity can access only its assigned set. Cache keys, storage partitions, traces and retrieval filters include tenant ID; context construction must verify every evidence item belongs to that tenant. External document text and worker summaries remain untrusted data.

The graph is preflight → eligible comparisons → validation/fan-in → bounded conflict verification → report. Comparisons are independent after preflight; an invalid tenant scope blocks that branch. Run up to eight workers concurrently and dispatch at most 60 comparison tasks. A deterministic preflight chooses a fixed comparator when sufficient; otherwise it selects a semantic worker. Do not distribute all tenants' documents in a shared prompt.

A compact typed handoff is:

```ts
type CompareTask = {
  runId: string; taskId: string; parentId: string;
  tenantId: string; attempt: number; generation: number;
  objective: string; scope: { documentSetId: string };
  evidence: { sourceId: string; version: string; hash: string }[];
  outputSchema: "comparison-v1";
  allowedTools: ("readScopedSource" | "compare")[];
  completion: "all-required-claims-have-versioned-evidence";
  deadline: string; cancelToken: string;
  budget: { spend: number; modelCalls: 1; toolCalls: 2 };
};
type CompareResult = {
  runId: string; taskId: string; tenantId: string;
  generation: number;
  status: "complete" | "insufficient" | "failed";
  claims: { key: string; value: string; evidenceIds: string[] }[];
  evidence: { id: string; sourceId: string; version: string; hash: string }[];
};
```

Spend=100 means shared accounting units, not an assumed currency. Reserve ceilings atomically: coordinator 10, 60 comparisons × 1.3 = 78, reconciliation/verification 12. Every provider call reserves its maximum charge before dispatch and settles actual usage afterward; outstanding reservations count against 100. Reject unbounded-cost operations. Release unused funds only after confirming no outstanding liability. Enforce global maxima of 70 model calls, 132 tool calls, 160 controller transitions, eight concurrent comparisons and a five-minute run deadline. Each logical comparison gets one model call, two tool calls, ten transitions and 30 seconds, cumulative across at most two attempts. Coordinator ceilings are eight model calls and eight tools. Verification gets at most two model calls and four tools, included in the global ceilings; budget numbers require calibration before deployment.

Controller states are READY, RUNNING, RECONCILING, VALIDATING, VERIFYING and terminal COMPLETE, PARTIAL, CANCELLED or FAILED. Dispatch requires valid scope, dependencies, active generation, remaining deadline and reserved budget. Accepting a result additionally requires matching IDs, schema, authorized provenance and the current generation. Completion requires all required branches accepted and material conflicts resolved. Three successive transitions without new accepted evidence, resolved uncertainty or a completed dependency terminate that branch; polling and repeated proposals do not count as progress.

For the timed-out worker with a possible effect, mark EFFECT_UNKNOWN and reconcile before retrying. Comparison workers should be read-only, but an observed possible legacy effect still demands reconciliation. An effect broker is the sole writer: it records a stable logical-operation idempotency key, request hash, status and receipt before dispatch. Query that receipt/provider status using the same key. If unresolved, quarantine the branch and return an incomplete result; neither timeout nor absence of a receipt proves failure. No new-key replay is allowed. A confirmed no-effect outcome permits one retry only within remaining task and global quotas; a confirmed effect resumes from its receipt.

For contradictory evidence, retain both versions and citations. Apply declared version precedence only when authoritative metadata actually establishes supersession; otherwise run one bounded targeted source check, then expose unresolved disagreement. Never majority-vote factual truth. Duplicate matching results deduplicate; differing duplicates become conflicts. For late responses after cancellation, generation and cancellation checks reject commit while preserving an audit record. Restart/resume preserves ledger, attempts, generations and unknown effects.

Evaluate against deterministic and single-agent baselines on tenant leakage, evidence correctness, completion, p95 latency and total cost including merge work. Inject skew, missing workers, duplicate dispatch, contradictions and cancellation races. These checks are proposed, not run; adopt workers only if their measured benefit survives them.

