"""Local, standard-library-only telemetry fake. Never invokes a real tool."""
import hashlib
import json
import re
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
VERSIONS = {
    "model": "fake-model-v1", "prompt": "support-v3", "schema": "trace-v1",
    "tool": "fake-tools-v1", "policy": "scope-v4", "retrieval": "fake-index-v1",
}
FIELDS = {
    "request.accepted": {"request_ref", "principal_ref", "scope", "state_version"},
    "action.proposed": {"action", "resource_ref", "action_digest", "state_version"},
    "policy.decided": {"decision", "reason_code", "action_digest", "state_version"},
    "model.completed": {"input_token_count", "output_token_count", "usage_source", "cost"},
    "tool.attempted": {"action", "resource_ref", "action_digest", "state_version"},
    "tool.result": {"classification", "receipt_ref", "effect", "state_version"},
    "worker.resumed": {"checkpoint_ref", "state_version", "previous_worker_ref"},
    "retry.scheduled": {"previous_attempt_id", "reason_code", "state_version"},
    "answer.completed": {"answer_ref", "evidence_refs", "state_version"},
    "run.terminal": {"task_outcome", "policy_outcome", "effect_outcome", "stop_reason", "state_version"},
}
FORBIDDEN = {"raw_tokens", "api_key", "credentials", "private_reasoning", "chain_of_thought"}
SECRET = re.compile(r"sk-test-[A-Za-z0-9_-]+|Bearer\s+\S+", re.IGNORECASE)


def scrub(value):
    if isinstance(value, str):
        return SECRET.sub("[REDACTED]", value)[:160]
    if isinstance(value, list):
        return [scrub(item) for item in value[:8]]
    if isinstance(value, dict):
        return {key: scrub(item) for key, item in value.items() if key not in FORBIDDEN}
    return value


def digest(action, resource):
    # Digest only normalized, non-secret action identity; never hash credentials.
    return hashlib.sha256(json.dumps([action, resource]).encode()).hexdigest()


class Recorder:
    def __init__(self):
        self.events = []

    def emit(self, kind, fields, *, op=None, attempt=None, span="root", parent=None, worker="w1"):
        if kind not in FIELDS:
            raise ValueError("unknown event contract")
        allowed = {key: value for key, value in fields.items() if key in FIELDS[kind]}
        sequence = len(self.events) + 1
        event = {
            "schema_version": "trace-v1", "event_id": f"e{sequence}", "seq": sequence,
            "event_time": datetime.now(timezone.utc).isoformat(), "run_id": "fake-run-17",
            "request_id": "fake-request-17", "event_type": kind, "span_id": span,
            "parent_span_id": parent, "worker_id": worker, "task_id": "support-task",
            "logical_operation_id": op, "attempt_id": attempt, "versions": VERSIONS,
            "fields": scrub(allowed), "dropped_field_count": len(fields) - len(allowed),
        }
        self.events.append(event)


def fake_run():
    r = Recorder()
    r.emit("request.accepted", {"request_ref": "restricted://requests/17", "principal_ref": "principal-7",
           "scope": "support.read", "state_version": 1, "api_key": "sk-test-credential",
           "raw_tokens": ["PRIVATE_TOKEN"], "private_reasoning": "PRIVATE_REASONING_SENTINEL"})
    write_digest = digest("write", "resource:case-17")
    r.emit("action.proposed", {"action": "write", "resource_ref": "resource:case-17",
           "action_digest": write_digest, "state_version": 1}, op="op-write")
    r.emit("policy.decided", {"decision": "deny", "reason_code": "scope_missing.write",
           "action_digest": write_digest, "state_version": 1}, op="op-write")
    r.emit("model.completed", {"input_token_count": 120, "output_token_count": 30,
           "usage_source": "fake_provider_counts", "cost": None, "raw_tokens": ["PRIVATE_TOKEN"]})
    read_digest = digest("read", "resource:case-17")
    r.emit("action.proposed", {"action": "read", "resource_ref": "resource:case-17",
           "action_digest": read_digest, "state_version": 1}, op="op-read", span="child-read", parent="root")
    r.emit("policy.decided", {"decision": "allow", "reason_code": "scope_matched.read",
           "action_digest": read_digest, "state_version": 1}, op="op-read", span="child-read", parent="root")
    r.emit("tool.attempted", {"action": "read", "resource_ref": "resource:case-17",
           "action_digest": read_digest, "state_version": 1}, op="op-read", attempt="read-1", span="child-read", parent="root")
    r.emit("tool.result", {"classification": "response_lost", "receipt_ref": None, "effect": "unknown",
           "state_version": 1}, op="op-read", attempt="read-1", span="child-read", parent="root")
    r.emit("worker.resumed", {"checkpoint_ref": "restricted://checkpoints/17", "state_version": 1,
           "previous_worker_ref": "w1"}, span="child-read", parent="root", worker="w2")
    r.emit("retry.scheduled", {"previous_attempt_id": "read-1", "reason_code": "read_only_safe_retry",
           "state_version": 1}, op="op-read", attempt="read-2", span="child-read", parent="root", worker="w2")
    r.emit("tool.attempted", {"action": "read", "resource_ref": "resource:case-17",
           "action_digest": read_digest, "state_version": 1}, op="op-read", attempt="read-2", span="child-read", parent="root", worker="w2")
    r.emit("tool.result", {"classification": "success", "receipt_ref": "restricted://receipts/read-2",
           "effect": "read_only", "state_version": 1}, op="op-read", attempt="read-2", span="child-read", parent="root", worker="w2")
    r.emit("answer.completed", {"answer_ref": "restricted://answers/17",
           "evidence_refs": ["restricted://receipts/read-2"], "state_version": 1})
    r.emit("run.terminal", {"task_outcome": "succeeded", "policy_outcome": "denied_attempt_present",
           "effect_outcome": "no_write_dispatched", "stop_reason": "answer_delivered", "state_version": 1})
    return r.events


def reconstruct(events):
    # Input is persisted/exported data, not the Recorder's internal state.
    ordered = sorted(events, key=lambda event: event["seq"])
    complete = [e["seq"] for e in ordered] == list(range(1, len(ordered) + 1))
    complete &= len({e["event_id"] for e in ordered}) == len(ordered)
    complete &= bool(ordered and ordered[0]["event_type"] == "request.accepted")
    terminals = [e for e in ordered if e["event_type"] == "run.terminal"]
    complete &= len(terminals) == 1
    spans = {e["span_id"] for e in ordered}
    complete &= all(e["parent_span_id"] is None or e["parent_span_id"] in spans for e in ordered)
    denied = [e["logical_operation_id"] for e in ordered
              if e["event_type"] == "policy.decided" and e["fields"]["decision"] == "deny"]
    attempts = [e for e in ordered if e["event_type"] == "tool.attempted"]
    forbidden_dispatch = any(e["logical_operation_id"] in denied for e in attempts)
    unknown = [e["attempt_id"] for e in ordered if e["event_type"] == "tool.result" and e["fields"]["effect"] == "unknown"]
    return {"trace_complete": bool(complete), "denied_operations": denied,
            "attempts": [e["attempt_id"] for e in attempts], "unknown_result_attempts": unknown,
            "denied_operation_dispatched": forbidden_dispatch,
            "terminal": terminals[-1]["fields"] if terminals else None}


def metric_labels(labels):
    allowed = {"release", "task_class", "outcome", "error_class"}
    if set(labels) - allowed:
        raise ValueError("unbounded or unsupported metric label")
    return labels


class ReconstructionTests(unittest.TestCase):
    def setUp(self):
        self.events = json.loads(json.dumps(fake_run()))

    def test_success_preserves_denied_write_and_unknown_read(self):
        result = reconstruct(self.events)
        self.assertTrue(result["trace_complete"])
        self.assertEqual(result["denied_operations"], ["op-write"])
        self.assertFalse(result["denied_operation_dispatched"])
        self.assertEqual(result["unknown_result_attempts"], ["read-1"])
        self.assertEqual(result["terminal"]["task_outcome"], "succeeded")

    def test_secret_private_reasoning_and_raw_tokens_absent(self):
        data = json.dumps(self.events)
        for value in ["sk-test-credential", "PRIVATE_REASONING_SENTINEL", "PRIVATE_TOKEN", "api_key", "raw_tokens", "private_reasoning"]:
            self.assertNotIn(value, data)
        self.assertEqual(scrub("Bearer fake-secret"), "[REDACTED]")
        self.assertEqual(len(scrub("x" * 300)), 160)

    def test_missing_denial_is_incomplete(self):
        self.assertFalse(reconstruct([e for e in self.events if e["event_type"] != "policy.decided" or e["fields"]["decision"] != "deny"])["trace_complete"])

    def test_duplicate_is_incomplete(self):
        self.assertFalse(reconstruct(self.events + [self.events[2]])["trace_complete"])

    def test_broken_worker_parent_is_incomplete(self):
        self.events[4]["parent_span_id"] = "missing-parent"
        self.assertFalse(reconstruct(self.events)["trace_complete"])

    def test_metric_run_id_rejected(self):
        with self.assertRaises(ValueError):
            metric_labels({"release": "fake-v1", "run_id": "fake-run-17"})
        self.assertEqual(metric_labels({"release": "fake-v1", "outcome": "succeeded"})["outcome"], "succeeded")


if __name__ == "__main__":
    events = fake_run()
    (OUT / "trace.jsonl").write_text("\n".join(json.dumps(e, sort_keys=True) for e in events) + "\n", encoding="utf-8")
    exported = [json.loads(line) for line in (OUT / "trace.jsonl").read_text(encoding="utf-8").splitlines()]
    (OUT / "reconstruction.json").write_text(json.dumps(reconstruct(exported), indent=2) + "\n", encoding="utf-8")
    print("Artifacts: trace.jsonl, reconstruction.json; all data synthetic; live tools invoked: 0", flush=True)
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ReconstructionTests))
    sys.exit(0 if result.wasSuccessful() else 1)
