"""Local fake trace/export test. No network, live effects, or provider SDK.

Run: python reconstruction_test.py
"""
import copy
import hashlib
import json
import re
import unittest
from pathlib import Path

OUT = Path(__file__).resolve().parent
SAFE_KEYS = {
    "schema_version", "event_id", "run_id", "request_id", "tenant_id",
    "worker_id", "span_id", "parent_span_id", "sequence", "event_time",
    "event_type", "logical_operation_id", "attempt_id", "state_version",
    "model_version", "prompt_version", "tool_version", "policy_version",
    "retrieval_version", "principal_scope", "action_digest", "reason_code",
    "result_class", "effect_class", "receipt_id", "evidence_ref",
    "status", "read_only", "approval_required", "evaluator_version",
    "evaluator_result", "tokens", "cost_usd", "external_boundaries",
}
SECRET = re.compile(r"(?:sk-[A-Za-z0-9_-]+|Bearer\s+\S+|token=[^\s,;]+)", re.I)


def safe_value(value):
    if isinstance(value, str):
        return SECRET.sub("[REDACTED]", value)[:256]
    if isinstance(value, list):
        return [safe_value(v) for v in value[:16]]
    if isinstance(value, (bool, int, float)) or value is None:
        return value
    raise ValueError("Unsupported payload shape; reject instead of serializing")


def export_event(raw):
    # An allowlist discards raw model payloads, arbitrary tool args, and reasoning.
    event = {k: safe_value(v) for k, v in raw.items() if k in SAFE_KEYS}
    if "evidence_ref" in event and not re.fullmatch(r"evidence:[a-z0-9-]+", event["evidence_ref"]):
        raise ValueError("Evidence reference must be an opaque, access-controlled ID")
    if not isinstance(event.get("tokens"), (int, type(None))):
        raise ValueError("Token usage must be an observed count or null")
    return event


METRIC_DOMAINS = {
    "release": {"v1", "v2"},
    "task_slice": {"support", "other"},
    "outcome": {"success", "failure", "safe_abstention"},
}


def metric_key(labels):
    if set(labels) != set(METRIC_DOMAINS):
        raise ValueError("Only registered bounded labels are permitted")
    if any(value not in METRIC_DOMAINS[key] for key, value in labels.items()):
        raise ValueError("Unknown dimension value; map to a registered bounded value")
    return tuple(sorted(labels.items()))


def fake_trace():
    rows = []
    current_state = 0
    def event(kind, span, parent, op=None, attempt=None, **fields):
        nonlocal current_state
        current_state = fields.get("state_version", current_state)
        n = len(rows) + 1
        rows.append({
            "schema_version": "1", "event_id": f"e{n}", "sequence": n,
            "event_time": f"2026-10-05T00:00:{n:02d}Z", "run_id": "run-local-1",
            "request_id": "request-local-1", "tenant_id": "fixture-tenant",
            "worker_id": "nested-worker" if parent != None else "root-worker",
            "span_id": span, "parent_span_id": parent, "event_type": kind,
            "logical_operation_id": op, "attempt_id": attempt, "state_version": current_state,
            "model_version": "fake-model-v1", "prompt_version": "support-v1",
            "tool_version": "mock-ticket-v1", "policy_version": "policy-v1",
            "retrieval_version": "fixture-v1", "principal_scope": "mock-ticket:write",
            **fields,
        })
    event("request.accepted", "root", None, external_boundaries=["provider-internals", "tool-internals"])
    event("worker.started", "worker", "root")
    digest = hashlib.sha256(b"write:restricted-destination").hexdigest()
    event("proposal.validated", "denied-proposal", "worker", "op-denied", action_digest=digest)
    event("policy.denied", "denial", "denied-proposal", "op-denied", reason_code="scope_excludes_destination")
    event("checkpoint", "checkpoint", "worker", state_version=1)
    event("runtime.resumed", "resume", "root", state_version=1)
    event("proposal.validated", "proposal", "resume", "op-mock", action_digest=hashlib.sha256(b"mock-ticket:fixture-1").hexdigest())
    event("policy.allowed", "admission", "proposal", "op-mock", approval_required=True)
    event("approval.requested", "approval-request", "admission", "op-mock")
    event("approval.granted", "approval", "approval-request", "op-mock", reason_code="fixture_operator_authorized")
    event("tool.attempt", "attempt-1", "approval", "op-mock", "a1", read_only=False)
    fake_store, write_calls = {}, 0
    def fake_write():
        nonlocal write_calls
        write_calls += 1
        fake_store["op-mock"] = "receipt-local-1"
        raise TimeoutError("Injected lost response after in-memory commit")
    try:
        fake_write()
    except TimeoutError:
        pass
    # In-memory fake committed; the simulated caller lost the response.
    event("tool.result", "result-1", "attempt-1", "op-mock", "a1", result_class="lost_response", effect_class="unknown")
    event("retry.scheduled", "retry", "result-1", "op-mock", reason_code="reconcile_before_resubmission")
    event("tool.attempt", "attempt-2", "retry", "op-mock", "a2", read_only=True)
    receipt = fake_store.get("op-mock")  # Read-only reconciliation, no write replay.
    assert receipt == "receipt-local-1" and write_calls == 1
    event("tool.result", "result-2", "attempt-2", "op-mock", "a2", result_class="reconciled", effect_class="committed", receipt_id=receipt, evidence_ref="evidence:receipt-local-1")
    event("checkpoint", "commit", "result-2", "op-mock", state_version=2)
    event("evaluator.outcome", "eval-a", "commit", evaluator_version="fixture-eval-a-v1", evaluator_result="fail")
    event("evaluator.outcome", "eval-b", "commit", evaluator_version="fixture-eval-b-v1", evaluator_result="pass")
    event("terminal", "terminal", "root", status="success", state_version=2, tokens=None, cost_usd=None)
    return rows


def reconstruct(events):
    """Reject broken joins/causality; a terminal answer alone never proves a run."""
    errors, missing = [], []
    by_span = {e["span_id"]: e for e in events}
    if len(by_span) != len(events):
        errors.append("duplicate_span_id")
    if len({e["event_id"] for e in events}) != len(events):
        errors.append("duplicate_event_id")
    if len({e["run_id"] for e in events}) != 1:
        errors.append("mixed_run_ids")
    sequences = [e["sequence"] for e in events]
    if len(set(sequences)) != len(sequences):
        errors.append("duplicate_sequence")
    if sequences and sorted(sequences) != list(range(1, max(sequences) + 1)):
        missing.append("sequence_gap")
    for e in events:
        p = e["parent_span_id"]
        if p and p not in by_span:
            missing.append("orphan_parent:" + p)
        visited, cursor = set(), e["span_id"]
        while cursor in by_span:
            if cursor in visited:
                errors.append("cyclic_parent_link")
                break
            visited.add(cursor)
            cursor = by_span[cursor]["parent_span_id"]
        if p in by_span and by_span[p]["sequence"] >= e["sequence"]:
            errors.append("parent_not_before_child")
    kinds = {e["event_type"] for e in events}
    for kind in ("request.accepted", "terminal"):
        if kind not in kinds:
            missing.append("missing:" + kind)
    for e in events:
        if e["event_type"] != "tool.attempt":
            continue
        prior = [x for x in events if x["logical_operation_id"] == e["logical_operation_id"] and x["sequence"] < e["sequence"]]
        policies = [x for x in prior if x["event_type"].startswith("policy.")]
        if not policies:
            missing.append("missing:policy_decision")
        elif policies[-1]["event_type"] != "policy.allowed":
            errors.append("attempt_after_denial")
        elif policies[-1].get("approval_required") and not any(x["event_type"] == "approval.granted" for x in prior):
            missing.append("missing:approval_granted")
        if any(x.get("effect_class") == "unknown" for x in prior) and not e["read_only"]:
            errors.append("mutation_retry_before_reconciliation")
        results = [x for x in events if x["event_type"] == "tool.result" and x["logical_operation_id"] == e["logical_operation_id"] and x["attempt_id"] == e["attempt_id"] and x["sequence"] > e["sequence"]]
        if len(results) != 1:
            missing.append("missing_or_duplicate:tool_result:" + e["attempt_id"])
    terminal = next((e for e in events if e["event_type"] == "terminal"), None)
    if terminal and terminal["sequence"] != max(sequences):
        errors.append("terminal_before_remaining_events")
    denials = [e["logical_operation_id"] for e in events if e["event_type"] == "policy.denied"]
    evaluations = {e["evaluator_result"] for e in events if e["event_type"] == "evaluator.outcome"}
    return {
        "reconstruction": "inconsistent" if errors else "incomplete" if missing else "complete_with_declared_boundaries",
        "errors": sorted(set(errors)), "missing": sorted(set(missing)),
        "terminal_status": terminal.get("status") if terminal else None,
        "denied_operations": denials, "evaluator_disagreement": len(evaluations) > 1,
        "unknown_effect_seen": any(e.get("effect_class") == "unknown" for e in events),
        "receipts": [e["receipt_id"] for e in events if e.get("receipt_id")],
        "state_versions": sorted({e["state_version"] for e in events}),
        "external_boundaries": events[0].get("external_boundaries", []) if events else [],
    }


class ReconstructionTests(unittest.TestCase):
    def setUp(self):
        self.trace = [export_event(e) for e in fake_trace()]

    def test_success_preserves_denial_restart_worker_ambiguity_and_disagreement(self):
        report = reconstruct(self.trace)
        self.assertEqual(report["reconstruction"], "complete_with_declared_boundaries")
        self.assertEqual(report["terminal_status"], "success")
        self.assertEqual(report["denied_operations"], ["op-denied"])
        self.assertTrue(report["evaluator_disagreement"])
        self.assertTrue(report["unknown_effect_seen"])
        self.assertEqual(report["receipts"], ["receipt-local-1"])
        self.assertEqual(report["state_versions"], [0, 1, 2])

    def test_redacts_before_persistence_and_drops_private_reasoning(self):
        raw = {**self.trace[0], "raw_tokens": ["private-token"], "api_credentials": "sk-private", "private_reasoning": "PRIVATE_REASONING_MARKER", "reason_code": "Bearer secret-value token=abc sk-secret"}
        serialized = json.dumps(export_event(raw))
        for forbidden in ("private-token", "sk-private", "PRIVATE_REASONING_MARKER", "secret-value", "token=abc", "sk-secret"):
            self.assertNotIn(forbidden, serialized)
        self.assertIn("[REDACTED]", serialized)

    def test_rejects_public_evidence_url(self):
        with self.assertRaises(ValueError):
            export_event({**self.trace[0], "evidence_ref": "https://public.example/private"})

    def test_rejects_run_id_metric_label(self):
        labels = {"release": "v2", "task_slice": "support", "outcome": "success"}
        metric_key(labels)
        with self.assertRaises(ValueError):
            metric_key({**labels, "run_id": "arbitrary-id"})

    def test_orphan_is_incomplete(self):
        self.trace[1]["parent_span_id"] = "absent"
        self.assertEqual(reconstruct(self.trace)["reconstruction"], "incomplete")

    def test_cycle_is_inconsistent(self):
        self.trace[0]["parent_span_id"] = "worker"
        self.assertEqual(reconstruct(self.trace)["reconstruction"], "inconsistent")

    def test_missing_required_policy_or_result_is_incomplete(self):
        for removed in ("policy.allowed", "tool.result"):
            altered = [e for e in self.trace if e["event_type"] != removed]
            self.assertEqual(reconstruct(altered)["reconstruction"], "incomplete")

    def test_deleted_denial_is_detected_as_gap(self):
        altered = [e for e in self.trace if e["event_type"] != "policy.denied"]
        self.assertIn("sequence_gap", reconstruct(altered)["missing"])

    def test_no_mutation_retry_after_lost_response(self):
        self.trace[13]["read_only"] = False
        self.assertIn("mutation_retry_before_reconciliation", reconstruct(self.trace)["errors"])

    def test_no_attempt_after_denial(self):
        self.trace[7]["event_type"] = "policy.denied"
        self.assertIn("attempt_after_denial", reconstruct(self.trace)["errors"])

    def test_unavailable_usage_is_null(self):
        self.assertIsNone(self.trace[-1]["tokens"])
        self.assertIsNone(self.trace[-1]["cost_usd"])


if __name__ == "__main__":
    trace = [export_event(e) for e in fake_trace()]
    OUT.joinpath("safe_trace.json").write_text(json.dumps(trace, indent=2), encoding="utf-8")
    OUT.joinpath("reconstruction.json").write_text(json.dumps(reconstruct(trace), indent=2), encoding="utf-8")
    unittest.main(verbosity=2)
