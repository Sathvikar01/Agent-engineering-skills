"""Synthetic signal-contract tests; no provider, production data, or live effects."""
import json
import sys
import unittest
from pathlib import Path

OUT = Path(__file__).resolve().parent
DIMENSIONS = ["release", "task_class", "retrieval_version", "policy_version"]
ENVELOPE = ["schema_version", "event_id", "event_time", "run_id", "worker_id", "release"]
CONTRACTS = {
    "evidence.claim_checked.v1": {
        "required": ENVELOPE + ["answer_ref", "claim_id", "requires_evidence", "citation_refs",
                                "context_refs", "verdict", "checker_version", "verdict_source"],
        "verdict_enum": ["supported", "unsupported", "unknown"],
        "population": "final-answer claims requiring external evidence",
        "numerator": "unsupported claims with a completed supported/unsupported verdict",
        "denominator": "supported plus unsupported claims requiring evidence",
        "coverage": "checked claims / all claims requiring evidence; unknown separately counted",
        "aggregation": "rolling one-hour window, per release/task class; deduplicate event_id",
        "metric_dimensions": DIMENSIONS,
        "unknown_policy": "missing verdict does not count as supported or unsupported",
        "operator_action": "inspect answer-to-claim-to-source links; validate checker; narrow or abstain",
    },
    "tool.attempt_finished.v1": {
        "required": ENVELOPE + ["logical_operation_id", "attempt_id", "tool_version", "classification",
                                "receipt_ref", "effect_status", "retry_reason", "provider_cost"],
        "classification_enum": ["success", "failure", "timeout", "invalid_response"],
        "population": "attempts with a finished result classification",
        "numerator": "failure, timeout or invalid_response attempts",
        "denominator": "all finished classified attempts; orphan started attempts separate",
        "aggregation": "rolling one-hour window; deduplicate (logical_operation_id, attempt_id)",
        "metric_dimensions": ["release", "task_class", "tool_version", "classification"],
        "unknown_policy": "unknown effect distinct from failed result; null cost remains unavailable",
        "operator_action": "group failures by tool/version; reconcile effects before retrying",
    },
    "user.override_recorded.v1": {
        "required": ENVELOPE + ["interaction_id", "override_category", "requested_action_ref",
                                "applied_action_ref", "repair_attribution", "disposition"],
        "category_enum": ["factual_correction", "preference", "cancel", "permission_change"],
        "population": "eligible conversations with a user feedback opportunity, after the observation window",
        "numerator": "eligible conversations with at least one override",
        "denominator": "eligible conversations observed through that window",
        "aggregation": "conversation-level cohort; events separately counted; deduplicate interaction_id",
        "metric_dimensions": ["release", "task_class", "override_category", "disposition"],
        "unknown_policy": "preference/cancellation not automatically task failure; repair attribution may be unknown",
        "operator_action": "review factual corrections and ignored overrides; preserve user authority",
    },
    "safety.effect_audited.v1": {
        "required": ENVELOPE + ["logical_operation_id", "action_digest", "policy_decision_ref",
                                "receipt_ref", "policy_version", "verdict", "reason_code"],
        "verdict_enum": ["compliant", "breach", "unknown"],
        "population": "effectful actions eligible for policy audit",
        "numerator": "confirmed breached actions",
        "denominator": "audited compliant or breached actions; report audit coverage separately",
        "aggregation": "event alert for confirmed breach plus rolling rate",
        "metric_dimensions": ["release", "task_class", "policy_version", "reason_code"],
        "unknown_policy": "denied proposal without dispatch is not an executed breach",
        "operator_action": "contain affected capability, preserve audit evidence, reconcile actual effects",
    },
}


def evidence_summary(retrieved, context, claims):
    if not set(context).issubset(retrieved):
        raise ValueError("context lacks retrieval provenance")
    required = [claim for claim in claims if claim["requires_evidence"]]
    for claim in claims:
        if claim["verdict"] not in {"supported", "unsupported", "unknown"}:
            raise ValueError("unversioned quality verdict")
        if not set(claim["citation_refs"]).issubset(context):
            raise ValueError("citation not in assembled context")
    unsupported = sum(claim["verdict"] == "unsupported" for claim in required)
    checked = sum(claim["verdict"] != "unknown" for claim in required)
    return {"source": "synthetic_checker", "retrieved_refs": retrieved, "context_refs": context,
            "cited_refs": sorted({ref for claim in claims for ref in claim["citation_refs"]}),
            "unsupported_claims": unsupported, "checked_required_claims": checked,
            "required_claims": len(required), "unknown_required_claims": len(required) - checked,
            "unsupported_rate": unsupported / checked if checked else None,
            "check_coverage": checked / len(required) if required else None}


def attempts_summary(attempts):
    unique = {}
    for attempt in attempts:
        key = (attempt["logical_operation_id"], attempt["attempt_id"])
        if key in unique and unique[key] != attempt:
            raise ValueError("conflicting duplicate attempt")
        unique[key] = attempt
    completed = list(unique.values())
    allowed = {"success", "failure", "timeout", "invalid_response"}
    if any(attempt["classification"] not in allowed for attempt in completed):
        raise ValueError("unknown result classification")
    errors = sum(attempt["classification"] != "success" for attempt in completed)
    costs = [attempt["provider_cost"] for attempt in completed]
    return {"finished_attempts": len(completed), "error_attempts": errors,
            "error_rate": errors / len(completed) if completed else None,
            "unknown_effect_attempts": sum(a["effect_status"] == "unknown" for a in completed),
            "known_cost_subtotal": sum(cost for cost in costs if cost is not None),
            "total_cost": sum(costs) if all(cost is not None for cost in costs) and costs else None,
            "cost_covered_attempts": sum(cost is not None for cost in costs)}


def override_summary(eligible_conversations, override_events):
    eligible = set(eligible_conversations)
    affected = {e["conversation_id"] for e in override_events if e["conversation_id"] in eligible}
    repairs = {e["conversation_id"] for e in override_events
               if e["conversation_id"] in eligible and e["repair_attribution"] == "confirmed"}
    return {"eligible_conversations": len(eligible), "conversations_with_override": len(affected),
            "confirmed_repair_conversations": len(repairs),
            "override_rate": len(affected) / len(eligible) if eligible else None}


def safety_summary(events):
    audited = [e for e in events if e["effect_dispatched"] and e["verdict"] in {"compliant", "breach"}]
    breaches = sum(e["verdict"] == "breach" for e in audited)
    return {"confirmed_breaches": breaches, "audited_effectful_actions": len(audited),
            "immediate_incident": breaches > 0,
            "denied_proposals": sum(e["policy_decision"] == "deny" for e in events),
            "unknown_effect_audits": sum(e["effect_dispatched"] and e["verdict"] == "unknown" for e in events)}


def retry_exhaustion(operations):
    eligible = [op for op in operations if op["retried"] and op["terminal"]]
    exhausted = sum(op["stop_reason"] == "retry_exhausted" for op in eligible)
    return {"exhausted_operations": exhausted, "terminal_retried_operations": len(eligible),
            "rate": exhausted / len(eligible) if eligible else None}


def specimen():
    claims = [
        {"claim_id": "c1", "requires_evidence": True, "citation_refs": ["doc-a"], "verdict": "supported"},
        {"claim_id": "c2", "requires_evidence": True, "citation_refs": ["doc-b"], "verdict": "unsupported"},
        {"claim_id": "c3", "requires_evidence": True, "citation_refs": [], "verdict": "unknown"},
    ]
    attempts = [
        {"logical_operation_id": "lookup", "attempt_id": "a1", "worker_id": "w1", "classification": "timeout", "effect_status": "unknown", "provider_cost": 0.01},
        {"logical_operation_id": "lookup", "attempt_id": "a2", "worker_id": "w2", "classification": "success", "effect_status": "read_only", "provider_cost": 0.02},
        {"logical_operation_id": "model", "attempt_id": "a1", "worker_id": "w1", "classification": "invalid_response", "effect_status": "read_only", "provider_cost": None},
    ]
    return {"data_kind": "synthetic_only", "historical_baselines": None,
            "gold_eval": {"rate": 0.90, "source": "user_supplied_report", "dataset_version": None,
                          "denominator": None, "comparable_to_live": "unknown"},
            "live_report": {"relative_change": "doubled", "source": "user_supplied_report", "recomputed": False},
            "ad_hoc_report": {"description": "fine", "sample_design": "unavailable", "authoritative": False},
            "evidence": evidence_summary(["doc-a", "doc-b", "doc-unused"], ["doc-a", "doc-b"], claims),
            "attempts": attempts_summary(attempts),
            "retrieval": {"expected_evidence": True, "reason": "relevance_unknown", "confirmed_miss": None},
            "latency": {"logical_task_duration_ms": None, "historical_reference": None},
            "cost_drift": {"comparison": "unavailable", "historical_reference": None},
            "monitoring_status": "no historical drift threshold calibrated"}


class SignalTests(unittest.TestCase):
    def test_retrieved_unused_is_not_a_citation(self):
        data = specimen()["evidence"]
        self.assertEqual(data["cited_refs"], ["doc-a", "doc-b"])
        self.assertNotIn("doc-unused", data["cited_refs"])

    def test_unknown_does_not_look_supported(self):
        data = specimen()["evidence"]
        self.assertEqual(data["unsupported_claims"], 1)
        self.assertEqual(data["checked_required_claims"], 2)
        self.assertEqual(data["unknown_required_claims"], 1)

    def test_no_checked_claims_has_no_rate(self):
        data = evidence_summary([], [], [{"requires_evidence": True, "citation_refs": [], "verdict": "unknown"}])
        self.assertIsNone(data["unsupported_rate"])

    def test_missing_citation_provenance_is_rejected(self):
        with self.assertRaises(ValueError):
            evidence_summary(["doc-a"], [], [{"requires_evidence": True, "citation_refs": ["doc-a"], "verdict": "supported"}])

    def test_cost_unavailable_and_errors_include_failed_attempts(self):
        data = specimen()["attempts"]
        self.assertEqual(data["error_attempts"], 2)
        self.assertEqual(data["finished_attempts"], 3)
        self.assertAlmostEqual(data["known_cost_subtotal"], 0.03)
        self.assertIsNone(data["total_cost"])
        self.assertEqual(data["unknown_effect_attempts"], 1)

    def test_duplicate_attempt_does_not_double_count(self):
        item = {"logical_operation_id": "lookup", "attempt_id": "a1", "classification": "success", "effect_status": "read_only", "provider_cost": 0.01}
        self.assertEqual(attempts_summary([item, item])["finished_attempts"], 1)

    def test_user_preference_is_not_confirmed_repair(self):
        data = override_summary(["conv-1", "conv-2"], [{"conversation_id": "conv-1", "override_category": "preference", "repair_attribution": "not_repair"}])
        self.assertEqual(data["conversations_with_override"], 1)
        self.assertEqual(data["confirmed_repair_conversations"], 0)

    def test_denial_is_not_breach_but_dispatched_breach_alerts(self):
        deny = {"policy_decision": "deny", "effect_dispatched": False, "verdict": "unknown"}
        self.assertFalse(safety_summary([deny])["immediate_incident"])
        breach = {"policy_decision": "allow", "effect_dispatched": True, "verdict": "breach"}
        self.assertTrue(safety_summary([deny, breach])["immediate_incident"])

    def test_retry_exhaustion_counts_operations_not_attempts(self):
        self.assertEqual(retry_exhaustion([{"retried": True, "terminal": True, "stop_reason": "retry_exhausted"},
                                           {"retried": True, "terminal": True, "stop_reason": "succeeded"}])["exhausted_operations"], 1)

    def test_baselines_and_metric_ids_not_invented(self):
        self.assertIsNone(specimen()["historical_baselines"])
        for contract in CONTRACTS.values():
            self.assertNotIn("run_id", contract["metric_dimensions"])
            self.assertNotIn("worker_id", contract["metric_dimensions"])


if __name__ == "__main__":
    (OUT / "signal_contracts.json").write_text(json.dumps(CONTRACTS, indent=2) + "\n", encoding="utf-8")
    (OUT / "synthetic_signals.json").write_text(json.dumps(specimen(), indent=2) + "\n", encoding="utf-8")
    print("Artifacts: signal_contracts.json, synthetic_signals.json; synthetic values only; live tools invoked: 0", flush=True)
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SignalTests))
    sys.exit(0 if result.wasSuccessful() else 1)
