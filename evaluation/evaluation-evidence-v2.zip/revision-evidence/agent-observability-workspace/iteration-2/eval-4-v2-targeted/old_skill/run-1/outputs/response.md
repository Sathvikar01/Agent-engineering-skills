# Distinct support-agent signals and action plan

Replace `quality=good` with attributable, versioned outcomes. Preserve three different evidence streams: formal gold evaluations measure performance on a defined dataset; live monitoring measures production behavior and coverage; ad-hoc reviews generate investigation leads. The reported 90% is a formal result, not a live guarantee. The doubled live unsupported-evidence rate warrants investigation despite the reassuring sample. Retrieve denominators, periods, evaluator/dataset versions, task slices and sampling methods before comparing them. Until those are available, retain the reports as reports, not recomputed measurements or verified historical baselines.

Record retrieval results, assembled context and answer citations separately. A retrieved ID becomes a citation only when the final answer actually cites that source. Join answer reference → claim ID → citation/source version → checker verdict. Presence of a citation does not establish support. Record unsupported, supported and unknown verdicts; missing checks must not become “good.” The evaluation owner defines semantic support and validates the checker; telemetry records its provenance, results and disagreements.

Four concrete contracts are supplied in `signal_contracts.json`. Each specifies mandatory event fields, population, numerator/denominator, aggregation, unknown handling, bounded metric dimensions and operator action. Event envelopes carry schema/event/time/run/worker/release identifiers; run and worker IDs are trace joins, never metric dimensions.

| Contract | Required contract-specific fields | Measurement |
|---|---|---|
| `evidence.claim_checked.v1` | answer reference, claim ID, evidence requirement, citations, context references, verdict, checker version/source | Unsupported / checked evidence-required claims; also checked / all required claims and unknown count |
| `tool.attempt_finished.v1` | operation/attempt IDs, tool version, result class, receipt, effect status, retry reason, provider cost | Error attempts / finished classified attempts; orphan attempts and unknown effects separate |
| `user.override_recorded.v1` | interaction ID, category, requested/applied action references, repair attribution, disposition | Conversations with overrides / eligible conversations observed through the feedback window |
| `safety.effect_audited.v1` | operation, action digest, admission/receipt references, policy version, verdict, reason | Confirmed breaches / audited effectful actions, with audit coverage; confirmed breach triggers immediate containment |

Use a proposed one-hour rolling operational window, preserving release/task/version slices and raw counts. Override cohorts require a defined feedback observation window. These are contract proposals, not calibrated alert thresholds. Deduplicate event/attempt identifiers; persist denied proposals and failed attempts even when the final task succeeds. References need tenant access control, redaction before export and explicit retention. Reconstruct consequential incidents from audit events and receipts using read-only evidence or fakes.

The action plan assigns each signal a diagnosable response:

| Signal | Operational response |
|---|---|
| Unsupported evidence | Inspect claim/source links and checker disagreement; increase targeted human review, constrain affected sources/releases, and require abstention when support is unavailable |
| Tool errors | Group by tool/version/class; inspect contracts and receipts; reconcile unknown effects before retries |
| User overrides | Separate factual repairs from preference/cancellation; inspect ignored overrides and preserve the user’s current authority |
| Safety breach | Contain affected capability, preserve audit evidence and investigate actual effects; track blocked proposals separately |
| Retry exhaustion | Count terminal exhausted logical operations / terminal retried operations; inspect retry reasons, budgets and repeated failures; route unresolved cases to review |
| Retrieval miss | Record expected-evidence need, empty/filtered/source-unavailable/relevance-gap reason and detector version; investigate retrieval/index/access paths; unknown relevance remains unknown |
| Latency/cost drift | Measure root task duration including queues/retries; roll up failed attempts, workers and cache charges without duplication; inspect release/provider shifts and known-data coverage |

Historical numeric baselines are unavailable. Establish comparable release/task cohorts prospectively, record sample sizes and coverage, and obtain service objectives and escalation thresholds from operators. Do not invent prior p95, spend or unsupported rates. Unknown provider charges leave total cost unavailable; a known subtotal is labeled separately. A safety breach needs action without waiting for a trend baseline.

Executed `python -u .\signal_contracts_test.py`: ten local tests passed; `test.log` captures actual output. The synthetic artifacts exercise citation provenance, unknown verdicts, attempt deduplication, unavailable cost, override classification, breach/denial distinction and operation-level exhaustion. They do not validate semantic entailment, production schema enforcement, provider billing, historical drift, representative sampling or access controls. Those remain proposed integration/evaluation checks; no live agent actions occurred.
