# Factual execution transcript

Configuration: `old_skill`; task ID: `4`. Executed independently after task ID 2; this task imports no artifacts or code from task ID 2.

Exact task: “Production support agent logs all retrieved IDs as citations and a quality=good event. Formal gold evals say 90%, live unsupported-evidence rate doubled, and an ad-hoc sample says fine. Design distinct signals and an action plan for unsupported evidence, tool errors, user overrides, safety breach, retry exhaustion, retrieval miss, latency/cost drift. Supply at least three concrete signal contracts; actual historical numeric baselines are unavailable.”

Assignment and executor protocol came from `work/v2/job-agent-observability.json` and `work/v2/executor-instructions.md`. The only skill source consulted was `work/v2/v1-snapshot/agent-observability/SKILL.md`; it was read earlier in this assignment. No current skill pack, evaluation suites, assertions, grading, or other configurations' artifacts were read.

Created `outputs/signal_contracts_test.py`, a self-contained Python standard-library fake. It defines four concrete signal contracts and synthetic signal reducers. It labels the 90% and doubling as user-supplied reports, keeps historical baselines unavailable, and labels all computed specimen values synthetic. Its only writes are this task's local artifacts.

Executed from this task's `outputs` directory:

```powershell
python -u .\signal_contracts_test.py | Tee-Object -FilePath '.\test.log'
exit $LASTEXITCODE
```

Command exit code: `0`. Actual test output reports ten tests, all `ok`, and `OK`. The test runner reported `Ran 10 tests in 0.001s`; that is local test execution duration, not production latency. The script created `signal_contracts.json` and `synthetic_signals.json`.

Tests cover retrieved-unused documents not counted as citations, unknown verdicts not treated as support, unavailable rates when nothing is checked, missing citation provenance rejected, failed attempts and unknown cost counted correctly, duplicate attempts not double-counted, preference overrides not classified as confirmed repair, denied proposals distinguished from executed breach, retry exhaustion counted by operation, and no invented baselines/run metric dimensions.

Saved `outputs/response.md` with distinct signal meanings, four contracts, an action plan for all requested categories and explicit limitations. No execution failures or test repairs occurred. No real provider, production telemetry, live external effects, live replay or global edits were used.

A final read-only `python -c` inspection counted 678 whitespace-separated response words and confirmed four entries in the saved contract JSON. This inspection exited successfully.
