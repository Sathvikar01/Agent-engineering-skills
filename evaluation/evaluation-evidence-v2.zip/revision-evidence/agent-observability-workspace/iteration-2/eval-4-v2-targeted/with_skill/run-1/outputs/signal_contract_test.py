"""Local signal contracts and deterministic evidence fixtures; no live traffic.

Run: python signal_contract_test.py
"""
import copy
import json
import math
import re
import unittest
from pathlib import Path

OUT = Path(__file__).resolve().parent


def contract(name, source, numerator, denominator, window, minimum, severity, owner, response, threshold, **extra):
    return {
        "signal": name, "source": source, "schema_version": "signals-v1",
        "slice_labels": ["registered_release", "task_slice", "evaluator_version"],
        "baseline": None, "baseline_status": "historical_numeric_baseline_unavailable",
        "baseline_measurement": "Prior 7 days, matched release/task/evaluator; capture coverage",
        "threshold_status": "provisional_operational_threshold",
        "numerator": numerator, "denominator": denominator, "window": window,
        "minimum_sample": minimum, "severity": severity, "owner": owner,
        "response": response, "threshold": threshold, **extra,
    }


CONTRACTS = [
    contract("unsupported_evidence", "production", "reviewed_unsupported_claims", "reviewed_eligible_factual_claims", "60m", 200, "P1", "Evidence quality lead", "Triage claims; gate risky automation; fix grounding or roll back verified release", {"kind": "relative", "factor": 2.0}),
    contract("tool_errors", "production", "failed_attempts", "all_tool_attempts", "15m", 100, "P2", "Tool/SRE owner", "Inspect provider/version/error class; circuit-break unavailable tool", {"kind": "rate", "value": 0.05}),
    contract("user_overrides", "production", "corrected_decisions", "delivered_override_eligible_decisions", "24h", 100, "P2", "Product/quality lead", "Review correction reasons and task slice; distinguish preference changes", {"kind": "rate", "value": 0.10}),
    contract("safety_breach", "production_audit", "confirmed_executed_policy_breaches", "executed_actions", "immediate", 1, "P0", "Incident/security lead", "Disable mutation capability; preserve audit; reconcile affected effects", {"kind": "count", "value": 1}, baseline_measurement="Policy target zero; not a measured historical baseline", threshold_status="policy_invariant"),
    contract("retry_exhaustion", "production", "terminal_exhausted_operations", "terminal_logical_operations", "15m", 100, "P1", "Orchestration owner", "Inspect retry reason/budget; safe abstention; fix recovery policy", {"kind": "rate", "value": 0.01}),
    contract("retrieval_miss", "production", "requests_without_relevant_visible_evidence", "evidence_required_requests", "60m", 100, "P2", "Retrieval owner", "Check index/freshness/filter/rank/context truncation; abstain when needed", {"kind": "rate", "value": 0.10}),
    contract("latency_drift", "production", "p95_complete_task_latency_ms", "completed_logical_tasks", "60m", 200, "P2", "SRE/performance owner", "Inspect worker critical path/retries; investigate or roll back verified release", {"kind": "relative", "factor": 1.5}, measure="value"),
    contract("cost_drift", "production", "mean_complete_task_cost_usd", "tasks_with_complete_billing", "60m", 200, "P2", "Platform/FinOps owner", "Inspect model/cache/retries/workers; constrain spend or roll back verified release", {"kind": "relative", "factor": 1.5}, measure="value"),
    contract("formal_eval_regression", "formal_eval", "passed_fixture_cases", "all_fixed_fixture_cases", "each_release", 100, "P1", "Evaluation owner", "Block release on paired suite regression; inspect slices and artifacts", {"kind": "eval_drop", "percentage_points": 0.03}, baseline_measurement="Last verified result on same fixed suite/version", reported_result=0.90, reported_denominator=None),
]


def evaluate(spec, observation):
    """No manufactured baselines; missing data is not a passing decision."""
    threshold = spec["threshold"]
    n, d = observation.get("numerator"), observation.get("denominator")
    if threshold["kind"] == "count":
        # A confirmed executed breach must not wait for a traffic denominator.
        if n is None:
            return {"status": "unavailable", "alert": False}
        fire = n >= threshold["value"]
    else:
        if d is None or d < spec["minimum_sample"]:
            return {"status": "insufficient_sample", "alert": False}
        if spec.get("measure") == "value":
            value = observation.get("value")
        else:
            if n is None or not 0 <= n <= d:
                return {"status": "invalid_or_unavailable", "alert": False}
            value = n / d
        if value is None or not math.isfinite(value):
            return {"status": "unavailable", "alert": False}
        baseline = spec["baseline"]
        if threshold["kind"] in {"relative", "eval_drop"} and baseline is None:
            return {"status": "insufficient_baseline", "alert": False, "observed_value": value}
        if threshold["kind"] == "relative":
            # Baseline zero requires a separately approved absolute threshold.
            if baseline <= 0:
                return {"status": "relative_baseline_zero", "alert": False, "observed_value": value}
            fire = value >= threshold["factor"] * baseline
        elif threshold["kind"] == "eval_drop":
            fire = baseline - value >= threshold["percentage_points"]
        else:
            fire = value > threshold["value"]
    return {"status": "alert" if fire else "within_configured_threshold", "alert": fire, "severity": spec["severity"] if fire else None, "owner": spec["owner"], "response": spec["response"] if fire else None}


def evidence_fixture():
    # IDs are candidates until explicitly cited in the reconciled output.
    retrieved = {"doc-1", "doc-2", "doc-3"}
    visible = {"doc-1", "doc-2"}
    claims = [
        {"claim_id": "c1", "rendered_text": "This fixture refund was approved. [cite:doc-1]", "eligible": True},
        {"claim_id": "c2", "rendered_text": "Every refund is instant. [cite:doc-2]", "eligible": True},
    ]
    # A deterministic fake reviewer, not a real semantic support model.
    adjudications = {"c1": "supported", "c2": "unsupported"}
    rows = []
    for claim in claims:
        used = set(re.findall(r"\[cite:([a-z0-9-]+)\]", claim["rendered_text"]))
        support = adjudications.get(claim["claim_id"], "unknown")
        if not used or not used <= visible:
            support = "unsupported"
        rows.append({
            "schema_version": "claim-evidence-v1", "run_id": "fixture-run-1",
            "claim_id": claim["claim_id"], "reconciled_output_id": "fixture-output-1",
            "retrieved_ids": sorted(retrieved), "model_visible_ids": sorted(visible),
            "used_ids": sorted(used), "support": support,
            "evaluator_version": "deterministic-fake-review-v1", "eligible": claim["eligible"],
            "release": "fixture-release", "task_slice": "fixture-support",
        })
    return rows


def support_counts(rows):
    eligible = [r for r in rows if r["eligible"]]
    reviewed = [r for r in eligible if r["support"] in {"supported", "unsupported"}]
    return {"numerator": sum(r["support"] == "unsupported" for r in reviewed), "denominator": len(reviewed), "review_coverage_numerator": len(reviewed), "review_coverage_denominator": len(eligible)}


def retrieval_is_miss(relevant_ids, model_visible_ids):
    return not bool(set(relevant_ids) & set(model_visible_ids))


def complete_task_usage(attempts):
    # Every failed/retried/worker/cache charge belongs to the task.
    complete = all(a.get("cost_usd") is not None for a in attempts)
    return {"cost_usd": sum(a["cost_usd"] for a in attempts) if complete else None, "cost_coverage_complete": complete}


def terminal_operation_counts(events):
    # A terminal operation contributes once, independently of attempt count.
    operations = {}
    for e in events:
        if e["type"] == "operation.terminal":
            operations[e["logical_operation_id"]] = e["status"]
    return {"numerator": sum(s == "retry_exhausted" for s in operations.values()), "denominator": len(operations)}


def find(name):
    return copy.deepcopy(next(c for c in CONTRACTS if c["signal"] == name))


class SignalTests(unittest.TestCase):
    def test_candidates_are_not_citations(self):
        rows = evidence_fixture()
        self.assertNotIn("doc-3", {d for r in rows for d in r["used_ids"]})
        self.assertEqual(rows[1]["support"], "unsupported")
        self.assertEqual(support_counts(rows)["denominator"], 2)

    def test_unknown_review_excluded_and_coverage_visible(self):
        rows = evidence_fixture()
        rows[1]["support"] = "unknown"
        count = support_counts(rows)
        self.assertEqual(count["denominator"], 1)
        self.assertEqual(count["review_coverage_denominator"], 2)

    def test_unsupported_doubling_requires_measured_baseline(self):
        spec = find("unsupported_evidence")
        observed = {"numerator": 40, "denominator": 200}  # Synthetic, not historical.
        self.assertEqual(evaluate(spec, observed)["status"], "insufficient_baseline")
        spec["baseline"] = 0.10  # Explicit synthetic fixture baseline for branch test.
        self.assertTrue(evaluate(spec, observed)["alert"])

    def test_zero_baseline_is_not_silent_pass(self):
        spec = find("unsupported_evidence")
        spec["baseline"] = 0
        self.assertEqual(evaluate(spec, {"numerator": 1, "denominator": 200})["status"], "relative_baseline_zero")

    def test_minimum_sample(self):
        self.assertEqual(evaluate(find("tool_errors"), {"numerator": 9, "denominator": 10})["status"], "insufficient_sample")

    def test_tool_errors_activate_provisional_response(self):
        result = evaluate(find("tool_errors"), {"numerator": 6, "denominator": 100})
        self.assertTrue(result["alert"])
        self.assertEqual(result["owner"], "Tool/SRE owner")

    def test_override_contract_is_independent(self):
        self.assertTrue(evaluate(find("user_overrides"), {"numerator": 11, "denominator": 100})["alert"])

    def test_one_confirmed_executed_breach_stops_mutation(self):
        result = evaluate(find("safety_breach"), {"numerator": 1, "denominator": 1})
        self.assertEqual(result["severity"], "P0")
        self.assertIn("Disable mutation", result["response"])

    def test_confirmed_breach_does_not_wait_for_unknown_traffic_count(self):
        result = evaluate(find("safety_breach"), {"numerator": 1, "denominator": None})
        self.assertTrue(result["alert"])

    def test_retry_counts_logical_operations_not_attempts(self):
        events = [{"type": "tool.attempt", "logical_operation_id": "op1", "status": "failed"}] * 4
        events += [{"type": "operation.terminal", "logical_operation_id": "op1", "status": "retry_exhausted"}] * 2
        self.assertEqual(terminal_operation_counts(events), {"numerator": 1, "denominator": 1})
        self.assertTrue(evaluate(find("retry_exhaustion"), {"numerator": 2, "denominator": 100})["alert"])

    def test_retrieval_miss_is_distinct_from_bad_support(self):
        self.assertFalse(retrieval_is_miss({"doc-1"}, {"doc-1", "doc-2"}))
        self.assertTrue(retrieval_is_miss({"doc-4"}, {"doc-1", "doc-2"}))
        self.assertTrue(evaluate(find("retrieval_miss"), {"numerator": 11, "denominator": 100})["alert"])

    def test_missing_cost_not_zero_and_all_attempts_count(self):
        self.assertIsNone(complete_task_usage([{"cost_usd": 1.0}, {"cost_usd": None}])["cost_usd"])
        self.assertEqual(complete_task_usage([{"cost_usd": 1.0}, {"cost_usd": 0.25}, {"cost_usd": 0.10}])["cost_usd"], 1.35)

    def test_cost_and_latency_drift_need_baselines(self):
        for name in ("cost_drift", "latency_drift"):
            spec = find(name)
            observed = {"denominator": 200, "value": 15.0}
            self.assertEqual(evaluate(spec, observed)["status"], "insufficient_baseline")
            spec["baseline"] = 10.0  # Synthetic fixture value, not production data.
            self.assertTrue(evaluate(spec, observed)["alert"])

    def test_formal_eval_cannot_override_production(self):
        spec = find("formal_eval_regression")
        self.assertEqual(spec["reported_result"], 0.90)
        self.assertIsNone(spec["reported_denominator"])
        self.assertEqual(evaluate(spec, {"numerator": 90, "denominator": 100})["status"], "insufficient_baseline")
        self.assertEqual(find("unsupported_evidence")["source"], "production")

    def test_every_contract_has_actionable_fields_no_invented_history(self):
        required = {"baseline", "threshold", "window", "minimum_sample", "numerator", "denominator", "severity", "owner", "response", "source"}
        for spec in CONTRACTS:
            self.assertTrue(required <= spec.keys())
            self.assertIsNone(spec["baseline"])


if __name__ == "__main__":
    rows = evidence_fixture()
    outputs = {
        "signal_contracts.json": CONTRACTS,
        "evidence_trace.json": rows,
        "signal_decisions.json": {
            "fixture_only": True, "support_counts": support_counts(rows),
            "unsupported_baseline_unavailable": evaluate(find("unsupported_evidence"), {"numerator": 40, "denominator": 200}),
            "confirmed_breach_fixture": evaluate(find("safety_breach"), {"numerator": 1, "denominator": 1}),
        },
    }
    for filename, payload in outputs.items():
        OUT.joinpath(filename).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    unittest.main(verbosity=2)
