# Corrected trace and operator reconstruction

Make the trace an audit of observable actions and evidence. A successful answer must preserve the earlier denied write as a separate operation with its policy decision. Record answer completion, effect completion, and policy history independently; an answer can complete while an attempted action remains blocked. Never overwrite that denial with a final success event.

Stop raw-token, credential, and private-reasoning exports at their source. Persist only an allowlisted event envelope, bounded redacted arguments or restricted evidence references, usage counts, observable decisions, and short reason codes. Redact before durable queues, logs, tracing SDK export, exception reporting, and evaluator ingestion. Drop private reasoning fields entirely. Hashing secrets is not redaction; action digests cover normalized approved actions without credentials. A scan failure quarantines/rejects the export and emits a payload-free control event. Tenant-scoped authorization must also protect referenced evidence; a pointer does not make private content safe to expose.

## Event contract

Every event carries schema version, request/run ID, unique event ID, event time, causal predecessors, sequence, task/worker/span/parent-span IDs, and state version. Logical operation IDs survive retries; attempt IDs change. Record actual model, prompt, schema, tool, retrieval and policy versions; authorized principal scope; normalized action digest; decision/reason code; effect classification; approval, receipt and evidence IDs; and known usage/timing. Explicit null plus availability status distinguishes missing cost data from zero. Persist producer sequence and causal relationships across workers rather than infer order from wall clocks.

| Instrumentation point | Required observable record |
|---|---|
| Accept / propose / validate | Safe request reference, action digest, validation result |
| Policy / approval | Scope, allow/deny, reason, approval identity bound to action and state |
| Tool gateway | Attempt ID, classified result: applied, not applied, read-only, unknown, failure |
| Retrieval / context / claims | Retrieved, visible and used evidence IDs linked to claim IDs |
| Checkpoint / resume / retry | Durable state version, checkpoint ID, reconciliation and retry reason |
| Evaluator / terminal | Evaluator version and outcome, evidence, receipts, final state and stop reason |

The synthetic timeline accepts a request, proposes a delete, denies it for missing scope, and records a checkpoint. A nested worker performs a read. A different permitted update receives approval; its first response is lost, leaving effect **unknown**. After restart, a fake reconciliation says not applied, then retry succeeds with a receipt at state s2. Two evaluators disagree. The terminal record is `answered_with_denied_action` with partial effects; the denied delete has no tool attempt. No real write occurs in this fixture.

## Metrics and operator procedure

Use bounded labels such as release, task class, tool family, outcome and policy reason. Keep run/user IDs in access-controlled trace fields, optionally as trace exemplars, never metric labels. Count denials, violations, unknown effects, exhaustion, abstention, human review, retrieval failures and evaluator disagreement alongside logical-task latency and spend. Include failed attempts, cache charges and nested workers in totals. Unknown billing remains unavailable. Retain policy, approval and effect receipts independently of sampled debug spans; document retention, deletion and tenant access. Operational records do not automatically become consented evaluation datasets.

For an incident, retrieve all events for its run, verify sequence/causal/checkpoint/worker joins, group by logical operation and attempt, then list proposals, policy and approval decisions, actual effects, unresolved effects, committed state and terminal status. Compare final claims against used evidence and each evaluator separately. Missing events mean **incomplete reconstruction**, not presumed success. Unknown effects require read-only receipt reconciliation before retry; never replay live mutations to investigate.

## Executed reconstruction test

`python .../outputs/reconstruct_test.py` ran 10 local tests successfully and generated `trace.ndjson`, `reconstruction.json`, and `test-results.txt`. Checks cover denial retention, nested worker linkage, checkpoint resume, lost response/reconciliation, approval binding, redaction, fail-closed scanning, missing events, unresolved effects and evaluator disagreement. These are synthetic contract checks. They do not prove exhaustive semantic/schema validation, universal secret detection, real provider idempotency, export ACLs, storage deletion, or production completeness. Integration checks for those controls are proposed and unexecuted; no production metrics or historical baseline were measured.
