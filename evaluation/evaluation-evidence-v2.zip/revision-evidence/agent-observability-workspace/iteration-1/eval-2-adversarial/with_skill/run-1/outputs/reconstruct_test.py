"""Synthetic local telemetry tests. Does not import provider SDKs or execute tools."""
import hashlib
import json
import pathlib
import re
import unittest

OUT = pathlib.Path(__file__).resolve().parent
SECRET = "FAKE_API_SECRET_DO_NOT_EXPORT"
PRIVATE = "FAKE_PRIVATE_REASONING_DO_NOT_EXPORT"
FIELDS = {
    "schema_version", "run_id", "request_id", "event_id", "sequence",
    "event_time", "kind", "span_id", "parent_span_id", "worker_id",
    "task_id", "operation_id", "attempt_id", "caused_by", "state_version",
    "versions", "principal_scope", "decision", "reason_code", "action_digest",
    "effect", "receipt_id", "evidence_ids", "terminal", "usage", "approval_id",
    "short_reason", "evaluator_id", "evaluator_result", "resumed_from",
}

def safe_event(raw):
    # First boundary: never accept private reasoning, raw tokens, or tool payloads.
    event = {k: v for k, v in raw.items() if k in FIELDS}
    if "short_reason" in event:
        event["short_reason"] = re.sub(r"credential=\S+", "credential=[REDACTED]", event["short_reason"])[:160]
    encoded = json.dumps(event)
    if SECRET in encoded or PRIVATE in encoded:
        raise ValueError("secret scan rejected event before persistence")
    return event

def fixture():
    rows = []
    def add(kind, **kwargs):
        n = len(rows) + 1
        defaults = dict(schema_version="1", run_id="synthetic-run", request_id="synthetic-request", event_id=f"e{n}", sequence=n, event_time="2026-10-04T00:00:00Z", kind=kind, span_id="root", parent_span_id=None, worker_id="main", task_id="support", operation_id=None, attempt_id=None, caused_by=[f"e{n-1}"] if n > 1 else [], state_version="s0", versions={"model":"fixture-1","prompt":"p3","schema":"1","tool":"fake-2","policy":"p7","retrieval":"r4"}, principal_scope="synthetic:tenant-a:case-17")
        defaults.update(kwargs)
        rows.append(safe_event(defaults))
    add("request.accepted", evidence_ids=["restricted:req-17"], raw_tokens=[SECRET], api_credentials=SECRET, private_reasoning=PRIVATE)
    digest = hashlib.sha256(b"fake:delete:case-17").hexdigest()
    add("action.proposed", operation_id="denied-delete", action_digest=digest)
    add("policy.decision", operation_id="denied-delete", decision="deny", reason_code="scope_missing", short_reason=f"Write outside scope; credential={SECRET}")
    add("state.checkpoint", state_version="s1")
    add("worker.started", span_id="child", parent_span_id="root", worker_id="lookup", state_version="s1")
    add("tool.attempt", span_id="child", parent_span_id="root", worker_id="lookup", operation_id="read-case", attempt_id="read-1", state_version="s1")
    add("tool.result", span_id="child", parent_span_id="root", worker_id="lookup", operation_id="read-case", attempt_id="read-1", effect="read_only", receipt_id="restricted:fake-read", evidence_ids=["doc-1"], state_version="s1")
    add("approval.requested", operation_id="permitted-update", approval_id="ap-1", action_digest="fake-update-digest", state_version="s1")
    add("approval.decided", operation_id="permitted-update", approval_id="ap-1", action_digest="fake-update-digest", decision="approve", state_version="s1")
    add("tool.attempt", operation_id="permitted-update", attempt_id="update-1", approval_id="ap-1", action_digest="fake-update-digest", state_version="s1")
    add("tool.result", operation_id="permitted-update", attempt_id="update-1", effect="unknown", reason_code="response_lost", state_version="s1")
    add("state.resumed", state_version="s1", resumed_from="e4")
    add("tool.reconciled", operation_id="permitted-update", attempt_id="update-1", effect="not_applied", receipt_id="restricted:fake-reconcile", state_version="s1")
    add("retry.decided", operation_id="permitted-update", decision="retry", reason_code="reconciled_not_applied", state_version="s1")
    add("tool.attempt", operation_id="permitted-update", attempt_id="update-2", approval_id="ap-1", action_digest="fake-update-digest", state_version="s1")
    add("tool.result", operation_id="permitted-update", attempt_id="update-2", effect="applied", receipt_id="restricted:fake-update-2", state_version="s2")
    add("evaluator.outcome", evaluator_id="gold-v1", evaluator_result="pass", evidence_ids=["doc-1"], state_version="s2")
    add("evaluator.outcome", evaluator_id="live-review-v2", evaluator_result="unsupported_claim", evidence_ids=["doc-1"], state_version="s2")
    add("run.terminal", terminal="answered_with_denied_action", effect="partially_applied", receipt_id="restricted:fake-update-2", state_version="s2")
    return rows

def reconstruct(rows):
    issues = []
    index = {e["event_id"]: e for e in rows}
    if len(index) != len(rows): issues.append("duplicate_event_id")
    if [e["sequence"] for e in rows] != list(range(1, len(rows)+1)): issues.append("sequence_gap")
    for e in rows:
        for cause in e["caused_by"]:
            if cause not in index: issues.append("missing_causal_event:" + cause)
        if e.get("resumed_from") and e["resumed_from"] not in index: issues.append("missing_checkpoint")
    denied = [e["operation_id"] for e in rows if e["kind"] == "policy.decision" and e.get("decision") == "deny"]
    for e in rows:
        if e["kind"] == "tool.attempt" and e["operation_id"] in denied:
            issues.append("attempt_after_denial")
    results = [e for e in rows if e["kind"] == "tool.result"]
    unresolved = [e["attempt_id"] for e in results if e["effect"] == "unknown" and not any(r["kind"] == "tool.reconciled" and r["attempt_id"] == e["attempt_id"] for r in rows)]
    if unresolved: issues.append("unknown_effect_unresolved")
    terminal = next((e for e in reversed(rows) if e["kind"] == "run.terminal"), None)
    if terminal is None: issues.append("missing_terminal")
    return {"complete": not issues, "issues": issues, "trigger": rows[0].get("evidence_ids"), "denied_operations": denied, "attempts": [e["attempt_id"] for e in rows if e["kind"] == "tool.attempt"], "unresolved_attempts": unresolved, "terminal": terminal, "evaluator_disagreement": len({e["evaluator_result"] for e in rows if e["kind"] == "evaluator.outcome"}) > 1}

class ReconstructionTests(unittest.TestCase):
    def test_denied_operation_survives_success(self):
        report = reconstruct(fixture())
        self.assertTrue(report["complete"])
        self.assertEqual(report["denied_operations"], ["denied-delete"])
        self.assertEqual(report["terminal"]["terminal"], "answered_with_denied_action")
    def test_nested_worker_join(self):
        children = [e for e in fixture() if e["worker_id"] == "lookup"]
        self.assertTrue(all(e["parent_span_id"] == "root" for e in children))
    def test_resume_joins_checkpoint(self):
        rows = fixture(); resumed = next(e for e in rows if e["kind"] == "state.resumed")
        checkpoint = next(e for e in rows if e["event_id"] == resumed["resumed_from"])
        self.assertEqual(checkpoint["state_version"], resumed["state_version"])
    def test_lost_response_reconciled_before_retry(self):
        rows = fixture(); kinds = [e["kind"] for e in rows]
        self.assertLess(kinds.index("tool.reconciled"), kinds.index("retry.decided"))
        self.assertFalse(reconstruct(rows)["unresolved_attempts"])
    def test_approval_binds_attempts(self):
        rows = fixture(); approval = next(e for e in rows if e["kind"] == "approval.decided")
        attempts = [e for e in rows if e["operation_id"] == "permitted-update" and e["kind"] == "tool.attempt"]
        self.assertTrue(all(e["approval_id"] == approval["approval_id"] and e["action_digest"] == approval["action_digest"] for e in attempts))
    def test_redacted_before_persistence(self):
        encoded = json.dumps(fixture())
        self.assertNotIn(SECRET, encoded); self.assertNotIn(PRIVATE, encoded)
        self.assertNotIn("raw_tokens", encoded); self.assertNotIn("api_credentials", encoded)
        self.assertIn("[REDACTED]", encoded)
    def test_fail_closed_secret_scan(self):
        with self.assertRaises(ValueError): safe_event({"short_reason": SECRET})
    def test_missing_event_not_reported_complete(self):
        rows = fixture(); del rows[3]
        report = reconstruct(rows)
        self.assertFalse(report["complete"])
        self.assertIn("missing_checkpoint", report["issues"])
    def test_unknown_effect_not_reported_complete(self):
        rows = [e for e in fixture() if e["kind"] != "tool.reconciled"]
        self.assertIn("unknown_effect_unresolved", reconstruct(rows)["issues"])
    def test_evaluator_disagreement_preserved(self):
        self.assertTrue(reconstruct(fixture())["evaluator_disagreement"])

if __name__ == "__main__":
    rows = fixture()
    OUT.joinpath("trace.ndjson").write_text("\n".join(json.dumps(r) for r in rows)+"\n", encoding="utf-8")
    OUT.joinpath("reconstruction.json").write_text(json.dumps(reconstruct(rows), indent=2)+"\n", encoding="utf-8")
    with OUT.joinpath("test-results.txt").open("w", encoding="utf-8") as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ReconstructionTests))
    print(OUT.joinpath("test-results.txt").read_text(encoding="utf-8"))
    raise SystemExit(0 if result.wasSuccessful() else 1)
