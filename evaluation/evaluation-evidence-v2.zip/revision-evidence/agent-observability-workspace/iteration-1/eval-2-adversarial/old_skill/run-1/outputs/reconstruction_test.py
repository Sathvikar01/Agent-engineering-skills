"""Offline synthetic audit reconstruction. No network, model, or live tool calls."""
import json
import unittest
from pathlib import Path

ALLOWED = {
    'schema_version', 'event_id', 'event_type', 'run_id', 'sequence',
    'worker_id', 'parent_span_id', 'logical_operation_id', 'attempt_id',
    'state_version', 'policy_version', 'decision', 'reason_code',
    'admission_ref', 'effect_status', 'receipt_ref', 'terminal_status',
    'denied_action_count', 'verdict', 'evaluator_version', 'usage_status',
    'token_count', 'request_ref', 'prior_attempt_id'
}
METRIC_LABELS = {'release', 'task_class', 'tool_class', 'status', 'reason_category'}

def project(event):
    # Only controlled fixture values in permitted fields; production must type,
    # bound and validate every field rather than trusting an arbitrary string.
    return {key: value for key, value in event.items() if key in ALLOWED}

def history():
    raw = []
    def event(kind, **fields):
        raw.append(dict(schema_version=1, event_id=f'e{len(raw)+1}',
                        event_type=kind, run_id='synthetic-run',
                        sequence=len(raw)+1, worker_id='root',
                        state_version=1, **fields))
    event('request.accepted', request_ref='restricted:request:1',
          api_key='SECRET-CREDENTIAL-123', raw_tokens='SECRET-OUTPUT-TOKENS',
          private_reasoning='PRIVATE-REASONING-DO-NOT-EXPORT')
    event('worker.started', parent_span_id='e1')
    # Child read is permitted; dispatch is observable before response is lost.
    event('admission.decided', logical_operation_id='read-1',
          decision='allow', policy_version='p1')
    event('tool.attempt', logical_operation_id='read-1', attempt_id='a1',
          parent_span_id='e2', admission_ref='e3')
    event('tool.result', logical_operation_id='read-1', attempt_id='a1',
          effect_status='observation_unknown', reason_code='response_lost')
    event('checkpoint', parent_span_id='e2')
    event('resume', parent_span_id='e6')
    event('retry', logical_operation_id='read-1', attempt_id='a2',
          prior_attempt_id='a1', parent_span_id='e7')
    event('tool.attempt', logical_operation_id='read-1', attempt_id='a2',
          admission_ref='e3', parent_span_id='e8')
    event('tool.result', logical_operation_id='read-1', attempt_id='a2',
          effect_status='read_only', receipt_ref='restricted:receipt:read2')
    event('proposal.validated', logical_operation_id='write-1')
    event('admission.decided', logical_operation_id='write-1', decision='deny',
          policy_version='p1', reason_code='outside_authorized_scope')
    event('evaluator.result', verdict='supported', evaluator_version='gold-v1')
    event('evaluator.result', verdict='unsupported', evaluator_version='live-v1')
    event('terminal', terminal_status='succeeded', denied_action_count=1,
          effect_status='none_for_denied_operation', usage_status='unavailable')
    safe = [project(x) for x in raw]
    for e in safe:
        if e['event_type'] in ('tool.attempt', 'tool.result', 'retry'):
            e['worker_id'] = 'child-read'
    return safe

def reconstruct(events):
    ids = {e['event_id']: e for e in events}
    problems = []
    expected = list(range(1, max((e['sequence'] for e in events), default=0)+1))
    if sorted(e['sequence'] for e in events) != expected:
        problems.append('sequence_gap_or_duplicate')
    denied = [e for e in events if e.get('decision') == 'deny']
    for e in events:
        for field in ('parent_span_id', 'admission_ref'):
            if field in e and e[field] not in ids:
                problems.append('missing_join')
        if e['event_type'] == 'tool.attempt':
            gate = ids.get(e.get('admission_ref'))
            if not gate or gate.get('decision') != 'allow':
                problems.append('unadmitted_attempt')
            elif gate.get('logical_operation_id') != e['logical_operation_id']:
                problems.append('operation_mismatch')
            elif gate['sequence'] >= e['sequence']:
                problems.append('admission_after_attempt')
    denied_ops = {e['logical_operation_id'] for e in denied}
    attempts = [e for e in events if e['event_type'] == 'tool.attempt']
    if any(e['logical_operation_id'] in denied_ops for e in attempts):
        problems.append('denied_operation_dispatched')
    terminal = [e for e in events if e['event_type'] == 'terminal']
    if len(terminal) != 1 or terminal[0]['denied_action_count'] != len(denied):
        problems.append('terminal_audit_mismatch')
    return dict(audit_status='incomplete' if problems else 'complete',
                problems=problems, denied_operations=sorted(denied_ops),
                unknown_observations=[e['attempt_id'] for e in events
                                      if e.get('effect_status') == 'observation_unknown'],
                terminal_status=terminal[0]['terminal_status'] if terminal else None,
                evaluator_disagreement=len({e['verdict'] for e in events
                                            if e['event_type'] == 'evaluator.result'}) > 1)

class ReconstructionTests(unittest.TestCase):
    def setUp(self):
        self.events = history()

    def test_denial_survives_success(self):
        result = reconstruct(self.events)
        self.assertEqual(result['terminal_status'], 'succeeded')
        self.assertEqual(result['denied_operations'], ['write-1'])
        self.assertEqual(result['audit_status'], 'complete')

    def test_denied_dispatch_is_detected(self):
        altered = [dict(e) for e in self.events]
        altered[8].update(logical_operation_id='write-1', admission_ref='e12')
        self.assertIn('denied_operation_dispatched', reconstruct(altered)['problems'])
        self.assertIn('unadmitted_attempt', reconstruct(altered)['problems'])

    def test_secret_and_reasoning_not_exported(self):
        serialized = json.dumps(self.events)
        for marker in ('SECRET-CREDENTIAL', 'SECRET-OUTPUT', 'PRIVATE-REASONING',
                       'api_key', 'private_reasoning', 'raw_tokens'):
            self.assertNotIn(marker, serialized)

    def test_metrics_are_bounded(self):
        labels = {'release': 'v1', 'task_class': 'support', 'status': 'succeeded'}
        self.assertTrue(set(labels) <= METRIC_LABELS)
        self.assertFalse({'run_id': 'synthetic-run'}.keys() <= METRIC_LABELS)

    def test_nested_worker_restart_joins(self):
        self.assertEqual(self.events[3]['worker_id'], 'child-read')
        self.assertEqual(self.events[6]['parent_span_id'], 'e6')
        self.assertEqual(self.events[7]['prior_attempt_id'], 'a1')
        self.assertEqual(reconstruct(self.events)['problems'], [])

    def test_lost_response_remains_visible(self):
        self.assertEqual(reconstruct(self.events)['unknown_observations'], ['a1'])
        self.assertEqual(self.events[9]['receipt_ref'], 'restricted:receipt:read2')

    def test_evaluator_disagreement(self):
        self.assertTrue(reconstruct(self.events)['evaluator_disagreement'])

    def test_missing_denial_cannot_look_clean(self):
        result = reconstruct([e for e in self.events if e['event_id'] != 'e12'])
        self.assertEqual(result['audit_status'], 'incomplete')
        self.assertIn('sequence_gap_or_duplicate', result['problems'])
        self.assertIn('terminal_audit_mismatch', result['problems'])

if __name__ == '__main__':
    out = Path(__file__).resolve().parent
    (out / 'synthetic-trace.json').write_text(json.dumps(history(), indent=2), encoding='utf-8')
    (out / 'reconstruction.json').write_text(json.dumps(reconstruct(history()), indent=2), encoding='utf-8')
    unittest.main(verbosity=2)
