# Corrected trace and reconstruction

The final answer and the authorization history are separate facts. A successful response must retain the earlier denied write, its policy decision, and the absence of a corresponding admitted tool attempt. Record `terminal_status=succeeded` together with `denied_action_count=1`, `effect_status=none_for_denied_operation`, and an audit completeness result. A denied proposal is not itself a policy violation; executing that proposal despite denial would be. Never derive safety from the final answer alone.

Use this common envelope for structured events: `schema_version`, `event_id`, `event_type`, `run_id`, `request_id`, `parent_span_id`, `worker_id`, `logical_operation_id`, `attempt_id`, `sequence`, `event_time`, `state_version`, `release_version`, and `policy_version`. IDs belong in traces and restricted audit indexes, not metric labels. Sequence and explicit parent links establish ordering across restart and workers; timestamps support diagnosis but cannot prove causality. In production, scope sequence to its producer and include explicit causal links across producers.

| Event | Required diagnostic content |
|---|---|
| Request accepted | Scoped principal reference, task class, bounded safe request summary |
| Model finished | Actual model/prompt/schema versions; usage or explicit unavailable status; refusal, malformed, truncation classification |
| Proposal validated | Normalized operation digest; action class; safe target reference; validation result |
| Admission decided | Allow/deny, policy version and reason code, proposal digest, authorization/approval reference |
| Tool attempt/result | Logical operation and attempt IDs, admission reference, timing, effect classification, restricted receipt reference |
| Retrieval assembled | Candidate references, selected context references, retrieval version and miss status |
| Checkpoint/resume/retry | State version, parent worker/task, original operation, prior attempt and retry reason |
| Evaluation/terminal | Evaluator version and verdict, final evidence references, stop reason, denied attempts and completeness |

Instrument these at the orchestration boundary, policy gate, tool adapter, state store, retrieval assembler and evaluator. Admission must precede dispatch; record denial before returning control to the model. Keep denied proposals, approvals, side-effect receipts and unknown-effect events under an audit retention policy even when ordinary debug spans are sampled. Emit a terminal record only after joining the observable history; missing audit events produce `incomplete`, not an invented clean history.

Remove API credentials, raw model output/token text, and private reasoning before persistence or export. Export an allowlisted event projection; discard reasoning fields entirely. Preserve numeric token usage when supplied by the provider, with unavailable values represented explicitly. Sensitive arguments become bounded typed summaries or access-controlled evidence references. Secret scanning is a second defense after allowlisting, not a guarantee that arbitrary text is safe. Apply tenant access controls, restricted evidence resolution, retention/deletion, and separate consented evaluation datasets. Do not expose evidence pointers as public debug links.

Metrics use bounded labels such as release, task class, tool class, status and reason category. Include task success/safe abstention, denial, policy violation, unknown effects, retry exhaustion, evaluator disagreement, retrieval failures, human review, latency and total task spend. Attribute failed attempts and workers to the logical task. Unknown usage/cost remains unavailable. Run/user/receipt IDs and prompt contents are prohibited metric labels.

For reconstruction, fetch the run's events, follow parent and operation joins, validate admission-to-attempt links, compare state versions and flag gaps. The operator should recover: accepted request; read-only child worker; interrupted read result and uncertain observation; resume/retry; denied write without dispatch; evaluator disagreement; final success. Inspect the restricted receipt before resolving any ambiguous effect. Analysis replay uses fakes only.

`reconstruction_test.py` executes this synthetic history and asserts denial preservation, redaction, metric labels, nested-worker/restart joins, lost response visibility, evaluator disagreement and missing-event handling. Its adjacent log contains actual unittest output. These are local contract tests, not production measurements or proof of exporter/collector reliability. Production transport loss, tenant authorization, durable ordering and provider accounting remain proposed, unexecuted checks. No measured baseline is available or claimed.
