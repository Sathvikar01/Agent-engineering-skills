"""Local structural consistency checks; not a semantic or production test."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
document = json.loads((root / 'signal-contracts.json').read_text(encoding='utf-8'))
assert document['historical_numeric_baseline'] is None
assert document['baseline_status'] == 'unavailable'
assert not set(document['common']['metric_labels']) & set(document['common']['prohibited_metric_labels'])
expected = {'unsupported_evidence', 'tool_errors', 'user_overrides', 'safety_breach',
            'retry_exhaustion', 'retrieval_miss', 'latency_cost_drift'}
assert {x['name'] for x in document['contracts']} == expected
assert len(document['contracts']) == 7
for contract in document['contracts']:
    assert contract['baseline'] is None
    for field in ('source', 'unit', 'numerator', 'required_fields', 'coverage', 'join', 'action'):
        assert contract[field], (contract['name'], field)
    assert 'denominator' in contract
assert len(document['common']['quality_channels']) == 3
print('PASS: JSON parsed; seven distinct contracts; required fields present; baseline values unavailable; metric label allowlist disjoint; three quality channels.')
print('LIMIT: structural consistency only; no live telemetry, evaluator correctness, provider accounting, or historical rate calculation exercised.')
