# Distinct signals and action plan

Replace `quality=good` with versioned, evidence-linked observations. Retrieved IDs describe candidates, not citations or support. For each final claim, retain restricted claim/output references, retrieved IDs, model-visible IDs after truncation, used IDs, emitted citation IDs, document versions, and a separate evaluator verdict/reason. Join these to the reconciled delivered output and state version. A candidate excluded from context cannot silently become a citation. A valid ID join still does not prove that the document supports the claim; semantic support needs the evaluator owned by the quality program.

Every event also carries request/run, logical-operation/attempt, span/parent/worker, causal event, state and release IDs, plus prompt/model/tool/retrieval/policy/evaluator versions. Record tool failures, policy denials, malformed outputs, unknown effects, retry decisions, overrides, and terminal reasons distinctly. Export redacted bounded fields and access-controlled evidence references; exclude secrets and private reasoning. Keep IDs in restricted traces, not unbounded metric labels. Use release, task class and tool family for bounded slices.

## Three evidence channels

| Channel | Meaning and required provenance | Decision role |
|---|---|---|
| Formal gold evaluation | Reported 90%; require fixture/suite/rubric/release versions, denominator and uncertainty | Controlled regression signal; cannot establish current live quality |
| Production telemetry | Reportedly doubled unsupported-evidence rate; require windows, reviewed-claim denominators, coverage and traffic mix | Investigate actual exposed traffic and affected slices now |
| Ad-hoc diagnostic | “Fine”; sampling method, cases, reviewer and exclusions currently unspecified | Generate hypotheses; cannot overturn a live alert or formal result |

Keep these records and dashboards separate. The supplied 90% and doubling are reported facts, not measurements performed here. Actual historical numeric baselines are unavailable. Do not infer absolute rates, significance or a safe release from either statement. Record evaluator disagreement and investigate its cases instead of choosing the most reassuring aggregate.

## Concrete production contracts

All numeric thresholds below are **provisional, unvalidated operational proposals**. Every baseline is `unavailable`, never zero. Rates use the stated denominator; insufficient samples produce an explicit unavailable status. The JSON artifact contains complete contracts including response details and bounded dimensions.

| Signal / denominator | Proposed threshold / window / minimum | Severity, owner and response |
|---|---|---|
| Unsupported claims / reviewed factual claims | >2%; rolling 30m; 100 claims | P1, support quality: inspect evidence, abstain/pause affected path |
| Tool errors / completed attempts, excluding policy denials | >5%; rolling 15m; 100 attempts | P2, integration on-call: isolate error class/tool; approved fallback |
| Explicit corrections/reversals / eligible runs observed for full 24h | >10%; daily matured cohort; 100 runs | P2, product owner: sample reasons and affected slices |
| Verified prohibited effect or secret disclosure | ≥1 event; immediate; 1 event | P0, security commander: halt affected mutations/exporter and investigate |
| Exhausted runs / all terminal logical runs | >2%; rolling 30m; 100 runs | P2, runtime on-call: inspect attempt chains; reconcile unknown effects |
| Relevant-context misses / evaluated answer-required retrieval requests | >5%; rolling 30m; 100 requests | P2, retrieval owner: check indexing, filters, coverage; abstain |
| Logical-task p95 latency / completed runs | >8s; rolling 30m; 100 runs | P2, reliability: inspect queue/model/tool spans and release changes |
| Mean fully attributed cost / tasks with complete billing | >$0.20; rolling 1h; 100 tasks | P2, platform: inspect retries/model/token changes; confirm billing |

Track unreviewed claims, unresolved tool attempts, pending/timed-out tasks and missing billing coverage separately. Cost includes failed attempts, workers and cache charges. These latency/cost limits are initial absolute warnings; true drift comparisons await measured comparable baselines.

## Response and verification

Start a read-only incident investigation of the reported live increase: preserve affected redacted traces, compare claim/evidence joins across release/task slices, audit reviewed/unreviewed coverage, and reconcile provider receipts. Escalate verified safety breaches immediately regardless of sample size. Consider rollback only to a verified version; record the decision and monitor recovery. Measure comparable control windows with denominators and uncertainty, then calibrate thresholds and alert deduplication. Run the versioned gold suite per release against a verified comparator; establish its regression contract before automating a delta gate. These production actions and suite runs are proposed, not executed.

Executed `signal_contracts.py`: seven local synthetic tests passed; JSON contracts and a synthetic report were generated. Checks demonstrate channel separation, candidate/citation errors, joins insufficient for semantic support, insufficient-sample handling, missing baselines, and safety routing. They do not validate real document semantics, provider/export integration, historical drift, classifier quality, or production baselines. No live effects occurred.
