"""Provisional signal contracts and synthetic routing checks; no production effects."""
import json
import pathlib
import unittest

OUT = pathlib.Path(__file__).resolve().parent

def contract(name, numerator, denominator, threshold, window, sample, severity, owner, response):
    return {"signal": name, "source": "production_telemetry", "baseline": {"status":"unavailable", "value": None, "next_step":"Measure comparable release/task slices with denominator and uncertainty."}, "numerator":numerator, "denominator":denominator, "threshold":threshold, "threshold_status":"provisional_unvalidated", "observation_window":window, "minimum_sample":sample, "severity":severity, "owner":owner, "response":response, "bounded_dimensions":["release", "task_class", "tool_family"], "drilldown":"restricted run/claim/operation/evidence references, excluded from metric labels"}

CONTRACTS = [
    contract("unsupported_evidence", "reviewed factual claims judged unsupported by evaluator-v2", "all reviewed factual claims; report unreviewed fraction separately", {"op":">", "value":0.02, "unit":"rate"}, "rolling 30 minutes", 100, "P1", "Support quality on-call", "Inspect claim-to-visible-and-used evidence; pause affected answer path or use safe abstention; consider verified-release rollback."),
    contract("tool_error", "failed terminal tool attempts, excluding policy denials", "all completed tool attempts; unresolved attempts tracked separately", {"op":">", "value":0.05, "unit":"rate"}, "rolling 15 minutes", 100, "P2", "Tool integration on-call", "Inspect provider error classes, release and retry amplification; isolate failing tool and use approved fallback."),
    contract("user_override", "eligible runs with an explicit user correction or action reversal within 24h", "eligible completed runs observed for the full 24h", {"op":">", "value":0.10, "unit":"rate"}, "daily matured cohort", 100, "P2", "Support product owner", "Sample override reasons and affected task slices; check unsupported claims and friction before changing workflow."),
    contract("safety_breach", "verified prohibited effect or secret disclosure", "observed safety audit events; count has no rate/sample suppression", {"op":">=", "value":1, "unit":"count"}, "each verified event, immediate", 1, "P0", "Security incident commander", "Halt affected mutation capability; restrict compromised exporter; preserve redacted audit/receipts and begin incident response."),
    contract("retry_exhaustion", "logical runs ending retry_exhausted", "all terminal logical runs including successful and failed runs", {"op":">", "value":0.02, "unit":"rate"}, "rolling 30 minutes", 100, "P2", "Agent runtime on-call", "Inspect operation/attempt chains and reconciliation; stop loops and escalate unresolved effects without replaying writes."),
    contract("retrieval_miss", "answer-required retrieval requests with no eligible relevant context per reviewer", "all answer-required retrieval requests evaluated for relevance", {"op":">", "value":0.05, "unit":"rate"}, "rolling 30 minutes", 100, "P2", "Retrieval owner", "Inspect coverage, tenant filters, indexing and context truncation; abstain where evidence is absent."),
    contract("latency_drift", "end-to-end logical-run p95 latency including workers and retries", "completed logical runs; pending/timed-out runs reported separately", {"op":">", "value":8, "unit":"seconds_p95"}, "rolling 30 minutes", 100, "P2", "Reliability on-call", "Decompose model/tool/queue spans; investigate changed release and rollback to a verified release if confirmed."),
    contract("cost_drift", "total known billable cost across logical tasks, attempts, cache and workers", "tasks with complete billing attribution; publish missing-cost coverage", {"op":">", "value":0.20, "unit":"USD_mean_per_task"}, "rolling 1 hour", 100, "P2", "Agent platform owner", "Inspect retry/token/model changes; cap waste and confirm with provider billing before attributing spend."),
]

def evidence_record(claim_id, retrieved, visible, used, cited, verdict):
    eligible = set(retrieved) & set(visible)
    return {"claim_id":claim_id, "retrieved_ids":retrieved, "visible_ids":visible, "used_ids":used, "cited_ids":cited, "reference_violation":not set(used).issubset(eligible) or not set(cited).issubset(set(used)), "support_verdict":verdict, "evaluator_version":"synthetic-reviewer-v2"}

def ratio(count, denominator, minimum):
    if denominator < minimum: return {"status":"insufficient_sample", "value":None}
    return {"status":"observed", "value":count/denominator}

def baseline_drift(current, baseline):
    if baseline is None: return {"status":"baseline_unavailable", "value":None}
    if baseline == 0: return {"status":"zero_baseline_requires_absolute_test", "value":None}
    return {"status":"observed", "value":current/baseline}

class SignalTests(unittest.TestCase):
    def test_contracts_have_actionable_fields(self):
        required = {"baseline","threshold","threshold_status","observation_window","numerator","denominator","minimum_sample","severity","owner","response"}
        for c in CONTRACTS:
            self.assertTrue(required.issubset(c))
            self.assertEqual(c["baseline"]["status"], "unavailable")
            self.assertIsNone(c["baseline"]["value"])
    def test_retrieved_candidates_are_not_citations(self):
        e = evidence_record("c1", ["d1","d2"], ["d1"], ["d1"], ["d1","d2"], "unsupported")
        self.assertTrue(e["reference_violation"])
        self.assertEqual(e["support_verdict"], "unsupported")
    def test_valid_reference_join_does_not_prove_support(self):
        e = evidence_record("c2", ["d1"], ["d1"], ["d1"], ["d1"], "unsupported")
        self.assertFalse(e["reference_violation"])
        self.assertEqual(e["support_verdict"], "unsupported")
    def test_small_sample_not_zero(self):
        self.assertEqual(ratio(0, 3, 100)["status"], "insufficient_sample")
    def test_missing_baseline_not_doubled_or_zero(self):
        self.assertEqual(baseline_drift(0.04, None), {"status":"baseline_unavailable", "value":None})
    def test_signal_sources_remain_separate(self):
        signals = [{"source":"formal_gold_eval","reported_accuracy":0.90,"suite_version":None,"sample_size":None}, {"source":"production_telemetry","reported_change":"unsupported evidence doubled","baseline":None,"sample_size":None}, {"source":"ad_hoc_diagnostic","reported_result":"fine","sampling_method":None}]
        self.assertEqual(len({s["source"] for s in signals}), 3)
        self.assertTrue(all("quality" not in s for s in signals))
    def test_safety_has_no_large_sample_gate(self):
        c = next(c for c in CONTRACTS if c["signal"] == "safety_breach")
        self.assertEqual(c["minimum_sample"], 1)
        self.assertEqual(c["severity"], "P0")

if __name__ == "__main__":
    OUT.joinpath("signal-contracts.json").write_text(json.dumps(CONTRACTS, indent=2)+"\n", encoding="utf-8")
    report = {"data":"synthetic only", "bad_candidate_citation":evidence_record("c1", ["d1","d2"], ["d1"], ["d1"], ["d1","d2"], "unsupported"), "missing_baseline":baseline_drift(0.04, None), "small_sample":ratio(0, 3, 100), "production_baselines_measured":False}
    OUT.joinpath("synthetic-report.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    with OUT.joinpath("test-results.txt").open("w", encoding="utf-8") as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(SignalTests))
    print(OUT.joinpath("test-results.txt").read_text(encoding="utf-8"))
    raise SystemExit(0 if result.wasSuccessful() else 1)
