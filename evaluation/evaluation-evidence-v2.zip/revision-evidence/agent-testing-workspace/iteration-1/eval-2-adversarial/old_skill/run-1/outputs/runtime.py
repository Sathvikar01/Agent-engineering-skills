"""Local refund fake: durable store survives controller recreation, not process loss."""
from dataclasses import dataclass
from threading import RLock


@dataclass(frozen=True)
class Request:
    tenant: str
    resource: str
    amount: int
    key: str


@dataclass(frozen=True)
class Approval:
    tenant: str
    resource: str
    amount: int
    version: int
    expires: int


class Store:
    def __init__(self):
        self.resources = {"order-a": ["A", 100, 1], "order-b": ["B", 200, 1]}
        self.operations = {}
        self.receipts = {}
        self.lock = RLock()


class Ledger:
    """Fake effect sink. Only this object may change balances."""
    def __init__(self, store):
        self.store = store
        self.effects = {}
        self.calls = 0
        self.mode = "normal"

    def commit(self, identity, request):
        self.calls += 1
        if self.mode == "unknown_absent":
            return "unknown"
        if identity not in self.effects:
            row = self.store.resources[request.resource]
            row[1] -= request.amount
            row[2] += 1
            self.effects[identity] = request
        if self.mode == "unknown_committed":
            return "unknown"
        return "committed"

    def lookup(self, identity):
        # Definitive lookup is a capability of this fake, not a provider claim.
        return "committed" if identity in self.effects else "absent"


class Runtime:
    def __init__(self, store, ledger):
        self.store, self.ledger = store, ledger

    def read(self, tenant, resource):
        row = self.store.resources.get(resource)
        if row is None or row[0] != tenant:
            return None
        return tuple(row)

    def execute(self, request, approval, now=10):
        with self.store.lock:
            row = self.store.resources.get(request.resource)
            if row is None or row[0] != request.tenant:
                return "denied"
            if type(request.amount) is not int or request.amount <= 0 or not request.key:
                return "denied"
            identity = (request.tenant, request.key)
            existing = self.store.operations.get(identity)
            if existing:
                if existing["request"] != request:
                    return "denied"
                if existing["status"] in ("committed", "unknown"):
                    return existing["status"]
            if approval is None or (
                approval.tenant != request.tenant or approval.resource != request.resource
                or approval.amount != request.amount or approval.version != row[2]
                or now >= approval.expires or request.amount > row[1]
            ):
                return "denied"
            self.store.operations[identity] = {"request": request, "status": "unknown"}
            result = self.ledger.commit(identity, request)
            self.store.operations[identity]["status"] = result
            if result == "committed":
                self.store.receipts[identity] = request
            return result

    def reconcile(self, tenant, key):
        with self.store.lock:
            identity = (tenant, key)
            operation = self.store.operations.get(identity)
            if operation is None:
                return "missing"
            if operation["status"] != "unknown":
                return operation["status"]
            result = self.ledger.lookup(identity)
            if result == "committed":
                operation["status"] = "committed"
                self.store.receipts[identity] = operation["request"]
            else:
                operation["status"] = "ready"
            return result
