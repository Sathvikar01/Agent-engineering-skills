import copy
import unittest
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from runtime import Approval, Ledger, Request, Runtime, Store


class RefundTests(unittest.TestCase):
    def setUp(self):
        self.store = Store()
        self.ledger = Ledger(self.store)
        self.runtime = Runtime(self.store, self.ledger)
        self.request = Request("A", "order-a", 30, "refund-1")
        self.approval = Approval("A", "order-a", 30, 1, 20)

    def snapshot(self):
        return copy.deepcopy((self.store.resources, self.store.operations,
                              self.store.receipts, self.ledger.effects, self.ledger.calls))

    def assert_denied_unchanged(self, request, approval, now=10):
        before = self.snapshot()
        self.assertEqual(self.runtime.execute(request, approval, now), "denied")
        self.assertEqual(self.snapshot(), before)

    def test_denial_no_effect_policy_boundaries(self):
        cases = [
            (self.request, None),
            (replace(self.request, amount=0), self.approval),
            (replace(self.request, amount=-1), self.approval),
            (replace(self.request, amount=True), self.approval),
            (replace(self.request, amount=1.5), self.approval),
            (replace(self.request, amount=101), replace(self.approval, amount=101)),
            (replace(self.request, key=""), self.approval),
            (self.request, replace(self.approval, amount=31)),
            (self.request, replace(self.approval, resource="order-b")),
            (self.request, replace(self.approval, tenant="B")),
        ]
        for request, approval in cases:
            with self.subTest(request=request, approval=approval):
                self.assert_denied_unchanged(request, approval)

    def test_allow_balance_boundary(self):
        request = replace(self.request, amount=100)
        approval = replace(self.approval, amount=100)
        self.assertEqual(self.runtime.execute(request, approval), "committed")
        self.assertEqual(self.store.resources["order-a"], ["A", 0, 2])
        self.assertEqual(len(self.ledger.effects), 1)
        self.assertEqual(self.store.receipts[("A", "refund-1")], request)

    def test_duplicate_retries_and_restart(self):
        self.assertEqual(self.runtime.execute(self.request, self.approval), "committed")
        restarted = Runtime(self.store, self.ledger)
        for _ in range(5):
            self.assertEqual(restarted.execute(self.request, self.approval, 100), "committed")
        self.assertEqual(self.ledger.calls, 1)
        self.assertEqual(self.store.resources["order-a"], ["A", 70, 2])
        self.assertEqual(len(self.ledger.effects), 1)

    def test_concurrent_duplicate_retries(self):
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: self.runtime.execute(self.request, self.approval), range(16)))
        self.assertEqual(results, ["committed"] * 16)
        self.assertEqual(self.ledger.calls, 1)
        self.assertEqual(len(self.ledger.effects), 1)

    def test_same_key_changed_payload_denied(self):
        self.runtime.execute(self.request, self.approval)
        self.assert_denied_unchanged(replace(self.request, amount=40), replace(self.approval, amount=40, version=2))

    def test_unknown_commit_blocks_replay_until_reconciled(self):
        self.ledger.mode = "unknown_committed"
        self.assertEqual(self.runtime.execute(self.request, self.approval), "unknown")
        self.assertFalse(self.store.receipts)
        restarted = Runtime(self.store, self.ledger)
        self.assertEqual(restarted.execute(self.request, self.approval), "unknown")
        self.assertEqual(self.ledger.calls, 1)
        self.assertEqual(restarted.reconcile("A", "refund-1"), "committed")
        self.assertEqual(restarted.execute(self.request, self.approval), "committed")
        self.assertEqual(self.ledger.calls, 1)
        self.assertEqual(len(self.store.receipts), 1)
        self.assertEqual(self.store.resources["order-a"][1], 70)

    def test_unknown_absent_requires_lookup_before_retry(self):
        self.ledger.mode = "unknown_absent"
        self.assertEqual(self.runtime.execute(self.request, self.approval), "unknown")
        self.assertEqual(self.runtime.execute(self.request, self.approval), "unknown")
        self.assertEqual(self.ledger.calls, 1)
        self.assertEqual(self.runtime.reconcile("A", "refund-1"), "absent")
        self.ledger.mode = "normal"
        self.assertEqual(self.runtime.execute(self.request, self.approval), "committed")
        self.assertEqual(self.ledger.calls, 2)
        self.assertEqual(len(self.ledger.effects), 1)

    def test_stale_and_expired_approval(self):
        self.store.resources["order-a"][2] += 1
        self.assert_denied_unchanged(self.request, self.approval)
        self.assert_denied_unchanged(self.request, replace(self.approval, version=2), now=20)
        self.assert_denied_unchanged(self.request, replace(self.approval, version=2), now=21)

    def test_cross_tenant_ids_cannot_read_execute_or_reconcile(self):
        self.assertIsNone(self.runtime.read("A", "order-b"))
        self.assert_denied_unchanged(replace(self.request, resource="order-b"), self.approval)
        self.assert_denied_unchanged(replace(self.request, tenant="B"), self.approval)
        self.ledger.mode = "unknown_committed"
        self.runtime.execute(self.request, self.approval)
        before = self.snapshot()
        self.assertEqual(self.runtime.reconcile("B", "refund-1"), "missing")
        self.assertEqual(self.snapshot(), before)

    def test_keys_are_scoped_by_tenant(self):
        self.runtime.execute(self.request, self.approval)
        request = Request("B", "order-b", 30, "refund-1")
        approval = Approval("B", "order-b", 30, 1, 20)
        self.assertEqual(self.runtime.execute(request, approval), "committed")
        self.assertEqual(len(self.ledger.effects), 2)
        self.assertEqual(self.store.resources["order-b"][1], 170)


if __name__ == "__main__":
    unittest.main(verbosity=2)
