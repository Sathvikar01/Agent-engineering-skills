The supplied local fake and tests replace model opinions about refund arithmetic with executable state invariants. I ran all 10 unittest methods successfully using Python 3.11.9. No model credentials, network clients, provider calls, or real refund effects are involved. The actual runner output is in `test-log.txt`; `runtime.py` implements the fake, and `test_runtime.py` tests its admission/execution boundary.

Balances are integer units. Each approval binds tenant, resource, amount, resource version, and expiry. Admission checks these values before creating an operation. Denial assertions snapshot balances, operation records, receipts, effect records, and executor call count, so an error response cannot hide a mutation. An amount equal to the available balance is also tested as an allowed boundary, producing one recorded effect and a zero balance.

| Risk | Executed check | Observed invariant |
|---|---|---|
| Denied refund | Ten policy subcases, including overdraft and boolean amount | Complete snapshot unchanged; no executor call |
| Duplicate retry | Five sequential retries after controller recreation | One call, one effect, one receipt |
| Concurrent duplicate | Sixteen submissions through eight worker threads | Exactly one effect call |
| Key reused with changed payload | Change amount under an existing key | Denied without changing prior state |
| Unknown committed refund | Commit occurs but acknowledgement/receipt is missing | Retry remains unknown; reconciliation creates receipt without replay |
| Unknown absent refund | No effect occurs before unknown response | Retry blocked until definitive fake lookup; subsequent execution commits once |
| Stale approval | Change version or reach expiry exactly | Denied without effect |
| Cross-tenant identifiers | Read, execute, and reconcile another tenant’s ID | No data read and no effect or state change |
| Tenant-scoped key | Two tenants use the same key | Independent authorized operations |

The controller persists an unknown operation before contacting the fake ledger. An unresolved operation cannot dispatch another execution. Reconciliation uses the tenant-scoped identity to discover whether the effect already exists. The fake’s absent lookup is definitive, allowing a later retry after admission is checked again. In a real system, an eventually consistent “not found” is insufficient evidence to retry; an inconclusive lookup must retain the unknown state. Already committed duplicates return their prior outcome even when their old approval has expired: this retrieves the receipt without authorizing a new effect.

Run from this outputs directory:

```powershell
python -m py_compile runtime.py test_runtime.py
python -m unittest -v test_runtime
```

Both commands exited 0. The unittest runner reported `Ran 10 tests in 0.004s` and `OK`. That duration is the runner’s actual output, not a model or infrastructure performance claim. The optional `py --version` probe failed because the Windows `py` launcher is absent; the installed `python` executable worked. No tests were skipped.

Put this deterministic suite in the mandatory fast CI job without model API access. Any failed assertion or unavailable Python runtime should fail that job. Exact reasoning transcripts should be removed from authority assertions: test permitted calls, receipts, and resulting balances instead. Trigger adapter contract and integration checks on execution, persistence, policy, or tool changes. Prompt/model changes may additionally run quality evals, whose unavailable status must be reported separately and must never skip refund safety checks.

Coverage is deliberately limited to this fake. No production runtime was supplied, so these tests prove the included implementation’s behavior, not your existing service. Controller recreation reuses in-memory store objects; it does not test disk persistence, process crashes, database transactions, distributed races, authentication, or receipt tampering. Its lock serializes local threads. Provider idempotency, crash recovery, and definitive reconciliation require separate adapter tests against a resettable sandbox. The arithmetic oracle is deterministic; semantic proposal quality and real model behavior remain outside this suite.
