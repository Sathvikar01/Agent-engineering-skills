import unittest
from runtime import Approval, FakeProvider, Refund, Runtime, Store


class RefundSafetyTests(unittest.TestCase):
    def setUp(self):
        self.store, self.provider = Store(), FakeProvider()
        self.runtime = Runtime(self.store, self.provider)
        self.proposal = Refund("A", "a-payment", 3, "retry-1")
        self.approval = Approval(self.proposal, 0, 100)

    def run_refund(self, proposal=None, approval=None, now=1, actor="A"):
        return self.runtime.run(actor, proposal or self.proposal,
                                approval or self.approval, now)

    def assert_no_effect(self, before):
        self.assertEqual(before, self.runtime.snapshot())
        self.assertEqual(self.provider.calls, 0)

    def test_allow_updates_balance_receipt_and_effect(self):
        self.assertEqual(self.run_refund(), "committed")
        self.assertEqual(self.store.payments["a-payment"]["balance"], 7)
        self.assertEqual(len(self.store.receipts), 1)
        self.assertEqual(len(self.provider.effects), 1)

    def test_denial_never_mutates_generated_balance_boundaries(self):
        for amount in [-10, -1, 0, 11, 100, True, 1.5]:
            with self.subTest(amount=amount):
                proposal = Refund("A", "a-payment", amount, "denied")
                before = self.runtime.snapshot()
                self.assertEqual(self.run_refund(proposal, Approval(proposal, 0, 100)), "denied")
                self.assert_no_effect(before)

    def test_exact_balance_is_allowed(self):
        proposal = Refund("A", "a-payment", 10, "full")
        self.assertEqual(self.run_refund(proposal, Approval(proposal, 0, 100)), "committed")
        self.assertEqual(self.store.payments["a-payment"]["balance"], 0)

    def test_duplicate_retries_commit_once_even_after_restart(self):
        self.assertEqual(self.run_refund(), "committed")
        self.runtime = Runtime(self.store, self.provider)
        before = self.runtime.snapshot()
        for _ in range(5):
            self.assertEqual(self.run_refund(now=200), "committed")
        self.assertEqual(before, self.runtime.snapshot())
        self.assertEqual(self.provider.calls, 1)

    def test_duplicate_key_changed_payload_is_denied(self):
        self.run_refund()
        proposal = Refund("A", "a-payment", 4, "retry-1")
        before = self.runtime.snapshot()
        self.assertEqual(self.run_refund(proposal, Approval(proposal, 1, 100)), "denied")
        self.assertEqual(before, self.runtime.snapshot())
        self.assertEqual(self.provider.calls, 1)

    def test_unknown_committed_reconciles_after_restart_without_replay(self):
        self.provider.next_result = "unknown_committed"
        self.assertEqual(self.run_refund(), "unknown")
        self.assertEqual(len(self.provider.effects), 1)
        self.assertEqual(self.store.receipts, {})
        self.assertEqual(self.store.payments["a-payment"]["balance"], 10)
        self.runtime = Runtime(self.store, self.provider)
        self.assertEqual(self.run_refund(now=200), "committed")
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(self.store.payments["a-payment"]["balance"], 7)
        self.assertEqual(len(self.store.receipts), 1)

    def test_unresolved_unknown_never_replays(self):
        self.provider.next_result = "unknown_committed"
        self.run_refund()
        self.provider.lookup_result = "unknown"
        before = self.runtime.snapshot()
        for _ in range(4):
            self.assertEqual(self.run_refund(), "unknown")
        self.assertEqual(before, self.runtime.snapshot())
        self.assertEqual(self.provider.calls, 1)

    def test_known_absence_revalidates_before_retry(self):
        self.provider.next_result = "unknown_absent"
        self.assertEqual(self.run_refund(), "unknown")
        before = self.runtime.snapshot()
        self.assertEqual(self.run_refund(now=100), "denied")
        self.assertEqual(before, self.runtime.snapshot())
        self.assertEqual(self.provider.calls, 1)
        self.assertEqual(self.run_refund(), "committed")
        self.assertEqual(self.provider.calls, 2)
        self.assertEqual(len(self.provider.effects), 1)

    def test_stale_approval_version_expiry_and_payload_bindings(self):
        alternatives = [Approval(self.proposal, 1, 100), Approval(self.proposal, 0, 1),
                        Approval(Refund("A", "a-payment", 4, "retry-1"), 0, 100)]
        for approval in alternatives:
            with self.subTest(approval=approval):
                before = self.runtime.snapshot()
                self.assertEqual(self.run_refund(approval=approval), "denied")
                self.assert_no_effect(before)

    def test_cross_tenant_unknown_and_spoofed_ids_fail_closed(self):
        for proposal, actor in [(Refund("A", "b-payment", 3, "x"), "A"),
                                (Refund("A", "missing", 3, "x"), "A"),
                                (Refund("B", "b-payment", 3, "x"), "A")]:
            with self.subTest(proposal=proposal):
                before = self.runtime.snapshot()
                self.assertEqual(self.run_refund(proposal, Approval(proposal, 0, 100), actor=actor), "denied")
                self.assert_no_effect(before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
