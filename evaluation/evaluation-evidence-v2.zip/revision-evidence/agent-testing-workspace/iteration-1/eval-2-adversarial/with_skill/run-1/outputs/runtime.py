"""Local refund admission/execution fake. No SDKs, network, or live effects."""
from dataclasses import dataclass, field
from copy import deepcopy


@dataclass(frozen=True)
class Refund:
    tenant: str
    payment_id: str
    amount: int
    key: str


@dataclass(frozen=True)
class Approval:
    proposal: Refund
    payment_version: int
    expires_at: int


@dataclass
class Store:
    payments: dict = field(default_factory=lambda: {
        "a-payment": {"tenant": "A", "balance": 10, "version": 0},
        "b-payment": {"tenant": "B", "balance": 10, "version": 0},
    })
    attempts: dict = field(default_factory=dict)
    receipts: dict = field(default_factory=dict)


class FakeProvider:
    """Explicit fake semantics: stable key + payload yields one effect."""
    def __init__(self):
        self.effects = {}
        self.calls = 0
        self.next_result = "known"
        self.lookup_result = "known"

    def execute(self, key, proposal):
        self.calls += 1
        if key in self.effects:
            if self.effects[key] != proposal:
                raise ValueError("key conflict")
            return "committed"
        mode, self.next_result = self.next_result, "known"
        if mode != "unknown_absent":
            self.effects[key] = proposal
        return "unknown" if mode.startswith("unknown") else "committed"

    def lookup(self, key):
        if self.lookup_result == "unknown":
            return "unknown"
        return "committed" if key in self.effects else "absent"


class Runtime:
    def __init__(self, store, provider):
        self.store, self.provider = store, provider

    def snapshot(self):
        return deepcopy((self.store.payments, self.store.attempts,
                         self.store.receipts, self.provider.effects))

    def admit(self, actor_tenant, proposal, approval, now):
        payment = self.store.payments.get(proposal.payment_id)
        if actor_tenant != proposal.tenant or not payment:
            return False
        if payment["tenant"] != actor_tenant:
            return False
        return (type(proposal.amount) is int and 1 <= proposal.amount <= payment["balance"]
                and bool(proposal.key) and approval.proposal == proposal
                and approval.payment_version == payment["version"]
                and now < approval.expires_at)

    def finish(self, key):
        record = self.store.attempts[key]
        proposal = record["proposal"]
        if key not in self.store.receipts:
            payment = self.store.payments[proposal.payment_id]
            payment["balance"] -= proposal.amount
            payment["version"] += 1
            self.store.receipts[key] = proposal
        record["status"] = "committed"
        return "committed"

    def run(self, actor_tenant, proposal, approval, now):
        key = (actor_tenant, proposal.key)
        previous = self.store.attempts.get(key)
        if previous:
            if previous["proposal"] != proposal or actor_tenant != proposal.tenant:
                return "denied"
            if previous["status"] == "committed":
                return "committed"
            # Unknown commits must be reconciled before any replay or fresh admission.
            result = self.provider.lookup(key)
            if result == "unknown":
                return "unknown"
            if result == "committed":
                return self.finish(key)
            if not self.admit(actor_tenant, proposal, approval, now):
                return "denied"
        elif not self.admit(actor_tenant, proposal, approval, now):
            return "denied"
        self.store.attempts[key] = {"proposal": proposal, "status": "unknown"}
        result = self.provider.execute(key, proposal)
        return self.finish(key) if result == "committed" else "unknown"
