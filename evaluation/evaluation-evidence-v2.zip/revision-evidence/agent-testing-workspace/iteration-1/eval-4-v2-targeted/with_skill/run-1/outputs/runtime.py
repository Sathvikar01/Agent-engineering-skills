"""A deterministic scripted model boundary, validator, and effect controller."""
from dataclasses import dataclass, field
import json


class InvalidProposal(ValueError):
    pass


def reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise InvalidProposal("duplicate_field")
        result[key] = value
    return result


def validate(raw, observed):
    if raw is None or raw == "" or (isinstance(raw, str) and not raw.strip()):
        raise InvalidProposal("missing_output")
    if not isinstance(raw, str):
        raise InvalidProposal("invalid_transport")
    try:
        value = json.loads(raw, object_pairs_hook=reject_duplicate_keys)
    except json.JSONDecodeError:
        raise InvalidProposal("malformed_json") from None
    if not isinstance(value, dict):
        raise InvalidProposal("invalid_shape")
    if value.get("kind") == "refusal":
        raise InvalidProposal("refusal")
    if value.get("kind") == "tool_request":
        raise InvalidProposal("unsupported_tool")
    fields = {"kind", "amount", "evidence_ids", "explanation_amount"}
    if set(value) != fields:
        raise InvalidProposal("fields")
    if value["kind"] != "propose":
        raise InvalidProposal("unsupported_kind")
    if type(value["amount"]) is not int:
        raise InvalidProposal("amount_type")
    if not 1 <= value["amount"] <= 10:
        raise InvalidProposal("amount_range")
    evidence = value["evidence_ids"]
    if not isinstance(evidence, list) or any(type(item) is not str for item in evidence):
        raise InvalidProposal("evidence_shape")
    if any(item not in observed for item in evidence):
        raise InvalidProposal("unobserved_evidence")
    if type(value["explanation_amount"]) is not int or value["explanation_amount"] != value["amount"]:
        raise InvalidProposal("contradictory_explanation")
    return value


class ScriptedModel:
    def __init__(self, responses, repeat_last=False):
        self.responses = list(responses)
        self.repeat_last = repeat_last
        self.calls = 0

    def respond(self):
        position = self.calls
        self.calls += 1
        if position < len(self.responses):
            raw = self.responses[position]
        elif self.repeat_last and self.responses:
            raw = self.responses[-1]
        else:
            raw = None
        if isinstance(raw, Exception):
            raise raw
        return raw


@dataclass
class Result:
    status: str
    steps: int
    errors: list = field(default_factory=list)
    effects: list = field(default_factory=list)


class Controller:
    def __init__(self, model, max_steps=4, max_retries=2, max_no_progress=2):
        if any(type(v) is not int for v in (max_steps, max_retries, max_no_progress)):
            raise ValueError("budgets must be integers")
        if max_steps < 1 or max_retries < 0 or max_no_progress < 1:
            raise ValueError("invalid budget")
        self.model = model
        self.max_steps, self.max_retries = max_steps, max_retries
        self.max_no_progress = max_no_progress
        self.observed = frozenset({"A"})
        self.effects = []
        self.validation_calls = 0

    def run(self):
        errors, last_fingerprint, repeated = [], None, 0
        for step in range(1, self.max_steps + 1):
            raw = None
            try:
                raw = self.model.respond()
                self.validation_calls += 1
                proposal = validate(raw, self.observed)
            except (InvalidProposal, TimeoutError) as error:
                reason = "timeout" if isinstance(error, TimeoutError) else str(error)
                errors.append(reason)
                fingerprint = (reason, repr(raw))
                repeated = repeated + 1 if fingerprint == last_fingerprint else 1
                last_fingerprint = fingerprint
                if repeated >= self.max_no_progress:
                    return Result("no_progress", step, errors, list(self.effects))
                if len(errors) > self.max_retries:
                    return Result("retry_limit", step, errors, list(self.effects))
                continue
            self.effects.append(dict(proposal))
            return Result("admitted", step, errors, list(self.effects))
        return Result("step_limit", self.max_steps, errors, list(self.effects))
