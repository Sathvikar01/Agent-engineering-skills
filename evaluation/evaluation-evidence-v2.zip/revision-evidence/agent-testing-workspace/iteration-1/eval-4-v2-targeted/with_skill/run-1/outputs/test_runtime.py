import json
import unittest
from runtime import Controller, ScriptedModel


def candidate(**changes):
    value = {"kind": "propose", "amount": 3, "evidence_ids": ["A"], "explanation_amount": 3}
    value.update(changes)
    return json.dumps(value)


class BoundaryTests(unittest.TestCase):
    def check_rejected(self, raw, reason):
        model = ScriptedModel([raw])
        controller = Controller(model, max_retries=0)
        result = controller.run()
        self.assertEqual(result.status, "retry_limit")
        self.assertEqual(result.errors, [reason])
        self.assertEqual(result.effects, [])
        self.assertEqual(controller.effects, [])
        self.assertEqual(model.calls, 1)
        return result

    def test_malformed_json(self):
        self.check_rejected('{"kind":', "malformed_json")

    def test_missing_and_empty_outputs(self):
        for raw, reason in [(None, "missing_output"), ("", "missing_output"),
                            ("   ", "missing_output"), ("{}", "fields")]:
            with self.subTest(raw=raw):
                self.check_rejected(raw, reason)

    def test_valid_shape_invalid_amount_11(self):
        self.check_rejected(candidate(amount=11, explanation_amount=11), "amount_range")

    def test_invented_evidence_Z(self):
        self.check_rejected(candidate(evidence_ids=["A", "Z"]), "unobserved_evidence")

    def test_contradictory_explanation(self):
        self.check_rejected(candidate(explanation_amount=2), "contradictory_explanation")

    def test_timeout(self):
        self.check_rejected(TimeoutError("scripted boundary timeout"), "timeout")

    def test_refusal(self):
        self.check_rejected('{"kind":"refusal","reason":"declined"}', "refusal")

    def test_unsupported_tool(self):
        self.check_rejected('{"kind":"tool_request","tool":"refund"}', "unsupported_tool")

    def test_repeated_no_progress_is_bounded(self):
        model = ScriptedModel([candidate(kind="wait")], repeat_last=True)
        controller = Controller(model, max_steps=20, max_retries=19)
        result = controller.run()
        self.assertEqual(result.status, "no_progress")
        self.assertEqual(result.errors, ["unsupported_kind", "unsupported_kind"])
        self.assertEqual(result.steps, 2)
        self.assertEqual(model.calls, 2)
        self.assertEqual(result.effects, [])

    def test_valid_proposal_creates_exactly_one_admitted_effect(self):
        model = ScriptedModel([candidate(), candidate(amount=4, explanation_amount=4)])
        controller = Controller(model)
        result = controller.run()
        self.assertEqual(result.status, "admitted")
        self.assertEqual(result.errors, [])
        self.assertEqual(result.effects, [json.loads(candidate())])
        self.assertEqual(model.calls, 1)

    def test_repair_gets_fresh_validation_before_admission(self):
        model = ScriptedModel([candidate(evidence_ids=["Z"]), candidate()])
        controller = Controller(model)
        result = controller.run()
        self.assertEqual(result.status, "admitted")
        self.assertEqual(result.errors, ["unobserved_evidence"])
        self.assertEqual(controller.validation_calls, 2)
        self.assertEqual(result.effects, [json.loads(candidate())])
        self.assertEqual(model.calls, 2)

    def test_unrepairable_answers_exhaust_retry_budget(self):
        model = ScriptedModel(["{", "{}", candidate(amount=11), candidate()])
        controller = Controller(model, max_steps=10, max_retries=2)
        result = controller.run()
        self.assertEqual(result.status, "retry_limit")
        self.assertEqual(result.steps, 3)
        self.assertEqual(model.calls, 3)
        self.assertEqual(result.effects, [])

    def test_distinct_answers_exhaust_step_budget(self):
        model = ScriptedModel(["{", "{}", candidate()])
        controller = Controller(model, max_steps=2, max_retries=10)
        result = controller.run()
        self.assertEqual(result.status, "step_limit")
        self.assertEqual(result.steps, 2)
        self.assertEqual(model.calls, 2)
        self.assertEqual(result.effects, [])

    def test_schema_edges_and_unknown_variants_fail_closed(self):
        cases = [("[]", "invalid_shape"), (candidate(amount=True), "amount_type"),
                 (candidate(amount=3.0), "amount_type"), (candidate(evidence_ids="A"), "evidence_shape"),
                 (candidate(evidence_ids=[1]), "evidence_shape"), (candidate(extra=1), "fields"),
                 (candidate(kind="execute"), "unsupported_kind"),
                 (candidate(explanation_amount=True), "contradictory_explanation"),
                 ('{"kind":"propose","kind":"execute"}', "duplicate_field")]
        for raw, reason in cases:
            with self.subTest(raw=raw):
                self.check_rejected(raw, reason)

    def test_amount_boundaries(self):
        for amount in [1, 10]:
            with self.subTest(amount=amount):
                result = Controller(ScriptedModel([candidate(amount=amount, explanation_amount=amount)])).run()
                self.assertEqual(result.status, "admitted")
                self.assertEqual(result.effects[0]["amount"], amount)
        self.check_rejected(candidate(amount=0, explanation_amount=0), "amount_range")


if __name__ == "__main__":
    unittest.main(verbosity=2)
