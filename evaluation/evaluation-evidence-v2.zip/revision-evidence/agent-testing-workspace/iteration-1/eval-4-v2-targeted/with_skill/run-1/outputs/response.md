# Executed scripted-boundary checks

The supplied `runtime.py` and `test_runtime.py` implement and exercise a local scripted response boundary, runtime validator and bounded controller. I inspected the saved source and actually ran `python -m unittest -v` from this outputs directory. **All 15 unittest methods passed, exit code 0, on Python 3.11.9.** Actual captured stdout/stderr and full interpreter version are saved in `test-output.log`. The model fake returns only supplied fixtures, and admitted effects are dictionaries appended to an in-memory list; no SDK, provider request or live effect is involved.

The controller accepts only proposals that survive its runtime validator. Required fields are `kind`, `amount`, `evidence_ids` and `explanation_amount`; extra or missing fields fail closed. Kind must be `propose`. Amount must be an actual Python integer, excluding booleans, between 1 and 10 inclusive. Evidence IDs must form a list of strings whose members are in the immutable observed set `{A}`. Explanation amount must also be an actual integer and agree with the structured amount. A matching JSON shape cannot bypass the range, grounding or consistency checks. Duplicate JSON keys are rejected to avoid ambiguous interpretations.

| Fixture / risk | Actual test outcome |
|---|---|
| Malformed JSON | Rejected, zero recorded effects. |
| Missing, empty, whitespace, empty object | Rejected, zero effects. |
| Valid shape with amount 11 | Rejected by range validation. |
| Invented Z alongside observed A | Entire proposal rejected; A does not rescue Z. |
| Explanation amount contradicts amount | Rejected by consistency validation. |
| Timeout exception | Classified as timeout; zero effects. |
| Explicit refusal | Classified as refusal; zero effects. |
| Unsupported tool request | Classified and rejected without tool execution. |
| Repeated no-progress answer | Stops after two identical invalid answers despite larger budgets. |
| Valid proposal | Exactly one recorded admitted effect, one model call. |
| Repairable candidate | Invalid Z followed by valid A reaches fresh validation twice, then one effect. |
| Unrepairable / changing errors | Retry and step limits independently stop before later valid fixtures are consumed. |

Individual rejection tests use a zero-retry configuration and inspect status, errors, model-call count and both the controller's effect list and returned effect list. Thus an error label alone cannot make a test pass while an effect slips through. Integration tests use nonzero budgets to exercise fresh validation after repair. Additional boundary subtests cover amount 1, 10 and 0, arrays instead of objects, booleans and floats, wrong evidence container/item types, extra fields, unknown kinds and duplicate keys. These subtests execute within the 15 counted methods.

Default controller limits are four steps, two retries and two consecutive identical failed responses. Two retries mean the initial response plus at most two subsequent attempts. An independent step cap also bounds alternating invalid responses that evade the repeat detector. Admission terminates the loop immediately, so a later scripted answer cannot produce another effect in the same run. Failure records preserve rejection reasons; the tests assert useful behavior and state rather than exact reasoning transcripts. Scripted timeout injection demonstrates handling of a timeout signal, not enforcement of a real wall-clock deadline.

These checks belong in fast CI for changes to output parsing, validation, controller budgets or admission. A separate model-dependent evaluation job should run when prompts, models or retrieval change. Its unavailable infrastructure must not skip or turn these deterministic authority checks into passing placeholders. Real transport/adapter contracts and consequential recovery tests belong at integration and release boundaries.

Coverage has explicit limits. This is the fake's own runtime validator, not an existing production implementation or provider schema engine. Evidence membership proves that IDs were observed; it does not prove relevance, entailment, actual use in reasoning or completeness of a claim. The contract does not require nonempty or unique evidence lists. The numeric explanation check cannot judge arbitrary natural-language explanations. No stochastic model selection, real refusal envelope, streaming/partial output, network latency, cancellation, durable restart, concurrency or external execution contract was tested. Budgets are per run and are not persisted across restarts. No branch coverage percentage or model-quality metric was measured. Those are proposed future checks, not claimed outcomes of this run.
