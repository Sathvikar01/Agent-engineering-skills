import json
from boundary import Controller, ScriptedModel
from test_boundary import CASES

for name, event in CASES.items():
    controller = Controller(ScriptedModel([event] * 10))
    controller.run()
    print(json.dumps({"case": name, "stop": controller.stop, "calls": controller.model.calls,
                      "trace": controller.trace, "admitted_effects": controller.effects}, sort_keys=True))
