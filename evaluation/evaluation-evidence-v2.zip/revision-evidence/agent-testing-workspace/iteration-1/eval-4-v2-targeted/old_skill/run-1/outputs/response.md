Built and executed a deterministic response boundary in `boundary.py`, with runnable tests in `test_boundary.py`. Python 3.11.9 ran all 12 unittest methods successfully, with no skipped tests. `show_cases.py` also executed the 11 requested scenarios and recorded each actual stop reason, call count, rejection trace, and admitted effect in `cases-log.jsonl`. Everything is local: the scripted model reads fixtures, and execution appends to a Python list.

The validator checks structure before domain predicates. The output must decode to an object with exactly `kind`, `amount`, `evidence_ids`, and `explanation_amount`. `kind` must be `propose`; both numeric fields must be actual integers, excluding booleans. The range, observed-evidence membership, and explanation agreement are then checked deterministically. An amount of 11 therefore passes the numeric shape check but fails the range predicate; invented Z and contradictory numeric explanation fail their distinct predicates. No LLM grades these facts.

| Scripted input | Actual first classification | Calls / final stop | Admitted effects |
|---|---|---|---|
| Malformed JSON | malformed_json | 2 / no_progress | 0 |
| Missing output | missing_output | 2 / no_progress | 0 |
| Empty output | missing_output | 2 / no_progress | 0 |
| Integer amount 11 | amount_range | 2 / no_progress | 0 |
| Invented evidence Z | unobserved_evidence | 2 / no_progress | 0 |
| explanation_amount=4, amount=5 | contradictory_explanation | 2 / no_progress | 0 |
| Timeout | timeout | 2 / no_progress | 0 |
| Refusal | refusal | 1 / refusal | 0 |
| Unsupported tool | unsupported_tool | 1 / unsupported_tool | 0 |
| Repeated wait response | schema | 2 / no_progress | 0 |
| Valid amount 5, evidence A | accepted | 1 / accepted | 1 |

In that case runner, the same fixture is repeated deliberately. The controller stops after two identical failed responses. Separate tests supply differing invalid responses, proving the retry budget stops after three total calls. Another test sets a two-step cap with a larger retry budget, proving the step limit wins. Zero retries allows only the initial attempt. Missing script entries become missing-output events and also terminate. Refusal, unsupported tools, and unknown boundary variants stop immediately, even if a valid response follows in the script.

Seven recoverable-fault subcases followed by a valid proposal prove that retry can make useful progress while admitting only the validated proposal. Additional checks cover amount endpoints 1 and 10, invalid numeric types, required/extra fields, evidence shape, invalid budgets, and a completed controller’s inability to append a second effect on another `run()` call. An empty evidence list is permitted: the supplied contract restricts IDs to observed A but does not require a nonempty list.

Executed from this outputs directory:

```powershell
python --version
python -m py_compile boundary.py test_boundary.py show_cases.py
python -m unittest -v test_boundary
python show_cases.py
```

Every task-specific command exited 0. The actual test log reports `Ran 12 tests in 0.001s` and `OK`; this is the runner’s duration, not provider latency. `test-log.txt` and `cases-exit.txt` preserve execution status. No task-specific execution failures occurred.

Use these deterministic checks as a required fast CI gate. Run real adapter contract checks when boundary envelopes or provider integrations change, and model quality evals on prompt/model changes. Model API unavailability must not skip these local safety predicates.

Coverage limitations remain concrete. This is a hand-written validator for the small contract, not validation of your production schema library. Evidence membership proves only that an ID was observed, not that its content supports the claim. Numeric explanation equality does not validate arbitrary prose. Timeout is an injected exception, not cancellation of a hung socket. No real streaming, provider refusal envelopes, rate limits, SDK parsing, process restart, concurrency, persistent effects, or provider guarantees were tested. Exact-repeat detection misses paraphrased stagnation, although the independent retry and step budgets still terminate it. Real stochastic proposal quality requires a separate eval population and measured model runs.
