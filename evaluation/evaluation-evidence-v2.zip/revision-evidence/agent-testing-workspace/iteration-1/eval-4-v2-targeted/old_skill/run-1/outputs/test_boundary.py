import json
import unittest
from boundary import Controller, Event, ScriptedModel


def proposal(**changes):
    value = {"kind": "propose", "amount": 5, "evidence_ids": ["A"], "explanation_amount": 5}
    value.update(changes)
    return json.dumps(value)


CASES = {
    "malformed_json": Event(output="{broken"),
    "missing_output": Event("missing"),
    "empty_output": Event(output=""),
    "amount_11": Event(output=proposal(amount=11, explanation_amount=11)),
    "invented_Z": Event(output=proposal(evidence_ids=["Z"])),
    "contradictory_explanation": Event(output=proposal(explanation_amount=4)),
    "timeout": Event("timeout"),
    "refusal": Event("refusal"),
    "unsupported_tool": Event(output=json.dumps({"kind": "tool", "name": "refund"})),
    "repeated_no_progress": Event(output=json.dumps({"kind": "wait"})),
    "valid_proposal": Event(output=proposal()),
}


class BoundaryTests(unittest.TestCase):
    def controller(self, script, **limits):
        return Controller(ScriptedModel(script), **limits)

    def test_required_scenarios_no_effect_except_valid(self):
        expected = {
            "malformed_json": "malformed_json", "missing_output": "missing_output",
            "empty_output": "missing_output", "amount_11": "amount_range",
            "invented_Z": "unobserved_evidence", "contradictory_explanation": "contradictory_explanation",
            "timeout": "timeout", "refusal": "refusal", "unsupported_tool": "unsupported_tool",
            "repeated_no_progress": "schema", "valid_proposal": "accepted",
        }
        for name, event in CASES.items():
            with self.subTest(name=name):
                controller = self.controller([event] * 10)
                controller.run()
                self.assertEqual(controller.trace[0]["reason"], expected[name])
                self.assertLessEqual(controller.model.calls, 3)
                if name == "valid_proposal":
                    self.assertEqual(controller.effects, [json.loads(proposal())])
                    self.assertEqual(controller.stop, "accepted")
                    self.assertEqual(controller.model.calls, 1)
                else:
                    self.assertEqual(controller.effects, [])
                    expected_stop = name if name in {"refusal", "unsupported_tool"} else "no_progress"
                    self.assertEqual(controller.stop, expected_stop)

    def test_unique_invalid_answers_exhaust_retry_budget(self):
        controller = self.controller([Event(output="bad" + str(i)) for i in range(10)])
        self.assertEqual(controller.run(), "retry_limit")
        self.assertEqual(controller.model.calls, 3)
        self.assertEqual(controller.effects, [])

    def test_step_limit_overrides_large_retry_budget(self):
        controller = self.controller([Event(output="bad" + str(i)) for i in range(10)], max_steps=2, max_retries=9)
        self.assertEqual(controller.run(), "step_limit")
        self.assertEqual(controller.model.calls, 2)
        self.assertEqual(controller.effects, [])

    def test_zero_retry_budget_means_one_attempt(self):
        controller = self.controller([CASES["malformed_json"], CASES["valid_proposal"]], max_retries=0)
        self.assertEqual(controller.run(), "retry_limit")
        self.assertEqual(controller.model.calls, 1)
        self.assertEqual(controller.effects, [])

    def test_recoverable_fault_then_valid_admits_one_effect(self):
        for name in ("malformed_json", "missing_output", "empty_output", "amount_11", "invented_Z", "contradictory_explanation", "timeout"):
            with self.subTest(name=name):
                controller = self.controller([CASES[name], CASES["valid_proposal"]])
                self.assertEqual(controller.run(), "accepted")
                self.assertEqual(controller.model.calls, 2)
                self.assertEqual(controller.effects, [json.loads(proposal())])

    def test_refusal_and_unsupported_tool_stop_before_later_valid(self):
        for name in ("refusal", "unsupported_tool"):
            with self.subTest(name=name):
                controller = self.controller([CASES[name], CASES["valid_proposal"]])
                self.assertEqual(controller.run(), name)
                self.assertEqual(controller.model.calls, 1)
                self.assertEqual(controller.effects, [])

    def test_finished_controller_cannot_replay_effect(self):
        controller = self.controller([CASES["valid_proposal"]] * 3)
        controller.run()
        controller.run()
        self.assertEqual(controller.model.calls, 1)
        self.assertEqual(len(controller.effects), 1)

    def test_amount_edges_and_empty_evidence_subset(self):
        for amount in (1, 10):
            with self.subTest(amount=amount):
                controller = self.controller([Event(output=proposal(amount=amount, explanation_amount=amount, evidence_ids=[]))])
                self.assertEqual(controller.run(), "accepted")
                self.assertEqual(len(controller.effects), 1)
        for amount in (0, -1, 11, True, 5.0, "5"):
            with self.subTest(amount=amount):
                controller = self.controller([Event(output=proposal(amount=amount))], max_retries=0)
                controller.run()
                self.assertEqual(controller.effects, [])

    def test_required_fields_shape_and_extra_fields(self):
        value = json.loads(proposal())
        del value["amount"]
        outputs = [json.dumps(value), "null", "[]", proposal(extra=1), proposal(evidence_ids="A"), proposal(evidence_ids=[1]), proposal(explanation_amount=True)]
        for output in outputs:
            with self.subTest(output=output):
                controller = self.controller([Event(output=output)], max_retries=0)
                controller.run()
                self.assertEqual(controller.trace[0]["reason"], "schema")
                self.assertEqual(controller.effects, [])

    def test_missing_script_is_bounded(self):
        controller = self.controller([])
        self.assertEqual(controller.run(), "no_progress")
        self.assertEqual(controller.model.calls, 2)
        self.assertEqual(controller.effects, [])

    def test_unknown_boundary_event_fails_closed(self):
        controller = self.controller([Event("new_variant"), CASES["valid_proposal"]])
        self.assertEqual(controller.run(), "unsupported_boundary_event")
        self.assertEqual(controller.effects, [])
        self.assertEqual(controller.model.calls, 1)

    def test_bad_budgets_rejected(self):
        for limits in ({"max_retries": -1}, {"max_retries": True}, {"max_steps": 0}):
            with self.subTest(limits=limits):
                with self.assertRaises(ValueError):
                    self.controller([], **limits)


if __name__ == "__main__":
    unittest.main(verbosity=2)
