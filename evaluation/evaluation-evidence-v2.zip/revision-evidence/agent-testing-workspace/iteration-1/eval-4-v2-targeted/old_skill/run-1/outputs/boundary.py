"""Deterministic model boundary; no SDK, credentials, network, or live effects."""
import json
from dataclasses import dataclass


@dataclass(frozen=True)
class Event:
    status: str = "answer"
    output: object = None


class ScriptedModel:
    def __init__(self, script):
        self.script = list(script)
        self.calls = 0

    def next(self):
        index = self.calls
        self.calls += 1
        event = self.script[index] if index < len(self.script) else Event("missing")
        if event.status == "timeout":
            raise TimeoutError("scripted timeout")
        return event


def validate(output):
    if not isinstance(output, str) or not output.strip():
        return None, "missing_output"
    try:
        proposal = json.loads(output)
    except (ValueError, TypeError):
        return None, "malformed_json"
    if not isinstance(proposal, dict):
        return None, "schema"
    if proposal.get("kind") == "tool":
        return None, "unsupported_tool"
    required = {"kind", "amount", "evidence_ids", "explanation_amount"}
    if set(proposal) != required or proposal["kind"] != "propose":
        return None, "schema"
    if type(proposal["amount"]) is not int or type(proposal["explanation_amount"]) is not int:
        return None, "schema"
    ids = proposal["evidence_ids"]
    if not isinstance(ids, list) or any(not isinstance(item, str) for item in ids):
        return None, "schema"
    if not 1 <= proposal["amount"] <= 10:
        return None, "amount_range"
    if any(item not in {"A"} for item in ids):
        return None, "unobserved_evidence"
    if proposal["explanation_amount"] != proposal["amount"]:
        return None, "contradictory_explanation"
    return proposal, "accepted"


class Controller:
    def __init__(self, model, max_retries=2, max_steps=4):
        if type(max_retries) is not int or max_retries < 0:
            raise ValueError("invalid retry budget")
        if type(max_steps) is not int or max_steps < 1:
            raise ValueError("invalid step budget")
        self.model = model
        self.max_retries, self.max_steps = max_retries, max_steps
        self.effects, self.trace = [], []
        self.stop = None
        self.finished = False

    def run(self):
        if self.finished:
            return self.stop
        previous = None
        limit = min(self.max_steps, self.max_retries + 1)
        for step in range(1, limit + 1):
            proposal = None
            try:
                event = self.model.next()
                fingerprint = (event.status, repr(event.output))
                if event.status == "refusal":
                    reason = "refusal"
                elif event.status == "missing":
                    reason = "missing_output"
                elif event.status != "answer":
                    reason = "unsupported_boundary_event"
                else:
                    proposal, reason = validate(event.output)
            except TimeoutError:
                reason, fingerprint = "timeout", ("timeout", None)
            self.trace.append({"step": step, "reason": reason})
            if reason == "accepted":
                # Admission is the only path to this local effect record.
                self.effects.append(dict(proposal))
                self.stop = "accepted"
                break
            if reason in {"refusal", "unsupported_tool", "unsupported_boundary_event"}:
                self.stop = reason
                break
            if fingerprint == previous:
                self.stop = "no_progress"
                break
            previous = fingerprint
        else:
            self.stop = "step_limit" if self.max_steps <= self.max_retries else "retry_limit"
        self.finished = True
        return self.stop
