"""Deterministic scripted-model boundary and bounded local proposal controller."""
import json
from dataclasses import dataclass, field


class Rejected(Exception):
    def __init__(self, code):
        super().__init__(code)
        self.code = code


class ScriptedModel:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = 0

    def respond(self):
        self.calls += 1
        if not self.responses:
            return {}  # Script exhaustion is missing output, never invented success.
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response


def parse_response(envelope):
    if type(envelope) is not dict:
        raise Rejected("invalid_envelope")
    if "refusal" in envelope:
        raise Rejected("refusal")
    if "tool_call" in envelope:
        raise Rejected("unsupported_tool")
    if "output" not in envelope or envelope["output"] is None:
        raise Rejected("missing_output")
    raw = envelope["output"]
    if type(raw) is not str:
        raise Rejected("output_type")
    if not raw.strip():
        raise Rejected("empty_output")
    try:
        def unique_object(pairs):
            value = {}
            for key, item in pairs:
                if key in value:
                    raise Rejected("duplicate_json_key")
                value[key] = item
            return value

        def reject_constant(_):
            raise Rejected("nonfinite_json")

        result = json.loads(raw, object_pairs_hook=unique_object,
                            parse_constant=reject_constant)
    except json.JSONDecodeError:
        raise Rejected("malformed_json") from None
    return result


def validate_contract(candidate, observed_ids):
    if type(candidate) is not dict:
        raise Rejected("object_required")
    required = {"kind", "amount", "evidence_ids", "explanation_amount"}
    if set(candidate) != required:
        raise Rejected("fields_mismatch")
    if candidate["kind"] != "propose":
        raise Rejected("unsupported_kind")
    if type(candidate["amount"]) is not int:
        raise Rejected("amount_type")
    if type(candidate["explanation_amount"]) is not int:
        raise Rejected("explanation_type")
    ids = candidate["evidence_ids"]
    if type(ids) is not list or any(type(item) is not str for item in ids):
        raise Rejected("evidence_type")
    # Semantic admission checks are deterministic, after structural validation.
    if not 1 <= candidate["amount"] <= 10:
        raise Rejected("amount_out_of_range")
    if any(item not in observed_ids for item in ids):
        raise Rejected("unobserved_evidence")
    if candidate["explanation_amount"] != candidate["amount"]:
        raise Rejected("explanation_conflict")
    return candidate


@dataclass
class Checkpoint:
    steps_left: int
    retries_left: int
    status: str = "running"
    outcome: dict | None = None
    last_rejection_signature: str | None = None
    identical_rejections: int = 0
    events: list = field(default_factory=list)


@dataclass
class Store:
    tasks: dict = field(default_factory=dict)
    effects: list = field(default_factory=list)


class Controller:
    def __init__(self, store, observed_ids=frozenset({"A"}),
                 max_steps=3, max_retries=2, no_progress_limit=2):
        if max_steps < 1 or max_retries < 0 or no_progress_limit < 1:
            raise ValueError("invalid budget")
        self.store = store
        self.observed_ids = frozenset(observed_ids)
        self.max_steps, self.max_retries = max_steps, max_retries
        self.no_progress_limit = no_progress_limit

    def finish(self, state, status):
        state.status = status
        state.outcome = {"status": status, "effect": None}
        return state.outcome

    def run(self, task_id, model):
        state = self.store.tasks.get(task_id)
        if state is None:
            state = Checkpoint(self.max_steps, self.max_retries)
            self.store.tasks[task_id] = state
        if state.status != "running":
            return state.outcome
        while state.steps_left:
            state.steps_left -= 1
            attempt = len([e for e in state.events if e["event"] == "requested"]) + 1
            state.events.append({"event": "requested", "attempt": attempt})
            signature = None
            try:
                try:
                    envelope = model.respond()
                except TimeoutError:
                    signature = "timeout"
                    raise Rejected("timeout") from None
                signature = json.dumps(envelope, sort_keys=True)
                candidate = parse_response(envelope)
                state.events.append({"event": "parsed", "attempt": attempt})
                decision = validate_contract(candidate, self.observed_ids)
                state.events.append({"event": "validated", "attempt": attempt})
            except Rejected as error:
                state.events.append({"event": "rejected", "attempt": attempt,
                                     "code": error.code})
                if signature == state.last_rejection_signature:
                    state.identical_rejections += 1
                else:
                    state.identical_rejections = 1
                state.last_rejection_signature = signature
                if error.code in {"refusal", "unsupported_tool"}:
                    return self.finish(state, error.code)
                if state.identical_rejections >= self.no_progress_limit:
                    return self.finish(state, "no_progress")
                if state.retries_left == 0 or state.steps_left == 0:
                    return self.finish(state, "exhausted")
                state.retries_left -= 1
                continue
            effect = {"task_id": task_id, "kind": decision["kind"],
                      "amount": decision["amount"],
                      "evidence_ids": list(decision["evidence_ids"]),
                      "explanation_amount": decision["explanation_amount"]}
            self.store.effects.append(effect)
            state.events.append({"event": "admitted", "attempt": attempt})
            state.status = "accepted"
            state.outcome = {"status": "accepted", "effect": effect}
            return state.outcome
        return self.finish(state, "exhausted")


def proposal(amount=5, evidence_ids=None, explanation_amount=None, **extra):
    return {"output": json.dumps({
        "kind": "propose", "amount": amount,
        "evidence_ids": ["A"] if evidence_ids is None else evidence_ids,
        "explanation_amount": amount if explanation_amount is None else explanation_amount,
        **extra})}


def fault_fixtures():
    # Each entry is run as a separate logical task with zero repair retries.
    return {
        "malformed_json": {"output": "{"},
        "missing_output": {},
        "null_output": {"output": None},
        "empty_output": {"output": "   "},
        "amount_11": proposal(11),
        "invented_Z": proposal(evidence_ids=["A", "Z"]),
        "contradictory_explanation": proposal(5, explanation_amount=6),
        "timeout": TimeoutError("scripted timeout"),
        "refusal": {"refusal": "cannot comply"},
        "unsupported_tool": {"tool_call": {"name": "refund", "amount": 5}},
    }


def demo():
    result = {"fixtures": {}, "sequences": {}}
    for name, response in fault_fixtures().items():
        store, model = Store(), ScriptedModel([response])
        outcome = Controller(store, max_retries=0).run(name, model)
        result["fixtures"][name] = {"outcome": outcome, "calls": model.calls,
                                    "effects": store.effects,
                                    "events": store.tasks[name].events}
    sequences = {
        "repeated_no_progress": [{"output": "Still thinking."}] * 10,
        "repairable": [proposal(11), proposal(5)],
        "unrepairable": [proposal(11), proposal(12), proposal(13), proposal(5)],
        "valid": [proposal(5)],
    }
    for name, script in sequences.items():
        store, model = Store(), ScriptedModel(script)
        outcome = Controller(store).run(name, model)
        result["sequences"][name] = {"outcome": outcome, "calls": model.calls,
                                    "effects": store.effects,
                                    "events": store.tasks[name].events,
                                    "steps_left": store.tasks[name].steps_left,
                                    "retries_left": store.tasks[name].retries_left}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    demo()
