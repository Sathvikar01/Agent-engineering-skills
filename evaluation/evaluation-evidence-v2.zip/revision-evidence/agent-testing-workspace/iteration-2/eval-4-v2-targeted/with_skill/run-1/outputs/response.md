I built and executed a deterministic scripted-model boundary with a surrounding proposal controller. **All 19 tests passed**, with exit code **0**, using **Python 3.11.9**. The runner reported `Ran 19 tests in 0.005s`. A separate demonstration also exited **0** and saved actual controller traces. These are local executions with no provider calls or external effects.

The runnable fake and controller are [scripted_runtime.py](~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-testing-workspace/iteration-2/eval-4-v2-targeted/with_skill/run-1/outputs/scripted_runtime.py). Tests are in [test_scripted_runtime.py](~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-testing-workspace/iteration-2/eval-4-v2-targeted/with_skill/run-1/outputs/test_scripted_runtime.py). Run these commands from their directory:

```powershell
python -m unittest -v test_scripted_runtime
python scripted_runtime.py
```

The saved evidence is [actual-test.log](~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-testing-workspace/iteration-2/eval-4-v2-targeted/with_skill/run-1/outputs/actual-test.log) and [actual-traces.json](~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-testing-workspace/iteration-2/eval-4-v2-targeted/with_skill/run-1/outputs/actual-traces.json). No tests were skipped, and no dependencies were installed.

Each model reply first passes envelope handling and strict JSON parsing, then structural and deterministic semantic validation. Admission requires exactly the four contract fields, `kind=propose`, an integer amount from 1 through 10, evidence IDs drawn only from observed `A`, and an integer explanation amount equal to the decision amount. Python booleans and floating-point values fail the integer predicate. Duplicate JSON keys and nonfinite constants fail closed. A tool request or refusal takes precedence over any otherwise valid output in its envelope.

| Executed fixture | Actual outcome and admitted effects |
|---|---|
| Malformed JSON; missing, null, or empty output | Rejected; zero effects, one call each with repairs disabled. |
| Valid shape containing amount 11 | Semantic rejection; zero effects. |
| Invented Z alongside observed A | Provenance rejection; zero effects. |
| Explanation amount contradicting amount | Agreement rejection; zero effects. |
| Scripted timeout | Recorded timeout; zero effects. |
| Refusal; unsupported tool | Immediate terminal result; zero effects. |
| Identical no-progress answer repeated | Terminal `no_progress` after two calls; zero effects. |
| Amount 11 followed by valid amount 5 | Fresh validation and admission on attempt two; exactly one effect. |
| Three different invalid amounts followed by a valid answer | Exhausted after three calls; later valid answer remains unread; zero effects. |
| One valid proposal | Accepted after one call; exactly one recorded effect. |

The controller defaults to three total steps and two repair retries. Every attempted model call spends a step; repair consumes the separate retry allowance. Identical rejected replies trigger a progress stop. Terminal success and failure reuse their stored outcome on reentry without another model request or effect. A resumed running checkpoint retains its remaining budget even when a new controller requests larger limits. Distinct logical task IDs permit distinct work. Tests assert these state and effect properties, not reasoning prose.

The requested contract permits empty evidence lists because every listed ID must be observed; it does not explicitly require a citation. A test confirms observed-but-unused A is not silently added to the receipt. This does not prove that A's contents support the amount: the fixture defines only an observed-ID allowlist. Likewise, numeric explanation agreement is a narrow semantic guarantee, not validation of arbitrary natural-language explanations or factual claims.

Coverage is explicit and limited. The 19 methods include parameterized integer boundaries and additional schema cases, but no branch-coverage percentage was measured. The timeout fixture raises an exception; it does not prove cancellation of a genuinely hung provider call or enforce a wall-clock deadline. Retained memory models checkpoints, not process durability, atomic effects, concurrent dispatch, or real provider retry semantics. No production validator was supplied, so this verifies the local controller rather than an existing deployment. Adapter contracts, real schema-library integration, crash/race tests, and stochastic model quality remain unexecuted work. Keep these deterministic checks in fast CI; trigger provider integration checks on adapter changes and separate model evaluations on prompt/model changes.
