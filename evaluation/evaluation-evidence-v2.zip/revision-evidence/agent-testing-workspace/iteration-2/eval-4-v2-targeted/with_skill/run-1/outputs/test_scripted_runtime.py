import unittest
from copy import deepcopy
from scripted_runtime import (Checkpoint, Controller, ScriptedModel, Store,
                              fault_fixtures, proposal)


class BoundaryTests(unittest.TestCase):
    def rejected(self, response, code):
        store, model = Store(), ScriptedModel([response])
        outcome = Controller(store, max_retries=0).run("task", model)
        self.assertNotEqual(outcome["status"], "accepted")
        self.assertEqual(store.effects, [])
        self.assertIsNone(outcome["effect"])
        self.assertEqual(model.calls, 1)
        errors = [e["code"] for e in store.tasks["task"].events if e["event"] == "rejected"]
        self.assertEqual(errors, [code])
        self.assertFalse(any(e["event"] == "admitted" for e in store.tasks["task"].events))

    def test_malformed_json(self):
        self.rejected(fault_fixtures()["malformed_json"], "malformed_json")

    def test_missing_null_and_empty_output(self):
        for name, code in [("missing_output", "missing_output"),
                           ("null_output", "missing_output"),
                           ("empty_output", "empty_output")]:
            with self.subTest(name=name):
                self.rejected(fault_fixtures()[name], code)

    def test_valid_shape_amount_11_is_semantically_denied(self):
        self.rejected(proposal(11), "amount_out_of_range")

    def test_invented_evidence_even_with_observed_A_denied(self):
        self.rejected(proposal(evidence_ids=["A", "Z"]), "unobserved_evidence")

    def test_contradictory_explanation_denied(self):
        self.rejected(proposal(5, explanation_amount=6), "explanation_conflict")

    def test_timeout_has_no_effect(self):
        self.rejected(TimeoutError("fake timeout"), "timeout")

    def test_refusal_does_not_fall_through_to_present_output(self):
        response = proposal(5)
        response["refusal"] = "cannot comply"
        self.rejected(response, "refusal")

    def test_unsupported_tool_does_not_execute(self):
        response = proposal(5)
        response["tool_call"] = {"name": "refund", "amount": 5}
        self.rejected(response, "unsupported_tool")

    def test_repeated_no_progress_terminates(self):
        store = Store()
        model = ScriptedModel([{"output": "Still thinking."}] * 100)
        outcome = Controller(store).run("task", model)
        self.assertEqual(outcome["status"], "no_progress")
        self.assertEqual(model.calls, 2)
        self.assertEqual(store.effects, [])
        self.assertEqual(store.tasks["task"].steps_left, 1)

    def test_one_valid_proposal_admitted(self):
        store, model = Store(), ScriptedModel([proposal(5)])
        outcome = Controller(store).run("task", model)
        self.assertEqual(outcome["status"], "accepted")
        self.assertEqual(store.effects, [{"task_id": "task", "kind": "propose", "amount": 5,
                                        "evidence_ids": ["A"], "explanation_amount": 5}])
        self.assertEqual(model.calls, 1)

    def test_repairable_candidate_is_freshly_validated(self):
        store, model = Store(), ScriptedModel([proposal(11), proposal(5)])
        outcome = Controller(store).run("task", model)
        self.assertEqual(outcome["status"], "accepted")
        self.assertEqual(model.calls, 2)
        self.assertEqual(len(store.effects), 1)
        events = store.tasks["task"].events
        self.assertEqual([e["attempt"] for e in events if e["event"] == "admitted"], [2])
        self.assertEqual([e["attempt"] for e in events if e["event"] == "validated"], [2])
        self.assertEqual([e["code"] for e in events if e["event"] == "rejected"], ["amount_out_of_range"])

    def test_unrepairable_candidate_stops_before_late_valid_answer(self):
        store = Store()
        model = ScriptedModel([proposal(11), proposal(12), proposal(13), proposal(5)])
        outcome = Controller(store).run("task", model)
        self.assertEqual(outcome["status"], "exhausted")
        self.assertEqual(model.calls, 3)
        self.assertEqual(len(model.responses), 1)
        self.assertEqual(store.effects, [])
        self.assertEqual(store.tasks["task"].steps_left, 0)
        self.assertEqual(store.tasks["task"].retries_left, 0)

    def test_retry_limit_is_independent_of_step_limit(self):
        store, model = Store(), ScriptedModel([proposal(11), proposal(12), proposal(5)])
        outcome = Controller(store, max_steps=10, max_retries=1).run("task", model)
        self.assertEqual(outcome["status"], "exhausted")
        self.assertEqual(model.calls, 2)
        self.assertEqual(store.tasks["task"].steps_left, 8)
        self.assertEqual(store.effects, [])

    def test_terminal_reentry_success_and_failure_reuse_outcome(self):
        for script in [[proposal(5)], [{"refusal": "stop"}]]:
            with self.subTest(script=script):
                store, model = Store(), ScriptedModel(script)
                original = Controller(store).run("task", model)
                before = deepcopy(store)
                new_model = ScriptedModel([proposal(10)])
                resumed = Controller(store, max_steps=999, max_retries=999).run("task", new_model)
                self.assertEqual(resumed, original)
                self.assertEqual(new_model.calls, 0)
                self.assertEqual(store, before)

    def test_running_checkpoint_preserves_remaining_budget(self):
        store = Store(tasks={"task": Checkpoint(steps_left=1, retries_left=0)})
        model = ScriptedModel([proposal(11), proposal(5)])
        Controller(store, max_steps=999, max_retries=999).run("task", model)
        self.assertEqual(model.calls, 1)
        self.assertEqual(store.tasks["task"].steps_left, 0)
        self.assertEqual(store.tasks["task"].retries_left, 0)
        self.assertEqual(store.effects, [])

    def test_new_work_requires_distinct_logical_task(self):
        store = Store()
        controller = Controller(store)
        controller.run("first", ScriptedModel([proposal(5)]))
        controller.run("second", ScriptedModel([proposal(6)]))
        self.assertEqual([e["task_id"] for e in store.effects], ["first", "second"])

    def test_unknown_variant_missing_extra_and_bad_types(self):
        for response, code in [
            ({"output": "[]"}, "object_required"),
            ({"output": '{"kind":"propose"}'}, "fields_mismatch"),
            (proposal(5, tool="refund"), "fields_mismatch"),
            ({"output": '{"kind":"wait","amount":5,"evidence_ids":["A"],"explanation_amount":5}'}, "unsupported_kind"),
            (proposal(True), "amount_type"),
            (proposal(5.0), "amount_type"),
            (proposal(5, explanation_amount=True), "explanation_type"),
            (proposal(5, evidence_ids=[5]), "evidence_type"),
            ({"output": '{"kind":"propose","amount":5,"amount":6,"evidence_ids":["A"],"explanation_amount":6}'}, "duplicate_json_key"),
            ({"output": "NaN"}, "nonfinite_json"),
        ]:
            with self.subTest(code=code):
                self.rejected(response, code)

    def test_integer_boundaries_with_explanation_and_observation(self):
        for amount in range(-2, 14):
            with self.subTest(amount=amount):
                store, model = Store(), ScriptedModel([proposal(amount)])
                outcome = Controller(store, max_retries=0).run("task", model)
                self.assertEqual(outcome["status"] == "accepted", 1 <= amount <= 10)
                self.assertEqual(len(store.effects), 1 if 1 <= amount <= 10 else 0)

    def test_observed_but_unused_id_is_not_added_to_receipt(self):
        store, model = Store(), ScriptedModel([proposal(5, evidence_ids=[])])
        # The requested contract allows an empty list: it requires a subset of A,
        # not mandatory citation or a claim-support relationship.
        Controller(store).run("task", model)
        self.assertEqual(store.effects[0]["evidence_ids"], [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
