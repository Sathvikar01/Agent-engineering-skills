I built and ran `test_model_boundary.py`, a standard-library-only fake with a scripted model response boundary, a deterministic admission function, and a bounded controller. It makes no provider calls. Its only effect is appending an admitted proposal to a local list; rejected responses never reach that list.

Run the tests and inspect the scripted traces from this outputs directory:

```powershell
python -m unittest -v test_model_boundary
python test_model_boundary.py --scenarios
```

Actual execution used Python 3.11.9. The unittest command exited 0 with **11 tests passing in 0.003 seconds**. The scenario command also exited 0 and recorded 14 scenario executions. `test-results.txt` contains the test output; `scenario-results.json` contains structured decisions, model call counts, and admitted effects; `scenario-log.txt` captures the scenario command's actual output.

The boundary accepts an envelope whose `output` is a JSON string. Transport absence, refusal, and scripted timeout are handled before admission. The parsed object must have exactly four fields, `kind="propose"`, integer `amount`, a list of string evidence IDs, and integer `explanation_amount`. It then checks three independent semantic predicates: amount is between 1 and 10 inclusive, every evidence ID belongs to observed `{A}`, and explanation amount equals amount. Python booleans are explicitly excluded from integer fields. Extra fields fail closed in this small strict contract.

| Executed scenario | Recorded decision | Admitted effects |
|---|---|---|
| Malformed JSON | `malformed_json` | 0 |
| Missing or null output | `missing_output` | 0 |
| Empty or whitespace output | `empty_output` | 0 |
| Valid-shaped amount 11 | `amount_out_of_range` | 0 |
| Invented evidence Z | `unobserved_evidence` | 0 |
| Contradictory explanation amount | `contradictory_explanation` | 0 |
| Scripted timeout | `timeout` | 0 |
| Refusal | Terminal `refused` | 0 |
| Unsupported tool kind | `unsupported_kind` | 0 |
| Same invalid answer repeated | `no_progress` after 2 calls | 0 |
| Valid proposal | `admitted` after 1 call | 1 |

The accepted example is:

```json
{"kind":"propose","amount":4,"evidence_ids":["A"],"explanation_amount":4}
```

The repeated no-progress fixture repeats amount 11 twice and includes a later valid proposal that the controller never calls. This checks early termination, not merely eventual exhaustion. Refusal also stops immediately despite remaining budget. Each boundary call consumes one step. A run permits at most `min(max_steps, max_retries + 1)` calls: two retries means at most three attempts. Separate tests verify the retry limit, independent step limit, and zero-step behavior. Another test supplies malformed JSON, timeout, then a valid amount 7; exactly one effect appears after three calls. Tests additionally exercise amount endpoints, missing/extra schema fields, wrong evidence types, and a changed observed set.

These are deterministic contract and integration checks around the delivered fake. No model grader, exact reasoning transcript, stochastic quality score, or inferred provider guarantee is involved. Put these checks in fast CI without a model API dependency. Adapter-envelope checks should run when provider integration changes, and model quality evaluations should run separately when prompts, models, or retrieval change. Those CI placements are recommendations; no existing pipeline was changed.

The coverage limits are explicit. The timeout is an injected exception, so these tests do not demonstrate real request deadlines, cancellation, streaming assembly, SDK error translation, or network behavior. The validator is local, not your production schema implementation. It does not test duplicate JSON keys, adversarial nesting, response-size limits, every malformed input, or arbitrary unsupported provider envelopes. Evidence membership proves the ID was observed, not that A supports the proposed amount; equality of two integer fields does not verify a natural-language explanation. No real tool dispatch, persistence, concurrent execution, crash recovery, cross-run budget persistence, token/cost limit, or provider reliability was exercised. A passing fake gives executable regression examples for this contract; follow-up work must run the same fixtures through the actual validator/controller and test the real adapter independently.
