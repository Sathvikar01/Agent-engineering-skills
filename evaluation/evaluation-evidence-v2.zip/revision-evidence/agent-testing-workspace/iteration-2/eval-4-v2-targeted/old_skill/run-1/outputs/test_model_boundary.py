"""Deterministic scripted model boundary and admission controller; no network."""
from dataclasses import dataclass
import json
import unittest


TIMEOUT = object()


class Rejected(Exception):
    def __init__(self, reason):
        super().__init__(reason)
        self.reason = reason


@dataclass(frozen=True)
class Proposal:
    amount: int
    evidence_ids: tuple
    explanation_amount: int


def decode_and_admit(envelope, observed):
    """Transport handling, shape validation, then independent semantic checks."""
    if not isinstance(envelope, dict):
        raise Rejected("invalid_envelope")
    if envelope.get("refusal"):
        raise Rejected("refusal")
    raw = envelope.get("output")
    if raw is None:
        raise Rejected("missing_output")
    if not isinstance(raw, str):
        raise Rejected("invalid_output_type")
    if not raw.strip():
        raise Rejected("empty_output")
    try:
        value = json.loads(raw)
    except (json.JSONDecodeError, ValueError):
        raise Rejected("malformed_json") from None
    if not isinstance(value, dict):
        raise Rejected("schema_object")
    expected = {"kind", "amount", "evidence_ids", "explanation_amount"}
    if set(value) != expected:
        raise Rejected("schema_fields")
    if value["kind"] != "propose":
        raise Rejected("unsupported_kind")
    if type(value["amount"]) is not int:
        raise Rejected("schema_amount_integer")
    if type(value["explanation_amount"]) is not int:
        raise Rejected("schema_explanation_integer")
    evidence = value["evidence_ids"]
    if not isinstance(evidence, list) or any(type(item) is not str for item in evidence):
        raise Rejected("schema_evidence")
    # These checks are semantic admission predicates, beyond JSON shape.
    if not 1 <= value["amount"] <= 10:
        raise Rejected("amount_out_of_range")
    if not set(evidence).issubset(observed):
        raise Rejected("unobserved_evidence")
    if value["explanation_amount"] != value["amount"]:
        raise Rejected("contradictory_explanation")
    return Proposal(value["amount"], tuple(evidence), value["explanation_amount"])


class ScriptedModel:
    def __init__(self, events):
        self.events = list(events)
        self.calls = 0

    def call(self):
        index = self.calls
        self.calls += 1
        event = self.events[index] if index < len(self.events) else {}
        if event is TIMEOUT:
            raise TimeoutError("scripted timeout")
        return event


class Controller:
    """Each call consumes one step; only an admitted Proposal reaches effects."""
    def __init__(self, model, *, observed=frozenset({"A"}), max_retries=2,
                 max_steps=5, no_progress_limit=2):
        if max_retries < 0 or max_steps < 0 or no_progress_limit < 1:
            raise ValueError("invalid controller budget")
        self.model = model
        self.observed = observed
        self.max_retries = max_retries
        self.max_steps = max_steps
        self.no_progress_limit = no_progress_limit
        self.trace = []
        self.effects = []

    def run(self):
        last_signature = None
        repeated = 0
        for step in range(min(self.max_steps, self.max_retries + 1)):
            envelope = None
            try:
                envelope = self.model.call()
                proposal = decode_and_admit(envelope, self.observed)
            except TimeoutError:
                reason = "timeout"
            except Rejected as rejected:
                reason = rejected.reason
            else:
                effect = {"kind": "propose", "amount": proposal.amount,
                          "evidence_ids": list(proposal.evidence_ids),
                          "explanation_amount": proposal.explanation_amount}
                self.effects.append(effect)
                self.trace.append({"step": step + 1, "decision": "admitted"})
                return {"status": "admitted", "steps": step + 1}
            self.trace.append({"step": step + 1, "decision": "rejected", "reason": reason})
            if reason == "refusal":
                return {"status": "refused", "steps": step + 1}
            signature = (reason, json.dumps(envelope, sort_keys=True))
            repeated = repeated + 1 if signature == last_signature else 1
            last_signature = signature
            if repeated >= self.no_progress_limit:
                return {"status": "no_progress", "steps": step + 1}
        limit = "step_limit" if self.max_steps < self.max_retries + 1 else "retry_limit"
        return {"status": limit, "steps": len(self.trace)}


def proposal(amount=4, evidence_ids=None, explanation_amount=None, kind="propose"):
    value = {"kind": kind, "amount": amount,
             "evidence_ids": ["A"] if evidence_ids is None else evidence_ids,
             "explanation_amount": amount if explanation_amount is None else explanation_amount}
    return {"output": json.dumps(value)}


SCENARIOS = [
    ("malformed JSON", {"output": "{broken"}, "malformed_json"),
    ("missing output", {}, "missing_output"),
    ("null output", {"output": None}, "missing_output"),
    ("empty output", {"output": ""}, "empty_output"),
    ("whitespace output", {"output": "   "}, "empty_output"),
    ("valid shape amount 11", proposal(11), "amount_out_of_range"),
    ("invented Z", proposal(evidence_ids=["Z"]), "unobserved_evidence"),
    ("contradictory explanation", proposal(4, explanation_amount=5), "contradictory_explanation"),
    ("timeout", TIMEOUT, "timeout"),
    ("refusal", {"refusal": "scripted refusal"}, "refusal"),
    ("unsupported tool", proposal(kind="tool"), "unsupported_kind"),
]


class BoundaryTests(unittest.TestCase):
    def test_each_requested_failure_has_zero_admitted_effects(self):
        for label, event, expected in SCENARIOS:
            with self.subTest(scenario=label):
                model = ScriptedModel([event, proposal()])
                controller = Controller(model, max_retries=0)
                result = controller.run()
                self.assertEqual(controller.effects, [])
                self.assertEqual(controller.trace[0]["reason"], expected)
                self.assertEqual(model.calls, 1)
                self.assertEqual(result["status"], "refused" if expected == "refusal" else "retry_limit")

    def test_valid_proposal_records_one_admitted_effect(self):
        model = ScriptedModel([proposal(), proposal(6)])
        controller = Controller(model)
        self.assertEqual(controller.run(), {"status": "admitted", "steps": 1})
        self.assertEqual(controller.effects, [{"kind": "propose", "amount": 4,
                          "evidence_ids": ["A"], "explanation_amount": 4}])
        self.assertEqual(model.calls, 1)

    def test_recoverable_failures_then_valid_proposal(self):
        model = ScriptedModel([{"output": "{"}, TIMEOUT, proposal(7)])
        controller = Controller(model, max_retries=2)
        self.assertEqual(controller.run(), {"status": "admitted", "steps": 3})
        self.assertEqual(len(controller.effects), 1)
        self.assertEqual(controller.effects[0]["amount"], 7)
        self.assertEqual([entry.get("reason") for entry in controller.trace],
                         ["malformed_json", "timeout", None])

    def test_repeated_no_progress_stops_without_effect_or_later_valid_call(self):
        model = ScriptedModel([proposal(11), proposal(11), proposal()])
        controller = Controller(model, max_retries=10, max_steps=10)
        self.assertEqual(controller.run(), {"status": "no_progress", "steps": 2})
        self.assertEqual(model.calls, 2)
        self.assertEqual(controller.effects, [])

    def test_retry_limit_bounds_distinct_bad_answers(self):
        model = ScriptedModel([{"output": "{"}, proposal(11), proposal(evidence_ids=["Z"]), proposal()])
        controller = Controller(model, max_retries=2, max_steps=10)
        self.assertEqual(controller.run(), {"status": "retry_limit", "steps": 3})
        self.assertEqual(model.calls, 3)
        self.assertEqual(controller.effects, [])

    def test_step_limit_bounds_calls_independently_of_retry_budget(self):
        model = ScriptedModel([{"output": "{"}, proposal(11), proposal()])
        controller = Controller(model, max_retries=10, max_steps=2)
        self.assertEqual(controller.run(), {"status": "step_limit", "steps": 2})
        self.assertEqual(model.calls, 2)
        self.assertEqual(controller.effects, [])

    def test_zero_steps_never_calls_model(self):
        model = ScriptedModel([proposal()])
        controller = Controller(model, max_steps=0)
        self.assertEqual(controller.run(), {"status": "step_limit", "steps": 0})
        self.assertEqual(model.calls, 0)
        self.assertEqual(controller.effects, [])

    def test_refusal_is_terminal_even_with_remaining_budget(self):
        model = ScriptedModel([{"refusal": "scripted refusal"}, proposal()])
        controller = Controller(model)
        self.assertEqual(controller.run(), {"status": "refused", "steps": 1})
        self.assertEqual(model.calls, 1)
        self.assertEqual(controller.effects, [])

    def test_amount_boundaries_and_python_bool_rejection(self):
        for amount in [1, 10]:
            with self.subTest(allowed=amount):
                self.assertEqual(decode_and_admit(proposal(amount), {"A"}).amount, amount)
        for amount, reason in [(0, "amount_out_of_range"), (-1, "amount_out_of_range"),
                               (True, "schema_amount_integer"), (1.0, "schema_amount_integer")]:
            with self.subTest(denied=amount):
                with self.assertRaises(Rejected) as context:
                    decode_and_admit(proposal(amount), {"A"})
                self.assertEqual(context.exception.reason, reason)

    def test_required_extra_and_wrong_type_schema_fields(self):
        valid = json.loads(proposal()["output"])
        variants = [([1, 2], "schema_object"),
                    ({key: value for key, value in valid.items() if key != "amount"}, "schema_fields"),
                    ({**valid, "extra": 1}, "schema_fields"),
                    ({**valid, "evidence_ids": "A"}, "schema_evidence"),
                    ({**valid, "evidence_ids": [1]}, "schema_evidence"),
                    ({**valid, "explanation_amount": True}, "schema_explanation_integer")]
        for value, reason in variants:
            with self.subTest(reason=reason, value=value):
                with self.assertRaises(Rejected) as context:
                    decode_and_admit({"output": json.dumps(value)}, {"A"})
                self.assertEqual(context.exception.reason, reason)

    def test_observed_set_is_used_at_admission(self):
        controller = Controller(ScriptedModel([proposal()]), observed=frozenset(), max_retries=0)
        controller.run()
        self.assertEqual(controller.effects, [])
        self.assertEqual(controller.trace[0]["reason"], "unobserved_evidence")


def write_scenario_log():
    results = []
    for label, event, _ in SCENARIOS:
        model = ScriptedModel([event])
        controller = Controller(model, max_retries=0)
        result = controller.run()
        results.append({"scenario": label, "result": result, "model_calls": model.calls,
                        "trace": controller.trace, "admitted_effects": controller.effects})
    for label, events, retries, steps in [
        ("repeated no-progress answer", [proposal(11), proposal(11), proposal()], 10, 10),
        ("valid proposal", [proposal()], 2, 5),
        ("retry then valid", [{"output": "{"}, TIMEOUT, proposal(7)], 2, 5),
    ]:
        model = ScriptedModel(events)
        controller = Controller(model, max_retries=retries, max_steps=steps)
        result = controller.run()
        results.append({"scenario": label, "result": result, "model_calls": model.calls,
                        "trace": controller.trace, "admitted_effects": controller.effects})
    with open("scenario-results.json", "w", encoding="utf-8") as handle:
        json.dump(results, handle, indent=2)
        handle.write("\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    if "--scenarios" in __import__("sys").argv:
        write_scenario_log()
    else:
        unittest.main(verbosity=2)
