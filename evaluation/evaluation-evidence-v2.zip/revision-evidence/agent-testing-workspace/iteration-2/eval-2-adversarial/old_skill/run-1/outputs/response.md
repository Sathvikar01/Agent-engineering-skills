I built and ran a local Python refund runtime and deterministic tests. The delivered `test_refund_runtime.py` uses only the Python standard library, has no model dependency, and produces effects only in an in-memory list. Its tests check arithmetic, authorization, persisted state, receipts, and recovery directly. No LLM decides whether those predicates are correct, and no reasoning transcript is asserted.

Run it from this outputs directory:

```powershell
python -m unittest -v test_refund_runtime
```

Actual execution used Python 3.11.9 and completed with exit code 0: **16 tests passed in 0.009 seconds**. The captured output is `test-results.txt`. This is measured local test evidence, not a proposed test suite or a claim about production behavior.

| Risk | Concrete executable evidence |
|---|---|
| Denial changes money or state | Snapshot comparisons cover insufficient balance, nonpositive amounts, wrong types, absent approval, changed approval payload, and missing retry key. They compare all store fields and effects and assert no provider commit call. |
| Duplicate retries create repeated refunds | Six retries through a newly constructed runtime return the original receipt, debit once, and leave one effect and one commit call. Changed payload with the same key is denied. |
| Unknown commit triggers unsafe replay | Lost response after commit reconciles the original receipt; unavailable reconciliation leaves the operation pending without another commit. A failure before commit replays only after the fake reports authoritative absence. |
| Approval outlives its authority | Exact expiration boundary and account revision changes reject the approval. Recovery after an uncommitted attempt also checks expiration again. |
| IDs cross tenant boundaries | Foreign account reads and writes are rejected, foreign approval IDs cannot authorize a local refund, and equal retry keys in different tenants remain independent. |
| Implementation always denies | Valid refund and full-balance boundary tests check the debit, recorded effect, and receipt. |

The integer denial test contains 51 deterministic boundary cases; another test exercises five wrong types, including Python booleans, which otherwise behave like integers. Those are subcases inside the reported 16 tests. The runtime stores approvals against the complete tenant/account/amount payload and account revision. Retry identity is `(tenant, key)`, and reusing that identity for a different payload fails closed. A matching completed retry returns its existing receipt even after the approval expires, because returning an already committed outcome creates no new effect.

The uncertain-commit tests deliberately separate an operation record from its receipt. The provider can commit and lose the response, or lose the connection before its local commit. The runtime preserves uncertainty and asks for reconciliation before sending again. The fixture keeps the store and provider across runtime reconstruction, which simulates restart recovery; it does not claim disk durability or process-crash recovery.

For CI, put this deterministic authority layer in the required fast check and run it regardless of model availability. Remove the model API condition from refund correctness tests. Keep provider availability failures separate from product failures; an unavailable required adapter test must be reported as unavailable or failed, not converted into a pass. Trajectory assertions should constrain allowed dependencies, admitted effects, and termination rather than exact wording or private reasoning. These are proposed CI changes: this task created test artifacts and did not modify an existing CI configuration.

Coverage limitations matter. This is an intentionally small illustrative runtime, not tests wired into your production validator/executor. Its provider supplies atomic commits, tenant-scoped idempotency, and authoritative lookup by construction; passing tests cannot establish those guarantees for your real provider. Follow-up integration work should reuse these scenarios against production admission, persistence, and the adapter in a resettable sandbox, including concurrent retries, transaction isolation, crashes before receipt persistence, partial writes, credential expiry, and error-envelope translation. No actual concurrency, network calls, model selection behavior, or durable database was exercised here. Arithmetic and permission correctness remain deterministic release gates; stochastic quality evaluations belong in a separate suite.
