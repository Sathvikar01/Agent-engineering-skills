"""Local deterministic authority/recovery tests; Python standard library only."""
from copy import deepcopy
from dataclasses import dataclass, field
import unittest


class Denied(Exception):
    pass


class UnknownCommit(Exception):
    pass


@dataclass
class Account:
    tenant: str
    balance: int
    revision: int = 0


@dataclass(frozen=True)
class Request:
    tenant: str
    account_id: str
    amount: int
    key: str
    approval_id: str

    def payload(self):
        return (self.tenant, self.account_id, self.amount)


@dataclass(frozen=True)
class Approval:
    payload: tuple
    revision: int
    expires_at: int


@dataclass
class Store:
    accounts: dict = field(default_factory=dict)
    approvals: dict = field(default_factory=dict)
    operations: dict = field(default_factory=dict)
    receipts: dict = field(default_factory=dict)


class FakeProvider:
    """Durable fake with atomic effects and authoritative lookup, not a real adapter."""

    def __init__(self, store):
        self.store = store
        self.committed = {}
        self.effects = []
        self.commit_calls = 0
        self.lookup_calls = 0
        self.next_outcome = "success"
        self.lookup_available = True

    def commit(self, request, expected_revision):
        self.commit_calls += 1
        op_key = (request.tenant, request.key)
        if op_key in self.committed:
            payload, receipt = self.committed[op_key]
            if payload != request.payload():
                raise Denied("idempotency key payload mismatch")
            return receipt
        outcome, self.next_outcome = self.next_outcome, "success"
        if outcome == "unknown_before":
            raise UnknownCommit("connection lost before local commit")
        account = self.store.accounts[request.account_id]
        if account.tenant != request.tenant:
            raise Denied("account unavailable")
        if account.revision != expected_revision or account.balance < request.amount:
            raise Denied("state changed before commit")
        account.balance -= request.amount
        account.revision += 1
        receipt = f"receipt-{len(self.effects) + 1}"
        self.effects.append((op_key, request.payload(), receipt))
        self.committed[op_key] = (request.payload(), receipt)
        if outcome == "unknown_after":
            raise UnknownCommit("local commit happened; response lost")
        return receipt

    def lookup(self, request):
        self.lookup_calls += 1
        if not self.lookup_available:
            return "unknown", None
        entry = self.committed.get((request.tenant, request.key))
        if entry is None:
            return "not_committed", None
        payload, receipt = entry
        if payload != request.payload():
            raise Denied("provider payload mismatch")
        return "committed", receipt


class Runtime:
    def __init__(self, store, provider):
        self.store = store
        self.provider = provider

    def read_balance(self, tenant, account_id):
        account = self.store.accounts.get(account_id)
        if account is None or account.tenant != tenant:
            raise Denied("account unavailable")
        return account.balance

    def validate(self, request, now):
        if type(request.amount) is not int or request.amount <= 0:
            raise Denied("amount must be positive integer units")
        if not request.key:
            raise Denied("missing idempotency key")
        self.read_balance(request.tenant, request.account_id)
        account = self.store.accounts[request.account_id]
        approval = self.store.approvals.get(request.approval_id)
        if approval is None or approval.payload != request.payload():
            raise Denied("approval does not authorize payload")
        if now >= approval.expires_at or approval.revision != account.revision:
            raise Denied("stale approval")
        if request.amount > account.balance:
            raise Denied("insufficient balance")
        return approval.revision

    def execute(self, request, now=0):
        op_key = (request.tenant, request.key)
        previous = self.store.operations.get(op_key)
        if previous:
            if previous["request"].payload() != request.payload():
                raise Denied("idempotency key payload mismatch")
            if op_key in self.store.receipts:
                return self.store.receipts[op_key]
            status, receipt = self.provider.lookup(request)
            if status == "unknown":
                return "pending"
            if status == "committed":
                self.store.receipts[op_key] = receipt
                previous["status"] = "committed"
                return receipt
            # Only authoritative absence in this fake permits replay. Revalidate
            # authority because the account or grant may have changed meanwhile.
        revision = self.validate(request, now)
        self.store.operations[op_key] = {"request": request, "status": "started"}
        try:
            receipt = self.provider.commit(request, revision)
        except UnknownCommit:
            self.store.operations[op_key]["status"] = "unknown"
            return "pending"
        except Denied:
            self.store.operations[op_key]["status"] = "denied"
            raise
        self.store.receipts[op_key] = receipt
        self.store.operations[op_key]["status"] = "committed"
        return receipt


class RefundTests(unittest.TestCase):
    def setUp(self):
        self.store = Store(accounts={"A": Account("tenant-a", 100),
                                     "B": Account("tenant-b", 80)})
        self.provider = FakeProvider(self.store)
        self.runtime = Runtime(self.store, self.provider)
        self.request = self.approve(20)

    def approve(self, amount, *, tenant="tenant-a", account_id="A",
                key="refund-1", approval_id="approval-1", expires_at=10):
        req = Request(tenant, account_id, amount, key, approval_id)
        self.store.approvals[approval_id] = Approval(
            req.payload(), self.store.accounts[account_id].revision, expires_at)
        return req

    def deny_without_effect(self, request, now=0):
        before_store = deepcopy(self.store)
        before_effects = deepcopy(self.provider.effects)
        before_commits = self.provider.commit_calls
        with self.assertRaises(Denied):
            self.runtime.execute(request, now)
        self.assertEqual(self.store, before_store)
        self.assertEqual(self.provider.effects, before_effects)
        self.assertEqual(self.provider.commit_calls, before_commits)

    def test_allowed_refund_persists_balance_effect_and_receipt(self):
        receipt = self.runtime.execute(self.request)
        self.assertEqual(self.store.accounts["A"].balance, 80)
        self.assertEqual(self.store.accounts["B"].balance, 80)
        self.assertEqual(len(self.provider.effects), 1)
        self.assertEqual(self.store.receipts[("tenant-a", "refund-1")], receipt)
        self.assertEqual(self.store.operations[("tenant-a", "refund-1")]["status"], "committed")

    def test_denied_integer_amounts_never_change_state(self):
        for amount in list(range(-25, 1)) + list(range(101, 126)):
            with self.subTest(amount=amount):
                self.deny_without_effect(self.approve(amount))

    def test_denied_wrong_types_never_change_state(self):
        for amount in [True, False, 1.0, "20", None]:
            with self.subTest(amount=repr(amount)):
                self.deny_without_effect(self.approve(amount))

    def test_unapproved_payload_and_missing_key_deny_without_effect(self):
        self.deny_without_effect(Request("tenant-a", "A", 21, "refund-1", "approval-1"))
        self.deny_without_effect(Request("tenant-a", "A", 20, "refund-1", "missing"))
        self.deny_without_effect(Request("tenant-a", "A", 20, "", "approval-1"))

    def test_duplicate_retry_is_one_effect_even_after_restart(self):
        receipt = self.runtime.execute(self.request)
        restarted = Runtime(self.store, self.provider)
        for _ in range(6):
            self.assertEqual(restarted.execute(self.request, now=99), receipt)
        self.assertEqual(self.provider.commit_calls, 1)
        self.assertEqual(len(self.provider.effects), 1)
        self.assertEqual(self.store.accounts["A"].balance, 80)

    def test_key_reuse_with_changed_payload_denies_without_effect(self):
        self.runtime.execute(self.request)
        changed = self.approve(21, approval_id="approval-2")
        self.deny_without_effect(changed)

    def test_unknown_after_commit_reconciles_without_replaying_effect(self):
        self.provider.next_outcome = "unknown_after"
        self.assertEqual(self.runtime.execute(self.request), "pending")
        self.assertEqual(self.store.receipts, {})
        self.assertEqual(self.store.accounts["A"].balance, 80)
        restarted = Runtime(self.store, self.provider)
        self.assertEqual(restarted.execute(self.request), "receipt-1")
        self.assertEqual(self.provider.lookup_calls, 1)
        self.assertEqual(self.provider.commit_calls, 1)
        self.assertEqual(len(self.provider.effects), 1)

    def test_unresolved_unknown_never_blindly_replays(self):
        self.provider.next_outcome = "unknown_after"
        self.assertEqual(self.runtime.execute(self.request), "pending")
        self.provider.lookup_available = False
        for _ in range(3):
            self.assertEqual(self.runtime.execute(self.request), "pending")
        self.assertEqual(self.provider.commit_calls, 1)
        self.assertEqual(len(self.provider.effects), 1)
        self.assertEqual(self.store.receipts, {})

    def test_unknown_before_commit_replays_only_after_authoritative_absence(self):
        self.provider.next_outcome = "unknown_before"
        self.assertEqual(self.runtime.execute(self.request), "pending")
        self.assertEqual(self.provider.effects, [])
        self.assertEqual(self.runtime.execute(self.request), "receipt-1")
        self.assertEqual(self.provider.lookup_calls, 1)
        self.assertEqual(self.provider.commit_calls, 2)
        self.assertEqual(len(self.provider.effects), 1)

    def test_expired_approval_denies_at_expiration_boundary(self):
        self.deny_without_effect(self.request, now=10)

    def test_account_revision_invalidates_approval(self):
        self.store.accounts["A"].revision += 1
        self.deny_without_effect(self.request)

    def test_recovery_after_no_commit_rechecks_expired_approval(self):
        self.provider.next_outcome = "unknown_before"
        self.runtime.execute(self.request)
        self.deny_without_effect(self.request, now=10)
        self.assertEqual(self.provider.lookup_calls, 1)
        self.assertEqual(self.provider.effects, [])

    def test_cross_tenant_account_id_cannot_read_or_write(self):
        before = deepcopy(self.store)
        with self.assertRaises(Denied):
            self.runtime.read_balance("tenant-a", "B")
        self.assertEqual(self.store, before)
        forged = self.approve(20, account_id="B")
        self.deny_without_effect(forged)

    def test_cross_tenant_approval_id_cannot_authorize(self):
        other = self.approve(20, tenant="tenant-b", account_id="B",
                             approval_id="other-approval")
        forged = Request("tenant-a", "A", 20, "refund-1", other.approval_id)
        self.deny_without_effect(forged)

    def test_identical_idempotency_keys_are_tenant_scoped(self):
        other = self.approve(20, tenant="tenant-b", account_id="B",
                             approval_id="other-approval")
        self.runtime.execute(self.request)
        self.runtime.execute(other)
        self.assertEqual(len(self.provider.effects), 2)
        self.assertEqual(self.store.accounts["A"].balance, 80)
        self.assertEqual(self.store.accounts["B"].balance, 60)

    def test_full_balance_boundary_is_allowed(self):
        req = self.approve(100)
        self.runtime.execute(req)
        self.assertEqual(self.store.accounts["A"].balance, 0)
        self.assertEqual(len(self.provider.effects), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
