"""Local refund runtime: proposals have no authority; admission owns predicates.

This fake is sequential and has no network or filesystem side effects. DurableState
is retained across Runtime instances to model restart, not real durable storage.
"""
from copy import deepcopy
from dataclasses import dataclass, field


class Denied(Exception):
    pass


class UnknownCommit(Exception):
    pass


class SimulatedCrash(Exception):
    pass


@dataclass(frozen=True)
class Request:
    tenant: str
    task_id: str
    account_id: str
    approval_id: str
    amount: int

    def fingerprint(self):
        return (self.tenant, self.task_id, self.account_id, self.approval_id, self.amount)


@dataclass
class Account:
    tenant: str
    refundable: int
    version: int = 0


@dataclass(frozen=True)
class Approval:
    tenant: str
    task_id: str
    account_id: str
    amount: int
    account_version: int
    expires_at: int


@dataclass
class Checkpoint:
    fingerprint: tuple
    state: str
    remaining_dispatches: int
    receipt: dict | None = None


@dataclass
class DurableState:
    accounts: dict = field(default_factory=dict)
    approvals: dict = field(default_factory=dict)
    tasks: dict = field(default_factory=dict)
    provider_records: dict = field(default_factory=dict)
    effects: list = field(default_factory=list)

    def snapshot(self):
        return deepcopy(self)


class FakeProvider:
    """An explicit local idempotency/reconciliation contract, not a provider claim."""
    def __init__(self, state):
        self.state = state
        self.dispatches = 0
        self.lookups = 0
        self.next_fault = None
        self.lookup_is_unknown = False

    def lookup(self, key):
        self.lookups += 1
        if self.lookup_is_unknown:
            return "unknown", None
        item = self.state.provider_records.get(key)
        return ("committed", item[1]) if item else ("absent", None)

    def dispatch(self, key, request):
        self.dispatches += 1
        prior = self.state.provider_records.get(key)
        if prior:
            if prior[0] != request.fingerprint():
                raise Denied("idempotency key payload changed")
            return prior[1]
        fault, self.next_fault = self.next_fault, None
        if fault == "unknown_before":
            raise UnknownCommit("response unavailable before fake commit")
        account = self.state.accounts[request.account_id]
        if account.refundable < request.amount:
            raise Denied("executor balance changed")
        account.refundable -= request.amount
        account.version += 1
        receipt = {"tenant": request.tenant, "task_id": request.task_id,
                   "amount": request.amount, "status": "committed"}
        self.state.effects.append(receipt)
        self.state.provider_records[key] = (request.fingerprint(), receipt)
        if fault == "unknown_after":
            raise UnknownCommit("fake committed but response lost")
        if fault == "crash_after":
            raise SimulatedCrash("fake committed before receipt persistence")
        return receipt


class Runtime:
    def __init__(self, state, provider, clock, dispatch_budget=2):
        self.state, self.provider, self.clock = state, provider, clock
        self.dispatch_budget = dispatch_budget

    def admit(self, tenant, request):
        if request.tenant != tenant:
            raise Denied("caller/request tenant mismatch")
        account = self.state.accounts.get(request.account_id)
        if account is None or account.tenant != tenant:
            raise Denied("account inaccessible")
        approval = self.state.approvals.get(request.approval_id)
        if approval is None or approval.tenant != tenant:
            raise Denied("approval inaccessible")
        if type(request.amount) is not int or request.amount < 1:
            raise Denied("positive integer amount required")
        if (approval.task_id, approval.account_id, approval.amount) != (
                request.task_id, request.account_id, request.amount):
            raise Denied("approval does not authorize payload")
        if approval.expires_at <= self.clock():
            raise Denied("approval expired")
        if approval.account_version != account.version:
            raise Denied("approval is stale")
        if account.refundable < request.amount:
            raise Denied("insufficient refundable balance")

    def execute(self, tenant, request, crash_before_dispatch=False):
        if request.tenant != tenant:
            raise Denied("caller/request tenant mismatch")
        # Python considers 5, 5.0 and True/1 equal in tuple comparisons. Check
        # schema predicates before even reusing a completed logical task.
        if type(request.amount) is not int or request.amount < 1:
            raise Denied("positive integer amount required")
        key = (tenant, request.task_id)
        checkpoint = self.state.tasks.get(key)
        if checkpoint:
            if checkpoint.fingerprint != request.fingerprint():
                raise Denied("logical task payload changed")
            if checkpoint.state == "terminal":
                return checkpoint.receipt
            if checkpoint.state in ("unknown", "dispatching"):
                status, receipt = self.provider.lookup(key)
                if status == "unknown":
                    checkpoint.state = "unknown"
                    return None
                if status == "committed":
                    checkpoint.state, checkpoint.receipt = "terminal", receipt
                    return receipt
                # Only this fake's authoritative ABSENT permits another dispatch.
        self.admit(tenant, request)
        if checkpoint is None:
            checkpoint = Checkpoint(request.fingerprint(), "ready", self.dispatch_budget)
            self.state.tasks[key] = checkpoint
        if checkpoint.remaining_dispatches <= 0:
            raise Denied("dispatch budget exhausted")
        checkpoint.remaining_dispatches -= 1
        checkpoint.state = "dispatching"
        if crash_before_dispatch:
            raise SimulatedCrash("checkpoint stored before dispatch")
        try:
            receipt = self.provider.dispatch(key, request)
        except UnknownCommit:
            checkpoint.state = "unknown"
            return None
        checkpoint.state, checkpoint.receipt = "terminal", receipt
        return receipt
