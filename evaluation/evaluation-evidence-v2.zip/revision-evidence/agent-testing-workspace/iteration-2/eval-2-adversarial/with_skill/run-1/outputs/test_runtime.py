import unittest
from dataclasses import replace
from runtime import (Account, Approval, Denied, DurableState, FakeProvider,
                     Request, Runtime, SimulatedCrash)


class RefundTests(unittest.TestCase):
    def setUp(self):
        self.now = 10
        self.state = DurableState(
            accounts={"acct-a": Account("A", 20), "acct-b": Account("B", 20)},
            approvals={"grant-a": Approval("A", "refund-1", "acct-a", 5, 0, 20),
                       "grant-b": Approval("B", "refund-1", "acct-b", 5, 0, 20)})
        self.provider = FakeProvider(self.state)
        self.runtime = Runtime(self.state, self.provider, lambda: self.now)
        self.request = Request("A", "refund-1", "acct-a", "grant-a", 5)

    def assert_denial_no_effect(self, request, tenant="A"):
        before = self.state.snapshot()
        dispatches = self.provider.dispatches
        with self.assertRaises(Denied):
            self.runtime.execute(tenant, request)
        self.assertEqual(self.state, before)
        self.assertEqual(self.provider.dispatches, dispatches)

    def test_allow_commits_exact_balance_and_receipt(self):
        receipt = self.runtime.execute("A", self.request)
        self.assertEqual(self.state.accounts["acct-a"].refundable, 15)
        self.assertEqual(self.state.accounts["acct-a"].version, 1)
        self.assertEqual(self.state.accounts["acct-b"].refundable, 20)
        self.assertEqual(self.state.effects, [receipt])
        self.assertEqual(receipt["amount"], 5)
        self.assertEqual(self.state.tasks[("A", "refund-1")].state, "terminal")

    def test_insufficient_balance_denial(self):
        self.state.accounts["acct-a"].refundable = 4
        self.assert_denial_no_effect(self.request)

    def test_invalid_amounts_and_changed_payload_denied(self):
        for amount in [-1, 0, True, 1.5, "5", 6]:
            with self.subTest(amount=amount):
                self.assert_denial_no_effect(replace(self.request, amount=amount))

    def test_duplicate_retry_and_terminal_restart_reuse_receipt(self):
        receipt = self.runtime.execute("A", self.request)
        before = self.state.snapshot()
        self.now = 100  # Expiry cannot cause terminal work to dispatch again.
        for _ in range(10):
            restarted = Runtime(self.state, self.provider, lambda: self.now, 999)
            self.assertEqual(restarted.execute("A", self.request), receipt)
        self.assertEqual(self.state, before)
        self.assertEqual(self.provider.dispatches, 1)

    def test_reused_task_with_different_payload_denied(self):
        self.runtime.execute("A", self.request)
        self.assert_denial_no_effect(replace(self.request, amount=6))

    def test_terminal_reentry_still_rejects_equal_float_amount(self):
        self.runtime.execute("A", self.request)
        self.assert_denial_no_effect(replace(self.request, amount=5.0))

    def test_unknown_after_commit_reconciles_without_replay(self):
        self.provider.next_fault = "unknown_after"
        self.assertIsNone(self.runtime.execute("A", self.request))
        self.assertEqual(len(self.state.effects), 1)
        restarted = Runtime(self.state, self.provider, lambda: self.now)
        receipt = restarted.execute("A", self.request)
        self.assertEqual(receipt["status"], "committed")
        self.assertEqual(self.provider.lookups, 1)
        self.assertEqual(self.provider.dispatches, 1)
        self.assertEqual(self.state.accounts["acct-a"].refundable, 15)

    def test_unknown_stays_unknown_without_blind_retry(self):
        self.provider.next_fault = "unknown_before"
        self.provider.lookup_is_unknown = True
        self.assertIsNone(self.runtime.execute("A", self.request))
        remaining = self.state.tasks[("A", "refund-1")].remaining_dispatches
        for _ in range(4):
            restarted = Runtime(self.state, self.provider, lambda: self.now, 999)
            self.assertIsNone(restarted.execute("A", self.request))
        self.assertEqual(self.provider.dispatches, 1)
        self.assertEqual(self.state.effects, [])
        self.assertEqual(self.state.accounts["acct-a"].refundable, 20)
        self.assertEqual(self.state.tasks[("A", "refund-1")].remaining_dispatches, remaining)

    def test_authoritative_absence_revalidates_and_retries_same_key(self):
        self.provider.next_fault = "unknown_before"
        self.assertIsNone(self.runtime.execute("A", self.request))
        self.runtime.execute("A", self.request)
        self.assertEqual(self.provider.dispatches, 2)
        self.assertEqual(len(self.state.effects), 1)
        self.assertEqual(len(self.state.provider_records), 1)
        self.assertEqual(self.state.tasks[("A", "refund-1")].remaining_dispatches, 0)

    def test_retry_budget_survives_restart(self):
        self.provider.next_fault = "unknown_before"
        self.runtime.execute("A", self.request)
        self.provider.next_fault = "unknown_before"
        self.runtime.execute("A", self.request)
        restarted = Runtime(self.state, self.provider, lambda: self.now, 999)
        with self.assertRaises(Denied):
            restarted.execute("A", self.request)
        self.assertEqual(self.provider.dispatches, 2)
        self.assertEqual(self.state.effects, [])
        self.assertEqual(self.state.tasks[("A", "refund-1")].remaining_dispatches, 0)

    def test_crash_after_commit_before_receipt_reconciles(self):
        self.provider.next_fault = "crash_after"
        with self.assertRaises(SimulatedCrash):
            self.runtime.execute("A", self.request)
        self.assertEqual(self.state.tasks[("A", "refund-1")].state, "dispatching")
        restarted = Runtime(self.state, self.provider, lambda: self.now)
        self.assertEqual(restarted.execute("A", self.request)["status"], "committed")
        self.assertEqual(self.provider.dispatches, 1)
        self.assertEqual(len(self.state.effects), 1)

    def test_crash_before_dispatch_reconciles_absence(self):
        with self.assertRaises(SimulatedCrash):
            self.runtime.execute("A", self.request, crash_before_dispatch=True)
        self.assertEqual(self.provider.dispatches, 0)
        self.assertEqual(self.state.effects, [])
        self.runtime.execute("A", self.request)
        self.assertEqual(self.provider.lookups, 1)
        self.assertEqual(self.provider.dispatches, 1)
        self.assertEqual(len(self.state.effects), 1)

    def test_expired_approval_denied_at_exact_boundary(self):
        self.now = 20
        self.assert_denial_no_effect(self.request)

    def test_stale_resource_version_denied(self):
        self.state.accounts["acct-a"].version += 1
        self.assert_denial_no_effect(self.request)

    def test_unknown_precommit_retry_requires_fresh_approval(self):
        self.provider.next_fault = "unknown_before"
        self.runtime.execute("A", self.request)
        self.now = 20
        self.assert_denial_no_effect(self.request)
        self.assertEqual(self.state.effects, [])

    def test_cross_tenant_account_approval_and_request_ids_denied(self):
        for request in [replace(self.request, account_id="acct-b"),
                        replace(self.request, approval_id="grant-b"),
                        replace(self.request, tenant="B"),
                        replace(self.request, account_id="invented"),
                        replace(self.request, approval_id="invented")]:
            with self.subTest(request=request):
                self.assert_denial_no_effect(request)

    def test_same_logical_id_across_tenants_is_namespaced(self):
        self.runtime.execute("A", self.request)
        request_b = Request("B", "refund-1", "acct-b", "grant-b", 5)
        self.runtime.execute("B", request_b)
        self.assertEqual(set(self.state.tasks), {("A", "refund-1"), ("B", "refund-1")})
        self.assertEqual([e["tenant"] for e in self.state.effects], ["A", "B"])
        self.assertEqual(self.provider.dispatches, 2)

    def test_provider_rejects_key_payload_collision(self):
        self.runtime.execute("A", self.request)
        before = self.state.snapshot()
        with self.assertRaises(Denied):
            self.provider.dispatch(("A", "refund-1"), replace(self.request, amount=6))
        self.assertEqual(self.state, before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
