I built and ran a standalone local refund runtime with deterministic admission, execution, checkpoints, and reconciliation. The final run passed **18 tests** using **Python 3.11.9**, with exit code **0**. The runner reported `Ran 18 tests in 0.004s`; that is this local test run's elapsed time, not a performance guarantee. No model API, payment service, or network request was used.

The runnable implementation is [runtime.py](~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-testing-workspace/iteration-2/eval-2-adversarial/with_skill/run-1/outputs/runtime.py); the executable checks are [test_runtime.py](~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-testing-workspace/iteration-2/eval-2-adversarial/with_skill/run-1/outputs/test_runtime.py). Run the following command from their directory:

```powershell
python -m unittest -v test_runtime
```

The captured final output is [actual-test.log](~/Documents/Codex/2026-10-03/i-want-you-to-build-a/work/v2/agent-testing-workspace/iteration-2/eval-2-adversarial/with_skill/run-1/outputs/actual-test.log). There were no skips or unavailable dependencies. An earlier run passed 17 tests; inspection then identified Python's integer/float tuple equality as a terminal-replay input edge. I added an early integer check and a regression test before the final run.

| Invariant | Executed evidence |
|---|---|
| Denial produces no effect | Insufficient funds, invalid amounts, expired/mismatched approvals and inaccessible IDs compare complete business/checkpoint/provider state snapshots and dispatch counts before and after rejection. |
| Duplicate retries do not refund twice | Ten terminal retries across new runtime instances return the saved receipt, leave state unchanged, and keep dispatch count at one, even after approval expiry. Changed payloads and equal-valued floating amounts are rejected. |
| Unknown commit is reconciled before replay | Lost post-commit response and crash before receipt persistence recover through lookup, preserving one effect. An unresolved lookup never dispatches again. Authoritative absence allows a bounded retry with the same key and fresh admission. |
| Approval remains current | Expiry at the exact boundary, changed resource version, and expiry between uncertain attempt and retry are denied. |
| Tenant IDs remain scoped | Foreign account/approval IDs, caller/request tenant mismatch and invented IDs fail closed. Identical logical task IDs in different tenants create distinct keys and effects. |
| Resume cannot replenish budget | Restart with a larger constructor budget preserves the checkpoint's depleted dispatch allowance. |

Admission owns the arithmetic and authorization predicates. Approval binds tenant, logical task, account, amount, account version, and expiry. Execution uses a tenant-scoped logical key and stores the exact request fingerprint. The fake provider also rejects a reused key with a changed payload. The allowed path asserts the exact balance decrement, version increment, committed receipt, terminal checkpoint and unaffected second tenant; error text alone is never the outcome oracle.

For your CI, replace LLM judgments of balances and exact reasoning-transcript assertions with these invariant checks at the production validator/executor seam. Assert permitted call dependencies, admitted effects and terminal outcomes where trajectories matter. Put deterministic authority, schema and refund tests in the fast required job with no provider credentials. A model API outage must not skip them or convert an unavailable stochastic evaluation into a pass. Run separate model evaluations when prompts/models change; explicitly report infrastructure failure there.

This is executed evidence for the local fake, not verification of an existing production implementation. `DurableState` survives runtime-object recreation in memory; it does not establish database durability, transactional isolation, crash consistency across processes, concurrent approval behavior, or a real payment provider's idempotency and authoritative-absence semantics. The fake assumes serialized admission and dispatch. Those guarantees need production adapter contract tests in a resettable sandbox, database crash/race injection, and credential/grant lifecycle coverage. No such checks were executed here. Before applying this pattern to real refunds, retain the tested denial and reconciliation assertions while replacing the fake interfaces with the actual controller and provider adapter.
