Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$caseRows = @()

function New-MockState {
    return @{ emailCount = 0; paymentCount = 0; spent = 0; ledger = @{}; admissionCount = 0 }
}

function Invoke-UnsafePath($Scenario, $State) {
    switch ($Scenario) {
        'post_send_filter' { $State.emailCount++; return 'blocked_after_send' }
        'policy_outage' { $State.paymentCount++; $State.spent += 25; return 'allowed_on_checker_error' }
        'reviewer_over_limit' { $State.paymentCount++; $State.spent += 150; return 'reviewer_approved' }
        'retry_bypass' { $State.paymentCount++; $State.spent += 150; return 'retry_sent_without_admission' }
    }
}

function Invoke-AdmittedPath($Proposal, $State) {
    $State.admissionCount++
    # This is a fake boundary, without email/network/payment adapters.
    if ($Proposal.action -notin @('email', 'payment')) { return 'deny_unsupported' }
    if (-not $Proposal.permission) { return 'deny_permission' }
    if ($Proposal.action -eq 'payment' -and ($Proposal.amount -le 0 -or $Proposal.amount -gt 100)) { return 'deny_amount' }
    if ($Proposal.action -eq 'email' -and -not $Proposal.contentPass) { return 'deny_content_before_send' }
    if ($Proposal.policyState -ne 'available') { return 'abstain_checker_unavailable' }
    if ($Proposal.policyDecision -eq 'deny') { return 'deny_policy' }
    if ($Proposal.policyDecision -eq 'approval_required' -and (-not $Proposal.approvalValid)) { return 'wait_for_approval' }
    if ($Proposal.policyDecision -notin @('allow', 'approval_required')) { return 'deny_unknown_policy' }
    if (($State.spent + $Proposal.amount) -gt 200) { return 'deny_run_budget' }
    if ($State.ledger.ContainsKey($Proposal.key)) { return 'replay_recorded_result' }
    $State.ledger[$Proposal.key] = 'fake_effect_recorded'
    if ($Proposal.action -eq 'email') { $State.emailCount++ } else { $State.paymentCount++; $State.spent += $Proposal.amount }
    return 'fake_effect_recorded'
}

function New-Proposal($Action, $Amount, $ContentPass, $PolicyState, $PolicyDecision, $Permission, $ApprovalValid, $Key) {
    return @{ action = $Action; amount = $Amount; contentPass = $ContentPass; policyState = $PolicyState; policyDecision = $PolicyDecision; permission = $Permission; approvalValid = $ApprovalValid; key = $Key }
}

function Add-Check($Name, $Actual, $Expected, $Effects, $ExpectedEffects) {
    $passed = ($Actual -eq $Expected -and $Effects -eq $ExpectedEffects)
    $script:caseRows += [pscustomobject]@{ name = $Name; status = $Actual; expected = $Expected; fake_effects = $Effects; expected_fake_effects = $ExpectedEffects; passed = $passed }
    if (-not $passed) { throw "Failed: $Name (status=$Actual, effects=$Effects)" }
}

$scenarioRows = @(
    @{ name = 'post_send_filter'; proposal = (New-Proposal 'email' 0 $false 'available' 'allow' $true $true 'email-1'); expected = 'deny_content_before_send' },
    @{ name = 'policy_outage'; proposal = (New-Proposal 'payment' 25 $true 'error' 'allow' $true $true 'payment-2'); expected = 'abstain_checker_unavailable' },
    @{ name = 'reviewer_over_limit'; proposal = (New-Proposal 'payment' 150 $true 'available' 'allow' $true $true 'payment-3'); expected = 'deny_amount' },
    @{ name = 'retry_bypass'; proposal = (New-Proposal 'payment' 150 $true 'available' 'allow' $true $true 'payment-4'); expected = 'deny_amount' }
)
foreach ($scenarioRow in $scenarioRows) {
    $unsafeState = New-MockState
    $unsafeStatus = Invoke-UnsafePath $scenarioRow.name $unsafeState
    Add-Check ('unsafe_' + $scenarioRow.name) $unsafeStatus $unsafeStatus ($unsafeState.emailCount + $unsafeState.paymentCount) 1
    $safeState = New-MockState
    $safeStatus = Invoke-AdmittedPath $scenarioRow.proposal $safeState
    Add-Check ('corrected_' + $scenarioRow.name) $safeStatus $scenarioRow.expected ($safeState.emailCount + $safeState.paymentCount) 0
}
$goodState = New-MockState
$goodProposal = New-Proposal 'payment' 60 $true 'available' 'allow' $true $true 'idempotent-5'
Add-Check 'permitted_candidate' (Invoke-AdmittedPath $goodProposal $goodState) 'fake_effect_recorded' $goodState.paymentCount 1
Add-Check 'retry_duplicate' (Invoke-AdmittedPath $goodProposal $goodState) 'replay_recorded_result' $goodState.paymentCount 1
$goodProposal.permission = $false
Add-Check 'resume_permission_revoked' (Invoke-AdmittedPath $goodProposal $goodState) 'deny_permission' $goodState.paymentCount 1
if ($goodState.admissionCount -ne 3) { throw 'Every retry/resume must enter admission.' }
$approvalState = New-MockState
$approvalProposal = New-Proposal 'payment' 60 $true 'available' 'approval_required' $true $false 'approval-6'
Add-Check 'expired_or_mismatched_approval' (Invoke-AdmittedPath $approvalProposal $approvalState) 'wait_for_approval' $approvalState.paymentCount 0
[pscustomobject]@{ fake_only = $true; external_adapters_present = $false; check_count = $caseRows.Count; results = $caseRows } | ConvertTo-Json -Depth 8
