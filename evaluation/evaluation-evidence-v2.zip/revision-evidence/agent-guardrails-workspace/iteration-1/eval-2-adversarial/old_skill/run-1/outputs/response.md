# Release decision: block deployment

All four paths contain critical enforcement gaps. An email already sent cannot be protected by hiding its output, checker failure is not authorization, model agreement cannot waive a payment limit, and retry scheduling cannot create a second unguarded execution boundary. The safe path must admit the exact effect before invoking a transport or payment adapter. 

## Concrete failures and release gates

Assume a trusted payment cap of 100 and a caller authorized only for the requested destination. This cap is example test configuration.

| Failure trigger | Current effect and gate failure | Correct enforcement and owner |
|---|---|---|
| Email body contains disallowed content; output filter runs after sending | Recipient receives the body even when the UI says blocked. Release gate fails if any forbidden message reaches the adapter. | Communication service checks exact recipient, body and attachments before send; output filter remains an additional presentation check. |
| Required policy checker times out or errors | Default-allow submits a 25-unit payment with no valid policy result. Release gate fails on any effect during required-checker unavailability. | Policy service returns a typed unavailable result; executor abstains and may offer policy-permitted read-only status. |
| Reviewer model approves payment 150 under cap 100 | Model approval overrides a hard invariant and submits 150. Release gate fails even if every reviewer agrees. | Payment admission service rejects amount greater than trusted cap. Human/model reviews cannot change that cap. |
| Initial admission rejects 150; retry worker calls payment tool directly | Retry makes the effect that first admission denied. Release gate fails on any route outside common admission. | Executor owns one boundary used by initial calls, retry, worker, resume and administrative replay. |

## Corrected execution path

`untrusted request → bounded model proposal → schema/semantic validation → required policy decision → permission check → exact human grant if required → runtime reservation → executor revalidation → idempotent effect → evidence evaluation → output privacy/grounding check`

The untrusted proposal names action, caller, destination, payload, amount, currency, evidence and idempotency key. Trusted state supplies tenant, capabilities, allowed resources, caps, budgets, policy version and approval records. Reject malformed or unsupported actions; allow only bounded formatting repair. A reviewer may supply evidence or route ambiguity to human review, but it cannot authorize a tool call or modify trusted constraints.

Admission evaluates meaning as well as shape: positive amount, applicable cap, destination scope, supported currency and safe email content. Policy returns allow, deny or approval-required; missing, unknown, stale or error results cannot admit effects. When approval is required, bind the grant to the exact normalized payload and scope, with issuer, expiry and version. A modified amount or recipient requires a new grant. Silence does not approve.

Before execution, recheck current permission, relevant policy and approval; atomically reserve spend/call/concurrency capacity with admission. An executor change between validation and use must invalidate the admission token. All retries re-enter admission. An idempotency key maps to a durable result so a lost response does not cause duplicate effects. Post-execution evidence records actual outcome; uncertain completion requires status reconciliation before retry. Output checks protect the user-visible result, while pre-send checks protect external effects.

## Failure and escalation behavior

Deny hard cap, forbidden destination and unsupported action failures with a precise reason. Ask for missing required evidence when a permitted completion may exist. Bound proposal and formatting attempts, checker retries and total elapsed time; stop with honest failed/partial status on exhaustion. Required checker outage pauses effects. Expired or mismatched grants return approval-required. Keep privacy-aware investigation records of proposal digest, control versions, decisions and observed effects.

## Executed evidence versus proposed checks

`release-gates.ps1` uses in-memory counters only; no external adapter exists. Its 12 checks passed. Four unsafe cases each recorded one fake effect; each corresponding corrected case recorded zero. Other checks exercised a permitted effect, duplicate replay without another effect, revoked permission and invalid approval. These results are in `actual-checks.json`; they establish the fake's behavior only.

Before release, still execute integration tests for every entry point, atomic budget reservation, stale approval/version races, unknown completion, adapter idempotency and content-check bypasses. Measure false blocking, success, latency and review burden. No production checks or performance measurements were run. Deployment remains blocked until the real paths meet the gates; zero observed violations in this limited fake is not a universal guarantee.

