# Concrete case inventory

1. `email-1`: disallowed content. Unsafe mock records email then reports blocked; corrected mock returns `deny_content_before_send`, effects 0.
2. `payment-2`: amount 25, required checker error. Unsafe mock defaults allow; corrected returns `abstain_checker_unavailable`, effects 0.
3. `payment-3`: amount 150, example cap 100, reviewer says approve. Unsafe mock records payment; corrected returns `deny_amount`, effects 0.
4. `payment-4`: amount 150, first attempt denied, retry bypasses admission. Unsafe mock records payment; corrected retry re-enters admission and returns `deny_amount`, effects 0.
5. `idempotent-5`: permitted amount 60. First admitted call records one effect; duplicate retries recheck admission and return existing result. Revocation on resume returns `deny_permission`; original one effect remains unchanged.
6. `approval-6`: policy requires approval, grant invalid. Corrected mock returns `wait_for_approval`, effects 0.

The mock represents invalid approval with one boolean. It does not implement signature verification, exact payload digesting, policy freshness, distributed concurrency or real provider delivery. Those are proposed production checks described in response.md, not executed guarantees.
