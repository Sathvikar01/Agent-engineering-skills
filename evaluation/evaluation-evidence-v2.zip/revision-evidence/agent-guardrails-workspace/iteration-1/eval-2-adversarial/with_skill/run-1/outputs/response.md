These four failures block release because the application’s claimed safeguards do not control the effect boundary. A blocked response after an email was sent still leaves a sent email; a reviewer’s agreement is evidence about a proposal, not authority to spend. The corrected design routes every effect through one trusted admission path and makes the executor enforce that path.

| Trigger | Concrete release failure | Required corrected behavior |
|---|---|---|
| Email contains protected content; filter runs after send | Provider accepts email; UI says “blocked”; recipient already has it | Inspect the actual recipient, attachments and rendered body before sending; rejected content produces zero sends |
| Required policy checker times out | Missing decision becomes allow; email/payment proceeds | Produce `required_checker_unavailable`; preserve draft and stop effects until a fresh decision is available |
| Reviewer approves an over-limit payment | Reviewer approval becomes the effective spending rule | Deterministic amount/currency/account/cumulative-limit checks reject it regardless of reviewer score |
| Retry invokes the provider directly | First attempt is rejected; retry executes the same invalid proposal | Initial, retry, worker and resume all enter the same gate; revalidate current authority and limits |

Use this execution path: untrusted input → model proposal → deterministic schema and semantic validation → pre-effect privacy/grounding checks → trusted policy decision → resource-scoped permission check → exact human grant if required → atomic budget reservation and executor admission → idempotent provider call → reconciliation and factual result. Critical checks belong inside the executor’s admission boundary; earlier checks improve feedback but cannot grant authority. Evaluate every mandatory predicate even when another model approves. Pin the immutable payload used for checks and execution; late body, amount or destination changes create a new candidate.

The orchestration owner bounds proposal repair and tool attempts. The validation owner checks supported action, required fields, positive exact money units, currencies, installment totals and business limits. The policy owner returns explicit allow, deny or approval-required decisions with rule version and freshness. The executor owns least-privilege capabilities, current permissions, atomic limits and idempotency. The approval service issues a bounded grant tied to actor, payload hash, destination, amount, policy version and expiry. An approval cannot waive a hard limit unless trusted policy explicitly supports a separate authorized exception process. A classifier or reviewer can flag uncertain content and route review; its false negatives and false positives require measurement.

| Failure | Repair or escalation |
|---|---|
| Malformed or unsupported candidate | Reject candidate; bounded reconstruction only within supported actions and unchanged constraints |
| Removable protected content | Construct a safe draft, rerun all applicable checks, and obtain new approval when its scope changes |
| Amount above a hard limit | Reject; do not split into repeated calls that evade a cumulative cap |
| Required checker outage | Pause effects; permit policy-approved read-only work; bounded backoff never changes outage to allow |
| Stale, expired or missing grant | Keep proposed action pending; request fresh exact approval |
| Provider timeout after possible acceptance | Reconcile status by operation ID; retry only through admission and idempotency |
| Exhausted time/call/spend budget | Cancel or stop with honest partial status; no hidden continuation |

The local fake reproduces the four unsafe compositions as observable in-memory effects and exercises the corrected gates, every entry label, permission denial, bounded attempts and one allowed email with duplicate suppression. `release_gate_fake.ps1` contains no network or provider calls. All 10 checks passed after repairing an empty-pipeline `Count` bug in the harness. Its checks measure fixture state, not response wording. Actual outcomes are recorded separately in `actual-checks.json`; no production violation rate, model quality, latency or cost is claimed.

Production release remains blocked until integration tests demonstrate zero forbidden effects across bypass routes, stale grants, service outage, budget races and uncertain provider outcomes, while legitimate authorized actions still succeed. These are proposed checks, not executed evidence. Add ambiguous-content datasets, poisoned inputs, policy-version changes and cumulative spending tests. Measure violations, legitimate task completion, safe abstention, false blocking, review burden and added latency/cost. Sandbox ablation may remove optional reviewers while keeping mandatory policy and permission boundaries. Zero observed critical violations is necessary evidence for a scoped release decision, not a universal guarantee.
