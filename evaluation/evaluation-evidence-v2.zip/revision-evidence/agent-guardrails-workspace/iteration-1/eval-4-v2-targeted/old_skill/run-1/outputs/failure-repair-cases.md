# Failure and repair cases

- Required total: trusted integer 100. Candidate [40,40] returns deny_total. Independently supported and permitted [40,60] passes the sum check and can become ready after all remaining gates.
- New candidate [40,70] remains invalid and returns deny_total. A semantic repair receives no exemption.
- [40,60] with revoked permission returns deny_permission even though its sum is correct.
- [40,60] unsupported by product configuration returns deny_unsupported.
- Candidate set {[40,40] permitted, [40,60] not permitted} yields stop_no_authorized_valid_candidate; zero live effects.
- [40,60] during required checker timeout returns pause_checker_unavailable; unknown policy returns pause_policy_unknown; deny policy returns deny_policy.
- Approval of [40,40] cannot authorize changed [40,60]; changed candidate returns await_exact_approval.
- Expired grant for [40,60] returns await_exact_approval. A current grant matching [40,60] returns ready_for_execution_not_executed.

All entries were exercised by a pure function fake. No email/payment/scheduling/network adapter is present. Caller/resource scopes, provenance and provider behavior are design requirements, not executed real-system tests.
