Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$checkRows = @()
function Get-PlanDigest($Plan) { return ($Plan -join ',') }
function Test-PlanAdmission($Plan, $RequiredTotal, $Supported, $Permitted, $CheckerState, $PolicyDecision, $ApprovalRequired, $ApprovalDigest, $ApprovalCurrent) {
    if ($Plan.Count -ne 2) { return 'deny_shape' }
    foreach ($value in $Plan) {
        if ($value -isnot [int] -or $value -le 0) { return 'deny_amount_shape' }
    }
    if (($Plan[0] + $Plan[1]) -ne $RequiredTotal) { return 'deny_total' }
    if (-not $Supported) { return 'deny_unsupported' }
    if (-not $Permitted) { return 'deny_permission' }
    if ($CheckerState -ne 'available') { return 'pause_checker_unavailable' }
    if ($PolicyDecision -eq 'deny') { return 'deny_policy' }
    if ($PolicyDecision -notin @('allow', 'approval_required')) { return 'pause_policy_unknown' }
    if ($ApprovalRequired -or $PolicyDecision -eq 'approval_required') {
        if (-not $ApprovalCurrent -or $ApprovalDigest -ne (Get-PlanDigest $Plan)) { return 'await_exact_approval' }
    }
    return 'ready_for_execution_not_executed'
}
function Add-Check($Name, $Actual, $Expected) {
    $pass = $Actual -eq $Expected
    $script:checkRows += [pscustomobject]@{ name = $Name; actual = $Actual; expected = $Expected; passed = $pass }
    if (-not $pass) { throw "Failed: $Name actual=$Actual expected=$Expected" }
}
$badPlan = [int[]]@(40,40)
$goodPlan = [int[]]@(40,60)
Add-Check 'first_invalid_sum' (Test-PlanAdmission $badPlan 100 $true $true 'available' 'allow' $false '' $false) 'deny_total'
Add-Check 'supported_permitted_alternative' (Test-PlanAdmission $goodPlan 100 $true $true 'available' 'allow' $false '' $false) 'ready_for_execution_not_executed'
Add-Check 'semantic_repair_still_invalid' (Test-PlanAdmission ([int[]]@(40,70)) 100 $true $true 'available' 'allow' $false '' $false) 'deny_total'
Add-Check 'valid_sum_permission_denied' (Test-PlanAdmission $goodPlan 100 $true $false 'available' 'allow' $false '' $false) 'deny_permission'
Add-Check 'unsupported_candidate' (Test-PlanAdmission $goodPlan 100 $false $true 'available' 'allow' $false '' $false) 'deny_unsupported'
Add-Check 'required_checker_outage' (Test-PlanAdmission $goodPlan 100 $true $true 'timeout' 'allow' $false '' $false) 'pause_checker_unavailable'
Add-Check 'unknown_policy' (Test-PlanAdmission $goodPlan 100 $true $true 'available' 'unknown' $false '' $false) 'pause_policy_unknown'
Add-Check 'policy_denied' (Test-PlanAdmission $goodPlan 100 $true $true 'available' 'deny' $false '' $false) 'deny_policy'
Add-Check 'changed_plan_invalidates_grant' (Test-PlanAdmission $goodPlan 100 $true $true 'available' 'allow' $true '40,40' $true) 'await_exact_approval'
Add-Check 'expired_grant' (Test-PlanAdmission $goodPlan 100 $true $true 'available' 'allow' $true '40,60' $false) 'await_exact_approval'
Add-Check 'exact_current_grant' (Test-PlanAdmission $goodPlan 100 $true $true 'available' 'allow' $true '40,60' $true) 'ready_for_execution_not_executed'
# Evaluate the finite allowed candidate set; reaching no admitted candidate returns a typed stop.
$deniedCandidates = @(@{ plan = $badPlan; allowed = $true }, @{ plan = $goodPlan; allowed = $false })
$admitted = @()
foreach ($candidate in $deniedCandidates) {
    $result = Test-PlanAdmission $candidate.plan 100 $true $candidate.allowed 'available' 'allow' $false '' $false
    if ($result -eq 'ready_for_execution_not_executed') { $admitted += $candidate }
}
$noCandidateStatus = if ($admitted.Count -eq 0) { 'stop_no_authorized_valid_candidate' } else { 'candidate_available' }
Add-Check 'no_authorized_valid_candidate' $noCandidateStatus 'stop_no_authorized_valid_candidate'
[pscustomobject]@{ fake_only = $true; external_execution = $false; effect_adapter_present = $false; check_count = $checkRows.Count; results = $checkRows } | ConvertTo-Json -Depth 8
