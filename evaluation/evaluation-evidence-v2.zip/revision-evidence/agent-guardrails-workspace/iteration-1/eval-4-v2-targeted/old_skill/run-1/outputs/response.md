# Keep the task open while preserving every boundary

Reject [40,40] because its total is 80, then evaluate the supported, permitted alternative [40,60] against the required total 100. The first proposal is inadmissible, but that does not establish that the user's goal is impossible. Immediate product refusal loses a legitimate completion. Skipping sum or permission checks after model repair creates an authorization bypass. Use bounded candidate selection followed by complete admission, and present the resulting plan without executing it.

## Layered path and owners

`request → trusted requirements → untrusted proposal → validation → bounded supported alternative → full validation → policy → permission → exact approval if needed → ready state → executor revalidation`

| Layer | Concrete responsibility and failure behavior |
|---|---|
| Guidance/reviewer model | Propose an evidence-supported installment plan or explain an error. Model approval grants no execution permission. |
| Deterministic validator | Normalize amounts, enforce positive valid amounts, supported installment count and sum exactly 100 using canonical integer minor units. Reject [40,40]. |
| Product orchestration | Search a bounded permitted candidate set, preserving the user's required total and intent. Select [40,60] only because it is independently supported; cap attempts and do not invent evidence. |
| Trusted policy | Classify allow, deny or approval-required for the exact candidate. Required-checker failure or unknown policy pauses effects. |
| Permissions | Check current caller, tenant, account and capability scope. Recheck at the executor; valid arithmetic alone never grants access. |
| Human approval | Bind any required grant to the exact amounts, dates, account, currency, total and relevant versions; expired or changed grants cannot authorize. |
| Runtime/executor | Bound candidates, time, calls and spend; share admission across retries/workers/resume. Execute only after a current admission token and atomic budget reservation. |

Trusted business configuration owns total 100. The model cannot lower it to 80 to make the first proposal pass. Retain installment dates, limits, destination and currency; arithmetic alone does not establish product feasibility. Obtain missing evidence through permitted lookup or ask for the missing choice.

## Repair and decision cases

| Situation | Required outcome |
|---|---|
| [40,40] fails; supported permitted [40,60] exists | Record `deny_total` for the first candidate. Independently propose and validate [40,60], then evaluate policy, permissions and approval. Return a ready preview when all gates pass. |
| Model returns [40,70], unsupported dates or unauthorized account | Reject that candidate with typed reasons; do not waive checks because it came from a repair step. Continue only within the bounded allowed candidate search. |
| No authorized valid candidate exists | Stop without effects. Explain which constraints prevent completion, and offer a permitted requirement change or request missing evidence when actionable. Do not loop indefinitely or call a tool speculatively. |
| Required checker unavailable | Pause with `checker_unavailable`; bounded retries may recover. A preview may remain visible if read-only policy permits, clearly marked pending verification. No default allow. |
| Approval conditions change | Invalidate the old grant and rerun affected validation, policy and permission checks. Request approval for the exact new candidate if required. |

Formatting repair is narrowly bounded. A change from [40,40] to [40,60] changes semantics, so treat it as a new proposal with its own provenance and full admission, not as a cosmetic normalization. Approval may resolve a choice that trusted rules delegate to an approver; it cannot waive the required sum or unauthorized account scope. Changed requirements, permissions or policy require re-evaluation even when amounts remain unchanged.

The preview can say: “The initial plan totals 80. A supported alternative is 40 followed by 60, totaling 100. This plan is ready for your required approval,” or “ready to submit” when no additional approval is required. Never say submitted, scheduled or paid before verified effect evidence exists.

## Actual checks and limits

The pure PowerShell fake in `plan-admission-fake.ps1` ran 12 passing checks, recorded in `actual-checks.json`. It exercised both totals, invalid semantic repair, unsupported/unauthorized candidates, no valid authorized candidate, checker outage, unknown/denied policy, changed/expired approval and exact approval. There is no execution adapter.

This fake models support, permission and freshness with supplied booleans and approval binding with an amount string. It does not establish real evidence quality, date/currency validity, signature verification, provider schemas or distributed race safety. Production bypass, cumulative-budget, stale-state and approval-digest tests remain proposed and unexecuted. No live execution or production release approval occurred.

