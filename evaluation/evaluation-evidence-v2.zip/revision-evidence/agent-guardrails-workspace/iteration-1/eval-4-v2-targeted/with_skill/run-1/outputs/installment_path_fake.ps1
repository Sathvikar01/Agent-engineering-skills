# Local design check only. Commit records are in-memory; no live tool exists.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:checks = [System.Collections.Generic.List[object]]::new()
$script:fakeCommits = [System.Collections.Generic.List[object]]::new()
$script:validationCalls = 0

function Reset-Sandbox {
    $script:fakeCommits.Clear()
    $script:validationCalls = 0
}

function New-Plan([int[]]$Installments) {
    return @{ Installments = $Installments; Total = 100; Account = 'merchant'; Currency = 'UNIT'; RequestId = 'req-1' }
}

function New-Context([string[]]$Permitted = @('40,60'),
                     [string]$Checker = 'available',
                     [bool]$RequireApproval = $false,
                     [string]$PolicyVersion = 'policy-1',
                     [string]$PermissionVersion = 'permissions-1') {
    return @{ Permitted = $Permitted; Checker = $Checker; RequireApproval = $RequireApproval;
        PolicyVersion = $PolicyVersion; PermissionVersion = $PermissionVersion;
        RequiredTotal = 100; Account = 'merchant'; Currency = 'UNIT'; RequestId = 'req-1' }
}

function Get-Fingerprint([hashtable]$Plan, [hashtable]$Context) {
    $canonical = [ordered]@{ RequestId = $Plan.RequestId; Account = $Plan.Account;
        Currency = $Plan.Currency; Total = $Plan.Total; Installments = @($Plan.Installments);
        PolicyVersion = $Context.PolicyVersion; PermissionVersion = $Context.PermissionVersion }
    $payload = $canonical | ConvertTo-Json -Compress -Depth 5
    $hash = [System.Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($payload))).Replace('-', '').ToLowerInvariant() }
    finally { $hash.Dispose() }
}

function New-Grant([hashtable]$Plan, [hashtable]$Context, [bool]$Expired = $false) {
    $expiry = if ($Expired) { [datetime]::UtcNow.AddMinutes(-1) } else { [datetime]::UtcNow.AddMinutes(5) }
    return @{ Decision = 'approved'; Fingerprint = Get-Fingerprint $Plan $Context; ExpiresAt = $expiry }
}

function Verdict([string]$State, [string]$Reason) {
    return [pscustomobject]@{ State = $State; Reason = $Reason }
}

function Test-Candidate([hashtable]$Plan, [hashtable]$Context, [hashtable]$Grant = $null) {
    $script:validationCalls++
    foreach ($key in @('Installments', 'Total', 'Account', 'Currency', 'RequestId')) {
        if (!$Plan.ContainsKey($key)) { return (Verdict 'reject_candidate' 'schema') }
    }
    if ($Plan.Installments -isnot [int[]] -or $Plan.Installments.Count -ne 2) {
        return (Verdict 'reject_candidate' 'unsupported_shape')
    }
    if (@($Plan.Installments | Where-Object { $_ -le 0 }).Count -gt 0 -or
        $Plan.Total -ne $Context.RequiredTotal -or $Plan.Account -ne $Context.Account -or
        $Plan.Currency -ne $Context.Currency -or $Plan.RequestId -ne $Context.RequestId) {
        return (Verdict 'reject_candidate' 'request_constraint')
    }
    $sum = 0
    foreach ($part in $Plan.Installments) { $sum += $part }
    if ($sum -ne $Context.RequiredTotal) { return (Verdict 'reject_candidate' 'sum') }
    if ($Context.Checker -ne 'available') { return (Verdict 'paused' 'required_checker_unavailable') }
    $signature = $Plan.Installments -join ','
    if ($signature -notin $Context.Permitted) { return (Verdict 'reject_candidate' 'permission') }
    if ($Context.RequireApproval) {
        if ($null -eq $Grant) { return (Verdict 'pending' 'approval_missing') }
        if ($Grant.Decision -ne 'approved') { return (Verdict 'stopped' 'approval_denied') }
        if ($Grant.ExpiresAt -le [datetime]::UtcNow) { return (Verdict 'pending' 'approval_expired') }
        if ($Grant.Fingerprint -ne (Get-Fingerprint $Plan $Context)) {
            return (Verdict 'pending' 'approval_payload_or_authority_changed')
        }
    }
    return (Verdict 'ready' 'all_required_checks_passed')
}

function Invoke-BoundedDesignPath([hashtable]$First, [hashtable]$Context,
                                 [hashtable]$Grant = $null,
                                 [hashtable]$Repair = $null) {
    # Exactly two proposals maximum; repair is an untrusted candidate too.
    $candidates = [System.Collections.Generic.List[object]]::new()
    $candidates.Add($First)
    if ($null -eq $Repair) { $Repair = New-Plan @(40, 60) }
    $candidates.Add($Repair)
    $trace = [System.Collections.Generic.List[object]]::new()
    foreach ($candidate in $candidates) {
        $verdict = Test-Candidate $candidate $Context $Grant
        $trace.Add([pscustomobject]@{ Installments = @($candidate.Installments); Verdict = $verdict })
        if ($verdict.State -ne 'reject_candidate') {
            return [pscustomobject]@{ State = $verdict.State; Reason = $verdict.Reason; Candidate = $candidate; Trace = @($trace.ToArray()) }
        }
    }
    return [pscustomobject]@{ State = 'abstain'; Reason = 'no_authorized_valid_candidate_found_within_budget'; Candidate = $null; Trace = @($trace.ToArray()) }
}

function Invoke-FakeCommit([hashtable]$Plan, [hashtable]$CurrentContext, [hashtable]$Grant = $null) {
    # Re-entry always validates using current trusted authority before recording.
    $verdict = Test-Candidate $Plan $CurrentContext $Grant
    if ($verdict.State -eq 'ready') {
        $script:fakeCommits.Add([pscustomobject]@{ Installments = @($Plan.Installments); Fingerprint = Get-Fingerprint $Plan $CurrentContext })
    }
    return $verdict
}

function Check([string]$Name, [bool]$Passed, [object]$Observed) {
    $script:checks.Add([pscustomobject]@{ Name = $Name; Passed = $Passed; Observed = $Observed })
    if (!$Passed) { throw "Check failed: $Name" }
}

$first = New-Plan @(40, 40)
$valid = New-Plan @(40, 60)
Reset-Sandbox
$context = New-Context
$result = Invoke-BoundedDesignPath $first $context
Check 'invalid_first_candidate_repaired_and_revalidated' ($result.State -eq 'ready' -and $result.Trace.Count -eq 2 -and $result.Trace[0].Verdict.Reason -eq 'sum' -and $script:validationCalls -eq 2 -and $script:fakeCommits.Count -eq 0) @{ Result = $result; ValidationCalls = $script:validationCalls; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$result = Invoke-BoundedDesignPath $first (New-Context @('40,40'))
Check 'no_authorized_candidate_abstains_after_bounded_search' ($result.State -eq 'abstain' -and $result.Trace.Count -eq 2 -and $result.Trace[1].Verdict.Reason -eq 'permission' -and $script:fakeCommits.Count -eq 0) @{ Result = $result; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$result = Invoke-BoundedDesignPath $first (New-Context @('40,60') 'outage')
Check 'checker_outage_pauses_repaired_candidate' ($result.State -eq 'paused' -and $result.Reason -eq 'required_checker_unavailable' -and $script:fakeCommits.Count -eq 0) @{ Result = $result; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$result = Invoke-BoundedDesignPath $first $context $null (New-Plan @(40, 50))
Check 'model_repair_does_not_skip_sum' ($result.State -eq 'abstain' -and $result.Trace[1].Verdict.Reason -eq 'sum' -and $script:validationCalls -eq 2 -and $script:fakeCommits.Count -eq 0) @{ Result = $result; ValidationCalls = $script:validationCalls }

Reset-Sandbox
$context = New-Context @('40,60') 'available' $true
$result = Invoke-BoundedDesignPath $first $context
Check 'valid_repair_awaits_exact_approval' ($result.State -eq 'pending' -and $result.Reason -eq 'approval_missing' -and $script:fakeCommits.Count -eq 0) @{ Result = $result; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$badGrant = New-Grant $first $context
$result = Invoke-BoundedDesignPath $first $context $badGrant
Check 'approval_for_invalid_original_does_not_cover_repair' ($result.State -eq 'pending' -and $result.Reason -eq 'approval_payload_or_authority_changed' -and $script:fakeCommits.Count -eq 0) @{ Result = $result; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$grant = New-Grant $valid $context
$result = Invoke-BoundedDesignPath $first $context $grant
$commit = Invoke-FakeCommit $result.Candidate $context $grant
Check 'approved_valid_candidate_rechecked_at_fake_executor' ($result.State -eq 'ready' -and $commit.State -eq 'ready' -and $script:validationCalls -eq 3 -and $script:fakeCommits.Count -eq 1) @{ Result = $result; Commit = $commit; ValidationCalls = $script:validationCalls; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$changed = New-Context @('40,60', '50,50') 'available' $true
$commit = Invoke-FakeCommit (New-Plan @(50, 50)) $changed $grant
Check 'changed_installments_need_new_approval' ($commit.State -eq 'pending' -and $script:fakeCommits.Count -eq 0) @{ Commit = $commit; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$changed = New-Context @('40,60') 'available' $true 'policy-2'
$commit = Invoke-FakeCommit $valid $changed $grant
Check 'policy_change_invalidates_old_grant' ($commit.State -eq 'pending' -and $script:fakeCommits.Count -eq 0) @{ Commit = $commit; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$changed = New-Context @('40,60') 'available' $true 'policy-1' 'permissions-2'
$commit = Invoke-FakeCommit $valid $changed $grant
Check 'permission_version_change_invalidates_old_grant' ($commit.State -eq 'pending' -and $script:fakeCommits.Count -eq 0) @{ Commit = $commit; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$changed = New-Context @('50,50') 'available' $true 'policy-1' 'permissions-2'
$commit = Invoke-FakeCommit $valid $changed $grant
Check 'revocation_denies_even_with_prior_approval' ($commit.State -eq 'reject_candidate' -and $commit.Reason -eq 'permission' -and $script:fakeCommits.Count -eq 0) @{ Commit = $commit; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$expired = New-Grant $valid $context $true
$commit = Invoke-FakeCommit $valid $context $expired
Check 'expired_approval_cannot_commit' ($commit.State -eq 'pending' -and $commit.Reason -eq 'approval_expired' -and $script:fakeCommits.Count -eq 0) @{ Commit = $commit; FakeCommits = $script:fakeCommits.Count }

Reset-Sandbox
$changed = New-Context @('40,60') 'outage' $true
$commit = Invoke-FakeCommit $valid $changed $grant
Check 'executor_outage_cannot_use_prior_approval' ($commit.State -eq 'paused' -and $script:fakeCommits.Count -eq 0) @{ Commit = $commit; FakeCommits = $script:fakeCommits.Count }

[pscustomobject]@{ Kind = 'local_in_memory_design_fake'; ExternalEffects = 0;
    CheckCount = $script:checks.Count; Checks = @($script:checks.ToArray());
    Limitations = @('No payment provider', 'Only two-installment integer UNIT fixture', 'No actor identity or due-date validation', 'No real policy/checker service', 'No durable grant, transaction or idempotency implementation', 'No model accuracy, latency or cost measurements')
} | ConvertTo-Json -Depth 12
