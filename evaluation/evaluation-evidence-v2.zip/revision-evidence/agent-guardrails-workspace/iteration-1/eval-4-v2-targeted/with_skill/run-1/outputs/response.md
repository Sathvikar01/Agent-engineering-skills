Reject `[40,40]` as the current candidate because its sum is 80, then continue a bounded search under the original required total of 100. Since `[40,60]` is supported and permitted, construct that candidate, verify it, and admit it only after every applicable boundary passes. Immediate refusal unnecessarily blocks a legitimate task. Skipping sum or permission checks after model repair creates an execution bypass.

The layers compose as follows:

| Layer and owner | Enforcement location and invariant |
|---|---|
| Model guidance, orchestration owner | Propose supported plans; explain repair feedback; model agreement never authorizes payment |
| Deterministic validator | Each candidate and executor entry: supported structure, exact numeric representation, positive amounts, total exactly 100, unchanged request constraints |
| Trusted policy service | Before admission: explicit allow, deny or approval-required; required missing/error decision blocks effects |
| Permission authority and executor | Current actor/account/capability scope; allowed plan and cumulative limits; recheck on retries and resume |
| Runtime controller | Bound proposals, checker retries, elapsed time, calls and spend; stop honestly on exhaustion |
| Human approval service | If required, issue a scoped, expiring grant for the exact verified candidate; no grant means pending |

Use `propose → verify → reject current candidate → construct supported alternative → verify again → policy/permission decision → exact approval if required → executor recheck → effect → reconcile`. Validation includes meaning, not merely a JSON schema. The second vector must total 100 and obey installment count, due-date, currency, account and per-installment constraints. For money, use the system’s exact minor-unit representation. Do not infer authorization from a model’s confidence or invent unsupported terms.

For this request, allow two candidate attempts: the original plan and the known alternative. Prefer trusted construction; model repairs remain untrusted. Preserve request, total, recipient, policy context and spending constraints. Record rejection and admission reasons. Candidate-specific denial permits another supported candidate; permanent action denial ends the path. Exhausted search means no verified candidate was found, not proof of universal infeasibility. Never relax authority to continue.

| Situation | Layered behavior and terminal status |
|---|---|
| `[40,40]` fails; `[40,60]` passes | Reject first candidate; validate replacement; continue to approval/admission |
| Repair returns `[40,50]` | Sum check rejects again; bounded search exhausts; safe abstention |
| Valid replacement lacks current permission | Reject it; search only remaining supported candidates within budget; abstain when none qualifies |
| Required checker unavailable | Pause effects; retain a draft if read-only policy allows; bounded backoff; fresh full admission on recovery |
| Approval missing, expired or silent | Keep valid candidate pending; no payment |
| Approval denies | Stop requested effect; return factual denial |
| Approved payload or authority changes | Invalidate grant; revalidate and seek a fresh grant when still permitted |
| Permission revoked or hard policy denies | Deny even when earlier approval exists |

Approval for `[40,40]` does not approve `[40,60]` and cannot make the invalid sum acceptable. Bind a grant to the actor, request, installments and dates, account, currency, total, policy and permission versions, expiry and payload hash. Freeze the checked payload. Recheck current authority at execution, including approval freshness; use atomic budget reservation and durable idempotency for provider retries. A timeout after possible payment acceptance requires reconciliation, not an unconditional resend. Log privacy-aware run IDs, control versions, decision reasons and effect evidence.

The local fake passed 13 checks covering reconstruction, revalidation, exhaustion, outage, exact approval, payload/authority changes, revocation and expiry. The no-solution fixture permits only `[40,40]`, which cannot total 100. It contains no live payment implementation. `actual-checks.json` records sandbox evidence only; the fake lacks complete business semantics, real checker integration, actor verification, durable approvals and provider behavior.

Production release remains conditional on proposed integration checks for races between approval and execution, concurrent cumulative limits, worker/resume bypasses, outage recovery, duplicate provider requests, poisoned repair input and false refusal of legitimate plans. Measure violations, successful authorized tasks, safe abstention, false blocking, review load and added latency/cost. Preserve mandatory deterministic policy and permission boundaries when evaluating optional model-review ablations. Do not claim production safety or measured release readiness from this design fake alone.
