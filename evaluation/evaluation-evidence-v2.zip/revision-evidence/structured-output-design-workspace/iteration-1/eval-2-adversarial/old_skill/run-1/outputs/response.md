The object must not enter authoritative inventory state. Parsing succeeds, but parsing establishes only JSON syntax. Even if the current permissive schema accepts it, the proposed change would produce `3 + (-99) = -96` units, and the authenticated actor has no write permission. Either failure independently prevents admission. `approved: true` is an untrusted model assertion and supplies no authority.

| Field or fact | Trust and interpretation |
|---|---|
| `version`, `kind` | Model-provided contract selectors; allow only explicitly supported variants and versions. |
| `item_id: I4` | A proposed identifier; resolve it in the actor's tenant and confirm existence and accessibility in trusted storage. |
| `quantity_delta: -99` | A proposed adjustment; recompute resulting stock and enforce business rules server-side. |
| `approved: true` | Unknown, untrusted property; reject it under the revised contract. It can never grant permission. |
| Stock `3` | Trusted current state, read again under the atomic write boundary if a proposal ever reaches execution. |
| Read-only permission | Trusted authenticated context; fails the inventory-adjustment permission check. |

Use a closed contract for the action variant. For example, this is a server-side draft 2020-12 schema fragment; provider support for the chosen subset must be checked separately:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "type": "object",
  "additionalProperties": false,
  "required": ["version", "kind", "item_id", "quantity_delta"],
  "properties": {
    "version": {"const": "1"},
    "kind": {"const": "propose"},
    "item_id": {"type": "string", "minLength": 1, "maxLength": 80},
    "quantity_delta": {"type": "integer", "minimum": -1000, "maximum": 1000}
  }
}
```

The wide delta range illustrates why numeric schema bounds cannot replace stock semantics. Under this closed schema, the original object fails immediately because it contains `approved`. If the deployment must temporarily retain its permissive schema, it must still promote only explicitly named validated fields into a typed proposal. Never merge the raw object into application state or feed its unknown fields into authorization code. Dropping `approved` does not make the remaining proposal admissible: it still fails stock and authorization checks.

The admission sequence is bounded input parsing, contract validation, trusted item/tenant resolution, semantic validation, authorization, any independently required approval, and atomic execution. Reject duplicate JSON keys and non-finite values at parsing; reject unknown versions before interpreting actions. A separate `no_action` or `insufficient_evidence` variant can convey an abstention without creating an inventory adjustment. If evidence is required by the inventory workflow, add required evidence references and validate their provenance; this particular payload supplies none.

For this input the decisive server-side conditions are:

```python
next_stock = trusted_stock + proposal.quantity_delta
if next_stock < 0:
    reject("insufficient_stock")
if not authenticated_actor.can_adjust_inventory:
    reject("permission_denied")
```

Run authorization from trusted principal data even if semantic checks are successful. Approval, when required, must be a server-stored decision bound to the exact proposal and state version. A model cannot issue an execution receipt. At execution, compare the expected stock version and apply the change transactionally so concurrent stock changes cannot invalidate an earlier calculation.

A restricted audit record may store the raw proposal and rejection reasons; that is diagnostic storage, not accepted domain state. The accepted-proposal queue and inventory must remain unchanged. Do not repair this by changing `-99` to `-3`, fabricating evidence, or changing the actor's permission. Those alter meaning or authority. Return a typed rejection or abstention. Proposed verification cases include the original payload, a valid but read-only proposal, an unknown version, and a conflicting no-action variant. No code execution was requested or performed for this design response.
