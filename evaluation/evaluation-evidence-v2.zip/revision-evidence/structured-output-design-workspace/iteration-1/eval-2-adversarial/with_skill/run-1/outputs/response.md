This proposal cannot enter authoritative inventory state. Successful JSON parsing establishes neither a valid inventory transition nor permission to make one. With trusted stock of 3, the proposed delta would produce `3 + (-99) = -96`. That violates the stock invariant. Independently, the authenticated actor has read permission only and cannot authorize an inventory mutation. The model's `approved: true` grants no authority.

The raw response may enter a restricted diagnostic record, and a rejection may enter an application-visible proposal history. Neither admission changes inventory, marks the proposal approved, or places it in an executable queue. Preserve this distinction in storage and UI labels.

| Field/fact | Trust and treatment |
|---|---|
| `version: "1"` | Untrusted contract selector; accept only an explicitly supported version. |
| `kind: "propose"` | Untrusted action variant, not a command to execute. |
| `item_id: "I4"` | Untrusted reference; verify existence, tenant ownership, access, and provenance against trusted records. |
| `quantity_delta: -99` | Proposed integer in inventory units; validate bounds and the resulting stock. |
| `approved: true` | Unknown, prohibited authority assertion; never copy into an authoritative object. |
| Stock `3` | Trusted current state used for server-side arithmetic. |
| Actor's read permission | Authenticated policy input; a model cannot expand it. |

Change the consumer contract to reject unknown properties. For example, the action branch should require `version`, `kind`, `item_id`, and `quantity_delta`, specify their types and bounds, and set `additionalProperties: false`. If evidence is required for inventory adjustments, also require bounded, unique evidence references; this candidate supplies none. The schema must contain no model-generated approval field. Use distinct no-action and insufficient-evidence variants so these cannot accidentally pass through an action executor.

The prompt does not specify the existing schema's complete constraints, so its current schema-validation result cannot be inferred merely from parse success. Even if the current schema accepts the object by ignoring `approved`, the subsequent admission gates must reject it. Ignoring extras is not a license to retain the original dictionary for execution: passing that dictionary downstream allows the ignored flag to regain meaning through object spreading, ORM assignment, or a later permissive consumer.

The admission sequence is bounded parsing, complete server-side shape validation, semantic validation, authorization, and an atomic state transition. Reject duplicate keys and non-finite numbers under an explicit parsing policy. Resolve `I4` and compute the next stock from trusted records; reject the negative result. Derive the actor from authenticated context and require the inventory-write permission. Only validated allowlisted fields can become a typed proposal. An approval, when policy requires one, must come from a trusted approval system bound to the exact proposal and state version.

```python
# Illustrative admission logic; no inventory operation was executed here.
proposal = validate_closed_contract(raw)
item = trusted_items.resolve(proposal.item_id, authenticated_actor.tenant)
if item.stock + proposal.quantity_delta < 0:
    return Rejected("negative_stock")
if not policy.can_adjust_inventory(authenticated_actor, item):
    return Rejected("write_permission_required")
return atomic_executor.apply(proposal, expected_state_version=item.version)
```

Fail closed regardless of which error is reported first. Reconstruction cannot repair absent authorization, invent evidence, or silently change `-99` to `-3`. A separately supported alternative can be constructed only from permitted facts under a bounded budget, then validated and authorized from the beginning. For this actor, every inventory-writing alternative remains unauthorized; return a typed rejection or nonmutating read-only result. Test that unknown approval fields are rejected, an otherwise valid decrement is denied to this actor, and a write-authorized actor is still denied a decrement exceeding available stock.
