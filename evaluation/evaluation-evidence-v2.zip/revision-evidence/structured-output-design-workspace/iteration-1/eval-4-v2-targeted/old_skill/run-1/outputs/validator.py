"""Small local fake: shape checks + payment semantics, no payment effects."""
import copy
import json

FACTS = {
    "required_total": 100,
    "latest_due_day": 30,
    "permitted_schedules": [([40, 60], [10, 20])],
    "observed_evidence": {"A": {"supports_total": 100}},
}
KEYS = {"version", "kind", "installments", "due_days", "status",
        "execute_day", "explanation_status", "evidence_ids"}


def parse(raw):
    if len(raw.encode("utf-8")) > 4096:
        raise ValueError("input too large")
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate key: " + key)
            result[key] = value
        return result
    def reject_constant(value):
        raise ValueError("non-finite number: " + value)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=reject_constant)


def shape_errors(p):
    if type(p) is not dict:
        return ["shape: object required"]
    errors = []
    if set(p) != KEYS:
        errors.append("shape: missing or unknown fields")
        return errors
    if p["version"] != "1" or p["kind"] != "payment_schedule":
        errors.append("shape: unsupported version or kind")
    for key in ("installments", "due_days"):
        values = p[key]
        if type(values) is not list or not 1 <= len(values) <= 8:
            errors.append("shape: " + key + " must be a bounded array")
        elif any(type(value) is not int for value in values):
            errors.append("shape: " + key + " must contain integers")
    if p["status"] not in ("READY", "WAIT"):
        errors.append("shape: status enum")
    if p["explanation_status"] not in ("PROPOSED", "PENDING", "APPROVED"):
        errors.append("shape: explanation_status enum")
    if p["execute_day"] is not None and type(p["execute_day"]) is not int:
        errors.append("shape: execute_day must be integer or null")
    evidence = p["evidence_ids"]
    if (type(evidence) is not list or not 1 <= len(evidence) <= 8
            or any(type(e) is not str or not 1 <= len(e) <= 80 for e in evidence)):
        errors.append("shape: evidence_ids must be bounded strings")
    elif len(evidence) != len(set(evidence)):
        errors.append("shape: duplicate evidence IDs")
    return errors


def validate(p, facts):
    errors = shape_errors(p)
    if errors:
        return errors
    amounts, days = p["installments"], p["due_days"]
    if any(amount <= 0 for amount in amounts):
        errors.append("nonpositive_installment")
    if sum(amounts) != facts["required_total"]:
        errors.append("total_mismatch")
    if len(amounts) != len(days):
        errors.append("array_length_mismatch")
    if any(not 1 <= day <= facts["latest_due_day"] for day in days):
        errors.append("due_day_out_of_range")
    if any(left >= right for left, right in zip(days, days[1:])):
        errors.append("due_days_not_increasing")
    if (amounts, days) not in facts["permitted_schedules"]:
        errors.append("schedule_not_permitted")
    if p["status"] == "WAIT":
        if p["execute_day"] is not None or p["explanation_status"] != "PENDING":
            errors.append("conflicting_wait")
    elif p["execute_day"] != days[0] or p["explanation_status"] != "PROPOSED":
        errors.append("conflicting_ready")
    unknown = set(p["evidence_ids"]) - set(facts["observed_evidence"])
    if unknown:
        errors.append("unknown_evidence:" + ",".join(sorted(unknown)))
    elif not any(facts["observed_evidence"][e]["supports_total"] == facts["required_total"]
                 for e in p["evidence_ids"]):
        errors.append("unsupported_total")
    return errors


def reconstruct_once(p, facts):
    """New alternative from permitted facts, never silent normalization."""
    errors = validate(p, facts)
    if set(errors) != {"total_mismatch", "schedule_not_permitted"}:
        return None
    if p["status"] != "READY":
        return None
    choices = [(amounts, days) for amounts, days in facts["permitted_schedules"]
               if days == p["due_days"]]
    if len(choices) != 1:
        return None
    amounts, days = choices[0]
    alternative = copy.deepcopy(p)
    alternative["installments"] = list(amounts)
    alternative["due_days"] = list(days)
    return alternative


class FakeAdmission:
    def __init__(self):
        self.accepted_proposals = []
        self.payment_effects = []
    def admit(self, p, facts, can_propose=True):
        errors = validate(p, facts)
        if not can_propose:
            errors.append("permission_denied")
        if errors:
            return False, errors
        if p["status"] == "WAIT":
            return False, ["abstention"]
        self.accepted_proposals.append(copy.deepcopy(p))
        return True, []


def main():
    base = {"version": "1", "kind": "payment_schedule", "installments": [40, 40],
            "due_days": [10, 20], "status": "READY", "execute_day": 10,
            "explanation_status": "PROPOSED", "evidence_ids": ["A"]}
    fake = FakeAdmission()
    original = parse(json.dumps(base))
    accepted, errors = fake.admit(original, FACTS)
    print("first rejected:", json.dumps({"admitted": accepted, "errors": errors}))
    assert not accepted and errors == ["total_mismatch", "schedule_not_permitted"]
    alternative = reconstruct_once(original, FACTS)
    assert alternative is not None and original["installments"] == [40, 40]
    print("one reconstructed alternative:", json.dumps(alternative, sort_keys=True))
    accepted, errors = fake.admit(alternative, FACTS)
    print("alternative revalidated:", json.dumps({"admitted": accepted, "errors": errors}))
    assert accepted and not errors
    conflicting = {**alternative, "status": "WAIT", "execute_day": 0,
                   "explanation_status": "APPROVED"}
    unknown = {**alternative, "evidence_ids": ["Z"]}
    unsupported = {**base, "evidence_ids": ["Z"]}
    for label, p in (("WAIT conflict", conflicting), ("unknown evidence", unknown),
                     ("bad total plus unknown evidence", unsupported)):
        accepted, errors = fake.admit(p, FACTS)
        repaired = reconstruct_once(p, FACTS)
        print(label + ":", json.dumps({"admitted": accepted, "errors": errors,
                                       "reconstruction": repaired}))
        assert not accepted and repaired is None
    for label, p in (("boolean installment", {**alternative, "installments": [True, 99]}),
                     ("late day", {**alternative, "due_days": [10, 31]}),
                     ("unknown field", {**alternative, "approved": True}),
                     ("unknown version", {**alternative, "version": "2"})):
        assert validate(p, FACTS), label
    assert fake.admit(alternative, FACTS, can_propose=False)[0] is False
    for raw in ('{"version":"1","version":"2"}', '{"n": NaN}'):
        try:
            parse(raw)
        except ValueError:
            pass
        else:
            raise AssertionError("parser accepted forbidden input")
    assert len(fake.accepted_proposals) == 1 and fake.payment_effects == []
    print("PASS: only reconstructed supported proposal admitted; payment effects = 0")
    print("PASS: boolean, late day, extra field, version, permission, duplicate key, NaN checks")


if __name__ == "__main__":
    main()
