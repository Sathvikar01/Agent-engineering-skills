"""Local payment-proposal fake; partial shape checks, not a JSON Schema engine."""
import copy
import json
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Facts:
    required_total: int = 100
    latest_due_day: int = 30
    schedules: tuple = (((40, 60), (10, 20)),)
    observed_evidence: tuple = ("A",)
    evidence_total: tuple = (("A", 100),)
    permissions: tuple = ("payment:propose",)
    state_version: int = 7


def errors_for_raw(raw):
    if len(raw.encode("utf-8")) > 4096:
        return None, ["BYTE_LIMIT"]

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("DUPLICATE_KEY")
            result[key] = value
        return result

    def nonfinite(value):
        raise ValueError("NONFINITE_NUMBER")

    try:
        proposal = json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite)
    except (ValueError, RecursionError) as exc:
        return None, [str(exc) if str(exc) in ("DUPLICATE_KEY", "NONFINITE_NUMBER") else "PARSE_ERROR"]

    def depth(value):
        if isinstance(value, dict):
            return 1 + max((depth(v) for v in value.values()), default=0)
        if isinstance(value, list):
            return 1 + max((depth(v) for v in value), default=0)
        return 0

    if depth(proposal) > 6:
        return None, ["DEPTH_LIMIT"]
    return proposal, []


FIELDS = {"version", "decision", "installments", "due_days", "execute_day", "explanation_status", "evidence_ids"}


def shape_errors(p):
    if type(p) is not dict:
        return ["OBJECT_REQUIRED"]
    result = []
    if set(p) - FIELDS:
        result.append("UNKNOWN_FIELDS")
    if FIELDS - set(p):
        result.append("MISSING_FIELDS")
    if result:
        return result
    if p["version"] != "1":
        result.append("UNKNOWN_VERSION")
    if p["decision"] not in ("PAY", "WAIT"):
        result.append("DECISION_ENUM")
    if p["explanation_status"] not in ("SUPPORTED", "UNSUPPORTED", "APPROVED"):
        result.append("EXPLANATION_ENUM")
    for key in ("installments", "due_days"):
        if type(p[key]) is not list or len(p[key]) > 8 or any(type(v) is not int for v in p[key]):
            result.append("INTEGER_ARRAY_" + key.upper())
    if p["execute_day"] is not None and type(p["execute_day"]) is not int:
        result.append("EXECUTE_DAY_TYPE")
    evidence = p["evidence_ids"]
    if type(evidence) is not list or not 1 <= len(evidence) <= 8 or any(type(v) is not str or not 1 <= len(v) <= 80 for v in evidence):
        result.append("EVIDENCE_SHAPE")
    elif len(set(evidence)) != len(evidence):
        result.append("DUPLICATE_EVIDENCE")
    return result


def semantic_errors(p, facts):
    result = []
    allowed = set(facts.observed_evidence)
    totals = dict(facts.evidence_total)
    if any(e not in allowed for e in p["evidence_ids"]):
        result.append("UNOBSERVED_EVIDENCE")
    elif not any(totals.get(e) == facts.required_total for e in p["evidence_ids"]):
        result.append("TOTAL_UNSUPPORTED")
    if p["explanation_status"] == "APPROVED":
        result.append("MODEL_APPROVAL_CLAIM")
    if p["decision"] == "WAIT":
        if p["execute_day"] is not None:
            result.append("WAIT_HAS_EXECUTION_DAY")
        if p["installments"] or p["due_days"]:
            result.append("WAIT_HAS_PAYMENT_SCHEDULE")
        if p["explanation_status"] != "UNSUPPORTED":
            result.append("WAIT_EXPLANATION_CONFLICT")
        return result
    amounts, days = p["installments"], p["due_days"]
    if not amounts or len(amounts) != len(days):
        result.append("SCHEDULE_LENGTH")
    if any(v <= 0 for v in amounts):
        result.append("NONPOSITIVE_INSTALLMENT")
    if sum(amounts) != facts.required_total:
        result.append("TOTAL_MISMATCH")
    if any(day < 0 or day > facts.latest_due_day for day in days) or any(a >= b for a, b in zip(days, days[1:])):
        result.append("DUE_DAY_CONSTRAINT")
    if (tuple(amounts), tuple(days)) not in facts.schedules:
        result.append("SCHEDULE_NOT_PERMITTED")
    if not days or p["execute_day"] != days[0]:
        result.append("EXECUTION_SCHEDULE_CONFLICT")
    if p["explanation_status"] != "SUPPORTED":
        result.append("PAY_EXPLANATION_CONFLICT")
    return result


def validate(raw, facts):
    p, failures = errors_for_raw(raw)
    if failures:
        return None, "parse", failures
    failures = shape_errors(p)
    if failures:
        return None, "shape", failures
    failures = semantic_errors(p, facts)
    if failures:
        return None, "semantic", failures
    # Only contract fields become a typed/allowlisted proposal representation.
    return copy.deepcopy(p), "validated", []


@dataclass
class FakeApplication:
    facts: Facts = field(default_factory=Facts)
    admitted: list = field(default_factory=list)
    real_effects: int = 0

    def admit(self, raw, expected_version):
        p, stage, errors = validate(raw, self.facts)
        if errors:
            return {"admitted": False, "stage": stage, "errors": errors}
        if "payment:propose" not in self.facts.permissions:
            return {"admitted": False, "stage": "authorization", "errors": ["PROPOSE_DENIED"]}
        if expected_version != self.facts.state_version:
            return {"admitted": False, "stage": "freshness", "errors": ["STALE_STATE"]}
        if p["decision"] == "WAIT":
            return {"admitted": False, "stage": "abstention", "errors": []}
        self.admitted.append(p)
        return {"admitted": True, "stage": "fake_proposal_state", "errors": []}


def safe_reconstruct(raw, facts, budget=1):
    p, stage, errors = validate(raw, facts)
    recoverable = {"TOTAL_MISMATCH", "SCHEDULE_NOT_PERMITTED"}
    # Evidence and conflicts cannot be reconstructed by adding or overriding claims.
    if budget <= 0 or stage != "semantic" or not errors or not set(errors) <= recoverable:
        return None, 0
    source = json.loads(raw)
    for amounts, days in facts.schedules[:budget]:
        candidate = {"version": "1", "decision": "PAY", "installments": list(amounts), "due_days": list(days),
                     "execute_day": days[0], "explanation_status": "SUPPORTED", "evidence_ids": list(source["evidence_ids"])}
        candidate_raw = json.dumps(candidate, allow_nan=False)
        verified, _, errors = validate(candidate_raw, facts)
        if verified is not None and not errors:
            return candidate_raw, 1
    return None, min(budget, len(facts.schedules))


def main():
    app = FakeApplication()
    first = {"version": "1", "decision": "PAY", "installments": [40, 40], "due_days": [10, 20],
             "execute_day": 10, "explanation_status": "SUPPORTED", "evidence_ids": ["A"]}
    raw = json.dumps(first)
    rejected = app.admit(raw, 7)
    assert not rejected["admitted"] and "TOTAL_MISMATCH" in rejected["errors"] and app.admitted == []
    print("first_candidate:", json.dumps(rejected))
    repaired, attempts = safe_reconstruct(raw, app.facts, budget=1)
    assert repaired is not None and attempts == 1
    print("reconstructed:", repaired, "attempts:", attempts)
    result = app.admit(repaired, 7)
    assert result["admitted"] and len(app.admitted) == 1
    print("revalidation_and_admission:", json.dumps(result))

    conflict = dict(first, decision="WAIT", installments=[], due_days=[], execute_day=0, explanation_status="APPROVED")
    unknown = dict(json.loads(repaired), evidence_ids=["Z"])
    for label, p in (("conflicting_wait", conflict), ("unknown_evidence", unknown)):
        candidate_raw = json.dumps(p)
        before = copy.deepcopy(app.admitted)
        result = app.admit(candidate_raw, 7)
        reconstruction, attempts = safe_reconstruct(candidate_raw, app.facts, budget=1)
        assert not result["admitted"] and reconstruction is None and attempts == 0 and app.admitted == before
        print(label + ":", json.dumps(result), "reconstruction_attempts:", attempts)

    # Additional focused checks exercise trust boundaries and failure classes.
    valid = json.loads(repaired)
    cases = [
        ("unknown_version", json.dumps(dict(valid, version="99")), "UNKNOWN_VERSION"),
        ("unknown_field", json.dumps(dict(valid, approved=True)), "UNKNOWN_FIELDS"),
        ("missing_critical", json.dumps({k: v for k, v in valid.items() if k != "evidence_ids"}), "MISSING_FIELDS"),
        ("duplicate_keys", '{"version":"1","version":"99"}', "DUPLICATE_KEY"),
        ("nonfinite", '{"value":NaN}', "NONFINITE_NUMBER"),
        ("boolean_installment", json.dumps(dict(valid, installments=[True, 99])), "INTEGER_ARRAY_INSTALLMENTS"),
        ("late_due", json.dumps(dict(valid, due_days=[10, 31])), "DUE_DAY_CONSTRAINT"),
        ("nonpositive", json.dumps(dict(valid, installments=[0, 100])), "NONPOSITIVE_INSTALLMENT"),
    ]
    for label, candidate_raw, expected in cases:
        before = copy.deepcopy(app.admitted)
        result = app.admit(candidate_raw, 7)
        assert not result["admitted"] and expected in result["errors"] and before == app.admitted
        print(label + ":", json.dumps(result))
    denied = FakeApplication(Facts(permissions=()))
    assert denied.admit(repaired, 7)["errors"] == ["PROPOSE_DENIED"] and denied.admitted == []
    stale = app.admit(repaired, 6)
    assert stale["errors"] == ["STALE_STATE"] and len(app.admitted) == 1
    assert safe_reconstruct(raw, app.facts, budget=0) == (None, 0)
    assert app.real_effects == denied.real_effects == 0
    print("authorization_denied: PROPOSE_DENIED; stale_state: STALE_STATE; zero_budget: no reconstruction")
    print("PASS: admitted_count=1; real_effects=0; unsupported/conflicting admissions=0")


if __name__ == "__main__":
    main()
