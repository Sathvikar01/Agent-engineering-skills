# Cross-skill adversarial review

Reviewer: primary Codex agent. Scope: all 19 staged SKILL.md files and six references read completely after the v2 patch. This is a source review, separate from executable behavioral grading and automatic invocation.

| Adversarial question | Enforcement and review conclusion |
|---|---|
| Are deterministic tasks agentified? | Architecture classifies known rules separately; orchestration asks whether model next-step control is necessary before workers. Lifecycle delegates the decision rather than prescribing a swarm. |
| Is semantic ambiguity forced into brittle rules? | Architecture uncertainty map and recovery fallback rules prohibit regex guessing for genuinely semantic interpretation. Model-assisted fixed pipelines remain valid. |
| Are frameworks or multiple roles treated as necessities? | Architecture/orchestration require needed capabilities and net comparison evidence. Several responsibilities do not establish worker benefit. |
| Can proposals become trusted state? | Structured-output-design separates parsing/shape/meaning; deterministic-authority owns current admission and atomic commit; state/memory owns typed transitions. Model approval fields and evaluator agreement do not confer authority. |
| Can an unsupported but known ID support an answer? | Provenance distinguishes retrieved/visible/used support and checks access/version/claim support. RAG retains anchors; observability records the distinct stages. General semantic entailment needs calibrated review; ID whitelists are insufficient. |
| Can valid shape hide invalid meaning or explanation? | Structured/provenance rules check totals, date/decision relations and explanation/facts/evidence consistency before promotion. |
| Can fail-closed become immediate refusal? | Authority/structured/guardrails/recovery allow bounded supported reconstruction under unchanged constraints. Missing permission is not repairable by a model. No candidate executes until fresh admission; unavailable required checker remains closed. |
| Can repair, retries or workers reset limits? | Orchestration enforces cumulative limits; recovery and state preserve budget and effect identity on resume. All fallback paths retain admission. |
| Can unknown committed effects be repeated? | Recovery reconciles status before replay; stable keys and version checks preserve deduplication. Unsupported provider guarantees are not claimed. |
| Can critical state survive restart? | State checkpoints include pending/unknown effects, receipts, versions and remaining budget; revalidation and reauthorization occur on resume. |
| Are high-impact operations permissioned without ritual approvals? | Authority enforces permissions; HITL considers standing authorization, consequence and reversibility, binds concrete approval and rejects silence/expiry. |
| Can an injected source redefine policy or mint lineage? | Security treats external content as data, checks source envelopes and executor scope, constrains exfiltration destinations, and tests allowed benign behavior as well as attacks. |
| Can operators reconstruct runs and respond? | Observability joins logical operation/attempt/run/evidence/state IDs and defines signal baseline/threshold/window/owner/response. Private reasoning is excluded. |
| Are controlled evals conflated with telemetry? | Evals defines measurement; observability records production signals; both distinguish exploratory diagnostics. Missing usage is unavailable, not zero. |
| Can an average score conceal a critical regression? | Evals sets metric/slice gates before results; quality cannot offset unauthorized effects or operational breaches. Testing allocates deterministic predicates to cheap tests. |
| Can descriptions guide tool selection? | Tool-design requires explicit use/non-use, pre/postconditions, neighboring capability and request/response semantics. Tool-evals owns discovery/selection/chaining measurements. |
| Can added complexity survive without evidence? | Architecture, orchestration, RAG, prompts and cost require matched baseline/ablation and operational gates. Role selection is distributed among existing owners; no duplicate model-selection skill was added. |
| Can completion stop at generated code or one example? | Lifecycle requires PLAN/IMPLEMENT/RUN/DEBUG/CORRECT/REVIEW, comparison and direct defence. Unexecuted checks and ownership remain visible. |

Found and corrected: architecture table retained escalation-to-next-class cells after conversion from a ranking to task-fit hypotheses. Three cells now state validation/comparison checks for their actual class. Both selected cases/configurations are rerun in iteration-2 with the original assertion contract, while iteration-1 is preserved.

Before iteration-2 execution, separated hybrid control from the multi-agent row: a fixed extraction pipeline plus adaptive retrieval need not introduce workers. Updated the unexecuted tested-source snapshot to the reviewed draft.

Behavioral claim review also found binary-success counts inferred from undefined quality percentages in both agent-evals v2 outputs. Added preserving metric definitions, units and denominators; fresh paired iteration-2 uses unchanged assertions. Original assertion passes and unverified claims remain archived rather than being relabeled.

Supplemental probes found the first revised trace fake accepting an orphan parent as complete and the first revised testing controller permitting another effect after terminal reentry. Added explicit orphan/cyclic/missing-event reconstruction checks and terminal-controller/checkpoint reentry properties. Fresh paired iteration-2 retains the original assertions and separately rechecks those probes. The original passing bounded assertions and uncovered gaps remain archived.

Scope boundaries: lifecycle coordinates; architecture chooses system boundaries; orchestration owns control flow; evals owns scoring; testing owns executable layers; authority owns admission; guardrails owns composition; security owns attack paths; provenance owns lineage; RAG owns retrieval. Links are optional consultation, not mandatory cycles. Three v1 instruction bodies remain unchanged because their scoped procedures already cover the requested responsibilities.

No claim that source review proves distributed idempotency, general entailment, provider/schema support, automatic triggering or production safety. Independent fake probes and grader limitations are preserved separately.

Evaluation-specification correction: the original cost case required measured cost per success and tail latency but supplied no executable workload. Both configurations correctly disclosed the experiment as unexecuted, and both literal measurement assertions failed. Preserve those grades; the iteration-2 prompt supplies a forty-task local fake clock/billing workload with failure/retry charges and independently verified success. Original assertions and skill instructions remain unchanged. Synthetic measurement scope is explicit; no provider benchmark or pre-change performance is invented.
