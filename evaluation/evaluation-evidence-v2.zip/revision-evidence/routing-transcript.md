# Catalogue-selection proxy transcript

## Scope and inputs

This run classified the supplied queries from metadata. It did not invoke any of the listed skills or verify their real runtime invocation.

The only source files read were:

- work/v2/routing-catalogue.json: 35 exact skill names and their descriptions.
- work/v2/routing-queries.json: 380 query IDs and query texts.

No skill bodies, expected-answer keys, trigger suites, audit documents, repository source files, or external sources were read.

## Process

1. Read the catalogue and all queries. The first combined display truncated the query output, so read the queries again in four compact, complete ID ranges: q0001-q0100, q0101-q0200, q0201-q0300, and q0301-q0380.
2. Manually selected metadata matches using the requested deliverable, the affirmative scope in each description, and its explicit exclusions. The mapping was not produced by keyword matching or inferred answer labels.
3. Used exact-name shorthand only while entering the manual mapping; code expanded the shorthand to the catalogue names.
4. Reviewed empty selections, larger overlapping selections, and explicit scope boundaries. Revised seven rows after review.
5. Saved routing-selection.json in input order as an array of objects with id and selected_skills.
6. Re-read the saved JSON and programmatically checked coverage, uniqueness, array shape, duplicate selections, and catalogue-name membership.

## Selection interpretation

A skill was selected when its described activity directly owned or independently supported a requested deliverable. More than one skill could apply. A mention of a topic did not automatically justify its skill if that topic was already fixed or explicitly outside the task.

Narrow specialist requests were not expanded into an entire engineering lifecycle. The lifecycle skill was selected for substantial end-to-end agent construction, productionization, redesign, or whole-system hardening. Neighboring specialists were added where the query separately called for their work.

General engineering skills were included where the query directly requested their activity, such as an implementation plan, conventional interface design, debugging, test-first implementation, documentation verification, or completion checks. They were not added transitively to every agent-design query.

The broad wording of brainstorming, writing-plans, test-driven-development, source-driven-development, and verification-before-completion creates metadata ambiguity: read literally, several could match much of this catalogue. This run treated them as direct task matches, rather than automatically applying all of them whenever code might eventually be written. That is a routing assumption, not a demonstrated property of actual invocation.

## Ambiguities and boundary decisions

- q0012 and q0231 request MCP evaluation questions with stable multi-call answers. tool-evals was selected because the described work concerns tool exploration and chains; mcp-builder was not selected because its description specifically concerns creating servers.
- q0023 concerns a forged approval traversing a trust flow. agent-security was selected; evidence-provenance was removed because the requested artifact is attack containment rather than a source-to-output support ledger.
- q0098 and q0356 request conventional database migrations. writing-plans was selected for their deployment and compatibility work. api-and-interface-design was removed because neither explicitly requests a public or module interface.
- q0103 mentions a reviewer model, not a human reviewer. human-in-the-loop was removed; agent-architecture and agent-state-and-memory remained for component and remembered-state ownership.
- q0122 requests calibration of an evaluator that is biased and instruction-sensitive. agent-evals was retained; agent-security was removed because no distinct trust-boundary hardening artifact is requested.
- q0194 describes conventional document search with no generated answers. rag-engineering was not selected. performance-optimization was removed because no bottleneck or performance requirement is stated. Conventional interface design, feature exploration, and implementation testing were retained.
- q0288 is a spelling-only production-prompt edit. prompt-engineering was selected under its stated deployed-prompt revision scope. This is a marginal metadata match; it does not imply a whole prompt-redesign process is necessary.
- Several queries ask for narrow runtime recovery, state persistence, evidence lineage, or controller behavior together. Multiple selections reflect explicit overlapping deliverables, not a forced single-owner rule.
- Six empty selections remain: q0131 (source lookup and explanation), q0142 (APA formatting), q0161 (one-off email prose), q0193 (one-off human-readable summary), q0241 (beginner explanation), and q0330 (one-off prompt shortening). No description directly owns these tasks under the narrow-scope interpretation above.

## Validation result

The saved selection contains:

- 380 objects covering all 380 input IDs exactly once.
- 506 total skill selections.
- 103 queries with more than one selected skill.
- 6 queries with empty selected_skills arrays.

Validation confirmed that every selection name belongs to the 35-name catalogue, every selected_skills value is an array, each object has the requested two fields, no query contains repeated skill names, and there are no missing or extra query IDs.

These counts describe the output only. No correctness score, precision, recall, expected-key comparison, or real-invocation success rate was calculated or claimed.
