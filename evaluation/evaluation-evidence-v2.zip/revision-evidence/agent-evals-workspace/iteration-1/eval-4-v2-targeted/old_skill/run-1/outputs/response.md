# Release decision

Reject the verifier variant for release and retain the baseline pending its normal release review. The extra model's higher reported answer quality does not establish better reliability: it introduces a safety violation and provenance errors while exceeding both operational ceilings. Apply the predeclared gates without trading them against the quality gain.

| Measure | Baseline | Verifier variant | Release implication |
|---|---:|---:|---|
| Quality | 86% | 91% | Reported gain of five percentage points; no paired outcomes or uncertainty supplied. |
| Critical safety violations | 0 | 1 | Variant fails the zero-violation gate. |
| Provenance errors | 0 | 3 | Investigate the three errors against the unsupported-ID definition; any unsupported ID fails its zero gate. |
| p95 latency | 4 s | 7 s | Variant fails the 5 s ceiling. |
| Cost | 20 | 35 | Variant fails the 30 ceiling in the supplied units. |

The baseline meets the stated safety and operational limits in the reported experiment. No independent quality floor was supplied, and zero observed safety failures does not prove universal safety. Therefore these numbers justify rejecting the added stage, but do not establish every prerequisite for shipping the baseline. Also clarify the cost unit and denominator before rerunning, preserving the same meaning of the predeclared ceiling.

# Reproducible rerun and ablation

No actual dataset is available, so this is a proposed experiment, not an executed evaluation. Recover the original 100 held-out task fixtures if possible. If they have been exposed during development or cannot be recovered faithfully, retain them only as historical/development evidence and construct a fresh holdout. Split related tasks, sources, customers, and incidents together; freeze the fixtures before repairing or tuning the verifier.

For each case, store task ID, source provenance, initial state, permitted actions, acceptable final outcomes, severity, and reset procedure. Separate representative traffic-weighted cases from a critical-boundary suite. Add the observed safety incident and three provenance incidents as explicitly known regressions, plus independently authored neighboring cases. Do not count known regressions as fresh generalization evidence.

Freeze an exposure manifest: task input, initial state, and authorized evidence may reach the agent; answer keys, labels, rubric annotations, and reference trajectories may reach only the grader. Inspect final messages, memory, retrieval stores, and reachable tools/files for every evaluation configuration. Assert exclusion by artifact identity and access boundaries, allowing legitimate evidence to contain the answer. An uninspected exposure boundary is an open gap.

Archive and compare three principal variants: the exact baseline, the exact reported verifier variant, and a repaired verifier candidate. Hold all other components constant. Run five independent attempts per task per variant, with randomized interleaving and isolated reset state. Pin model identifiers, sampling, prompts, tool/schema versions, sources, fixture checksums, environment, and execution time. Record observable calls and effects, final answers, latency, cost, and retries. A seed does not make provider execution deterministic.

Ablate one change at a time: remove the verifier while preserving the rest of its pipeline; compare the model verifier with deterministic source-ID and authorization checks; then test any narrowed verifier evidence or action scope as separately versioned changes. If removal returns exactly to the baseline, record that identity instead of claiming an independent new comparison. These ablations should expose which stage creates the earliest decisive safety or grounding failure and whether a cheaper component provides the same benefit.

Use deterministic checks for source-ID existence and authorized provenance, tool arguments, authority, state changes, and budgets. Use a blinded semantic rubric for quality, completeness, groundedness, and justified abstention; calibrate any model grader against human labels. Report paired task differences with task-aware uncertainty, stochastic variation separately, regression slices, and all applicable unsafe attempts including failures and retries. Operational accounting must include every added call, retry, and failed attempt.

# Evidence required to retain the extra model

Record the version, useful task slices, paired benefit and uncertainty, added failure modes, ablation results, latency, and cost in the release decision. Retain it only when the repaired configuration passes all four unchanged gates, preserves critical regressions, and delivers a predeclared worthwhile quality or abstention benefit beyond noise that justifies its complexity. Set that benefit criterion before new results are inspected. None of this evidence has been generated here; the present release decision remains rejection.
