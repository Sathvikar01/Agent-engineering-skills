REJECT the verifier variant for release. The reported quality gain does not satisfy the predeclared contract. Keep the baseline as the candidate on these four gates, subject to any other existing release requirements. The supplied summary does not establish those additional requirements.

| Metric | Baseline | Verifier | Gate and decision |
|---|---:|---:|---|
| Quality | 86% | 91% | Five more successful tasks out of 100; uncertainty and paired regressions unavailable. |
| Critical safety violations | 0 | 1 | Zero required: verifier fails. |
| Provenance errors | 0 | 3 | Audit error types against the zero unsupported-ID gate; compliance is not established. If these include unsupported IDs, that gate fails too. |
| p95 latency | 4 s | 7 s | At most 5 s: verifier fails. |
| Cost | 20 | 35 | At most 30: verifier fails. Preserve the original cost unit and aggregation definition. |

An extra model is an architectural change, not evidence of reliability. Here the variant has worse observed safety, provenance, latency and cost. The summary cannot attribute the quality change to verification, show statistical significance, or establish repeatability. A safety failure remains decisive even if the final answer was correct. Do not retrospectively relax the gates.

Create versioned fixtures for the same 100 held-out cases, with source provenance, allowed source IDs, actor permissions, initial state, reset instructions, permitted actions and acceptable outcomes. Preserve their historical held-out status only if no tuning or answer exposure occurred. If repairs use their results or answers, move them into regression/development and collect a fresh grouped holdout for the final release decision. Group related source, customer and incident families across splits. Reproduce the reported violation and provenance errors in additional isolated regression fixtures, and cover critical boundary cases separately.

Freeze one common agent and expose verifier modes as the sole initial variable: baseline with verification off; the extra model active in shadow mode with its result ignored; and the verifier active with its result used. Shadow mode estimates overhead; off versus active estimates the combined effect of verification. It does not automatically isolate every cause. Keep prompts, retrieval, routing, memory, tools, model settings and context budgets otherwise fixed; if the original variants differ elsewhere, first record those differences and ablate each separately. Further ablate a deterministic checker versus the model verifier if feasible. Only targeted failed components should change between reruns.

Run each frozen variant ten times per case, randomized in order with paired starting states and authorized evidence. Reset fake state before each attempt; no live effects. Record model IDs, sampling, prompts, schemas, fixture hashes, environment, architecture, retrieval/verification settings and timestamp. Retain observable calls, arguments, final state, evidence IDs and termination, without requiring private reasoning. These repetitions measure stochastic variability; they do not turn 100 task families into 1,000 independent tasks.

Enforce a runtime-input manifest: agent-visible task, approved state fields and authorized evidence; grader-only answer keys, labels, annotations and reference trajectories. Assert disjoint artifact identities and reachable stores across assembled messages, memory, retrieval and tools during both development and evaluation. Authorized evidence may contain the answer. A sealed file alone is insufficient, and this assertion has not run.

Use deterministic safety, ID provenance, state and budget checks. Grade semantic correctness and groundedness with a blinded rubric calibrated against independent human labels; record disagreement and grader versions. Attribute the earliest decisive failure as authority, grounding, retrieval, schema, tool execution, state or termination. Report paired per-task differences with task-cluster uncertainty, repeated-run distributions, safety across all attempts, abstentions and critical regression slices. Measure end-to-end p95 and the original cost metric consistently; also report cost per successful task including failures/retries.

Proposed reset/run/report entry point, **unimplemented and unexecuted**:

```powershell
python eval_runner.py --manifest rerun-spec.json --reset-fixtures --variants baseline shadow active --repeats 10 --output results
```

Retain the verifier only after it passes every original gate, loses no critical regression case, and shows a reproducible benefit on a fresh sealed holdout that justifies its added complexity. Predeclare the quality floor and minimum worthwhile paired gain before collecting new results; require uncertainty to support that gain, plus evidence from ablations. Record hypothesis, changed variable, versions, metrics, failure analysis and KEEP/REVISE/REJECT. Current conclusion: REJECT. No dataset is available, so no rerun, calibration, leakage audit or causal attribution was executed. Zero observed future violations would remain limited evidence, not proof of universal safety.
