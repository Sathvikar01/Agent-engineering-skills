Do not ship B. Its unauthorized account edit is a release blocker regardless of answer quality. Preserve the observable tool trace and before/after account state, reproduce the authorization failure in an isolated fixture, and repair the authority boundary before another release evaluation. A correct final answer cannot cancel an unauthorized effect.

The reported scores are 46/50 for A and 47/50 for B: one additional successful task. One run per task gives no estimate of repeated-run instability. Without paired outcomes, we cannot tell which tasks improved or regressed. Repeated tuning against those same answers makes the 50 cases development data; their scores cannot establish generalization. This is not evidence that B is reliably better.

Freeze the following rerun contract before inspecting new results:

| Component | Concrete specification |
|---|---|
| Development cases | Retain the original 50 for debugging only; label them exposed. |
| Fresh quality holdout | Collect 400 representative tasks, grouped by customer, underlying source, incident and near-duplicate family; prevent groups crossing development/holdout boundaries. Use prospective or later-time cases where feasible. |
| Critical boundary suite | Add 100 distinct authorization cases, including the incident, cross-account targets, expired approvals, missing permissions, approval bound to another proposed action, retries and malicious instructions in source content. Report this suite separately. |
| Repetitions | Run frozen A and repaired B 10 times per case, paired on identical starting state and available evidence, with randomized execution order. These are 500 distinct cases and 5,000 attempts per variant, not 5,000 independent tasks. |
| Baselines | Keep A unchanged; include a deterministic workflow on tasks where it can perform the intended work. Record coverage rather than inventing an inferior baseline. |

Each fixture needs an ID, provenance, task, authorized evidence IDs, actor permissions, permitted actions, initial state, reset procedure, acceptable final states, severity and traffic weight. Include successful completion, justified refusal and supported partial results. Use isolated fake accounts and tools; reset state before every attempt and retain observed calls, arguments, mutations and termination. No live account edits belong in the rerun.

Seal expected answers, reference trajectories, labels and grading annotations in a grader-only store. Publish an exposure manifest listing the task/state fields and source IDs that the agent may access. Assert that assembled model messages, memory, retrieval results and tool-visible stores contain only permitted artifacts and cannot reach grader-only artifacts. Inspect this boundary during development and evaluation. Do not ban answer text: an authorized source can legitimately contain the answer. Until this assertion runs, leakage prevention remains unverified.

Score final-answer correctness, completeness, support and abstention separately from trajectory authorization, target IDs, arguments, evidence use, retries, state and termination. Use deterministic final-state/permission checks where possible. For semantic grading, conceal variant identity, delimit source content, calibrate the rubric against independent human labels and report disagreement. Attribute the earliest decisive failure rather than counting downstream symptoms repeatedly.

Pin fixture hashes, model identifiers, sampling, prompt/tool/schema versions, environment, fake-tool behavior and relevant time. Record per-task paired quality differences; use task-cluster bootstrap intervals and show repeated-run variability separately. Report all safety attempts including failed/retried runs, regression slices, p95 latency, total spend and cost per successful task including failures. Seeds do not guarantee provider determinism.

Predeclare zero observed critical authority violations, every critical boundary covered, no critical regression, and a quality noninferiority margin of one percentage point against A. Set actual latency/spend ceilings from the service requirements before running; they were not supplied here. To claim superiority, require a positive paired confidence interval on fresh quality cases. These sample counts are a concrete starting design, not a completed power analysis.

Proposed harness entry point, **unimplemented and unexecuted**:

```powershell
python eval_runner.py --manifest rerun-spec.json --reset-fixtures --variants A B-fixed --repeats 10 --output results
```

Ablate B's changed components individually, including optional verification or extra model calls. KEEP B only after the frozen safety, quality, slice and operational gates pass; REVISE if a repair needs another fresh sealed evaluation; REJECT the current B now. Zero observed violations would establish a test result, not universal safety. No rerun results are available.
