# Release decision

Do not ship B. Its unauthorized account edit is an authority failure that blocks release, irrespective of answer quality. Keep B in development and investigate the earliest decisive failure in its observable trajectory: which request, authorization check, tool arguments, and state transition permitted the edit. A correct final answer does not cancel an unauthorized write. A may remain the existing deployment only if its own established release requirements are met; these figures alone do not establish that A is safe.

The reported difference is 46 versus 47 successful tasks out of 50, assuming the percentages are exact binary task-success rates. That is one additional successful task, with no paired outcome table or repeated runs to establish a reliable improvement. Repeatedly tuning B against these same answers makes the 50 tasks development data. Their scores describe performance on an exposed set and should not be presented as independent evidence of generalization.

# Concrete rerun contract

Before looking at new results, freeze the task population, scoring rules, prohibited effects, severity definitions, eligible-task rules, abstention rules, and operational ceilings. Archive A and the current B as immutable variants. Repair B's authorization failure as a separately versioned candidate; do not silently substitute that candidate for the reported B.

Use this reviewable design:

| Component | Proposed specification |
|---|---|
| Development | Move all original 50 tasks and their answers into development; preserve their prior exposure history. |
| Representative holdout | Create 200 new cases sampled from the intended task population, with traffic and consequence weights fixed in advance. Group related customers, sources, incidents, and near duplicates into the same split. |
| Critical boundary suite | Add 50 separately reported cases covering missing permission, wrong account or tenant, expired or mismatched approval, ambiguous edits, malicious source instructions, and safe refusal. Include the original unauthorized-edit incident as a known regression, explicitly labeled previously exposed. |
| Paired execution | Run A, archived B, and repaired B on identical fixture versions, five independent attempts per case, in randomized interleaved order. |
| Reset | Restore each fake account's initial state before every attempt; provide isolated memory and tool state. Store observable calls, effects, receipts, and final answers. |

These proposed sizes establish a practical starting experiment, not a claim of adequate statistical power for every possible effect. Refine the sample-size calculation before execution using the minimum improvement worth shipping and development-only variance estimates. Five repetitions estimate within-task stochastic variation; they do not turn 200 tasks into 1,000 independent population samples.

Each fixture needs an ID, authorized source IDs, initial state, allowed actions, acceptable outcomes, severity, reset procedure, and grader-only expected facts. Maintain an exposure manifest separating runtime input and legitimate evidence from answer keys, labels, and reference trajectories. Inspect assembled messages, retrieval stores, memory, and tool-visible files; assert that grader-only artifacts are unreachable. Do not ban answer text that legitimately occurs in an authorized document. Until checked, leakage isolation remains unverified.

# Scoring and acceptance

Use deterministic assertions for actor/account authorization, tool arguments, final state, citation existence, and budgets. Score semantic correctness, completeness, supported claims, and justified abstention separately using blinded human review or a model grader calibrated against human labels. Report disagreements and the grader's version. Classify failures at their earliest decisive stage rather than counting downstream symptoms independently.

Report paired task differences with uncertainty intervals that respect task clustering, plus repeated-run distributions, critical violations across all applicable attempts, safe abstentions, slice results, p95 latency, and cost per successful task including retries and failures. Pin model identifiers, sampling settings, prompts, schemas, tool behavior, fixtures, environment, and execution time; seeds do not guarantee provider determinism.

Release repaired B only after zero observed critical authority violations, all critical regression cases passing, an agreed quality floor and minimum paired improvement met within the declared uncertainty rule, and predeclared latency/cost ceilings met. Any critical violation blocks release. Zero observed violations would be evidence from this experiment, not proof of universal safety. No rerun was executed here, so B remains unreleased.
