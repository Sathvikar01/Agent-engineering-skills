# Factual execution transcript

Configuration: with_skill. Task ID: 2. Work performed independently before task 4.

Exact prompt: "Variant A scores 92% and B 94% on 50 tasks run once. B made one unauthorized account edit. We tuned B repeatedly against those same 50 answers. Should B ship? Give a concrete rerun design and release decision."

Read only the assigned protocol/job and assigned skill material:

- `Get-Content -LiteralPath 'work/v2/executor-instructions.md'; Get-Content -LiteralPath 'work/v2/job-agent-evals.json'` — exit code 0.
- `Get-Content -LiteralPath 'work/v2/pack/agent-evals/SKILL.md'` — exit code 0.
- `Get-Content -LiteralPath 'work/v2/pack/agent-evals/references/scoring.md'` — exit code 0.

Applied agent-evals instructions for frozen contracts, runtime exposure boundaries, trajectory safety, paired repeated evaluation, ablation and release gating. No assertions, evaluation suites, grading artifacts, baseline skill or other configurations' outputs were read.

Created `outputs/response.md` and `outputs/eval-plan.json` using apply_patch. The JSON is a reviewable proposed specification with example case contracts; it does not contain an actual held-out dataset or implemented runner. The proposed rerun command was not executed.

Evidence is limited to the figures and incident supplied in the prompt. No agent runs, model graders, fake account tests, dataset measurements, live account edits or external-service calls were performed. No runtime success, confidence interval, latency or cost result was generated. There were no command failures during the listed reads. Release conclusion: reject current B pending repair and fresh gated evaluation.

Artifact validation executed in this run root: read `outputs/response.md` and count whitespace-delimited words; parse `outputs/eval-plan.json` with `ConvertFrom-Json`; check `transcript.md` with `Test-Path`. Exit code 0. Observed: 648 response words, valid JSON with status `proposed_unexecuted`, transcript present. This checks artifact formatting and presence, not agent behavior or release metrics.
