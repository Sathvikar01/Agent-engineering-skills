**Do not ship B.** Its unauthorized account edit breaches a critical authority gate, regardless of its average quality score. Keep the currently approved release, if one exists; these facts alone do not establish that A is approved or safe.

The supplied evidence is a 92% score for A, 94% for B, one run on 50 tasks, repeated tuning of B against those answers, and one unauthorized edit. I have not observed the traces or executed a rerun. The score definition is missing: a quality percentage could be a rubric average, so it does not establish raw successful-task counts. The two-point improvement has no reported uncertainty. Moreover, those 50 answers are now development material, not an independent release holdout. Neither issue changes the immediate safety rejection.

Freeze a new evaluation contract before making further changes. Define an eligible task, a successful supported outcome, permitted account actions, safe abstention, and critical severity. A correct answer with an unauthorized write fails the trajectory safety check. Retain the original edit incident as a mandatory regression, recording its initial state, actor permissions, requested operation and expected blocked effect. Diagnose the earliest decisive failure from observable inputs, decisions and tool calls; do not count its downstream symptoms as separate root causes.

Use this concrete proposed rerun:

| Component | Frozen design |
|---|---|
| Representative holdout | 200 fresh tasks sampled from the intended traffic population, with predeclared traffic weights and task slices |
| Critical challenge suite | 100 fresh account-authority and provenance cases, reported separately from representative quality |
| Development regressions | Original 50 tasks plus the edit incident; label their results exploratory/regression evidence |
| Variants and repeats | Frozen A and repaired B, five independent attempts per case, interleaved in randomized order |
| Environment | Reset identical account state before every attempt; isolated fake account service and captured effects |

Group related customer accounts, sources, incidents and near duplicates before splitting; reserve a later-time slice where appropriate. Do not let developers inspect the new gold answers while optimizing B. For every case, record allowed task fields, authorized evidence IDs and grader-only keys/labels. Inspect assembled messages, memory, retrieval indexes and tool-accessible stores to assert that grader-only artifacts are unreachable during both development and evaluation. Do not prohibit legitimate source text merely because it contains the answer. A sealed file directory alone is insufficient evidence of isolation.

Check final state, actor/target authorization, tenant/account identity, tool arguments and source-ID existence with executable assertions. Include authorized edits, denied edits, ambiguous targets, cross-account substitutions, prompt injection in account notes, safe refusal and partial-result cases. Use a blinded, human-calibrated semantic rubric only for correctness or completeness that deterministic checks cannot express. Preserve disagreements and grader versions; grader approval cannot authorize account changes.

Pin case and prompt hashes, model identifiers, sampling settings, schemas, tool behavior, environment and relevant time. Report paired per-task quality differences with a task-cluster bootstrap interval; preserve repeated-attempt outcomes within each resampled task. The 1,500 attempts per variant on the fresh suites are not 1,500 independent tasks. Report authority violations across all applicable attempts, including retries and failures, plus supportedness, safe abstention, critical regression slices, p95 end-to-end latency and cost per successful task including failed-attempt spend. Predeclare operational budgets before opening results; none were supplied here.

Ablate the proposed repair or added verification one change at a time against frozen B and A. The accompanying reviewable specification gives the intended reset/run/report command; its runner and private fixtures remain unimplemented, so that command is **not executed evidence**.

Release only if repaired B records zero observed critical authority violations, passes every critical boundary regression and exposure check, meets predeclared quality and operational limits, and shows a practically useful paired improvement with uncertainty reported. Any critical violation rejects the candidate. Zero observed violations supports a bounded release decision; it does not prove universal safety. Current conclusion: **REJECT B; repair and rerun on a fresh holdout.**
