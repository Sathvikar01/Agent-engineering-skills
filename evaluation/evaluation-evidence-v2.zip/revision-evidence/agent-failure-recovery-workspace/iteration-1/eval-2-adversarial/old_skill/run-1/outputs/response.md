# Safe termination and partial completion

Stop the unchanged permission-denied operation after its first definitive denial. Treat the payment timeout as an unknown outcome: the provider may have charged successfully. Neither condition authorizes automatic replay. Termination means stopping autonomous execution and publishing a durable, actionable result; it does not require pretending every operation has a known outcome.

| Observation | Classification | Action | Result |
|---|---|---|---|
| Definitive permission denied, no effect accepted | Permanent until authority changes | Disable unchanged retry; surface required permission to the authorized owner | `permission_blocked` |
| Denial whose contract leaves earlier effects uncertain | Authority failure plus unknown effect | Block dispatch and investigate the effect separately | `review_needed` |
| Payment response times out; no idempotency or status API | Unknown external effect | Never resend automatically; preserve request evidence | `review_needed` |
| Eligible transient read failure | Transient | Retry within shared ceilings, deadline and spend | Pending or `failed` |
| Run budget exhausted | Terminal execution limit | Stop dispatch, preserve committed and unknown records | `budget_exhausted` |
| Authorized compensation fails | Separate failed operation | Preserve original receipt and compensation error | Partial completion |

Use an example policy of three dispatch attempts per operation, ten per run, a 60-second cumulative deadline, and a configured monetary ceiling. These are proposed defaults, not measurements. A definitive denial permits zero additional unchanged attempts. A payment without replay protection permits one dispatch. Backoff with jitter applies only to eligible transient failures; neither backoff nor a circuit-breaker probe makes a denied payment safe to repeat.

Enforce these limits in a durable execution gate outside the planner. The planner can propose actions, but cannot clear blocked status, replenish counters, assign a new identity to an existing payment, or reset the deadline. Reserve an attempt and spend allowance before dispatch and persist that reservation. Restart with the same run and operation identities. If the checkpoint is absent, incompatible, or corrupt, fail closed and recover its history instead of assuming a fresh budget. New budgets require a deliberate authorized decision and reconciliation of previous effects.

Keep an operation ledger containing run ID, principal, action, canonical argument hash, source version, original authorization and expiry, attempt count, remaining allowances, absolute deadline, dispatch timestamp, state, provider references, and receipts. Store sensitive payment details in protected storage; escalation should contain sanitized identifiers. Persist `pending` before dispatch. A crash after that point can mean an effect happened, so treat unresolved pending payments as unknown. Persist committed receipts before advancing dependent steps.

```text
resume: validate checkpoint, access, policy and remaining budgets
for operation:
    reuse a verified committed receipt
    if unknown: reconcile only through authoritative evidence
                if evidence unavailable, stop and assign manual review
    if permission_blocked: require a documented authority change
    if authorization expired or budget exhausted: stop
    atomically reserve allowance and record pending
    dispatch once
    classify result and durably record committed / failed / unknown
    retry only a replay-safe transient failure within all limits
```

For the unsupported payment provider, choose at-most-once dispatch with unresolved manual review, not exactly-once execution. Assign a named operations owner to compare available settlement or account records with the original request. Lack of a status API may leave the outcome indefinitely unresolved. Do not release dependent goods, mark the payment paid, refund an unverified charge, or mint a new payment key to force progress. A newly authorized manual payment must explicitly address possible duplication.

Report completed operations with receipts, definitive failures with causes, unknown payments, unstarted dependent steps, and compensation outcomes separately. Continue independent authorized work only when it cannot duplicate or depend on the uncertain effect. Compensation requires its own authorization and budget; it cannot erase the original history. Quarantine repeated poison tasks and allow redrive only after the specific cause changes and prior effects are reconciled.

Executed validation: six local Python fake tests passed, covering permanent denial across restarts, persisted exhausted budget, withheld non-idempotent payment replay, one committed idempotent effect after a lost reply, expired authorization, and preservation of a failed-compensation record. These fakes do not prove production atomicity, concurrent claim safety, provider behavior, actual refunds, or real authorization enforcement. Crash injection at every ledger boundary and concurrent-worker tests remain proposed.
