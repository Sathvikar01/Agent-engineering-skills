"""Policy fakes only: no network, real payment, or production runtime."""
import json
import tempfile
import unittest
from pathlib import Path


class Run:
    def __init__(self, path):
        self.path = path
        self.state = json.loads(path.read_text()) if path.exists() else {
            'remaining': 2, 'status': 'ready', 'operations': {}
        }

    def save(self):
        self.path.write_text(json.dumps(self.state))

    def dispatch(self, key, provider, grant=True, idem=False):
        if not grant:
            self.state['status'] = 'permission_blocked'
            self.save()
            return
        op = self.state['operations'].get(key)
        if op and op['status'] == 'unknown':
            # Only the idempotent fake permits reconciliation/replay.
            if not idem:
                self.state['status'] = 'review_needed'
                self.save()
                return
        if self.state['status'] == 'permission_blocked':
            return
        if self.state['remaining'] == 0:
            self.state['status'] = 'budget_exhausted'
            self.save()
            return
        self.state['remaining'] -= 1
        self.state['operations'][key] = {'status': 'pending'}
        self.save()
        try:
            result = provider(key)
            self.state['operations'][key] = {'status': 'committed', 'receipt': result}
            self.state['status'] = 'completed'
        except PermissionError:
            self.state['operations'][key] = {'status': 'failed', 'cause': 'permission_denied'}
            self.state['status'] = 'permission_blocked'
        except TimeoutError:
            self.state['operations'][key] = {'status': 'unknown'}
            self.state['status'] = 'review_needed'
        self.save()


class RecoveryFakes(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'ledger.json'

    def test_permanent_denial_called_once_across_restarts(self):
        calls = []
        def deny(key):
            calls.append(key)
            raise PermissionError()
        for _ in range(5):
            Run(self.path).dispatch('op', deny)
        self.assertEqual(calls, ['op'])

    def test_budget_does_not_reset(self):
        run = Run(self.path)
        run.state['remaining'] = 0
        run.save()
        calls = []
        Run(self.path).dispatch('new', lambda k: calls.append(k))
        self.assertEqual(calls, [])
        self.assertEqual(Run(self.path).state['remaining'], 0)

    def test_unknown_non_idempotent_payment_is_not_replayed(self):
        charges = []
        def charge(key):
            charges.append(key)
            raise TimeoutError()
        Run(self.path).dispatch('payment', charge)
        Run(self.path).dispatch('payment', charge)
        self.assertEqual(charges, ['payment'])
        self.assertEqual(Run(self.path).state['operations']['payment']['status'], 'unknown')

    def test_idempotent_lost_reply_has_one_committed_effect(self):
        effects, calls = {}, []
        def provider(key):
            calls.append(key)
            if key not in effects:
                effects[key] = 'receipt-1'
                raise TimeoutError()
            return effects[key]
        Run(self.path).dispatch('stable-key', provider, idem=True)
        Run(self.path).dispatch('stable-key', provider, idem=True)
        self.assertEqual(len(effects), 1)
        self.assertEqual(len(calls), 2)
        self.assertEqual(Run(self.path).state['operations']['stable-key']['status'], 'committed')

    def test_expired_grant_blocks_pending_dispatch(self):
        calls = []
        Run(self.path).dispatch('pending', lambda k: calls.append(k), grant=False)
        self.assertEqual(calls, [])
        self.assertEqual(Run(self.path).state['status'], 'permission_blocked')

    def test_failed_compensation_does_not_erase_original_effect(self):
        run = Run(self.path)
        run.state['operations']['original'] = {'status': 'committed', 'receipt': 'receipt-1'}
        run.state['operations']['refund'] = {'status': 'failed', 'cause': 'provider_unavailable'}
        run.save()
        resumed = Run(self.path)
        self.assertEqual(resumed.state['operations']['original']['status'], 'committed')
        self.assertEqual(resumed.state['operations']['refund']['status'], 'failed')


if __name__ == '__main__':
    unittest.main(verbosity=2)
