import unittest

class Denied(Exception): pass
class LostReply(Exception): pass

class Provider:
    def __init__(self, idempotent=False):
        self.idempotent = idempotent
        self.receipts = {}
        self.effects = 0
        self.calls = 0
    def pay(self, key):
        self.calls += 1
        if self.idempotent and key in self.receipts:
            return self.receipts[key]
        self.effects += 1
        receipt = 'receipt-' + str(self.effects)
        if self.idempotent:
            self.receipts[key] = receipt
        raise LostReply()

class Runner:
    # The shared dict models durable storage; it does not implement real disk transactions.
    def __init__(self, durable): self.durable = durable
    def invoke(self, key, action, authorized=True, replay_safe=False):
        row = self.durable['ops'].setdefault(key, {'status': 'pending'})
        if row['status'] in ('committed', 'denied', 'expired'):
            return row['status']
        if not authorized:
            row['status'] = 'expired'
            return 'expired'
        if row['status'] == 'unknown' and not replay_safe:
            return 'unknown'
        if self.durable['remaining'] <= 0:
            return 'budget_exhausted'
        self.durable['remaining'] -= 1
        row['status'] = 'unknown'  # write-ahead: a crash may precede actual dispatch
        try:
            row['receipt'] = action(key)
            row['status'] = 'committed'
        except Denied:
            row['status'] = 'denied'
        except LostReply:
            pass
        return row['status']
    def compensate(self, key, action, authorized):
        row = self.durable['ops'][key]
        if not authorized:
            row['compensation'] = 'approval_required'
            return
        try:
            action()
            row['compensation'] = 'completed'
        except RuntimeError:
            row['compensation'] = 'failed'

def ledger(remaining=3): return {'remaining': remaining, 'ops': {}}

class RecoveryTests(unittest.TestCase):
    def test_lost_reply_idempotent_retry_has_one_effect(self):
        state, provider = ledger(), Provider(idempotent=True)
        self.assertEqual(Runner(state).invoke('payment-1', provider.pay), 'unknown')
        self.assertEqual(Runner(state).invoke('payment-1', provider.pay, replay_safe=True), 'committed')
        self.assertEqual((provider.calls, provider.effects, state['remaining']), (2, 1, 1))
    def test_permanent_denial_stops_across_restarts(self):
        state, calls = ledger(), []
        def deny(key):
            calls.append(key)
            raise Denied()
        for _ in range(20):
            self.assertEqual(Runner(state).invoke('restricted-1', deny), 'denied')
        self.assertEqual((len(calls), state['remaining']), (1, 2))
    def test_no_idempotency_unknown_is_never_replayed(self):
        state, provider = ledger(), Provider()
        for _ in range(20):
            self.assertEqual(Runner(state).invoke('payment-2', provider.pay), 'unknown')
        self.assertEqual((provider.calls, provider.effects), (1, 1))
    def test_expired_grant_and_exhausted_budget_block_dispatch(self):
        state, provider = ledger(), Provider()
        self.assertEqual(Runner(state).invoke('expired-1', provider.pay, authorized=False), 'expired')
        state['remaining'] = 0
        self.assertEqual(Runner(state).invoke('new-1', provider.pay), 'budget_exhausted')
        self.assertEqual(provider.calls, 0)
        self.assertEqual(Runner(state).durable['remaining'], 0)
    def test_failed_compensation_preserves_committed_history(self):
        state = ledger()
        state['ops']['completed-1'] = {'status': 'committed', 'receipt': 'r1'}
        def fail(): raise RuntimeError('simulated reversal failure')
        Runner(state).compensate('completed-1', fail, authorized=True)
        self.assertEqual(state['ops']['completed-1'], {'status': 'committed', 'receipt': 'r1', 'compensation': 'failed'})

if __name__ == '__main__': unittest.main(verbosity=2)
