# Skill Benchmark: agent-failure-recovery

**Model**: <model-name>
**Date**: 2026-10-05T03:46:54Z
**Evals**: 2, 4 (3 runs each per configuration)

## Summary

| Metric | Old Skill | With Skill | Delta |
|--------|------------|---------------|-------|
| Pass Rate | 88% ± 18% | 100% ± 0% | -0.12 |
| Time | 0.0s ± 0.0s | 0.0s ± 0.0s | +0.0s |
| Tokens | 0 ± 0 | 0 ± 0 | +0 |