# Factual executor transcript — task 4, with_skill

Assignment: execute task 4 from `work/v2/job-tool-design.json` under configuration `with_skill`.

Read completely: `work/v2/executor-instructions.md`; job JSON for assigned prompts/paths; `work/v2/pack/tool-design/SKILL.md` (tool-design 2.0.0). No references were named by that skill. Did not read assertions, grades, eval suites, baseline outputs or baseline skill source.

Prompt: Design three model-facing capabilities for invoice work: find invoices, preview a payment schedule, commit a schedule. Search is read-only. Preview checks sums/dates without mutation. Commit requires permission and an application-issued approval bound to the exact schedule. Model calls preview to send money because its description says handles payments. Supply corrected selection descriptions and contract examples; no implementation needed.

Actions: authored `outputs/response.md` with capability map, USE WHEN / DO NOT USE WHEN descriptions, contracts and authorization/approval/idempotency semantics. Authored `outputs/contract-examples.json` with illustrative search, preview, commit, invalid-date, denial, mismatch and lost-response envelopes. Their statuses, IDs, hashes and timestamps are examples, not observations or issued approvals.

No implementation or tests were executed for this design-only task. No provider was contacted, approval issued, schedule committed, or money sent. The three-capability surface uses an identical commit retry to recover its stored result; unresolved outcomes require application reconciliation. Permission checks, schema validation, deterministic sums/dates validation, approval verification, persistence and provider deduplication are proposed contracts, not verified integrations. No claims about model-selection success, timing or provider guarantees are made.

All writes stayed within this task's assigned run directory. No execution failures occurred; there were no execution requests in this task.
