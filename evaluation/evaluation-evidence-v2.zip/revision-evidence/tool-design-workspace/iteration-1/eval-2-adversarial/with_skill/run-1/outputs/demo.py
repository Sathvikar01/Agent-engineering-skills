"""Local contract simulation only; no network or production persistence."""
import hashlib
import json
import uuid


def error(code, message, retryable=False, **details):
    return {"error": {"code": code, "message": message, "retryable": retryable,
                      "details": details, "request_id": "local-demo"}}


class Fake:
    def __init__(self):
        self.version = 7
        self.address = "Old address"
        self.writes = 0
        self.ledger = {}
        self.cursors = {}
        self.rows = [{"id": f"customer-{i:04d}"} for i in range(101)]

    def change(self, principal, request, authorized=True, lose_reply=False):
        if not authorized:
            return error("FORBIDDEN", "Address change is not permitted.")
        if set(request) != {"customer_id", "expected_version", "idempotency_key", "address"}:
            return error("VALIDATION", "Unexpected or missing field.")
        if not request["address"] or not isinstance(request["expected_version"], int):
            return error("VALIDATION", "Invalid address or version.")
        try:
            uuid.UUID(request["idempotency_key"])
        except (ValueError, TypeError):
            return error("VALIDATION", "Invalid operation key.")
        scope = (principal, "change_customer_address", request["idempotency_key"])
        semantic = {k: v for k, v in request.items() if k != "idempotency_key"}
        fingerprint = hashlib.sha256(json.dumps(semantic, sort_keys=True,
                                               separators=(",", ":")).encode()).hexdigest()
        if scope in self.ledger:
            digest, stored = self.ledger[scope]
            if digest != fingerprint:
                return error("IDEMPOTENCY_CONFLICT", "Operation key was used with different arguments.")
            return stored.copy()
        if request["customer_id"] != "customer-001":
            return error("NOT_FOUND", "Customer was not found.")
        if request["expected_version"] != self.version:
            return error("VERSION_CONFLICT", "Customer version changed.", current_version=self.version)
        # A single synchronous in-memory operation simulates the transactional boundary.
        self.address = request["address"]
        self.version += 1
        self.writes += 1
        result = {"operation_id": request["idempotency_key"], "status": "committed",
                  "customer_id": request["customer_id"], "version": self.version}
        self.ledger[scope] = (fingerprint, result.copy())
        if lose_reply:
            raise TimeoutError("Local simulated lost response after commit")
        return result

    def status(self, principal, key):
        record = self.ledger.get((principal, "change_customer_address", key))
        return record[1].copy() if record else {"status": "unknown"}

    def search(self, principal, page_size=100, cursor=None, fail=False, rows=None):
        if fail:
            # Upstream might include credentials; adapter never serializes its exception.
            try:
                raise RuntimeError("Provider leaked Bearer secret-user-token")
            except RuntimeError:
                return error("TRANSIENT", "Search is temporarily unavailable.", True)
        if not isinstance(page_size, int) or isinstance(page_size, bool) or not 1 <= page_size <= 100:
            return error("VALIDATION", "page_size must be between 1 and 100.")
        source = self.rows if rows is None else rows
        offset = 0
        if cursor is not None:
            record = self.cursors.get(cursor)
            if not record or record[0] != principal:
                return error("STALE_CURSOR", "Search cursor is no longer valid.")
            _, offset = record
        items = source[offset:offset + page_size]
        more = offset + len(items) < len(source)
        next_cursor = None
        if more:
            next_cursor = str(uuid.uuid4())
            self.cursors[next_cursor] = (principal, offset + len(items))
        return {"items": items, "snapshot_version": "fake-snapshot-1",
                "empty": not items, "truncated": more, "next_cursor": next_cursor}


def submit_and_reconcile(api, principal, request):
    # Mutation is attempted once. Two bounded status queries cannot create another write.
    try:
        return api.change(principal, request, lose_reply=True)
    except TimeoutError:
        for _ in range(2):
            observed = api.status(principal, request["idempotency_key"])
            if observed["status"] == "committed":
                return observed
        return error("UNKNOWN_OUTCOME", "Commit outcome requires reconciliation.")


def main():
    api = Fake()
    request = {"customer_id": "customer-001", "expected_version": 7,
               "idempotency_key": "ed8aeb7f-54bd-4f95-82d5-fd9e5d71fe7b", "address": "New address"}
    committed = submit_and_reconcile(api, "alice", request)
    assert committed["status"] == "committed" and api.writes == 1
    print("lost-response reconciliation:", json.dumps(committed))
    replay = api.change("alice", dict(reversed(list(request.items()))))
    assert replay == committed and api.writes == 1
    changed = {**request, "address": "Different address"}
    conflict = api.change("alice", changed)
    assert conflict["error"]["code"] == "IDEMPOTENCY_CONFLICT" and api.writes == 1
    print("changed retry:", json.dumps(conflict))
    denied = api.change("alice", request, authorized=False)
    assert denied["error"]["code"] == "FORBIDDEN" and api.writes == 1
    invalid = api.change("alice", {**request, "address": ""})
    assert invalid["error"]["code"] == "VALIDATION" and api.writes == 1
    stale = api.change("alice", {**request, "idempotency_key": str(uuid.uuid4())})
    assert stale["error"]["code"] == "VERSION_CONFLICT" and api.writes == 1
    assert api.status("bob", request["idempotency_key"])["status"] == "unknown"
    pages, cursor, found = 0, None, []
    while pages < 20:
        page = api.search("alice", cursor=cursor)
        pages += 1
        found.extend(page["items"])
        print("search page:", json.dumps({k: v for k, v in page.items() if k != "items"}), "rows=", len(page["items"]))
        if not page["truncated"]:
            break
        assert page["next_cursor"]
        cursor = page["next_cursor"]
    assert len(found) == 101 and len({row["id"] for row in found}) == 101 and pages == 2
    assert api.search("bob", cursor=cursor)["error"]["code"] == "STALE_CURSOR"
    assert api.search("alice", page_size=101)["error"]["code"] == "VALIDATION"
    empty = api.search("alice", rows=[])
    assert empty["empty"] and not empty["truncated"] and empty["next_cursor"] is None
    safe = api.search("alice", fail=True)
    assert "secret-user-token" not in json.dumps(safe) and "Bearer" not in json.dumps(safe)
    print("safe upstream error:", json.dumps(safe))
    print("PASS: local reconciliation, same-key replay/conflict, denial, validation, version conflict, principal isolation, pagination, empty results and error redaction checks")


if __name__ == "__main__":
    main()
