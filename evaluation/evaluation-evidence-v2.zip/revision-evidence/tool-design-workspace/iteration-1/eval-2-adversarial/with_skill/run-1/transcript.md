# Factual executor transcript — task 2, with_skill

Assignment: execute task 2 from `work/v2/job-tool-design.json` under configuration `with_skill`.

Read completely: `work/v2/executor-instructions.md`; job JSON for assigned prompts/paths; `work/v2/pack/tool-design/SKILL.md` (tool-design 2.0.0). No references were named by that skill. Did not read assertions, grades, eval suites, baseline outputs or baseline skill source.

Prompt: A change-address tool times out after committing; retry uses the same key with a changed address. Search silently cuts off after 100 rows and exposes the user token in its error. Design the corrected contracts and demonstrate client behavior.

Actions: authored `outputs/response.md` and `outputs/demo.py` inside this assigned run. Checked Python availability using `Get-Command python | Select-Object -ExpandProperty Source` and `python --version`; actual runtime reported Python 3.11.9.

Executed: `python <this-run>/outputs/demo.py` via PowerShell. Captured stdout/stderr into `outputs/actual-test.log`. Process exit code was 0. Observed a lost post-commit response reconciled to version 8, one total mutation, changed-request key conflict, two search pages containing 100 and 1 rows, and safe upstream error translation. Local invariant checks passed for same-key replay, key conflict, denied mutation, invalid address, version conflict, principal isolation, stale cursor, page bound, explicit empty result and credential-free error output. No execution failures occurred.

Limitations: this is a synchronous in-memory fake using a simplified address string. It does not implement the entire proposed input/output schema, persistent transaction, TTL/expiry, complete authorization/tenant system, country-specific semantic address validation, byte/deadline/fan-out limits, pending operation state, crash/concurrency recovery or actual provider behavior. The fake demonstrates client recovery and selected contract invariants only. No model-selection evaluation, benchmark, timing metric or real service integration was run. No live external effects occurred. Production checks stated in the design are proposed, not evidence of implementation success.
