"""Local deterministic contract demonstration; no network, database, or live writes."""
import hashlib
import json


class FakeTools:
    def __init__(self):
        self.ledger = {}
        self.version = 1
        self.writes = 0
        self.records = [{"customer_id": f"c-{i:03d}"} for i in range(250)]

    def change(self, principal, request, *, allowed=True, lose_response=False):
        if not allowed:
            return {"code": "PERMISSION_DENIED", "message": "Address change denied", "retryable": False}
        if set(request) != {"customer_id", "expected_version", "address", "idempotency_key"}:
            return {"code": "INVALID_ARGUMENT", "message": "Unexpected or missing fields", "retryable": False}
        if not isinstance(request["expected_version"], int) or request["expected_version"] < 1:
            return {"code": "INVALID_ARGUMENT", "message": "Invalid expected_version", "retryable": False}
        scope = ("tenant-demo", principal, "change_customer_address", request["idempotency_key"])
        digest = hashlib.sha256(json.dumps(request, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        if scope in self.ledger:
            previous_hash, result = self.ledger[scope]
            if previous_hash != digest:
                return {"code": "IDEMPOTENCY_CONFLICT", "message": "Key belongs to a different request", "retryable": False}
            return result
        if request["expected_version"] != self.version:
            return {"code": "VERSION_CONFLICT", "message": "Customer version changed", "retryable": False}
        self.version += 1
        self.writes += 1
        result = {"status": "committed", "operation_id": "op-1", "customer_id": request["customer_id"], "version": self.version, "address": request["address"]}
        self.ledger[scope] = (digest, result)
        if lose_response:
            raise TimeoutError("Response lost after local fake commit")
        return result

    def status(self, principal, key):
        entry = self.ledger.get(("tenant-demo", principal, "change_customer_address", key))
        return entry[1] if entry else {"status": "not_found"}

    def search(self, *, limit=100, cursor=None):
        # Fixed snapshot and simple fake cursors; real cursors must be opaque and scoped.
        offset = 0 if cursor is None else int(cursor.split(":")[1])
        items = self.records[offset:offset + limit]
        end = offset + len(items)
        more = end < len(self.records)
        return {"items": items, "snapshot_version": "fake-1", "returned_count": len(items), "has_more": more, "next_cursor": f"fake:{end}" if more else None, "truncated": False}

    def provider_error(self, raw_error):
        # Never interpolate raw provider content, regardless of what it contains.
        return {"code": "TRANSIENT_FAILURE", "message": "Search provider temporarily unavailable", "retryable": True, "request_id": "req-demo"}


def main():
    tools = FakeTools()
    original = {"customer_id": "c-001", "expected_version": 1, "address": {"line1": "10 First Street", "city": "Example", "postal_code": "12345", "country": "US"}, "idempotency_key": "change-001"}
    try:
        tools.change("principal-demo", original, lose_response=True)
        raise AssertionError("Expected the injected timeout")
    except TimeoutError:
        print("Lost response: UNKNOWN_COMMIT_OUTCOME; client retains the original request.")
    changed = {**original, "address": {**original["address"], "line1": "20 Second Street"}}
    rejected = tools.change("principal-demo", changed)
    assert rejected["code"] == "IDEMPOTENCY_CONFLICT"
    assert tools.writes == 1
    print("Changed-address reuse:", rejected["code"], "writes=1")
    recovered = tools.status("principal-demo", original["idempotency_key"])
    assert recovered["status"] == "committed" and recovered["address"] == original["address"]
    print("Reconciliation: committed original address, version", recovered["version"])
    replayed = tools.change("principal-demo", original)
    assert replayed == recovered and tools.writes == 1
    print("Identical retry: saved result replayed, writes=1")
    denied = tools.change("principal-demo", {**original, "idempotency_key": "denied"}, allowed=False)
    invalid = tools.change("principal-demo", {**original, "unexpected": "x"})
    assert denied["code"] == "PERMISSION_DENIED" and invalid["code"] == "INVALID_ARGUMENT"
    assert tools.writes == 1
    print("Denied mutation and unexpected field rejected without writes.")
    cursor, collected, sizes = None, [], []
    for _ in range(5):
        page = tools.search(cursor=cursor)
        collected.extend(page["items"])
        sizes.append(page["returned_count"])
        if not page["has_more"]:
            assert page["next_cursor"] is None
            break
        assert page["next_cursor"] is not None
        cursor = page["next_cursor"]
    else:
        raise AssertionError("Pagination budget exhausted")
    assert sizes == [100, 100, 50] and len({x["customer_id"] for x in collected}) == 250
    print("Search page sizes:", sizes, "unique customers=250")
    token = "synthetic-user-token-must-not-leak"
    safe_error = tools.provider_error(f"provider rejected credential {token}")
    assert token not in json.dumps(safe_error)
    print("Safe provider error:", json.dumps(safe_error, sort_keys=True))
    print("PASS: local behavioral assertions; no live external effects.")


if __name__ == "__main__":
    main()
