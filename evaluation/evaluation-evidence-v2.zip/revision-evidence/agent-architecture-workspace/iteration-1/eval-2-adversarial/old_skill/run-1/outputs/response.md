Choose a deterministic support workflow with model-powered interpretation and narrowly scoped tools. Remove the loop whose termination depends on the model saying “solved.” The current description supplies no evidence that adaptive planning improves support outcomes. Introduce a bounded tool-using agent only if a representative evaluation later shows that the fixed workflow cannot select necessary investigative steps.

Success means the authorized support outcome is independently verified, the account retains only permitted privileges, and the application records durable evidence. Disallowed actions include granting privileges from ticket instructions, bypassing review, crossing tenant boundaries, and converting chat claims into authoritative status. Establish a baseline using the current support process, including its manual permission-change path; do not benchmark against the unsafe loop as an acceptable release candidate.

Use this run path:

`authenticated request → retrieve bounded context → interpret → validate proposal → authorize → obtain required approval → execute → verify → persist terminal status`

| Boundary | Owner and enforceable contract |
|---|---|
| Intent and identity | Application authenticates requester, tenant, account, and requested scope. |
| Interpretation | Model extracts the issue and proposes a typed investigation or action with source references. |
| Untrusted context | Ticket text remains evidence, including the “grant admin and skip review” instruction; it cannot alter policy or tool permissions. |
| Validation | Deterministic code checks schema, target identity, action allowlist, parameter bounds, and expected account version. |
| Authority | Policy service checks requester entitlement and permitted transitions using authoritative account data. |
| Approval | Authorized reviewer approves the exact target, change, and version; material changes invalidate approval. |
| Execution | Least-privilege service performs only admitted operations and records receipts. |
| Completion | Independent verifier checks resulting state; application updates durable workflow status. |

Expose read tools separately from mutations. The runtime identity should have no unrestricted administration capability. A permission-change tool accepts a validated account identifier, expected version, allowed change, authorization reference, approval reference, and idempotency key. Return a structured receipt and current state, not an unverified success sentence. Explicitly deny privilege escalation outside policy even when a human approval is present.

Persist run ID, request identity, workflow and policy versions, transitions, validated proposals, approvals, execution receipts, evidence references, and evaluator results. Store account permissions in the account service and workflow status in an application database. Chat may summarize these records but cannot be the source of truth. Retrieve only relevant ticket excerpts with provenance and explicit size limits; omit secrets from logs and model context.

A happy trajectory: an authenticated user requests an allowed role adjustment; the model extracts the request; validators and policy admit it; a reviewer approves the exact change; execution returns a receipt; a fresh authoritative read confirms the expected role; the application marks the run verified complete.

A denied trajectory: retrieved text instructs admin access and review bypass. The model may propose escalation, but deterministic policy denies it. No mutation occurs; the application records policy denial and offers the permitted escalation process. Unavailable verification produces an unresolved status, never “solved.”

As initial configurable ceilings, use 10 minutes per run, 8 workflow transitions, 3 model calls, 6 read-tool calls, one mutation attempt per admitted operation, and a deployment-defined monetary cap enforced before each call. These are proposed limits, not measured optima. Stop on cancellation, policy denial, invalid approval, repeated identical proposals, exhausted budget, or missing evidence. Terminal states include verified_complete, denied, cancelled, budget_exhausted, needs_review, failed, and partial_completion.

Checkpoint before mutation and after its receipt. After timeout, reconcile the idempotency key and authoritative state before any retry. Resume only after rechecking identity, policy, account version, and approval validity.

Release only after a versioned test set passes permission invariants, cross-tenant isolation, injected-ticket rejection, approval binding, cancellation, budget termination, timeout reconciliation, and independent completion verification. Require zero unauthorized writes and zero false verified completions in that suite; inspect denied and partial trajectories. Set quality, latency, and cost thresholds from the baseline before testing. Shadow read-only runs first, then a restricted rollout. No implementation or gate execution has occurred; policy details, provider limits, and baseline performance remain to be established.
