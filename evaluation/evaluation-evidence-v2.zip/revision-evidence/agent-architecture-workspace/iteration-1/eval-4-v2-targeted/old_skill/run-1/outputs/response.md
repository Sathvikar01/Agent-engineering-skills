Use a deterministic workflow with a model-powered interpretation step for policy notes. Use deterministic software for arithmetic over validated, typed invoices. Neither case currently justifies an autonomous agent loop or a five-agent framework: the next stages are already known, and arithmetic does not require adaptive reasoning.

Regex can recognize stable identifiers or explicit formats, but using it as the whole policy interpreter requires evidence that it handles negation, exceptions, conflicting accounts, and paraphrases. Test that claim before replacing the existing process. Where meaning cannot reliably be expressed as rules, use a bounded model step within the workflow.

| Work | Architecture | Trusted output |
|---|---|---|
| Policy interpretation | One model invocation within a fixed workflow | Validated structured candidate with source spans and unresolved issues |
| Rule and authority validation | Deterministic code against approved policy | Accepted interpretation, rejected interpretation, or review required |
| Invoice totals | Deterministic decimal arithmetic | Reproducible totals and calculation trace |
| Explanation | Templates, with an optional bounded model for wording | Explanation tied to accepted facts and computed values |

Run `interpret → validate → calculate → explain`. Interpretation produces typed claims, scope, negations, exceptions, source references, and contradictions rather than an executable policy change. Structural validity is necessary but does not prove semantic correctness. Validate source references and required fields, then check consistency and approved policy precedence. If two accounts contradict each other and no authority rule resolves them, stop for review instead of silently choosing an account. Only validated inputs reach calculation.

Keep the source documents, accepted interpretation, policy version, and arithmetic trace in application-owned storage. The model cannot declare a policy authoritative or promote its explanation into persisted business truth. A reviewer owns unresolved policy judgments; deterministic services own arithmetic and permitted transitions. Restrict context to the relevant documents with provenance and bounded input size.

For invoices, define currency, decimal precision, rounding stage, tax treatment, discounts, missing-field behavior, and credit rules explicitly. A single function or ordinary service can perform the calculation once these business rules are defined. If invoice extraction is fuzzy, put extraction before validation as its own bounded model step; keep the arithmetic deterministic. Five agents would introduce messages, reconciliation, failure modes, and cost without a demonstrated benefit.

Evaluate these candidate configurations on the same held-out cases:

| Candidate/ablation | Decision question |
|---|---|
| Existing process and regex interpreter | What does the proposed replacement improve or break? |
| One interpreter plus deterministic validation | Does a model recover necessary semantic accuracy? |
| Same pipeline without semantic consistency checks | How much protection comes from validation? |
| First pipeline plus independent second-model review | Does review catch additional meaningful errors? |
| Typed arithmetic service versus proposed five-agent calculation | Does coordination add any benefit beyond correct arithmetic? |

Include paired negation cases, paraphrases with unchanged meaning, exception scope changes, contradictory-source cases, and insufficient-evidence cases. Reviewers should establish accepted meanings and unresolved cases before comparing candidates. Score semantic correctness, unsupported conclusions, contradiction handling, review burden, arithmetic accuracy, end-to-end success, latency, and cost. Record versioned inputs, model/configuration versions, run IDs, and evaluator outcomes. Do not tune against held-out failures and then report them as unseen results.

A second model might help as a bounded reviewer with an independent instruction and genuinely distinct evidence or expertise. It should cite the suspected error and return a structured disagreement; deterministic workflow logic decides whether to accept or escalate. Another model reading the same context may repeat the first model’s errors. Agreement is not authorization or proof, and using two models to add numbers provides no necessary advantage. Retain review only if the ablation demonstrates enough incremental error reduction to justify added cost, latency, and escalation load.

An accepted policy follows validation to calculation and evidence-backed explanation. An unresolved contradiction stops before calculation. Enforce configured call, context, time, and spend limits; checkpoint accepted inputs before calculation and terminate with completed, needs_review, invalid_input, cancelled, or failed. Release requires predeclared baseline-relative quality thresholds and exact arithmetic agreement on approved cases. No experiment or implementation has been run; the current recommendation is provisional until those comparisons supply evidence.
