# Architecture decisions

Choose a **model-assisted deterministic pipeline** for policy-document interpretation and **deterministic software** for typed invoice arithmetic. Interpret, validate, calculate, explain is a known sequence. Semantic uncertainty justifies a model, without an adaptive loop or five agents. Regex is a comparison baseline; semantic modeling need not wait for it to fail.

Success means supported policy meaning, explicit conflicts, exact totals and consistent explanations. Forbidden outcomes include ignoring exceptions, reversing negation, choosing between contradictory accounts without a precedence rule, and inventing amounts. Cases include “not reimbursable unless approved,” paraphrased policies, incompatible dated accounts, and typed invoices needing no interpretation.

| Stage | Architecture and owner | Reason and admission check |
|---|---|---|
| Interpret documents | One bounded model call proposes structured claims, qualifiers, exceptions and source spans | Meaning is uncertain; validation checks faithful support, including negation and scope |
| Validate interpretation | Application checks types and known policy constraints; reviewer handles unresolved meaning | Schema validity cannot establish semantic truth; contradictions remain explicit |
| Calculate totals | Deterministic decimal/integer-minor-unit functions | Currency, rounding, tax and eligibility rules must be specified and testable |
| Explain | Prefer templates; optionally a model receives only validated facts | Reject unsupported claims and mismatched totals; no authority to change results |

The model interprets/extracts and possibly explains; code owns validation, arithmetic, transitions and business authority. One model can fill several roles. Application state stores validated interpretation, evidence references, policy version and calculation inputs/outputs. Original documents remain immutable evidence; extracted text and model output are untrusted until admitted. Citations must support consequential claims. Contradictions require an explicit precedence rule or review.

## Runs and operational bounds

Happy path: record the requested outcome → select bounded source context → model proposes supported meaning → validate semantics and policy rules → calculate with authoritative inputs → generate an explanation from committed results → check outcome → persist `verified_complete`. For a typed invoice, skip the interpretation call entirely.

Failed path: one account says an exception applies and another denies it → extraction preserves both accounts → validation finds no authorized precedence rule → persist `needs_review` with supporting spans → calculate only if a safe, explicitly authorized partial result exists; otherwise stop. A plausible model explanation cannot promote unresolved policy into trusted state. A reviewer’s resolution is recorded with identity and policy version before resuming.

Initial proposed ceilings are one interpretation call and one optional explanation call, 10,000 input tokens per document batch, 60 seconds active processing and a configured spend cap. Oversized or unavailable evidence routes to review; context selection must not silently drop applicable exceptions. No open-ended “verify again” loop exists. Terminal outcomes include verified completion, partial completion, failure, cancellation and budget exhaustion; review is a durable waiting state. Checkpoint after admitted interpretation and calculation. Resume revalidates changed inputs/policy; downstream effects, if later added, require separate authorization and idempotent execution. Log run IDs, versions, transitions, cost and evaluator decisions.

## Baseline, ablations and the second model

Use held-out representative documents with expert-adjudicated meanings and expected totals. Compare regex plus deterministic arithmetic, one-model interpretation plus that same arithmetic, and—with justification—a second model checking consequential interpretations. Keep rules, source context and arithmetic constant so improvements can be attributed. Also ablate source spans, contradiction handling and optional model explanations. Evaluate semantic correctness, unsupported conclusions, conflict escalation, arithmetic exactness, latency and cost. Include bad variants that flatten negation or manufacture precedence; the evaluation must reject them.

A second model could help detect semantic mistakes if it demonstrably catches errors the interpreter misses and its added latency/cost are acceptable. Different prompts or models do not establish independent judgment; correlated mistakes remain possible. Give the checker original evidence, test disagreement handling, and send unresolved disagreement to review. Do not use a second model to approve arithmetic that code can check exactly, or as a vote that creates policy authority.

Release requires exact arithmetic and zero unsupported critical decisions in the agreed test set, plus predeclared semantic-quality and operational thresholds against the baseline. No results have been measured here. Unknown policy precedence and rounding rules need owner decisions; the value of a second model needs the controlled ablation. Adopt a framework only if demonstrated resumability or tracing needs exceed a small state machine and queue.
