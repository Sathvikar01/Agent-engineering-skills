Use a deterministic workflow with model-powered interpretation for policy documents, and deterministic software for typed invoice arithmetic. Known next steps do not justify an autonomous loop. Five agents add coordination and failure paths without a demonstrated need for independent contexts or adaptive decisions.

Policy success means extracting meaning with evidence, preserving exceptions and uncertainty, calculating correct totals, and explaining the result faithfully. “Avoid AI” does not establish that regex can recover meaning. Matching “eligible” can also match “not eligible”; a global negation rule can mishandle exceptions. Paraphrases and contradictions require contextual interpretation and sometimes an unresolved outcome. These are failure-mode examples, not measured benchmark results.

The fixed graph should be: source ingestion → interpretation → validation → calculation → explanation → outcome verification → durable result. The model returns a constrained intermediate representation: claims, applicability conditions, exceptions, source passages, account identities, and unresolved conflicts. An authoritative precedence rule may settle a conflict deterministically. Where no such rule exists, require review or clarification instead of inventing precedence. Regex can still locate identifiers and candidate passages where its contract is clear.

| Responsibility | Owner and boundary |
|---|---|
| Document meaning | Model proposes interpretations with source references; document text remains untrusted input. |
| Validation | Application checks schema, IDs, citations, completeness, contradictions, and applicable authoritative rules. Passing a schema does not prove semantic correctness. |
| Calculation | Deterministic code uses validated typed quantities, currency, decimal arithmetic, explicit rounding, and tax/discount rules. |
| Explanation | Template or bounded model step describes approved interpretations and computed results; every material claim must agree with them. |
| Authority and state | Application owns policy versions, calculation records, review status, and final outcome. Model prose cannot change these. |

For typed invoices, use input validation → deterministic calculation → deterministic reconciliation → formatted explanation. Arithmetic requires no model. Document interpretation is a separate ingestion requirement. Any model-generated explanation receives verified numbers rather than recalculating them.

A happy trajectory identifies a negated condition and exception, cites both, passes validation, computes the amount, and explains that record. Conflicting accounts without trusted precedence instead produce needs review before calculation. Malformed invoice currency or unsupported rounding rules fail admission. These outcomes are part of correctness.

Establish baselines before adding complexity. Build an independently labeled representative set covering negation, nested exceptions, paraphrases, contradictions, clear policies, and abstention cases. Keep a separate held-out release set. Evaluate semantic accuracy, unsupported assertions, unresolved-conflict handling, downstream total accuracy, latency, cost, and review burden. Proposed comparisons are:

| Candidate | Decision it tests |
|---|---|
| Existing process and regex-only pipeline | Whether deterministic interpretation actually meets the task’s acceptance cases. |
| Fixed workflow with one interpreter | Whether a bounded semantic step improves outcome quality enough to justify its cost. |
| Same workflow with a second independent interpretation or verifier | Whether disagreement handling reduces material semantic errors beyond the one-model baseline. |
| Deterministic typed arithmetic versus proposed agent framework | Whether agents add any measurable benefit for a task with fully specified rules. |

Select the least complex candidate meeting predeclared quality and operational thresholds. Require no arithmetic discrepancy against reference calculations, and no unsupported finalized result for designated contradictory cases. Specify acceptable semantic error rates with stakeholders before examining results. No candidate has been benchmarked here; the provisional choice is one semantic step and deterministic arithmetic, with additional-model and multi-agent designs withheld pending evidence.

A second model may help when it has meaningfully different evidence, independently assesses interpretation, or detects a class of errors the first misses. Agreement is not proof: shared training, prompts, and sources can produce correlated mistakes. It adds little to arithmetic, where deterministic checks are stronger. It must not arbitrate permission or policy authority. Test its marginal error reduction, including both models being wrong, against added latency, spend, and review load.

Persist source and policy versions, interpreted records, validated inputs, totals, and evaluator outcomes. Bound context, model calls, and time; terminate on missing evidence, validation failure, or budget exhaustion. Resume from durable validated checkpoints. This is a design decision, with all experiments and release checks proposed and unexecuted.
