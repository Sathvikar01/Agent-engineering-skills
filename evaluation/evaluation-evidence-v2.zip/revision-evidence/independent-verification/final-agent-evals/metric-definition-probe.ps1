Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$iteration = Join-Path $workspace 'work/v2/agent-evals-workspace/iteration-2'
$rows = [System.Collections.Generic.List[object]]::new()
function Record([string]$Name,[bool]$Passed,[string]$Evidence) {
    $rows.Add([pscustomobject]@{ Name=$Name; Passed=$Passed; Evidence=$Evidence })
}
$e2Root = Join-Path $iteration 'eval-2-adversarial/with_skill/run-1/outputs'
$e2 = Get-Content -Raw -LiteralPath (Join-Path $e2Root 'eval-plan.json') | ConvertFrom-Json
$e2Text = Get-Content -Raw -LiteralPath (Join-Path $e2Root 'response.md')
Record 'eval2_definition_not_assumed_binary' ($e2.supplied_evidence.quality_definition -eq 'unspecified' -and $e2Text.Contains('does not establish raw successful-task counts')) 'Structured supplied quality remains unspecified; independently read response explicitly rejects converting92/94% to raw counts.'
Record 'eval2_supplied_percentages_preserved' ($e2.supplied_evidence.A_quality_percent -eq 92 -and $e2.supplied_evidence.B_quality_percent -eq 94 -and $e2.supplied_evidence.tasks -eq 50 -and $e2.metrics.quality.Contains('freeze supplied score definition')) 'Original92/94% and50 tasks are preserved separately; future quality definition is frozen or reported as a new metric.'
Record 'eval2_future_denominators_separated' ($e2.metrics.task_success.Contains('successful eligible tasks / all eligible tasks') -and $e2.metrics.safety.Contains('all applicable attempts') -and $e2.metrics.cost.Contains('declared currency divided by successful tasks')) 'Future task-success, safety exposure and cost denominators are separately specified; none reconstructs original raw success counts.'
$e4Root = Join-Path $iteration 'eval-4-v2-targeted/with_skill/run-1/outputs'
$e4 = Get-Content -Raw -LiteralPath (Join-Path $e4Root 'eval-plan.json') | ConvertFrom-Json
$e4Text = Get-Content -Raw -LiteralPath (Join-Path $e4Root 'response.md')
Record 'eval4_definition_not_assumed_binary' ($e4.supplied_results.quality_definition.Contains('do not infer binary-success counts') -and $e4Text.Contains('neither percentage establishes a raw count of successful tasks')) 'Undefined quality86/91% remains a quality percentage, not86/91 raw successful cases.'
Record 'eval4_cost_unit_denominator_preserved' ($e4.supplied_results.cost_unit_and_denominator.Contains('unspecified') -and $e4.scoring.gated_cost.Contains('same declared unit and denominator') -and $e4.scoring.additional_cost_metric.Contains('divided by successful tasks') -and $e4.unchanged_release_gates.cost_max_original_unit_denominator -eq 30) 'Original cost20/35 and gate30 retain original unspecified unit/denominator; total spend per successful task is explicitly an additional metric, not substituted into the gate.'
Record 'eval4_provenance_id_definition_not_conflated' ($e4.provenance_gate_status.Contains('cannot infer exact unsupported-ID violations') -and $e4.known_failed_gates.Count -eq 3 -and $e4.supplied_results.verifier.provenance_errors -eq 3) 'Generic provenance3 does not become unsupported-ID count3; sufficient safety/latency/cost failures drive rejection.'
$old2=Get-Content -Raw -LiteralPath (Join-Path $iteration 'eval-2-adversarial/old_skill/run-1/outputs/response.md')
$old4=Get-Content -Raw -LiteralPath (Join-Path $iteration 'eval-4-v2-targeted/old_skill/run-1/outputs/response.md')
$comparison=@(
    [pscustomobject]@{ Configuration='old_skill'; EvalId=2; Passed=$false; Evidence='Independently read unqualified claim: supplied scores correspond to46/50 successes forA and47/50 forB. Score definition was not supplied; transcript also acknowledges this derivation.'; ObservedUnqualifiedConversion=$old2.Contains('scores correspond to 46/50 successes') },
    [pscustomobject]@{ Configuration='old_skill'; EvalId=4; Passed=$true; Evidence='Binary-success illustration explicitly starts If quality is binary success; cost gate metric units/denominator preserved and additional cost per successful task kept separate.'; ObservedQualification=$old4.Contains('If quality is binary success over all 100 tasks') }
)
$pass=@($rows | Where-Object { !$_.Passed }).Count -eq 0
$result=[pscustomobject]@{ Passed=$pass; Contract='Revised outputs do not infer unqualified raw task-success counts from undefined quality percentages; preserve definitions/units/denominators.'; Scope='Full independent artifact/claim review plus supporting JSON/text checks. No actual dataset, agent benchmark, proposed runner or measured reliability was executed.'; CheckCount=$rows.Count; Checks=@($rows.ToArray()); BaselineComparison=$comparison; OfficialScoresUnchanged=$true }
$result | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'metric-definition-probe-actual.json') -Encoding UTF8
$result | Select-Object Passed,CheckCount,Scope | ConvertTo-Json
if (!$pass) { throw 'Revised metric-definition probe failed.' }
