"""Independent local verification; executor sources are copied, never altered."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT / 'work/v2/agent-cost-and-latency-workspace/iteration-1'
DEST = Path(__file__).parent
PROBE = r'''
import json, sys
from pathlib import Path
source, config, folder = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
namespace = {'__file__': str(source), '__name__': '__main__'}
text = source.read_text(encoding='utf-8')
prefix = text.split('passed = []')[0] if config == 'with_skill' else text.split('class AcceptanceTests')[0]
exec(compile(prefix,str(source),'exec'),namespace)
C,M,L = [namespace[name] for name in ('Cache','Mutations','Ledger')]
def denied(call):
    try: call()
    except (ValueError, RuntimeError, PermissionError): return True
    return False
results={}
c=C()
if config=='with_skill':
    ctx=dict(tenant='A',principal='P',permission_epoch=1,permission_digest='read',model='m',prompt='p',schema='s',tool='t',index='i',freshness='f')
    payload={'id':1}
    c.put(ctx,payload,'A-only',0,10)
    results['tenant_miss']=c.get({**ctx,'tenant':'B'},payload,1,True) is None
    results['prompt_miss']=c.get({**ctx,'prompt':'p2'},payload,1,True) is None
    results['access_epoch_miss']=c.get({**ctx,'permission_epoch':2},payload,1,True) is None
    results['current_revocation']=c.get(ctx,payload,1,False) is None
    results['expiry_boundary']=c.get(ctx,payload,10,True) is None
    results['approval_denied']=denied(lambda:c.put(ctx,payload,'grant',0,10,'approval'))
    m=M();results['prerequisite_denied']=denied(lambda:m.second(0,'b')) and m.version==0 and not m.first_committed
    version=m.first(0,'a');results['stale_denied']=denied(lambda:m.second(0,'b')) and m.version==1
    results['ordered_two_effects']=m.second(version,'b')==2 and m.version==2
    path=folder/'probe.sqlite';l=L(path,'retained');l.create(100)
    assert l.reserve('done',60);l.settle('done',40);assert l.reserve('pending',60)
    r=L(path,'retained');results['retained_aggregate_blocks']=r.state()==(100,40,60) and not r.reserve('extra',1)
    results['changed_retry_denied']=denied(lambda:r.reserve('pending',61))
    results['pending_replay_result']=r.reserve('pending',60)
    results['pending_replay_state']=r.state()
    b=L(folder/'bool.sqlite','b');b.create(1);results['bool_as_amount_accepted']=b.reserve('b',True);results['bool_amount_state']=b.state()
    z=M();z.first(0,'shared');results['cross_operation_same_key_second_result']=z.second(1,'shared');results['cross_operation_same_key_version']=z.version
else:
    K=namespace['Key'];replace=namespace['replace'];key=K();c.put(key,'A-only',0,10)
    results['tenant_miss']=c.get(replace(key,tenant='B'),1,True) is None
    results['prompt_miss']=c.get(replace(key,prompt='p2'),1,True) is None
    results['permissions_miss']=c.get(replace(key,permissions='revoked-v2'),1,True) is None
    results['current_revocation']=denied(lambda:c.get(key,1,False))
    results['expiry_boundary']=c.get(key,10,True) is None
    results['approval_denied']=denied(lambda:c.put(key,'grant',0,10,'approval'))
    m=M();results['prerequisite_denied']=denied(lambda:m.activate(0)) and m.events==[] and m.version==0
    m=M();results['failed_predecessor_stops']=denied(lambda:m.ordered_chain(fail=True)) and m.events==['create'] and m.version==0
    m=M();results['stale_denied']=denied(lambda:m.ordered_chain(conflict=True)) and m.events==['create']
    m=M();m.ordered_chain();results['ordered_two_effects']=m.events==['create','activate'] and m.version==2
    path=folder/'probe.sqlite';l=L(path,100);assert l.reserve('done',60);l.settle('done',40);assert l.reserve('pending',60)
    r=L(path,100);results['retained_aggregate_blocks']=r.usage()==100 and not r.reserve('extra',1)
    results['changed_retry_denied']=denied(lambda:r.reserve('pending',61))
    results['pending_replay_result']=r.reserve('pending',60);results['pending_replay_usage']=r.usage()
    results['cap_change_denied']=denied(lambda:L(path,200))
    b=L(folder/'bool.sqlite',1);results['bool_as_amount_accepted']=b.reserve('b',True);results['bool_amount_usage']=b.usage()
for k,v in results.items():print(k+': '+json.dumps(v))
for k in ('tenant_miss','prompt_miss','current_revocation','expiry_boundary','approval_denied','prerequisite_denied','stale_denied','ordered_two_effects','retained_aggregate_blocks','changed_retry_denied'):
    assert results[k],k
print('LIMITS: synthetic local fixtures; authorization is an input/design, not a policy engine; no actual provider billing, process-crash recovery, distributed deployment or latency experiment. Bool and replay results are observations, not assertions of production safety.')
'''

def hashes():
    return {str(p.relative_to(BASE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in BASE.rglob('*') if p.is_file()}

before=hashes()
for ident,name in ((2,'eval-2-adversarial'),(4,'eval-4-v2-targeted')):
    for config in ('with_skill','old_skill'):
        output=BASE/name/config/'run-1/outputs'
        script=output/('acceptance_fake.py' if ident==2 else ('verify_arithmetic.py' if config=='with_skill' else 'arithmetic_check.py'))
        with tempfile.TemporaryDirectory(prefix='fixture-',dir=DEST) as temp:
            directory=Path(temp);copy=directory/script.name;copy.write_bytes(script.read_bytes())
            command=[sys.executable,'-X','utf8','-B',str(copy)]
            run=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',cwd=directory)
            log='SOURCE '+str(script)+'\nCOPIED SOURCE SHA256 '+hashlib.sha256(copy.read_bytes()).hexdigest()+'\nCOMMAND '+repr(command)+'\nEXIT '+str(run.returncode)+'\n'+run.stdout+run.stderr
            if ident==2:
                probe=directory/'probe.py';probe.write_text(PROBE,encoding='utf-8')
                cmd=[sys.executable,'-X','utf8','-B',str(probe),str(copy),config,str(directory)]
                extra=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',cwd=directory)
                log+='\nINDEPENDENT PROBE COMMAND '+repr(cmd)+'\nEXIT '+str(extra.returncode)+'\n'+extra.stdout+extra.stderr
                assert extra.returncode==0,log
            (DEST/f'eval-{ident}-{config}.log').write_text(log,encoding='utf-8')
            assert run.returncode==0,log
            print(f'{ident}/{config}: original copied script and independent probes exit0')
after=hashes()
assert before==after,'Archived executor artifact changed'
(DEST/'artifact-preservation.json').write_text(json.dumps({'all_original_files_unchanged':True,'sha256':before,'original_file_count':len(before),'fixtures':'copies in temporary directories removed after subprocess completion'},indent=2)+'\n',encoding='utf-8')
print('Original artifact hash preservation verified:',len(before),'files')
