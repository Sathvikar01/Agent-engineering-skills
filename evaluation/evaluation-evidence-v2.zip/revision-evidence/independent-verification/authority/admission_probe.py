import copy
import json
import sys
import threading
from dataclasses import replace
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
kind, config = sys.argv[1:]
if kind == 'budget':
    if config == 'with_skill':
        import admission_fake as fake
        ex = fake.setup()
        names = ['A', 'B']
        def execute(name):
            return ex.execute(key=name, token=name, amount=60)
    else:
        import budget_admission as fake
        ex = fake.Executor()
        names = ['worker-A', 'worker-B']
        assert ex.preflight(60)['decision'] == ex.preflight(60)['decision'] == 'allow'
        for name in names:
            ex.issue_approval(name, name, 60)
        def execute(name):
            return ex.execute(name, name, 60, name)
    gate = threading.Barrier(2)
    results = {}
    errors = []
    def worker(name):
        try:
            gate.wait(timeout=5)
            results[name] = execute(name)
        except Exception as error:
            errors.append(repr(error))
    threads = [threading.Thread(target=worker, args=(name,)) for name in names]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=5)
    assert not errors and not any(thread.is_alive() for thread in threads)
    assert ex.remaining == 40 and len(ex.receipts) == 1
    if config == 'with_skill':
        assert sorted(value[0] for value in results.values()) == ['committed', 'deny']
        ex.issue('rest', 40)
        rest = ex.execute(key='rest', token='rest', amount=40)
        ex.issue('extra', 1)
        before = copy.deepcopy(ex.state())
        overflow = ex.execute(key='extra', token='extra', amount=1)
        assert rest[0] == 'committed' and overflow == ('deny', 'INSUFFICIENT_BUDGET')
    else:
        assert sorted(value['decision'] for value in results.values()) == ['allow', 'deny']
        ex.issue_approval('rest', 'worker-A', 40)
        rest = ex.execute('worker-A', 'rest', 40, 'rest')
        ex.issue_approval('extra', 'worker-A', 1)
        before = copy.deepcopy(ex.state())
        overflow = ex.execute('worker-A', 'extra', 1, 'extra')
        assert rest['decision'] == 'allow' and overflow['reason'] == 'insufficient_budget'
    assert ex.state() == before and ex.remaining == 0 and len(ex.receipts) == 2
    print(json.dumps(dict(configuration=config, simultaneous=results, fresh40=rest, extra1=overflow, remaining=ex.remaining, effects=len(ex.receipts)), indent=2))
else:
    import candidate_controller as fake
    invalid = dict(amounts=[40, 40], days=[10, 20])
    valid = dict(amounts=[40, 60], days=[10, 20])
    if config == 'with_skill':
        context = fake.Context('actor', True)
        state = fake.FakeState()
        before = copy.deepcopy(state.__dict__)
        first = fake.execute_fake(context, state, invalid, 'same-request', state.version)
        assert first == ('deny', 'INVALID_TOTAL') and state.__dict__ == before
        revoked = fake.execute_fake(replace(context, can_choose_plan=False), state, valid, 'same-request', state.version)
        assert revoked == ('deny', 'NO_PERMISSION') and state.__dict__ == before
        print(json.dumps(dict(configuration=config, first=first, fresh_alternative_revoked=revoked, state=state.__dict__), indent=2))
    else:
        controller = fake.Controller(fake.Context('actor', True))
        before = copy.deepcopy(controller.state)
        first = controller.run(invalid, max_candidates=1)
        assert first['audit'][-1]['reason'] == 'total_mismatch' and controller.state == before
        controller.context = replace(controller.context, may_choose_plan=False)
        revoked = controller.run(valid, max_candidates=1)
        assert revoked['audit'][-1]['reason'] == 'forbidden' and controller.state == before and controller.effects == []
        print(json.dumps(dict(configuration=config, first_decision=first['audit'][-1], fresh_alternative_revoked=revoked['audit'][-1], state=controller.state, effects=controller.effects), indent=2))
