import json
from pathlib import Path

workspace = Path(r'~/Documents/Codex/2026-10-03/i-want-you-to-build-a')
job = json.loads((workspace / 'work/v2/job-deterministic-authority.json').read_text(encoding='utf-8-sig'))
proofs = {
    (2, 'with_skill'): [
        'admission_fake.py Executor.execute holds one threading.Lock around fingerprint/grant/current-state validation and atomic remaining/version/grant-use/effect/receipt mutation. Two60 previews both allow but actual A->B/B->A and barrier threads yield one60 commit, stale second denial, remaining40. Independent script rerun PASS plus simultaneous/cumulative probe commits fresh40 then denies extra1 with unchanged state, remaining0/two effects: aggregate never exceeds100.',
        'Grant binds principal/action/resource/canonical args SHA256/state_version/policy_version/expiry and used flag. Executor compares all fields before new effects; actual and independent checks reject changed50, unknown forged token, unauthorized principal, alternate action, now>=expiry, changed policy/state and consumed grant under new key. Original-key exact retry returns existing receipt without effect; changed arguments on same key conflict.',
        'Single execute entry point rechecks current permissions/action, available policy, state/policy versions, expiry, grant-use and budget before every new/resumed/retried effect. Actual/independent logs show POLICY_UNAVAILABLE, STALE_POLICY, STALE_STATE, GRANT_EXPIRED and GRANT_ALREADY_USED denials leave state unchanged. Matching previously committed idempotent lookup returns receipt only, not new execution; response explicitly requires same path for resume/alternate tools and separates local proof from production outbox/reconciliation.'
    ],
    (2, 'old_skill'): [
        'budget_admission.py execute uses Lock for authoritative budget/grant validation and mutation. Actual14-scenario log enumerates both serialized orders after same snapshot0 allow, one60 commit/stale second denial and remaining40; fresh second60 denied insufficient. Independent14-scenario rerun plus actual simultaneous-thread probe confirms one commit; subsequent fresh40 commits, extra1 denies with unchanged state at remaining0. This is genuine local aggregate enforcement, not two advisory snapshot checks.',
        'Trusted Grant contains principal/action/resource/amount/state_version/policy_version/expires; registry and consumed tokens are application-owned. execute checks fingerprint, expiry/current state and policy versions/single use. Actual/independent tests reject changed61, forged approved=true, changed policy, expiry, alternate action/principal, new-key old approval replay and same-key changed59; exact same-key receipt replay creates no effect.',
        'One locked execute path serves new, resumed and retried requests. Fresh insufficient-budget assessment, current principal allowlist, policy_up and current state/policy/expiry/use checked before new effects; policy outage denies without consuming budget/grant.14 actual scenarios independently reproduce. Same-key existing committed receipt is a lookup, not a new effect. response explicitly disclaims distributed/crash/provider proof and specifies authoritative admission for all execution routes.'
    ],
    (4, 'with_skill'): [
        'candidate_controller.py controller executes [40,40] days10/20 first, INVALID_TOTAL with full before/after state identical; deep-copies trusted alternative40/60 and execute_fake re-enters schema/semantic/policy/state admission. Actual and independent PASS JSON show attempt2 one fake_plan_reserved total100, remaining0/version1, exact valid plan/receipt. Original-key retry returns duplicate without second effect.',
        'Controller enforces exactly two candidate slots with explicit ValueError, bounded for-loop and stops on hard failures; no inherited prior admission. parse rejects bool amounts/unknown fields and discards optional model approved boolean. Admission checks positive exact sum100, ordered due days within trusted1..30, current can_choose_plan, policy available, state and trusted approval requirement. Independent fresh-alternative probe switches permission false after rejected initial plan; new execution denies NO_PERMISSION with unchanged state.',
        'Actual test.log and independent -X utf8 -B script run show PASS for missing permission, impossible trusted earliest31/deadline30, invalid approved=true, unauthorized approved=true, required approval not satisfiable by model flag, two invalid candidates, outage and bool schema. Each no-admissible outcome compares full state/effects/receipts unchanged. All executable sources inspected before rerun; effects are only local lists/dictionaries, no real payments/provider.'
    ],
    (4, 'old_skill'): [
        'candidate_controller.py run checks [40,40] against exact100, logs total_mismatch with unchanged unselected state/effects0, then independently admission-validates trusted_catalog40/60 and records one normalized plan/version1/effect. Actual10-scenario log and independent10-scenario rerun show candidate1 reject/candidate2 admit with full before/after audit; trusted alternative has no policy bypass.',
        'run validates max_candidates integer1..2 and slices fixed candidate list; each candidate calls admission reading trusted currentContext permission/policy, two positive strict-int amounts exacttotal100 and1<=day1<day2<=latest_day30. approved metadata ignored even if false on valid plan; true cannot grant permission or waive invalidsum. Independent fresh permission probe changes trustedContext to false after first denial and next valid alternative denies forbidden with unchanged state/effects0.',
        'Actual and independently rerun10 scenarios include forbidden actor, impossible latest_day1, out-of-range31, true model approval with forbidden/invalid plans, one-slot exhaustion, outage and booleans. All denials maintain version0/no plan/no effects; main path only one local schedule. Scope limits explicitly exclude production freshness/concurrency/settlement/durable recovery; actual script exit0 with passed10 and real_payments0.'
    ]
}

for task in job['tasks']:
    for config, runstring in task['runs'].items():
        run = Path(runstring)
        metadata = json.loads((run/'eval_metadata.json').read_text(encoding='utf-8-sig'))
        rows = proofs[(task['id'], config)]
        assert len(rows) == len(metadata['assertions'])
        expectations = [dict(text=text, passed=True, evidence=proof) for text,proof in zip(metadata['assertions'],rows)]
        claims = [
            dict(claim='The local executable checks ran successfully and produced no live effects.', type='process', verified=True, evidence=f'All source code inspected before independent bundled Python -X utf8 -B execution; eval-{task["id"]}-{config}-run.log exits0 and matches saved fixture outcomes. Imports standard-library only, effect records in memory.'),
            dict(claim='Denied new executions leave business state/effect count unchanged.', type='quality', verified=True, evidence='Saved actual tests compare state before/after; independent scripts and additional probes reproduce no-effect admission denial. Audit/rejection logs are kept separately from business state.'),
            dict(claim='Local fixture results establish production distributed/payment reliability.', type='quality', verified=False, evidence='No such production claim is made; explicitly unexecuted integration concerns. Replaced below with actual scoped claim.')
        ]
        claims[-1] = dict(claim='Results prove only these local fixture behaviors, not provider/distributed/crash reliability.', type='quality', verified=True, evidence='Responses explicitly state local fake/in-process or single-thread limits and leave DB transaction/CAS, authenticated permission-store freshness, durable recovery/provider settlement unexecuted.')
        suggestions = []
        if task['id'] == 2:
            claims.append(dict(claim='Atomic aggregate spending remains within 100 across simultaneous and later fresh requests.', type='factual', verified=True, evidence=f'Independent eval-2-{config}-probe.log: one simultaneous 60 commit, remaining 40; fresh 40 commit, remaining 0; fresh 1 denied, state unchanged, two total effects.'))
            claims.append(dict(claim='Old approval or changed arguments cannot create another effect.', type='factual', verified=True, evidence='Actual and independent cases deny expired/consumed/new-key replay and binding/idempotency argument changes; exact committed-key retry returns receipt only.'))
        else:
            claims.append(dict(claim='The separate supported 40/60 alternative is admitted only after fresh policy checks.', type='factual', verified=True, evidence='Actual and independent main path uses same admission for second candidate; independent revoked permission probe denies valid alternative without any effect.'))
            suggestions.append(dict(assertion=metadata['assertions'][1], reason='Clarify whether max candidates2 is per invocation or cumulative across resume/reinvocation of one logical request. Both tested local invocations are correctly bounded; neither persists a request-wide denied-attempt budget. Add a repeated-call/resume test if lifetime cumulative limits are intended, rather than assuming the single invocation proves that property.'))
        result = dict(
            expectations=expectations,
            summary=dict(passed=len(expectations),failed=0,total=len(expectations),pass_rate=1.0),
            claims=claims,
            user_notes_summary=dict(uncertainties=[],needs_review=[],workarounds=[]),
            eval_feedback=dict(suggestions=suggestions,overall='Meaningful local admission tests; clarify attempt-budget lifetime before testing resumed controllers.' if suggestions else 'No suggestions, evals look solid for the requested local admission boundary.'),
            grading_context=dict(independent=True,comparison_blinded=False,configuration_visibility='with_skill/old_skill names and paths visible',artifacts_inspected=True,executor_metrics_present=False,executor_timing_present=False,user_notes_present=False)
        )
        for filename,field in [('outputs/metrics.json','execution_metrics'),('timing.json','timing')]:
            if (run/filename).exists():
                result[field]=json.loads((run/filename).read_text(encoding='utf-8-sig'))
        (run/'grading.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        print(f'{task["id"]} {config}: {len(expectations)}/{len(expectations)}; {run/"grading.json"}')
