"""Independent supplied-fixture arithmetic/design checks; no model/RAG pipeline."""
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[4]
DEST=Path(__file__).resolve().parent
BASE=ROOT/"work/v2/rag-engineering-workspace/iteration-1"
ranking=["B","A","A","C"];gold={"A","C"};k=3
raw_cut=ranking[:k];raw_hits=set(raw_cut)&gold
unique=list(dict.fromkeys(ranking));dedup_hits=set(unique[:k])&gold
raw_recall=len(raw_hits)/len(gold);dedup_recall=len(dedup_hits)/len(gold)
first=next(i for i,doc in enumerate(ranking,1) if doc in gold);rr=1/first
assert (raw_recall,dedup_recall,rr)==(.5,1,.5)
source=BASE/"eval-2-adversarial/old_skill/run-1/outputs/metrics-check.ps1"
# Entire original arithmetic script was read before execution; it is local-only.
result=subprocess.run(["C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe","-NoProfile","-File",str(source)],capture_output=True,text=True,encoding="utf-8",errors="replace")
(DEST/"original-baseline-arithmetic-rerun.log").write_text("reviewed_script="+str(source)+"\n"+result.stdout+result.stderr+"exit_code="+str(result.returncode)+"\n",encoding="utf-8")
assert result.returncode==0,result.stderr
for ident,name in ((2,"eval-2-adversarial"),(4,"eval-4-v2-targeted")):
    for config in ("with_skill","old_skill"):
        run=BASE/name/config/"run-1";outputs=run/"outputs"
        text=(outputs/"response.md").read_text(encoding="utf-8-sig")
        note={"grader_identity":"/root/v2_grade_remaining","comparison_blinded":False,"run":str(run),"response_words":len(text.split()),"artifact_review_complete":True,"runtime":sys.executable,"fixture_arithmetic":{"raw_ranking":ranking,"gold":sorted(gold),"raw_cutoff":raw_cut,"raw_unique_relevant":sorted(raw_hits),"raw_cutoff_recall_at_3":raw_recall,"stable_unique_before_cutoff":unique,"dedup_first_recall_at_3":dedup_recall,"first_relevant_rank":first,"reciprocal_rank":rr} if ident==2 else None,"design_lineage":{"retrieved":["A","B"],"context_visible":["A","B"],"decision_used_for_total":["A"],"bad_final_cited":["B","Z"],"source_validated_total":100,"bad_final_total":120,"conflict":120!=100,"normalization_gap":"N1 missing observed A/version/span ancestry"} if ident==4 else None,"pipeline_or_semantic_behavior_executed":False,"no_live_effects":True,"limits":"Arithmetic uses symbolic task facts; support relationships are supplied premises. No actual corpus/source spans, model/provider calls, fake pipeline, injection/security test, heldout results, latency/cost or causal ablation was executed. Design lineage comparisons cannot establish real provider support."}
        (DEST/("eval-"+str(ident)+"-"+config+".json")).write_text(json.dumps(note,indent=2)+"\n",encoding="utf-8")
        print(str(ident)+"/"+config+": reviewed; fixture math/design notes saved, no pipeline behavior claimed")
