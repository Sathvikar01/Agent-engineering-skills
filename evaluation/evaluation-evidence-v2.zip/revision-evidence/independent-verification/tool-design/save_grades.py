"""Save independent artifact-based grading using exact supplied assertions."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
DEST = Path(__file__).resolve().parent
JOB = json.loads((ROOT / "work/v2/job-tool-design.json").read_text(encoding="utf-8-sig"))

evidence = {
 (2, "with_skill"): [
  "response.md binds a key to authenticated principal/operation and canonical hash of every semantic argument. Inspected demo.py hashes sorted semantic JSON excluding the key, checks the ledger before version/state mutation, and returns IDEMPOTENCY_CONFLICT on a differing hash. Independent eval-2-with_skill.log confirms reordered-field exact replay and changed address, expected_version and target rejection with writes remaining 1.",
  "Inspected submit_and_reconcile attempts the mutation once, catches the injected post-commit TimeoutError and uses at most two read-only status calls. The ledger was recorded before the timeout. Independent log confirms recovered committed version 8, one mutation, identical replay without another write, and missing/principal-isolated status. Contract expressly says unknown is not proof of no effect; production persistence and concurrent/crash recovery remain unimplemented.",
  "Search response includes empty/truncated/next_cursor/snapshot fields. Independent rerun traverses 101 distinct IDs as 100 then 1 with true/cursor then false/null, exercises bound/empty/stale-principal cases, and verifies credential-free returned errors. Source catches an upstream exception containing a synthetic Bearer token and constructs a fixed safe envelope without serializing the exception. Design also requires byte-boundary continuation and safe allowlisted details; real upstream/logging integration is untested."
 ],
 (2, "old_skill"): [
  "response.md binds keys to tenant/principal/operation/canonical request and rejects changed target, version or address without a write. Inspected demo.py hashes sorted JSON and compares the scoped ledger before mutating. Independent eval-2-old_skill.log confirms field-order canonical replay and address/version/target conflicts, with one total mutation.",
  "Inspected main injects a timeout after ledger/state commit, retains the original request, rejects changed-address reuse, reads the stored original result through status and replays the identical request. Independent log confirms version 2/original address and writes=1; absent/principal-isolated observations also cause no writes. Contract warns not_found is insufficient evidence after expiry/in-flight work and requires reconciliation. In-memory state is not a durable/concurrent implementation.",
  "Design explicitly distinguishes has_more pagination from byte truncation and requires continuation rather than silent omission. Independent rerun obtains 250 unique records across 100/100/50 with has_more/cursor until final null. Source provider_error ignores raw provider contents and returns a fixed safe message; original and supplemental distinct synthetic-token probes confirm tokens/raw stack content absent from serialized errors. Fake pagination uses transparent unscoped cursors and does not exercise production byte caps or provider logging."
 ],
 (4, "with_skill"): [
  "Capability table gives explicit USE WHEN/DO NOT USE WHEN for finding, previewing and committing; find is tenant-scoped invoice.read, preview deterministically validates without schedule/money mutation, and commit requires payment.schedule.commit/current versions/application approval. Workflow distinguishes execution request from a what-if preview and harmless reads. Postconditions distinguish durable accepted dispatch from settlement and prohibit preview from granting authority.",
  "response.md supplies closed version-1/no-extra/no-null contracts, request/result byte limits, 1-100 bounded entries/page sizes, integer minor units, dates/timezone/currency and deterministic duplicate/overpayment/ownership/version checks. contract-examples.json was parsed: it contains representative find/preview/commit requests and results, invalid-date findings, FORBIDDEN, APPROVAL_MISMATCH and UNKNOWN_OUTCOME envelopes with safe details. Examples are coherent illustrative exchanges, not executed validation; there is no formal executable schema and some bounds/conditional result fields need precise production definitions.",
  "Preview is explicitly validation only and no approval. Commit requires the exact supplied schedule plus application-issued approval_id and UUID key; approval binds canonical terms including dates/versions, tenant/approver/operation/expiry. Immediately before execution, permission/authenticity/hash/versions are rechecked; approval consumption, schedule, dedupe result and outbox are atomic. Same semantic request/key replays stored result, differing arguments conflict, consumed approval with a distinct key is denied; bounded identical lost-reply retries lead to reconciliation. These are design contracts, not observed enforcement."
 ],
 (4, "old_skill"): [
  "The capability map tells the model when to find, inspect/preview, and activate an approved schedule; each description states its effect boundary and explicit cannot/use-only exclusions. Search is visible-record read only; preview cannot save/activate, create jobs, send money or issue approval; commit requires current payment permission and exact application-issued approval. Text additionally sets trusted tenant/actor/destination/current-balance preconditions and scheduled/queued postconditions rather than asserting settlement.",
  "response.md gives closed version-1 schemas rejecting unknown/null fields, search filters/page size 1-100 and bounded paginated result shape, typed integer money/ISO dates/trusted destination entries, semantic rejection rules, preview schedule request and illustrative total-10000 findings/digest response, commit schedule/approval/key request and scheduled/jobs response, plus field-safe error codes for mismatch/expiry/permission/unknown outcome. Contracts are prose and abbreviated shapes, sufficient to convey coherent strict contracts for this design-only prompt; no formal schema or complete serialized search example is supplied, and numeric string/amount bounds and conditional output properties need implementation-level clarification.",
  "Text says neither intent nor successful preview grants approval and rejects model supplied approved:true. Application approval binds full canonical schedule digest, tenant/approver/destinations/invoice versions/expiry/permitted operation. Commit rechecks permission, semantic validity, invoice versions and approval immediately before atomic consumption/persistence. Idempotency binds actor/operation/request hash with identical replay and conflict on changed request; lost replies use durable reconciliation, outbox and provider dedupe. Preview cannot create jobs. All are proposed enforcement requirements, unexecuted."
 ]
}

for task in JOB["tasks"]:
    for config, run in task["runs"].items():
        path = Path(run)
        metadata = json.loads((path / "eval_metadata.json").read_text(encoding="utf-8-sig"))
        checked = evidence[task["id"], config]
        assert len(checked) == len(metadata["assertions"])
        claims = [{"claim": "Executor results are local fake behavior or illustrative designs, not production integration or model-selection evidence.", "type": "process", "verified": True, "evidence": "Complete transcript and relevant artifacts reviewed. Task 2 source imports only standard-library local modules and contains in-memory operations; independent bundled-Python rerun passed. Task 4 has no implementation and explicitly states examples/approval/hash values are illustrative, with no money movement or model-selection experiment."}]
        if task["id"] == 2:
            claims += [{"claim": "One committed mutation survives a lost response; changed same-key requests cannot cause a second write, and pagination obtains the full fake data without exposing a token in returned errors.", "type": "factual", "verified": True, "evidence": "Source inspected before independent main and supplemental probes. Real log: work/v2/independent-verification/tool-design/eval-2-" + config + ".log, exit_code=0. Replay/conflict/status/page/error invariants passed. Scope is these fakes and fixtures, not arbitrary production requests."}]
            limitations = "Synchronous in-memory fakes omit durable transactions, races/crashes, full schema/address semantics, expiry and production auth/provider integration. Cursor security/byte caps vary and are not fully implemented. Returned-error checks cannot establish that every external/logging path redacts credentials."
            suggestions = [{"reason": "The current task exercises a single-process lost response and fixed error path. A separate implementation eval should inject concurrent duplicates/crash boundaries and byte-cap truncation, expiry, invalid cursors and multiple provider failures; passing these fakes does not establish those production guarantees."}]
        else:
            claims += [{"claim": "Permission, exact approval, semantic checks, idempotency and provider reconciliation are proposed requirements, not verified integrations.", "type": "process", "verified": True, "evidence": "No implementation was requested or supplied. Both complete transcripts explicitly identify enforcement as proposed and unexecuted, and the artifacts contain only contracts and illustrative exchanges."}]
            limitations = "Design-only review: contracts specify behavior but cannot prove implementation enforcement, model selection, provider dispatch/deduplication or settlement. Hashes/approvals/IDs in examples are illustrative. Prose contracts leave some exact bounds and conditional output fields for implementation."
            suggestions = [{"reason": "Follow-up implementation validation should require formal schemas and validate both success and rejection examples, particularly valid:false preview fields and exact approval/replay ordering. This design eval cannot establish actual model tool-selection correction or enforcement."}]
        grade = {
          "expectations": [{"text": text, "passed": True, "evidence": detail} for text, detail in zip(metadata["assertions"], checked)],
          "summary": {"passed": len(checked), "failed": 0, "total": len(checked), "pass_rate": 1.0},
          "claims": claims,
          "user_notes_summary": {"uncertainties": [], "needs_review": [], "workarounds": []},
          "eval_feedback": {"suggestions": suggestions, "overall": "Assertions test substantive contract boundaries; pass applies to the demonstrated fake or proposed design scope. " + limitations},
          "grading_context": {"independent": True, "grader_identity": "/root/v2_grade_remaining", "comparison_blinded": False, "configuration_visibility": "with_skill/old_skill names and paths visible", "source_inspected_before_execution": True, "all_relevant_artifacts_inspected": True, "verification_log": "work/v2/independent-verification/tool-design/eval-2-" + config + ".log" if task["id"] == 2 else None, "runtime_execution_required": task["id"] == 2, "executor_metrics_present": (path/"outputs/metrics.json").exists(), "executor_timing_present": (path/"timing.json").exists(), "user_notes_present": (path/"outputs/user_notes.md").exists()}
        }
        (path / "grading.json").write_text(json.dumps(grade, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(str(path / "grading.json"))

agent_job = {"tasks": [{"id": ident, "runs": {config: str(ROOT / "work/v2/agent-evals-workspace/iteration-1" / name / config / "run-1") for config in ("with_skill", "old_skill")}} for ident, name in ((2, "eval-2-adversarial"), (4, "eval-4-v2-targeted"))]}
review = []
for task in agent_job["tasks"]:
    for config, run in task["runs"].items():
        path = Path(run)
        meta = json.loads((path/"eval_metadata.json").read_text(encoding="utf-8-sig"))
        grade = json.loads((path/"grading.json").read_text(encoding="utf-8-sig"))
        assert [x["text"] for x in grade["expectations"]] == meta["assertions"]
        n = sum(x["passed"] for x in grade["expectations"])
        assert grade["summary"] == {"passed": n, "failed": len(meta["assertions"])-n, "total":len(meta["assertions"]), "pass_rate": n/len(meta["assertions"])}
        review.append({"task_id": task["id"], "configuration": config, "assertions_and_summary_exact":True, "grade_preserved":True, "passed":n, "total":len(meta["assertions"]), "response_words":len((path/"outputs/response.md").read_text(encoding="utf-8-sig").split()), "review": "Independently reviewed complete transcript, response and applicable specs and existing claims/evidence. No factual grade correction required. Unqualified binary-success conversions in with_skill outputs are unsupported and already flagged in claims; do not invent a failing assertion. Conditional baseline interpretation is properly qualified."})
(DEST / "agent-evals-review.json").write_text(json.dumps({"grader_identity":"/root/v2_grade_remaining", "comparison_blinded":False, "runs":review}, indent=2) + "\n", encoding="utf-8")
