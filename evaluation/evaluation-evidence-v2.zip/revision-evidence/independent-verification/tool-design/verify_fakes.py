"""Independent local-only checks of reviewed executor fakes; no source edits."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
JOB = json.loads((ROOT / "work/v2/job-tool-design.json").read_text(encoding="utf-8-sig"))
DEST = Path(__file__).resolve().parent

for config, run in JOB["tasks"][0]["runs"].items():
    source = Path(run) / "outputs/demo.py"
    spec = importlib.util.spec_from_file_location("reviewed_fake_" + config, source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    captured = io.StringIO()
    with contextlib.redirect_stdout(captured):
        module.main()
        api = module.Fake() if config == "with_skill" else module.FakeTools()
        key = "2bbeb21f-4d1c-41b6-b4b7-84bb376eef74"
        req = {"customer_id": "customer-001" if config == "with_skill" else "c-001",
               "expected_version": api.version, "address": "Supplemental address",
               "idempotency_key": key}
        result = api.change("independent", req)
        assert result["status"] == "committed" and api.writes == 1
        assert api.change("independent", dict(reversed(list(req.items())))) == result
        for field, value in (("address", "Changed address"),
                             ("expected_version", req["expected_version"] + 1),
                             ("customer_id", "different-target")):
            conflict = api.change("independent", {**req, field: value})
            code = conflict["error"]["code"] if config == "with_skill" else conflict["code"]
            assert code == "IDEMPOTENCY_CONFLICT" and api.writes == 1
            print("supplemental changed semantic argument rejected:", field)
        absent = api.status("independent", "absent-operation")
        assert absent["status"] in {"unknown", "not_found"} and api.writes == 1
        assert api.status("different-principal", key)["status"] in {"unknown", "not_found"}
        print("supplemental canonical field-order replay and missing/principal-isolated status: PASS")
        if config == "old_skill":
            for token in ("unique-token-one", "unique-token-two\nraw-stack"):
                safe = api.provider_error("raw provider content: " + token)
                assert token not in json.dumps(safe)
            print("supplemental safe fixed provider errors with distinct raw content: PASS")
        print("Independent checks are bounded in-memory demonstrations; no production durability, races, full schema validation or model-selection result established.")
    log = DEST / ("eval-2-" + config + ".log")
    log.write_text("runtime=" + sys.executable + "\nflags=-X utf8 -B\nsource=" + str(source) + "\n" + captured.getvalue() + "exit_code=0\n", encoding="utf-8")
    print(config + ": PASS; log=" + str(log))
