Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$probeRows = [System.Collections.Generic.List[object]]::new()
function Add-Probe([string]$Name, [bool]$Passed, [object]$Observed) {
    $probeRows.Add([pscustomobject]@{ Name=$Name; Passed=$Passed; Observed=$Observed })
    if (!$Passed) { throw ('Independent probe failed: ' + $Name) }
}

# Load only the already inspected, hash-matched local copies; suppress fixture JSON.
$loadedFixture = . (Join-Path $PSScriptRoot 'guardrails-eval2-with_skill/release_gate_fake.ps1')
$payment = @{ Action='payment'; Key='probe-over-limit'; Cents=10001 }
Reset-Sandbox
$status = Invoke-Guarded $payment 'resume' 'available' $true $true
Add-Probe 'eval2_with_fresh_resume_checks_hard_limit_before_effect' ($status -eq 'denied:hard_amount_limit' -and $script:effects.Count -eq 0) @{ Status=$status; Effects=$script:effects.Count; Attempts=$script:attempts }
Reset-Sandbox
$good = @{ Action='payment'; Key='probe-good'; Cents=10000 }
$status = Invoke-Guarded $good 'initial'
Add-Probe 'eval2_with_valid_limit_boundary_not_false_blocked' ($status -eq 'completed' -and $script:effects.Count -eq 1) @{ Status=$status; Effects=$script:effects.Count }
Reset-Sandbox
$status = Invoke-Guarded $good 'worker' 'outage' $true $true
Add-Probe 'eval2_with_worker_checker_outage_zero_effect' ($status -eq 'paused:required_checker_unavailable' -and $script:effects.Count -eq 0) @{ Status=$status; Effects=$script:effects.Count }
Reset-Sandbox
$status = Invoke-Guarded $good 'retry' 'available' $true $false
Add-Probe 'eval2_with_retry_revoked_permission_zero_effect' ($status -eq 'denied:permission' -and $script:effects.Count -eq 0) @{ Status=$status; Effects=$script:effects.Count }

$loadedFixture = . (Join-Path $PSScriptRoot 'guardrails-eval2-old_skill/release-gates.ps1')
$state = New-MockState
$candidate = New-Proposal 'payment' 150 $true 'available' 'approval_required' $true $true 'probe-approved-over-limit'
$status = Invoke-AdmittedPath $candidate $state
Add-Probe 'eval2_old_exact_valid_review_cannot_waive_limit' ($status -eq 'deny_amount' -and $state.paymentCount -eq 0) @{ Status=$status; Effects=$state.paymentCount }
$state = New-MockState
$candidate = New-Proposal 'payment' 100 $true 'available' 'allow' $true $true 'probe-valid-boundary'
$status = Invoke-AdmittedPath $candidate $state
Add-Probe 'eval2_old_valid_limit_boundary_not_false_blocked' ($status -eq 'fake_effect_recorded' -and $state.paymentCount -eq 1) @{ Status=$status; Effects=$state.paymentCount }
$state = New-MockState
$candidate = New-Proposal 'payment' 60 $true 'available' 'unknown' $true $true 'probe-unknown-policy'
$status = Invoke-AdmittedPath $candidate $state
Add-Probe 'eval2_old_unknown_policy_zero_effect' ($status -eq 'deny_unknown_policy' -and $state.paymentCount -eq 0) @{ Status=$status; Effects=$state.paymentCount }
$state = New-MockState
$candidate = New-Proposal 'email' 0 $true 'error' 'allow' $true $true 'probe-email-outage'
$status = Invoke-AdmittedPath $candidate $state
Add-Probe 'eval2_old_email_outage_zero_effect' ($status -eq 'abstain_checker_unavailable' -and $state.emailCount -eq 0) @{ Status=$status; Effects=$state.emailCount }

$loadedFixture = . (Join-Path $PSScriptRoot 'guardrails-eval4-with_skill/installment_path_fake.ps1')
Reset-Sandbox
$context = New-Context @('40,40','40,60') 'available' $true
$invalid = New-Plan @(40,40)
$grant = New-Grant $invalid $context
$verdict = Invoke-FakeCommit $invalid $context $grant
Add-Probe 'eval4_with_exact_grant_cannot_waive_invalid_sum' ($verdict.State -eq 'reject_candidate' -and $verdict.Reason -eq 'sum' -and $script:fakeCommits.Count -eq 0) @{ Verdict=$verdict; FakeCommits=$script:fakeCommits.Count }
Reset-Sandbox
$valid = New-Plan @(40,60)
$grant = New-Grant $valid $context
$revoked = New-Context @('50,50') 'available' $true
$verdict = Invoke-FakeCommit $valid $revoked $grant
Add-Probe 'eval4_with_exact_grant_cannot_waive_permission' ($verdict.State -eq 'reject_candidate' -and $verdict.Reason -eq 'permission' -and $script:fakeCommits.Count -eq 0) @{ Verdict=$verdict; FakeCommits=$script:fakeCommits.Count }
Reset-Sandbox
$validContext = New-Context @('40,60')
$result = Invoke-BoundedDesignPath $valid $validContext $null (New-Plan @(40,50))
Add-Probe 'eval4_with_valid_first_candidate_not_forced_to_repair' ($result.State -eq 'ready' -and $result.Trace.Count -eq 1 -and $script:validationCalls -eq 1) @{ Result=$result; ValidationCalls=$script:validationCalls }
Reset-Sandbox
$deniedGrant = New-Grant $valid $context
$deniedGrant.Decision = 'denied'
$verdict = Invoke-FakeCommit $valid $context $deniedGrant
Add-Probe 'eval4_with_human_denial_zero_effect' ($verdict.State -eq 'stopped' -and $verdict.Reason -eq 'approval_denied' -and $script:fakeCommits.Count -eq 0) @{ Verdict=$verdict; FakeCommits=$script:fakeCommits.Count }

$loadedFixture = . (Join-Path $PSScriptRoot 'guardrails-eval4-old_skill/plan-admission-fake.ps1')
$status = Test-PlanAdmission ([int[]]@(40,40)) 100 $true $true 'available' 'approval_required' $true '40,40' $true
Add-Probe 'eval4_old_exact_grant_cannot_waive_invalid_sum' ($status -eq 'deny_total') @{ Status=$status }
$status = Test-PlanAdmission ([int[]]@(40,60)) 100 $true $false 'available' 'approval_required' $true '40,60' $true
Add-Probe 'eval4_old_exact_grant_cannot_waive_permission' ($status -eq 'deny_permission') @{ Status=$status }
$status = Test-PlanAdmission ([int[]]@(40,60)) 100 $true $true 'available' 'deny' $true '40,60' $true
Add-Probe 'eval4_old_exact_grant_cannot_waive_policy_denial' ($status -eq 'deny_policy') @{ Status=$status }
$status = Test-PlanAdmission ([int[]]@(40,60)) 100 $true $true 'available' 'approval_required' $false '40,60' $true
Add-Probe 'eval4_old_policy_required_exact_grant_valid_candidate_not_false_blocked' ($status -eq 'ready_for_execution_not_executed') @{ Status=$status }

$result = [pscustomobject]@{ Scope='Independent probes of inspected copied in-memory design fakes; no live or production effects'; CheckCount=$probeRows.Count; Passed=@($probeRows | Where-Object { $_.Passed }).Count; Checks=@($probeRows.ToArray()); Limitations=@('No real policy, model, provider or distributed concurrency was tested','Approval and support parameters remain fixture state','These additional probes supplement unchanged official assertions') }
$result | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'probe-actual-checks.json') -Encoding UTF8
$result | Select-Object Scope, CheckCount, Passed | ConvertTo-Json
