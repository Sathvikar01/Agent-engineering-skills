Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$workspace = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$verifiedRoot = $PSScriptRoot
$cases = @(
    @{ Name='guardrails-eval2-with_skill'; Relative='work/v2/agent-guardrails-workspace/iteration-1/eval-2-adversarial/with_skill/run-1'; Source='release_gate_fake.ps1'; Expected=10 },
    @{ Name='guardrails-eval2-old_skill'; Relative='work/v2/agent-guardrails-workspace/iteration-1/eval-2-adversarial/old_skill/run-1'; Source='release-gates.ps1'; Expected=12 },
    @{ Name='guardrails-eval4-with_skill'; Relative='work/v2/agent-guardrails-workspace/iteration-1/eval-4-v2-targeted/with_skill/run-1'; Source='installment_path_fake.ps1'; Expected=13 },
    @{ Name='guardrails-eval4-old_skill'; Relative='work/v2/agent-guardrails-workspace/iteration-1/eval-4-v2-targeted/old_skill/run-1'; Source='plan-admission-fake.ps1'; Expected=12 }
)
$manifest = @()
foreach ($case in $cases) {
    $caseRoot = Join-Path $verifiedRoot $case.Name
    New-Item -ItemType Directory -Force -Path $caseRoot | Out-Null
    $originalSource = Join-Path (Join-Path $workspace $case.Relative) ('outputs/' + $case.Source)
    $copiedSource = Join-Path $caseRoot $case.Source
    $before = (Get-FileHash -LiteralPath $originalSource -Algorithm SHA256).Hash
    Copy-Item -LiteralPath $originalSource -Destination $copiedSource
    $stdout = & 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -NoProfile -ExecutionPolicy Bypass -File $copiedSource 2> (Join-Path $caseRoot 'rerun-stderr.txt')
    $code = $LASTEXITCODE
    $stdout | Set-Content -LiteralPath (Join-Path $caseRoot 'rerun-actual-checks.json') -Encoding UTF8
    if ($code -ne 0) { throw ('Corrected copied rerun failed: ' + $case.Name) }
    $parsed = $stdout | ConvertFrom-Json
    if ($case.Name.EndsWith('with_skill')) {
        $count = $parsed.CheckCount
        $passed = @($parsed.Checks | Where-Object { $_.Passed }).Count
    } else {
        $count = $parsed.check_count
        $passed = @($parsed.results | Where-Object { $_.passed }).Count
    }
    $after = (Get-FileHash -LiteralPath $originalSource -Algorithm SHA256).Hash
    $copyHash = (Get-FileHash -LiteralPath $copiedSource -Algorithm SHA256).Hash
    if ($before -ne $after -or $copyHash -ne $before -or $count -ne $case.Expected -or $passed -ne $count) { throw ('Integrity/count failure: ' + $case.Name) }
    $manifest += [pscustomobject]@{ Case=$case.Name; OriginalSource=$originalSource; CopiedSource=$copiedSource; SHA256=$before; OriginalUnchanged=($before -eq $after); ExitCode=$code; CheckCount=$count; Passed=$passed; Scope='Inspected source; in-memory fixture only; no provider or network calls' }
}
$manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $verifiedRoot 'rerun-manifest.json') -Encoding UTF8
$failedCase = Join-Path $verifiedRoot 'guardrails-eval2-with_skill'
$correctedPath = Join-Path $failedCase 'release_gate_fake.ps1'
$corrected = Get-Content -Raw -LiteralPath $correctedPath
$safeLine = '@($statuses | Where-Object { $_ -ne ''denied:hard_amount_limit'' }).Count'
$unsafeLine = '($statuses | Where-Object { $_ -ne ''denied:hard_amount_limit'' }).Count'
if (-not $corrected.Contains($safeLine)) { throw 'Cannot locate documented Count repair.' }
$reconstructedPath = Join-Path $failedCase 'initial-count-failure-reconstruction.ps1'
$corrected.Replace($safeLine, $unsafeLine) | Set-Content -LiteralPath $reconstructedPath -Encoding UTF8
Copy-Item -LiteralPath (Join-Path $workspace 'work/v2/agent-guardrails-workspace/iteration-1/eval-2-adversarial/with_skill/run-1/outputs/initial-check-failure.txt') -Destination (Join-Path $failedCase 'executor-original-initial-check-failure.txt')
# Native stderr remains evidence even when ErrorActionPreference stops on it.
$ErrorActionPreference = 'Continue'
$initialStdout = & 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -NoProfile -ExecutionPolicy Bypass -File $reconstructedPath 2> (Join-Path $failedCase 'reconstructed-initial-stderr.txt')
$initialCode = $LASTEXITCODE
$ErrorActionPreference = 'Stop'
$initialStdout | Set-Content -LiteralPath (Join-Path $failedCase 'reconstructed-initial-stdout.txt') -Encoding UTF8
[pscustomobject]@{ ExitCode=$initialCode; Reconstruction='Copied corrected source with only the documented array wrapper removed; historical initial source not retained by executor'; ExpectedFailure='The property Count cannot be found on this object'; OriginalFailurePreserved='executor-original-initial-check-failure.txt'; CorrectedSourceUnchanged=((Get-FileHash -LiteralPath $correctedPath).Hash -eq $manifest[0].SHA256) } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $failedCase 'initial-failure-reconstruction-metadata.json') -Encoding UTF8
if ($initialCode -eq 0) { throw 'Documented initial failure did not reproduce.' }
$manifest | Select-Object Case, ExitCode, CheckCount, Passed, OriginalUnchanged | ConvertTo-Json
