# Sandbox only: all effects are in-memory records. No provider calls exist.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:effects = [System.Collections.Generic.List[object]]::new()
$script:checks = [System.Collections.Generic.List[object]]::new()
$script:attempts = 0
$script:seen = @{}

function Reset-Sandbox {
    $script:effects.Clear()
    $script:attempts = 0
    $script:seen = @{}
}

function Record-FakeEffect([hashtable]$Candidate, [string]$Entry) {
    $script:effects.Add([pscustomobject]@{
        Action = $Candidate.Action; Entry = $Entry; Key = $Candidate.Key
    })
}

function Invoke-Guarded([hashtable]$Candidate, [string]$Entry,
                        [string]$CheckerState = 'available',
                        [bool]$ReviewerAgrees = $false,
                        [bool]$Permission = $true) {
    # Entry may be initial/retry/worker/resume; no route gets another executor.
    $script:attempts++
    if ($script:attempts -gt 3) { return 'stopped:attempt_budget' }
    foreach ($field in @('Action', 'Key')) {
        if (!$Candidate.ContainsKey($field) -or
            [string]::IsNullOrWhiteSpace([string]$Candidate[$field])) {
            return 'denied:malformed'
        }
    }
    if ($Candidate.Action -notin @('email', 'payment')) { return 'denied:unsupported' }
    if ($Candidate.Action -eq 'email') {
        if (!$Candidate.ContainsKey('Body') -or !$Candidate.ContainsKey('To')) {
            return 'denied:malformed'
        }
        # Illustrative fixture classifier; production coverage needs evaluation.
        if ([string]$Candidate.Body -match 'PRIVATE') { return 'denied:egress' }
        if ($Candidate.To -ne 'allowed@example.test') { return 'denied:recipient_scope' }
    }
    if ($Candidate.Action -eq 'payment') {
        if (!$Candidate.ContainsKey('Cents') -or $Candidate.Cents -isnot [int]) {
            return 'denied:malformed'
        }
        if ($Candidate.Cents -le 0 -or $Candidate.Cents -gt 10000) {
            return 'denied:hard_amount_limit'
        }
    }
    # ReviewerAgrees is advisory; it cannot override any hard gate.
    if ($CheckerState -ne 'available') { return 'paused:required_checker_unavailable' }
    if (!$Permission) { return 'denied:permission' }
    # Fake single-process ledger; production requires durable atomic idempotency.
    if ($script:seen.ContainsKey($Candidate.Key)) { return 'already_completed' }
    Record-FakeEffect $Candidate $Entry
    $script:seen[$Candidate.Key] = $true
    return 'completed'
}

function Check([string]$Name, [bool]$Passed, [object]$Observed) {
    $script:checks.Add([pscustomobject]@{ Name = $Name; Passed = $Passed; Observed = $Observed })
    if (!$Passed) { throw "Check failed: $Name" }
}

# Concrete legacy failures are reproduced against an in-memory provider.
Reset-Sandbox
$email = @{ Action = 'email'; Key = 'email-1'; To = 'allowed@example.test'; Body = 'PRIVATE document' }
Record-FakeEffect $email 'legacy_initial'
$legacyOutputStatus = if ($email.Body -match 'PRIVATE') { 'blocked_after_send' } else { 'completed' }
Check 'legacy_post_filter_leaves_sent_effect' ($script:effects.Count -eq 1 -and $legacyOutputStatus -eq 'blocked_after_send') @{ Status = $legacyOutputStatus; Effects = $script:effects.Count }
Reset-Sandbox
$status = Invoke-Guarded $email 'initial'
Check 'egress_gate_before_send' ($status -eq 'denied:egress' -and $script:effects.Count -eq 0) @{ Status = $status; Effects = $script:effects.Count }

$email.Body = 'Public agenda'
Reset-Sandbox
$legacyPolicy = if ('outage' -eq 'available') { $false } else { $true }
if ($legacyPolicy) { Record-FakeEffect $email 'legacy_outage' }
Check 'legacy_outage_defaults_allow' ($script:effects.Count -eq 1) @{ Effects = $script:effects.Count }
Reset-Sandbox
$status = Invoke-Guarded $email 'initial' 'outage'
Check 'required_checker_outage_closes_effect_path' ($status -eq 'paused:required_checker_unavailable' -and $script:effects.Count -eq 0) @{ Status = $status; Effects = $script:effects.Count }

$payment = @{ Action = 'payment'; Key = 'payment-1'; Cents = 10001 }
Reset-Sandbox
$reviewerAgrees = $true
if ($reviewerAgrees) { Record-FakeEffect $payment 'legacy_reviewer' }
Check 'legacy_reviewer_overrides_hard_limit' ($script:effects.Count -eq 1) @{ Cents = $payment.Cents; Effects = $script:effects.Count }
Reset-Sandbox
$status = Invoke-Guarded $payment 'initial' 'available' $true
Check 'reviewer_cannot_override_limit' ($status -eq 'denied:hard_amount_limit' -and $script:effects.Count -eq 0) @{ Status = $status; Effects = $script:effects.Count }

Reset-Sandbox
$initial = Invoke-Guarded $payment 'initial'
Record-FakeEffect $payment 'legacy_retry_bypass'
Check 'legacy_retry_bypasses_failed_validation' ($initial -eq 'denied:hard_amount_limit' -and $script:effects.Count -eq 1) @{ Initial = $initial; Effects = $script:effects.Count }
Reset-Sandbox
$statuses = foreach ($entry in @('initial', 'retry', 'worker')) {
    Invoke-Guarded $payment $entry
}
$resumeStatus = Invoke-Guarded $payment 'resume'
Check 'all_entries_share_gate_and_budget' (($statuses | Where-Object { $_ -ne 'denied:hard_amount_limit' }).Count -eq 0 -and $resumeStatus -eq 'stopped:attempt_budget' -and $script:effects.Count -eq 0) @{ Statuses = @($statuses); Resume = $resumeStatus; Effects = $script:effects.Count }

Reset-Sandbox
$statuses = @(Invoke-Guarded $email 'initial'; Invoke-Guarded $email 'retry')
Check 'allowed_email_and_duplicate_retry' ($statuses[0] -eq 'completed' -and $statuses[1] -eq 'already_completed' -and $script:effects.Count -eq 1) @{ Statuses = $statuses; Effects = $script:effects.Count }

Reset-Sandbox
$status = Invoke-Guarded $email 'resume' 'available' $true $false
Check 'current_permission_rechecked' ($status -eq 'denied:permission' -and $script:effects.Count -eq 0) @{ Status = $status; Effects = $script:effects.Count }

[pscustomobject]@{
    Kind = 'local_in_memory_fake'; ExternalEffects = 0
    CheckCount = $script:checks.Count; Checks = @($script:checks.ToArray())
    Limitations = @('No real policy service or provider', 'PRIVATE is only a fixture marker', 'No durable concurrency/transaction guarantees', 'No production quality, latency or cost measurements')
} | ConvertTo-Json -Depth 10

