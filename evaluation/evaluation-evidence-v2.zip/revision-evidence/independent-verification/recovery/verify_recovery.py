"""Reviewed local recovery fakes and independent edge probes; no payments."""
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[4]
JOB = json.loads((ROOT / "work/v2/job-agent-failure-recovery.json").read_text(encoding="utf-8-sig"))
DEST = Path(__file__).resolve().parent
for config, run in JOB["tasks"][0]["runs"].items():
    source = Path(run) / "outputs" / ("recovery_fake_test.py" if config == "with_skill" else "recovery_fakes.py")
    spec = importlib.util.spec_from_file_location("independent_recovery_"+config, source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
    assert result.wasSuccessful()
    probes = []
    if config == "with_skill":
        state = module.ledger()
        state["ops"]["committed"] = {"status":"committed", "receipt":"retained"}
        calls = []
        assert module.Runner(state).invoke("committed", lambda key:calls.append(key)) == "committed"
        assert calls == []
        module.Runner(state).compensate("committed", lambda:calls.append("refund"), authorized=False)
        assert calls == [] and state["ops"]["committed"]["compensation"] == "approval_required"
        probes.append("PASS: verified committed state reused without dispatch; unauthorized compensation makes no call")
        state = module.ledger(remaining=1)
        provider = module.Provider()
        module.Runner(state).invoke("last-slot", provider.pay)
        assert state["remaining"] == 0
        for i in range(10):
            assert module.Runner(state).invoke("new-key-"+str(i),provider.pay) == "budget_exhausted"
        assert provider.calls == 1
        probes.append("PASS: exhausted shared state cannot be reset by runner recreation or fresh operation keys")
    else:
        with tempfile.TemporaryDirectory(dir=DEST) as directory:
            path = Path(directory)/"ledger.json"
            first = module.Run(path)
            first.state["remaining"] = 1
            first.save()
            calls = []
            module.Run(path).dispatch("last-slot",lambda key:calls.append(key))
            for i in range(10):
                module.Run(path).dispatch("new-key-"+str(i),lambda key:calls.append(key))
            assert calls == ["last-slot"] and module.Run(path).state["remaining"] == 0
            probes.append("PASS: on-disk exhausted budget survives reconstruction and new operation keys")
            path = Path(directory)/"committed-replay.json"
            calls = []
            def completed(key):
                calls.append(key)
                return "retained-receipt"
            module.Run(path).dispatch("same-payment",completed)
            module.Run(path).dispatch("same-payment",completed)
            assert calls == ["same-payment","same-payment"]
            probes.append("FAILURE OBSERVED: replaying a recorded committed operation dispatches again; source lacks committed-result reuse, contrary to response pseudocode")
            probes.append("observed_committed_replay="+json.dumps({"provider_calls":calls,"call_count":len(calls),"retained_state":module.Run(path).state},sort_keys=True))
            path = Path(directory)/"pending-recovery.json"
            retained = module.Run(path)
            retained.state["operations"]["uncertain-payment"] = {"status":"pending"}
            retained.save()
            calls = ["simulated-prior-dispatch-with-unrecorded-outcome"]
            module.Run(path).dispatch("uncertain-payment",lambda key:calls.append("replayed-pending-payment"))
            assert calls[-1] == "replayed-pending-payment"
            probes.append("FAILURE OBSERVED: retained pending payment is dispatched again without proving non-dispatch; design says unresolved pending must be unknown. Probe simulates crash state, not an actual OS crash")
            probes.append("observed_pending_recovery="+json.dumps({"synthetic_prior_state":{"operations":{"uncertain-payment":{"status":"pending"}},"remaining":2},"effect_markers":calls,"retained_state":module.Run(path).state},sort_keys=True))
    log = DEST / ("eval-2-"+config+".log")
    log.write_text("runtime="+sys.executable+"\nflags=-X utf8 -B\nsource="+str(source)+"\n"+stream.getvalue()+"\n"+"\n".join(probes)+"\nverification_process_exit_code=0\nNo live effects. Task4 remains design-only, 3 calls/5s is proposed acceptance policy, not measured.\n",encoding="utf-8")
    print(config+": original suite passed; independent edge evidence saved to "+str(log))
