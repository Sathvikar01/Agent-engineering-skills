import json
from pathlib import Path

workspace = Path(r'~/Documents/Codex/2026-10-03/i-want-you-to-build-a')
job = json.loads((workspace / 'work/v2/job-evidence-provenance.json').read_text(encoding='utf-8-sig'))
proofs = {
    (1, 'with_skill'): [
        'Inspected reconcile_fake.py and actual test-run.log: one unittest iterates nine named scenario subtests, expecting UNKNOWN_ID for Z, UNUSED_OR_IRRELEVANT for observed visible B, NOT_VISIBLE for retrieved C; each rejection asserts empty claims/citations. Independent bundled Python -X utf8 -B suite/scenario reruns exit0. Independent branch probes isolate relevant-but-unused B and used/relevant-but-invisible C and still reject, proving support/use/visibility checks beyond ID existence.',
        'reconcile_fake.py binds Decision total100 to ledger A total100, visible/T1; proposal120 returns CONTRADICTED, tenantT2 returns ACCESS_DENIED, valid A returns SUPPORTED with exactly total100/A. Independent scenarios reproduce these statuses and empty rejected claims. Typed equality and strict integer checks execute, not just annotations.',
        'observed_fixture assigns A/B/C IDs and metadata in application code; source_text stays opaque and cannot create a row or signature. Tests with evidence_id=Z signed=true reject citationZ and preserve validA behavior, explicitly asserting Z not in ledger. Decision support/version relations are structured application data; no cryptographic verification is fabricated.',
        'Decision.used_support=(A,) and support_versions=((A,2),) are separate from Proposal.citations; reconciliation verifies supporting typed fact then citation membership and claim equality. response.md explicitly limits this to declared application support/typed integer equality, not private model reliance, semantic entailment, business validity or source truth. Independent version-change probe returns STALE_OR_UNBOUND_VERSION.'
    ],
    (1, 'without_skill'): [
        'Inspected reconcile.py/tests.log/scenarios.log/execution.json: actual five-test suite includes invalid-case subtests for Z UNKNOWN_CITATION, B CITATION_NOT_USED plus fact mismatch, C CITATION_NOT_VISIBLE, all asserting empty emitted_claims. Independent bundled Python suite/scenario reruns exit0. Branch probes separately isolate unused but relevant B and used/relevant but invisible C and reject with exact use/visibility errors.',
        'reconcile.py compares output and decision fact/value, validates decision.uses against observation facts, checks tenant for dependency and citation, and validates visible support. Actual and independent outputs show120 rejected, tenantT2 rejected, A100 accepted with only A citation. Rejected cases emit no business claims.',
        'LEDGER construction supplies trusted Observation identities/tenant/version/visibility independently of source_text. Spoofed A payload evidence_id=Z signed=true is never parsed; validA result is unchanged, citationZ rejected, no Z row created. response.md explicitly disclaims cryptographic signing/authentication and live provider authority.',
        'Decision uses=(A,) is explicit and citations must be in decision.uses plus typed fact equality; unsupported decisionB is tested. response.md limits results to local typed facts/declared dependencies and disclaims general natural-language entailment, extraction accuracy, real current authorization/signing guarantees. Source version is recorded, but decision does not bind/check it; this is a separately noted coverage gap rather than this assertion requiring such a check.'
    ],
    (2, 'with_skill'): [
        'response.md refuses N2 without parent relation, contradictory granted claim against M4pending and guessed/unobserved M9. Proposed transform contract records exact parent observation IDs/versions, input/output digests, transform identity and claim-to-parent spans; recovery must match trusted logs/digests, never similar text. M4version3 remains historical rather than automatically current evidence.',
        'response.md blocks entire answer because WAIT code does not fix approved explanation or guessed citation. Final prose must derive from admitted fact and bound decision rule, or be checked jointly; PENDING->WAIT rule is explicitly a proposed policy needing owner approval. It forbids invented M9 and guessed M4 ancestry, recomputing summary/decision/explanation only from freshly validated support.',
        'response.md returns INSUFFICIENT_AUTHORIZED_EVIDENCE with no source claims/citations after revocation. Resume rechecks authorization before protected context loading and invalidates downstream support/summary/fact/decision/output edges. Repair explicitly finite: recover trusted transform then fresh authorized source/regenerated summary, else stop insufficient. Proposed tests cover revocation even with recovered ancestry, fresh authorized reconstruction and no-runtime/unexecuted limits.'
    ],
    (2, 'without_skill'): [
        'response.md quarantines N2 for missing transform edge and granted-versus-pending conflict, rejects guessed M9 and blocks final output. Source records preserve immutable version/digest/exact presented material; transform record links exact M4version3 input to artifact/claims/spans and implementation version. Repair reconstructs only from reliable exact input/output logs with auditable repair event, else new authorized observation and regenerated summary.',
        'response.md says WAIT cannot validate approved explanation; validate actual decision dependency/source support then reconcile both decision and source content before output. No silently attached N2->M4 edge and no invented M9 repair allowed. If current authorized source still pending, regenerate pending summary and recompute policy-consistent WAIT with verified citation; until then emit generic inability-to-validate status without revoked details.',
        'response.md refreshes current principal/tenant/authorization before restoring checkpoint context, invalidates revoked M4 and dependents across caches/memory/prompts/decisions, conservatively handles N2 unknown ancestry and rechecks authorization at emission for stale workers. Repair has finite conditional alternatives (exact trusted-log recovery or authorized new observation/regeneration), ending withheld generic status if unavailable; no open-ended retries proposed. Provider hidden-state deletion is explicitly unproven and dirty resume blocked. All tests are proposed, not executed.'
    ],
    (3, 'with_skill'): [
        'response.md contains exactly two bibliography entries: Example, Ada. Reliable Systems. 2024; Sample, Bea. Typed Interfaces. 2023, with italicized titles. Author/title/year match supplied references; no publisher/DOI/venue/URL or other invented metadata.',
        'Only response.md exists in outputs and contains the bibliography. Transcript excludes ordinary bibliography work from runtime provenance and records no ledger, lookup, reconciliation, approval or tests.'
    ],
    (3, 'without_skill'): [
        'response.md contains exactly two bibliography entries: Example, Ada. Reliable Systems. 2024; Sample, Bea. Typed Interfaces. 2023, with italicized titles. Author/title/year match supplied references; no invented publication metadata.',
        'Only response.md exists in outputs and contains the bibliography; transcript documents simple formatting without source lookup, runtime implementation or tests. No ledger, reconciliation or approval machinery imposed.'
    ]
}

for task in job['tasks']:
    for config, runstring in task['runs'].items():
        run = Path(runstring)
        metadata = json.loads((run / 'eval_metadata.json').read_text(encoding='utf-8-sig'))
        rows = proofs[(task['id'], config)]
        assert len(rows) == len(metadata['assertions'])
        expectations = [dict(text=text, passed=True, evidence=proof) for text, proof in zip(metadata['assertions'], rows)]
        suggestions = []
        claims = []
        if task['id'] == 1:
            count = 1 if config == 'with_skill' else 5
            claims.extend([
                dict(claim=f'The local suite passes {count} unittest method(s).', type='factual', verified=True, evidence=f'Independent bundled Python -X utf8 -B -m unittest -v rerun exits0 with {count} tests OK; with-skill method iterates nine scenario subtests; baseline covers requested invalid cases in one method plus four others.'),
                dict(claim='Invalid requested citations/conflicting or cross-tenant outputs emit no unsupported claims.', type='quality', verified=True, evidence='Inspected actual and independent scenario JSONs; rejected cases have empty claims/emitted_claims. Independent isolated support-use/visibility probes pass.'),
                dict(claim='Source text cannot mint observationZ or authenticate its claimed signature.', type='factual', verified=True, evidence='Opaque source_text never controls application ledger metadata; tests reject spoof citationZ and retain validA result, with no signature-verification claim.'),
                dict(claim='Typed equality does not establish general natural-language entailment or live source/provider authority.', type='quality', verified=True, evidence='Outputs explicitly state fixture/declared-support limits and no semantic/private reliance/cryptographic/current provider proof; inspected implementation uses typed facts only.')
            ])
            if config == 'with_skill':
                claims.append(dict(claim='Changing A to version3 invalidates support bound to version2.', type='factual', verified=True, evidence='Both executor scenario and independent branch probe return STALE_OR_UNBOUND_VERSION with no claims.'))
            else:
                claims.append(dict(claim='A source version change is not bound or checked by this fake decision.', type='factual', verified=True, evidence='Independent version-only A v2->v3 probe still emits SUPPORTED_TYPED_FACT; Decision stores uses but no support_versions and reconcile never examines version. Output does not explicitly claim freshness validation.'))
            suggestions.extend([
                dict(reason='Version2 is supplied in the prompt, but no assertion checks decision-to-source version binding or stale replacement. Independent baseline probe changes A to version3 while retaining typed100 and gets a supported claim; with-skill rejects. Add an explicit stale/unbound-version test to catch this substantive uncovered behavior.'),
                dict(assertion=metadata['assertions'][0], reason='Fixtures B and C each fail more than one condition (B unused/irrelevant; C unused/invisible). Existing status/reason assertions and code verify the branches here, but add orthogonal tests: relevant-but-unused B, used/relevant-but-invisible C, and decision-declared irrelevant B. Independent probes confirm both outputs handle them.')
            ])
        elif task['id'] == 2:
            claims.append(dict(claim='Tests and repair/resume behavior are proposed; no runtime evidence exists.', type='process', verified=True, evidence='Only design response.md is in outputs; transcript and response explicitly say no runtime or executed tests. Proposed outcomes are not presented as measured reliability.'))
            claims.append(dict(claim='WAIT cannot make an unsupported approval explanation or guessed citation admissible.', type='quality', verified=True, evidence='Design blocks emission, quarantines missing/contradictory derived support, revalidates authorization and rebuilds from trusted records or current authorized evidence; no ancestry fabricated from names/text.'))
            if config == 'without_skill':
                words = len((run / 'outputs/response.md').read_text(encoding='utf-8-sig').split())
                claims.append(dict(claim='The final response contains 700 whitespace-delimited words.', type='factual', verified=words == 700, evidence=f'Independent word count is {words}; matches transcript.'))
        else:
            claims.append(dict(claim='Only supplied reference metadata was formatted.', type='factual', verified=True, evidence='Compared two author/title/year entries directly with prompt; no extra source details or runtime artifacts.'))
        result = dict(
            expectations=expectations,
            summary=dict(passed=len(expectations), failed=0, total=len(expectations), pass_rate=1.0),
            claims=claims,
            user_notes_summary=dict(uncertainties=[], needs_review=[], workarounds=[]),
            eval_feedback=dict(suggestions=suggestions, overall='Meaningful scope/use/visibility/support checks; source-version freshness is an important uncovered gate.' if suggestions else 'No suggestions, evals look solid for this task.'),
            grading_context=dict(independent=True, comparison_blinded=False, configuration_visibility='with_skill/without_skill names and paths visible', artifacts_inspected=True, executor_metrics_present=False, executor_timing_present=False, user_notes_present=False)
        )
        for filename, field in [('outputs/metrics.json', 'execution_metrics'), ('timing.json', 'timing')]:
            if (run / filename).exists():
                result[field] = json.loads((run / filename).read_text(encoding='utf-8-sig'))
        (run / 'grading.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        print(f'{task["id"]} {config}: {len(expectations)}/{len(expectations)}; {run / "grading.json"}')
