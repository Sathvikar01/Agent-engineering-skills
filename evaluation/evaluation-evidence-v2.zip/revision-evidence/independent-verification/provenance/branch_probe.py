import json
import sys
from dataclasses import replace
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
config = sys.argv[1]
results = {}
if config == 'with_skill':
    import reconcile_fake as fake
    ledger = fake.observed_fixture()
    decision, proposal = fake.Decision(), fake.Proposal()
    relevant = dict(ledger)
    relevant['B'] = replace(ledger['B'], fact_name='total', fact_value=100, version=2)
    results['unused_but_relevant_B'] = fake.reconcile(relevant, decision, replace(proposal, citations=('B',)))
    invisible = dict(ledger)
    invisible['C'] = replace(ledger['C'], fact_name='total', fact_value=100, version=2)
    results['used_relevant_but_invisible_C'] = fake.reconcile(invisible, replace(decision, used_support=('C',), support_versions=(('C', 2),)), replace(proposal, citations=('C',)))
    results['decision_declares_irrelevant_B'] = fake.reconcile(ledger, replace(decision, used_support=('B',), support_versions=(('B', None),)), replace(proposal, citations=('B',)))
    stale = dict(ledger)
    stale['A'] = replace(ledger['A'], version=3)
    results['version_only_changed_to_3'] = fake.reconcile(stale, decision, proposal)
    assert results['unused_but_relevant_B']['status'] == 'UNUSED_OR_IRRELEVANT'
    assert results['used_relevant_but_invisible_C']['status'] == 'NOT_VISIBLE'
    assert results['decision_declares_irrelevant_B']['status'] == 'UNSUPPORTED_DECISION'
    assert results['version_only_changed_to_3']['status'] == 'STALE_OR_UNBOUND_VERSION'
    for result in results.values():
        assert result['claims'] == [] and result['citations'] == []
else:
    import reconcile as fake
    ledger = fake.LEDGER
    relevant = dict(ledger)
    relevant['B'] = replace(ledger['B'], fact_name='total', value=100, version=2)
    results['unused_but_relevant_B'] = fake.reconcile(relevant, 'tenantT1', fake.DECISION, 'total', 100, ('B',))
    results['used_relevant_but_invisible_C'] = fake.reconcile(ledger, 'tenantT1', fake.Decision('total', 100, ('C',)), 'total', 100, ('C',))
    results['decision_declares_irrelevant_B'] = fake.reconcile(ledger, 'tenantT1', fake.Decision('total', 100, ('B',)), 'total', 100, ('B',))
    stale = dict(ledger)
    stale['A'] = replace(ledger['A'], version=3)
    results['version_only_changed_to_3'] = fake.reconcile(stale, 'tenantT1', fake.DECISION, 'total', 100, ('A',))
    assert results['unused_but_relevant_B']['errors'] == ['CITATION_NOT_USED']
    assert 'DECISION_EVIDENCE_NOT_VISIBLE' in results['used_relevant_but_invisible_C']['errors']
    assert 'DECISION_FACT_UNSUPPORTED' in results['decision_declares_irrelevant_B']['errors']
    for label in ['unused_but_relevant_B', 'used_relevant_but_invisible_C', 'decision_declares_irrelevant_B']:
        assert results[label]['emitted_claims'] == []
    # Observation only: no freshness/version assertion is in this run's rubric.
    assert results['version_only_changed_to_3']['status'] == 'SUPPORTED_TYPED_FACT'
print(json.dumps(dict(configuration=config, results=results), indent=2))
