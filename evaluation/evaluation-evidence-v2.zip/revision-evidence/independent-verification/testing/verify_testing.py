"""Independent reviewed local testing suites and strict/state probes."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[4]
JOB=json.loads((ROOT/"work/v2/job-agent-testing-iteration-1.json").read_text(encoding="utf-8-sig"))
DEST=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module

for task in JOB["tasks"]:
    for config,run in task["runs"].items():
        current=config=="with_skill"
        outputs=Path(run)/"outputs"
        base="runtime" if task["id"]==2 or current else "boundary"
        test_name="test_runtime" if base=="runtime" else "test_boundary"
        for name in ["runtime","boundary","test_runtime","test_boundary"]:
            sys.modules.pop(name,None)
        runtime=load(base,outputs/(base+".py"))
        tests=load(test_name,outputs/(test_name+".py"))
        stream=io.StringIO()
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(tests))
        assert result.wasSuccessful()
        probes=[]
        if task["id"]==2:
            for amount in (True,False,1.0,0,11 if current else 101):
                store=runtime.Store()
                provider=runtime.FakeProvider() if current else runtime.Ledger(store)
                controller=runtime.Runtime(store,provider)
                if current:
                    proposal=runtime.Refund("A","a-payment",amount,"strict-edge")
                    approval=runtime.Approval(proposal,0,100)
                    before=controller.snapshot()
                    status=controller.run("A",proposal,approval,1)
                    assert status=="denied" and controller.snapshot()==before and provider.calls==0
                else:
                    proposal=runtime.Request("A","order-a",amount,"strict-edge")
                    approval=runtime.Approval("A","order-a",amount,1,100)
                    before=copy.deepcopy((store.resources,store.operations,store.receipts,provider.effects))
                    status=controller.execute(proposal,approval,1)
                    assert status=="denied" and (store.resources,store.operations,store.receipts,provider.effects)==before and provider.calls==0
            probes.append("PASS: boolean, float, zero and overdraft proposals denied without state/effect/executor calls")
            if current:
                store,provider=runtime.Store(),runtime.FakeProvider()
                controller=runtime.Runtime(store,provider)
                proposal=runtime.Refund("A","a-payment",3,"uncertain")
                approval=runtime.Approval(proposal,0,100)
                provider.next_result="unknown_committed"
                assert controller.run("A",proposal,approval,1)=="unknown"
                provider.lookup_result="unknown"
                for i in range(10):
                    assert runtime.Runtime(store,provider).run("A",proposal,approval,1)=="unknown"
                assert provider.calls==1 and len(provider.effects)==1 and store.receipts=={} and store.payments["a-payment"]["balance"]==10
                provider.lookup_result="known"
                assert runtime.Runtime(store,provider).run("A",proposal,approval,200)=="committed"
                assert provider.calls==1 and len(store.receipts)==1 and store.payments["a-payment"]["balance"]==7
                probes.append("PASS: unresolved unknown survives controller recreation without dispatch; later authoritative committed reconciliation books receipt/balance once despite expired original approval")
            else:
                store=runtime.Store();provider=runtime.Ledger(store);controller=runtime.Runtime(store,provider)
                proposal=runtime.Request("A","order-a",3,"uncertain")
                approval=runtime.Approval("A","order-a",3,1,100)
                provider.mode="unknown_committed"
                assert controller.execute(proposal,approval,1)=="unknown"
                for i in range(10):
                    assert runtime.Runtime(store,provider).execute(proposal,approval,1)=="unknown"
                assert provider.calls==1 and len(provider.effects)==1 and store.receipts=={}
                assert runtime.Runtime(store,provider).reconcile("A","uncertain")=="committed"
                assert provider.calls==1 and len(store.receipts)==1 and store.resources["order-a"][1]==97
                probes.append("PASS: unknown blocks replay across recreation; definitive lookup records original commitment with one effect/call")
                # Probe an extension beyond the fake's specified definitive lookup variants.
                store=runtime.Store();provider=runtime.Ledger(store);controller=runtime.Runtime(store,provider)
                provider.mode="unknown_absent"
                controller.execute(proposal,approval,1)
                provider.lookup=lambda identity:"unknown"
                controller.reconcile("A","uncertain")
                assert store.operations[("A","uncertain")]["status"]=="ready"
                controller.execute(proposal,approval,1)
                assert provider.calls==2
                probes.append("LIMITATION CONFIRMED: unexpected inconclusive lookup variant changes status to ready and permits redispatch; fake contract only promises definitive committed/absent, so production unknown handling is not demonstrated")
        else:
            def raw(**changes):
                value={"kind":"propose","amount":1,"evidence_ids":["A"],"explanation_amount":1};value.update(changes);return json.dumps(value)
            def make(script,**limits):
                return runtime.Controller(runtime.ScriptedModel(script if current else [runtime.Event(output=x) for x in script]),**limits)
            for candidate in [raw(amount=True),raw(explanation_amount=True),raw(amount=1.0),raw(evidence_ids=["A","Z"]),raw(explanation_amount=2)]:
                controller=make([candidate],max_retries=0)
                outcome=controller.run()
                assert controller.effects==[] and controller.model.calls==1
            probes.append("PASS: bool/float numeric fields, mixed invented evidence and contradiction all fail with zero effects")
            controller=make([raw(),raw(amount=2,explanation_amount=2)])
            first=controller.run()
            assert len(controller.effects)==1 and controller.model.calls==1
            second=controller.run()
            if current:
                assert len(controller.effects)==2 and controller.model.calls==2
                probes.append("LIMITATION CONFIRMED: calling current admitted Controller.run again appends second effect (calls=2,effects=2); each invocation is bounded but terminal reentry is not guarded, unlike baseline")
            else:
                assert len(controller.effects)==1 and controller.model.calls==1
                probes.append("PASS: completed baseline Controller rejects repeated run dispatch; calls/effects stay one")
                with contextlib.redirect_stdout(stream):
                    load("independent_show_cases",outputs/"show_cases.py")
                probes.append("PASS: actual eleven baseline scenario runner records reproduced without original artifact writes")
            duplicate='{"kind":"propose","amount":11,"amount":1,"evidence_ids":["A"],"explanation_amount":1}'
            controller=make([duplicate],max_retries=0)
            controller.run()
            if current:
                assert controller.effects==[]
                probes.append("PASS: duplicate JSON amount fields rejected before effect")
            else:
                assert len(controller.effects)==1
                probes.append("LIMITATION CONFIRMED: baseline default JSON parser accepts last duplicate field; repeated-key ambiguity is not covered by its current tests")
        log=DEST/("eval-"+str(task["id"])+"-"+config+".log")
        log.write_text("runtime="+sys.executable+"\nflags=-X utf8 -B\nsource_directory="+str(outputs)+"\n"+stream.getvalue()+"\n"+"\n".join(probes)+"\nverification_process_exit_code=0\nNo provider/live effects; original source/log artifacts unchanged. State recreation is local memory, not disk/process-crash guarantees.\n",encoding="utf-8")
        print(str(task["id"])+"/"+config+": "+str(result.testsRun)+" tests plus independent probes completed; "+str(log))
