import copy
import json
import sys
from dataclasses import replace
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
import validator as fake

config = sys.argv[1]
results = {}
if config == 'with_skill':
    facts = fake.Facts()
    app = fake.FakeApplication(facts)
    valid = dict(version='1', decision='PAY', installments=[40, 60], due_days=[10, 20], execute_day=10, explanation_status='SUPPORTED', evidence_ids=['A'])
    wait = dict(valid, decision='WAIT', installments=[], due_days=[], execute_day=None, explanation_status='UNSUPPORTED')
    cases = [('wait_execution_only', dict(wait, execute_day=0), 'WAIT_HAS_EXECUTION_DAY'), ('wait_explanation_only', dict(wait, explanation_status='SUPPORTED'), 'WAIT_EXPLANATION_CONFLICT')]
    for name, candidate, expected in cases:
        raw = json.dumps(candidate)
        assert fake.shape_errors(candidate) == []
        before = copy.deepcopy(app.admitted)
        outcome = app.admit(raw, 7)
        assert not outcome['admitted'] and expected in outcome['errors'] and app.admitted == before
        assert fake.safe_reconstruct(raw, facts) == (None, 0)
        results[name] = outcome
    results['consistent_wait'] = app.admit(json.dumps(wait), 7)
    assert results['consistent_wait']['stage'] == 'abstention' and app.admitted == []
    unsupported_facts = replace(facts, evidence_total=(('A', 7),))
    results['known_A_wrong_support'] = fake.FakeApplication(unsupported_facts).admit(json.dumps(valid), 7)
    assert results['known_A_wrong_support']['errors'] == ['TOTAL_UNSUPPORTED']
    unsafe = dict(valid, installments=[40, 40], evidence_ids=['Z'])
    outcome = app.admit(json.dumps(unsafe), 7)
    assert not outcome['admitted'] and fake.safe_reconstruct(json.dumps(unsafe), facts) == (None, 0)
    results['wrong_sum_unknown_Z_no_repair'] = outcome
    first = dict(valid, installments=[40, 40])
    original = copy.deepcopy(first)
    rebuilt, attempts = fake.safe_reconstruct(json.dumps(first), facts, budget=1)
    assert attempts == 1 and json.loads(rebuilt)['installments'] == [40, 60] and first == original
    results['fresh_revalidation'] = app.admit(rebuilt, 7)
    assert results['fresh_revalidation']['admitted'] and len(app.admitted) == 1 and app.real_effects == 0
else:
    facts = copy.deepcopy(fake.FACTS)
    app = fake.FakeAdmission()
    valid = dict(version='1', kind='payment_schedule', installments=[40, 60], due_days=[10, 20], status='READY', execute_day=10, explanation_status='PROPOSED', evidence_ids=['A'])
    wait = dict(valid, status='WAIT', execute_day=None, explanation_status='PENDING')
    cases = [('wait_execution_only', dict(wait, execute_day=0)), ('wait_explanation_only', dict(wait, explanation_status='APPROVED'))]
    for name, candidate in cases:
        assert fake.shape_errors(candidate) == []
        before = copy.deepcopy(app.accepted_proposals)
        accepted, errors = app.admit(candidate, facts)
        assert not accepted and 'conflicting_wait' in errors and app.accepted_proposals == before
        assert fake.reconstruct_once(candidate, facts) is None
        results[name] = dict(admitted=accepted, errors=errors)
    accepted, errors = app.admit(wait, facts)
    assert not accepted and errors == ['abstention'] and app.accepted_proposals == []
    results['consistent_wait'] = dict(admitted=accepted, errors=errors)
    unsupported_facts = copy.deepcopy(facts)
    unsupported_facts['observed_evidence']['A']['supports_total'] = 7
    accepted, errors = app.admit(valid, unsupported_facts)
    assert not accepted and errors == ['unsupported_total']
    results['known_A_wrong_support'] = dict(admitted=accepted, errors=errors)
    unsafe = dict(valid, installments=[40, 40], evidence_ids=['Z'])
    accepted, errors = app.admit(unsafe, facts)
    assert not accepted and fake.reconstruct_once(unsafe, facts) is None
    results['wrong_sum_unknown_Z_no_repair'] = dict(admitted=accepted, errors=errors)
    first = dict(valid, installments=[40, 40])
    original = copy.deepcopy(first)
    rebuilt = fake.reconstruct_once(first, facts)
    assert rebuilt['installments'] == [40, 60] and first == original
    accepted, errors = app.admit(rebuilt, facts)
    assert accepted and errors == [] and len(app.accepted_proposals) == 1 and app.payment_effects == []
    results['fresh_revalidation'] = dict(admitted=accepted, errors=errors)
print(json.dumps(dict(configuration=config, results=results), indent=2))
