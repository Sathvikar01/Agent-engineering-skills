import json
from pathlib import Path

workspace=Path(r'~/Documents/Codex/2026-10-03/i-want-you-to-build-a')
job=json.loads((workspace/'work/v2/job-structured-output-design.json').read_text(encoding='utf-8-sig'))
proofs={
 (2,'with_skill'):[
  'response.md marks approved=true prohibited/untrusted authority assertion, requires additionalProperties:false and promotes only allowlisted typed fields. Even permissive schema success cannot copy approval into state or executor via raw dictionary. No model-generated approval field allowed.',
  'response.md deterministically computes trusted3+(-99)=-96, violates stock invariant and rejects proposed delta independently of schema. Illustrative server logic resolves current item and negative-stock check, with atomic expected state version if any valid request reaches executor.',
  'response.md derives principal from authenticated context, requires inventory-write permission independent of semantic success, and explicitly says every inventory-writing alternative remains unauthorized for this read-only actor. Removing approved does not change this rejection.',
  'response.md permits restricted raw diagnostic/rejection history only, leaving inventory/approval/executable queue untouched. It forbids silent -99->-3, invented evidence or authorization repair and returns typed rejection/nonmutating read outcome. No execution claimed or requested for design task.'
 ],
 (2,'old_skill'):[
  'response.md closed draft2020-12 contract excludes approved and sets additionalProperties:false; original fails unknown property. If temporarily permissive, promote named validated fields only, never raw merge/unknown fields in auth. Model approved flag explicitly grants no authority.',
  'response.md computes current stock3+(-99)=-96 and checks next_stock<0 server-side. Stock read again under atomic write boundary; schema numericbounds cannot replace resulting-stock invariant.',
  'response.md read-only trusted principal independently fails can_adjust_inventory even with corrected shape/semantic validity. Required approval is server-stored exact proposal/state-bound and cannot be model-issued.',
  'response.md inventory and accepted-proposal queue remain unchanged; restricted audit is not accepted state. It explicitly forbids repairing delta to-3, fabricating evidence or permissions, returns typed rejection/abstention and labels verification proposed/unexecuted.'
 ],
 (4,'with_skill'):[
  'Inspected validator.py/contract.json/run.log: shape deliberately allows contradictory combinations, semantic validator rejects sum80, WAIT execute0/APPROVED, unknown Z and model approval claim. Independent -X utf8 -B main rerun exits0; isolated shape-valid WAIT execution-only and explanation-only probes each reject, observed A with wrong support rejects TOTAL_UNSUPPORTED, and wrongsum+Z cannot reconstruct/admit.',
  'safe_reconstruct only enables recoverable total/schedule defects after all evidence/conflict checks, budget1 in task; new40/60 at trusted10/20 is serialized and rerun through validate then FakeApplication.admit with unchanged Facts total100/day30/A/permitted schedule/state7. Original untouched, attempts1, revalidated one proposal; zero budget none. Independent probe reproduces one fresh admission from separate candidate.',
  'Actual/main and independent probes confirm invalid proposals never append trusted admitted list; consistent WAIT abstains, conflicting/unknown/unsupported cases reject with unchanged list, real_effects0 and no effect API exists. response.md explicitly says handwritten fixed shape does not read contract.json or implement refs/applicators/dialects/full equivalence/semantic entailment/evidence lineage; parser-depth/provider/concurrency/rounding/live auth/execution untested.'
 ],
 (4,'old_skill'):[
  'Inspected validator.py/schema.json/execution.log: exact shape fields/enums allow given WAIT conflict; semantic validate rejects wrong sum, execution/explanation conflict and unknownZ despite shape pass. Independent main exits0, isolated WAIT execution-only/explanation-only shape-valid probes reject, knownA supporting7 rejects total100, wrongsum+Z blocks repair.',
  'reconstruct_once runs only exact total_mismatch+schedule_not_permitted error set on READY, requires one trusted permitted schedule matching days, deep-copies new40/60 and leaves rejected40/40 intact. New candidate re-enters same semantic/shape admission under unchanged trusted facts; one reconstruction, no loops/ambiguous choice. Actual and independent runs admit one permitted alternative.',
  'FakeAdmission only appends after no shape/semantic errors plus can_propose; invalidsum/WAIT/Z/permission cases leave accepted list unchanged and payment_effects empty. Independent consistentWAIT abstains and unsafe wrongsum+Z not reconstructed. response.md honestly disclaims full schema engine (schema.json not consumed), general semantic entailment, current tenant/freshness/depth/immutable snapshots and atomic provider execution; code imports standard library only.'
 ]
}
for task in job['tasks']:
 for config,runstring in task['runs'].items():
  run=Path(runstring); metadata=json.loads((run/'eval_metadata.json').read_text(encoding='utf-8-sig'))
  assert len(proofs[(task['id'],config)])==len(metadata['assertions'])
  expectations=[dict(text=text,passed=True,evidence=proof) for text,proof in zip(metadata['assertions'],proofs[(task['id'],config)])]
  suggestions=[]
  if task['id']==4:
   claims=[
    dict(claim='Actual local checks reject original/conflicting/unsupported proposals and admit only one reconstructed supported proposal.',type='quality',verified=True,evidence=f'Independent {config}-run.log exits0 and semantic probes reproduce no-repair/no-transition negative cases and one supported fresh admission.'),
    dict(claim='No real payment or provider effects occur.',type='factual',verified=True,evidence='Code inspected before running: standard-library parsing/validation and list appends only, no network/provider/external business writes; original and independent logs report0 real effects.'),
    dict(claim='This is a partial handwritten fixed-shape validator, not full JSON Schema or semantic entailment proof.',type='quality',verified=True,evidence='Both code shape checkers are manually enumerated, do not load documented schema, and use local typed fact support. Response limitations expressly disavow refs/combination/dialects/general entailment/provider/production integration proof.')
   ]
   suggestions.append(dict(assertion=metadata['assertions'][0],reason='Given WAIT case combines execution-day and explanation contradictions, allowing one surviving check to mask another missing check. Add separate shape-valid WAIT execution-only and explanation-only rejects plus a consistent WAIT abstention. Independent probes confirm both current outputs pass these discriminating variants.'))
   if config=='with_skill':
    suggestions.append(dict(assertion=metadata['assertions'][1],reason='The task uses one reconstruction, which is correctly bounded/tested. If widening to multiple trusted alternatives, test accurate attempted-candidate accounting: safe_reconstruct currently returns1 on any successful alternative even after earlier failed alternatives. The response already calls counting every production attempt future work; do not infer multi-candidate accounting from this pass.'))
  else:
   claims=[dict(claim='The exact proposal cannot mutate inventory or become authorized merely by dropping approved.',type='quality',verified=True,evidence='Independent arithmetic3-99=-96 and supplied read-only permission each invalidate write; response explicitly separates diagnostics from authoritative state and prohibits fabricated repair.'),dict(claim='Illustrative code and tests are proposed, not executed.',type='process',verified=True,evidence='Only response.md in output; factual transcript and response state design/no requested execution, not runtime evidence.')]
  result=dict(expectations=expectations,summary=dict(passed=len(expectations),failed=0,total=len(expectations),pass_rate=1.0),claims=claims,user_notes_summary=dict(uncertainties=[],needs_review=[],workarounds=[]),eval_feedback=dict(suggestions=suggestions,overall='Substantive semantic checks; isolate contradictory fields and distinguish one-attempt fixture from broader accounting.' if suggestions else 'No suggestions, evals look solid for this design-only rejection.'),grading_context=dict(independent=True,comparison_blinded=False,configuration_visibility='with_skill/old_skill names and paths visible',artifacts_inspected=True,executor_metrics_present=False,executor_timing_present=False,user_notes_present=False))
  for filename,field in [('outputs/metrics.json','execution_metrics'),('timing.json','timing')]:
   if (run/filename).exists(): result[field]=json.loads((run/filename).read_text(encoding='utf-8-sig'))
  (run/'grading.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
  print(f'{task["id"]} {config}: {len(expectations)}/{len(expectations)}; {run/"grading.json"}')
