"""Independent closure probes of inspected copied sources; no live replay."""
import copy
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


revised = load("revised_reconstruction", ROOT / "eval2-with_skill/reconstruction_test.py")
baseline = load("baseline_reconstruction", ROOT / "eval2-old_skill/reconstruction_test.py")
trace = json.loads((ROOT / "eval2-with_skill/safe_trace.json").read_text())
old_trace = [json.loads(line) for line in (ROOT / "eval2-old_skill/trace.jsonl").read_text().splitlines()]
# Reconstruction must consume persisted records, never call even the fake runner.
def forbidden_replay():
    raise AssertionError("Reconstruction replayed a runtime")
revised.fake_trace = forbidden_replay
baseline.fake_run = forbidden_replay
checks = []
comparisons = []


def record(name, altered, expected, required_reason=None):
    result = revised.reconstruct(altered)
    passed = result["reconstruction"] in expected
    if required_reason:
        passed = passed and any(required_reason in reason for reason in result["errors"] + result["missing"])
    checks.append({"name": name, "passed": passed, "expected_statuses": expected, "actual": result})


def remove_and_close_parent(rows, kind):
    # Close surviving links and resequence: required-event checks cannot pass
    # merely because deleting an event happened to leave a sequence gap/orphan.
    altered = copy.deepcopy(rows)
    removed = [r for r in altered if r["event_type"] == kind]
    by_span = {r["span_id"]: r for r in removed}
    altered = [r for r in altered if r["event_type"] != kind]
    for r in altered:
        while r["parent_span_id"] in by_span:
            r["parent_span_id"] = by_span[r["parent_span_id"]]["parent_span_id"]
    for index, r in enumerate(altered, 1):
        r["sequence"] = index
    return altered


record("persisted_valid_trace_with_declared_external_boundaries", copy.deepcopy(trace), ["complete_with_declared_boundaries"])
orphan = copy.deepcopy(trace)
orphan[1]["parent_span_id"] = "required-internal-parent-missing"
record("orphan_required_parent_is_incomplete", orphan, ["incomplete"], "orphan_parent")
declared_orphan = copy.deepcopy(orphan)
declared_orphan[0]["external_boundaries"].append("required-internal-parent-missing")
record("declaration_does_not_waive_required_internal_parent", declared_orphan, ["incomplete"], "orphan_parent")
cyclic = copy.deepcopy(trace)
cyclic[0]["parent_span_id"] = "worker"
record("cycle_is_inconsistent", cyclic, ["inconsistent"], "cyclic_parent_link")
for kind, reason in [("request.accepted", "missing:request.accepted"),
                     ("terminal", "missing:terminal"),
                     ("policy.allowed", "missing:policy_decision"),
                     ("approval.granted", "missing:approval_granted"),
                     ("tool.result", "missing_or_duplicate:tool_result")]:
    record("missing_required_" + kind + "_after_resequence_and_parent_repair", remove_and_close_parent(trace, kind), ["incomplete", "inconsistent"], reason)
record("empty_trace_fails_closed", [], ["incomplete", "inconsistent"])
external = copy.deepcopy(trace)
external[0]["external_boundaries"].append("opaque-provider-subtrace-not-exported")
record("additional_declared_external_subtrace_need_not_be_materialized", external, ["complete_with_declared_boundaries"])

# Baseline comparisons are evidence, not a publication gate or official-score edit.
old_orphan = copy.deepcopy(old_trace)
old_orphan[4]["parent_span_id"] = "required-internal-parent-missing"
old_cycle = copy.deepcopy(old_trace)
old_cycle[0]["parent_span_id"] = "child-read"
old_no_allow = [r for r in copy.deepcopy(old_trace) if not (r["event_type"] == "policy.decided" and r["fields"]["decision"] == "allow")]
old_no_result = [r for r in copy.deepcopy(old_trace) if r["event_type"] != "tool.result"]
for name, rows in [("orphan_parent", old_orphan), ("cycle", old_cycle), ("missing_required_policy_resequenced", old_no_allow), ("missing_required_results_resequenced", old_no_result)]:
    for index, row in enumerate(rows, 1):
        row["seq"] = index
    result = baseline.reconstruct(rows)
    comparisons.append({"name": name, "passed": not result["trace_complete"], "actual": result})

report = {"passed": all(row["passed"] for row in checks),
          "contract": "Reject/mark incomplete or inconsistent orphan required parents, cyclic links and missing required events; declared external boundaries may remain external; no live replay.",
          "scope": "Inspected identical copied source; persisted fixture records only. Runtime entry functions replaced with raising sentinels; no model/provider/network replay.",
          "check_count": len(checks), "checks": checks, "baseline_comparison": comparisons,
          "limitations": ["No production collector completeness manifest, auth/receipt evidence or distributed trace delivery is tested",
                          "Missing arbitrary events with no surviving causal/schema requirement cannot be proven absent from received records alone",
                          "External boundary declarations are recorded opaque subtraces, not authority to waive required internal parent joins"],
          "official_scores_unchanged": True}
(ROOT / "closure-probe-actual.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"passed": report["passed"], "checks": len(checks), "baseline": [{"name": r["name"], "passed": r["passed"]} for r in comparisons]}))
if not report["passed"]:
    raise SystemExit(1)
