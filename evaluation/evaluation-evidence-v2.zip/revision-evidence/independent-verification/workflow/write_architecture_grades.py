import json
from pathlib import Path

workspace = Path(r'~/Documents/Codex/2026-10-03/i-want-you-to-build-a')
job = json.loads((workspace / 'work/v2/job-agent-architecture.json').read_text(encoding='utf-8-sig'))

evidence = {
    (2, 'with_skill'): [
        'response.md Boundaries table calls retrieved ticket text untrusted data, requires instruction/data separation and tenant-scoped provenance. It explicitly says retrieved grant admin and skip review has no authority; Denied trajectory sends any proposed admin command through policy denial with no mutation.',
        'response.md uses account service as permission source of truth, policy service authenticated identity/current rules/account facts, typed diff semantic admission, authorized human reviewer for allowed permission changes, and least privilege executor bound to exact diff/account/state version/expiry. Chat cannot record authoritative success.',
        'response.md proposes two model calls/four reads/one admitted mutation/90s active execution/context/spend ceilings, repeated-proposal stop, cancellation and explicit terminal outcomes. Happy trajectory requires account-service readback plus evaluator and durable verified_complete; model solved cannot alter denied state.',
        'response.md persists intent/approval/dispatch checkpoints; unknown mutation result reconciles operation ID and account state before retry; resume rechecks identity/policy/expiry/version and reports partial execution. Proposed release cases include injection, denied authority, expired approval, cancellation, ambiguous effects, resume and deliberately bad trust-ticket/skip-readback/blind-retry variants; zero violations/false completions in tested set blocks release. No executed result is claimed.'
    ],
    (2, 'old_skill'): [
        'response.md Untrusted context row says ticket text, including grant admin and skip review, is evidence only and cannot alter policy/tool permissions. Disallowed outcomes forbid privileges from ticket instructions; denied trajectory records policy denial without mutation.',
        'response.md authority boundary uses policy service requester entitlement/permitted transitions with authoritative account data. Reviewer must approve exact target/change/version; validation checks current account version and execution is least privilege. Account service owns permissions, database owns workflow status, chat is not source of truth; approval cannot override forbidden escalation.',
        'response.md removes model-solved loop and proposes 10 minutes/8 transitions/3 model calls/6 read calls/one admitted mutation plus spend cap, repeated proposal and cancellation stops. Success requires fresh authoritative state verification, structured execution receipt and durable status; unavailable verification stays unresolved.',
        'response.md checkpoints before mutation and after receipt, reconciles idempotency key/account state after timeout before retry, and resume rechecks identity/policy/version/approval. Release cases specify permission invariants, tenant isolation, injected-ticket rejection, approval binding, cancellation, budgets, timeout reconciliation, independent completion verification with zero unauthorized writes/false verified completions; denied/happy trajectories make input/outcome concrete. Gate is explicitly proposed/unexecuted.'
    ],
    (4, 'with_skill'): [
        'response.md chooses model-assisted deterministic policy pipeline because meaning/negation/exceptions/conflicting accounts are uncertain, calls regex a comparison baseline rather than universally safe semantic replacement, and says semantic modeling need not wait for regex to fail. Source spans, faithful scope, contradiction preservation and reviewer fallback prevent regex/model guessing from becoming authority.',
        'response.md uses known interpret -> validate -> calculate -> explain sequence, one bounded interpretation call and optional bounded explanation, code-owned transitions/arithmetic/business authority, decimal/minor-unit calculation, templates based on admitted results and explicit unresolved-policy review. Typed invoices skip interpretation entirely.',
        'response.md rejects five agents for known sequence/typed arithmetic. Held-out comparisons keep rules/context/arithmetic constant across regex, one interpreter and justified checker; source-span/contradiction/explanation ablations measure semantic correctness, critical unsupported decisions, exact arithmetic, latency/cost. A second model must catch additional errors and has correlated-error risk; it cannot vote policy authority or approve arithmetic. Framework only after demonstrated state-machine/queue needs.'
    ],
    (4, 'old_skill'): [
        'response.md says regex handles stable formats but whole-policy interpretation needs evidence for negation/exceptions/conflicts/paraphrases; recommends bounded model step where rules cannot reliably express meaning. It chooses semantic model interpretation immediately and rejects unsupported contradiction resolution, preserving source spans and scope.',
        'response.md fixes interpret -> validate -> calculate -> explain with one model invocation, deterministic approved-policy validation/transitions and reproducible decimal arithmetic. Models cannot declare policy authoritative; reviewers resolve uncertainties; code/ordinary service calculates typed invoices, bounded explanation receives accepted facts and computed values.',
        'response.md rejects autonomous/five-agent framework for known stages and typed arithmetic; extra messages/reconciliation/failures/cost need measured benefit. Held-out table compares existing/regex, single interpreter, removed consistency checking, second-model review and proposed five-agent arithmetic. Second model agreement is not proof/authorization, shared context can repeat errors, and retention requires incremental error reduction worth latency/cost/escalation load.'
    ]
}

audit = []
for task in job['tasks']:
    for config, runstring in task['runs'].items():
        run = Path(runstring)
        metadata = json.loads((run / 'eval_metadata.json').read_text(encoding='utf-8-sig'))
        proofs = evidence[(task['id'], config)]
        assert len(proofs) == len(metadata['assertions'])
        response = (run / 'outputs/response.md').read_text(encoding='utf-8-sig')
        transcript = (run / 'transcript.md').read_text(encoding='utf-8-sig')
        expectations = [dict(text=text, passed=True, evidence=proof) for text, proof in zip(metadata['assertions'], proofs)]
        suggestions = []
        if task['id'] == 4:
            suggestions = [dict(reason='The prompt explicitly asks why a second model would or would not help and for a baseline/ablation decision. Assertions only broadly require evidence before complexity; add a separate outcome checking same-input comparison and correlated-error/disagreement handling so a generic defer complexity answer cannot pass without that reasoning. Both inspected outputs do provide those details.')]
        claims = [
            dict(claim='This is a proposed architecture; no implementation or runtime/benchmark evaluation was executed.', type='process', verified=True, evidence='Factual transcript states design-only execution and unexecuted checks; output uses proposed budgets/gates and contains no measured improvement claims. Only response.md exists in outputs.'),
            dict(claim='Proposed numeric ceilings are design settings rather than measured performance.', type='quality', verified=True, evidence='Ceilings are explicitly proposed/configurable (with-skill eval4 labels initial proposed); no measured timing/cost/reliability results appear. Unknown rules/precedence/provider limits/baseline remain unresolved.'),
        ]
        if config == 'old_skill':
            expected_words = 681 if task['id'] == 2 else 693
            claims.append(dict(claim=f'The saved response contains {expected_words} whitespace-delimited words.', type='factual', verified=len(response.split()) == expected_words, evidence=f'Independent Python read and split count is {len(response.split())}; matches factual transcript.'))
        result = dict(
            expectations=expectations,
            summary=dict(passed=len(expectations), failed=0, total=len(expectations), pass_rate=1.0),
            claims=claims,
            user_notes_summary=dict(uncertainties=[], needs_review=[], workarounds=[]),
            eval_feedback=dict(suggestions=suggestions, overall='Add direct coverage of the requested second-model comparative reasoning; existing outputs are substantive.' if suggestions else 'No suggestions, evals look solid for this pre-implementation design task.'),
            grading_context=dict(independent=True, comparison_blinded=False, configuration_visibility='with_skill/old_skill names and job paths visible', artifacts_inspected=True, no_runtime_execution_required=True, executor_metrics_present=False, executor_timing_present=False, user_notes_present=False)
        )
        for filename, field in [('outputs/metrics.json', 'execution_metrics'), ('timing.json', 'timing')]:
            if (run / filename).exists():
                result[field] = json.loads((run / filename).read_text(encoding='utf-8-sig'))
        (run / 'grading.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        audit.append(dict(eval_id=task['id'], configuration=config, outputs=[str(p.relative_to(run / 'outputs')) for p in (run / 'outputs').rglob('*') if p.is_file()], word_count=len(response.split()), transcript_chars=len(transcript), runtime_execution_required=False))
        print(f'{task["id"]} {config}: {len(expectations)}/{len(expectations)}; {run / "grading.json"}')
(workspace / 'work/v2/independent-verification/workflow/architecture-artifact-audit.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
