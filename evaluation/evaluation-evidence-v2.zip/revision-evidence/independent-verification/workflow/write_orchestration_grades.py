import json
from decimal import Decimal
from pathlib import Path

workspace = Path(r'~/Documents/Codex/2026-10-03/i-want-you-to-build-a')
job = json.loads((workspace / 'work/v2/job-agent-orchestration.json').read_text(encoding='utf-8-sig'))
proofs = {
    (2, 'with_skill'): [
        'response.md justifies independent tenant-isolated document workers, distinguishes deterministic comparator from semantic workers, and defers adoption until controlled deterministic/single-agent comparisons show net benefit. Proposed metrics include tenant leakage, evidence correctness, completion, p95 latency and total cost including merge work, with failure/skew/race injection. This is a design prompt: measurement protocol is present and expressly unexecuted; no measured benefit is claimed.',
        'response.md CompareTask/CompareResult carry tenant/run/task/generation, version/hash evidence, scoped allowlisted tools, completion criteria/deadline/budget. Scoped identities/storage/cache/traces and context checks prevent tenant mixing. Fan-in validates IDs/schema/scope/provenance/generation, deduplicates matching results, retains contrary evidence/versions and permits precedence only when authoritative supersession exists; one bounded targeted check then unresolved conflict.',
        'response.md atomically reserves coordinator10 + 60 comparisons×1.3=78 + verification12=100. Every call reserves worst-case charge; outstanding liabilities count and unused funds released only after reconciliation. Global70 model/132 tool/160 transitions/eight workers/five minutes; per-comparison one model/two tools/ten transitions/30s cumulative across at most two attempts. Coordinator8/8 and verification2/4 are included. Independent arithmetic confirms allocations and global call/tool totals.',
        'response.md timed-out possible effect becomes EFFECT_UNKNOWN; sole broker uses stable logical key/request hash and authoritative provider status before retry. Unresolved outcome quarantines incomplete branch; confirmed no-effect permits one quota-bounded retry, confirmed effect resumes from receipt, never fresh-key replay. Acceptance checks cancellation/current generation; late response rejected from commit but audited; resume preserves counters/generations/unknown effects.',
        'response.md worker capability has no coordinator credentials/write/shared state/delegation; one controller owns accepted results and sole broker writes. It says never majority-vote factual truth and only authorized provenance/current-generation results are admitted. No mutual conversations/recursive loops; verified progress required and three unchanged transitions stop branch.'
    ],
    (2, 'old_skill'): [
        'response.md independent sets and tenant context isolation justify separate invocations while deterministic rules use ordinary functions. Sequential-worker baseline is retained and quality/latency advantage explicitly unmeasured. Comparative design tests sequential vs parallel on representative duplicates/skew/unknown-effects/late-results, with parent/attempt/version/budget/conflict/acceptance logs and coordinator/merge cost included in aggregate spend. Measurement is proposed as appropriate to design-only task.',
        'response.md typed Task/Result carry tenant/document allowlist, source versions/digests/locations, schema, capability/deadline/lease/cancellation, claims/contradictions/unresolved questions. Fresh scoped contexts and retrieval identities plus storage/cache partitions, reference-time authorization and no merged cross-tenant transcripts. Deterministic fan-in validates scope/version/support/provenance/current lease, accepts one logical result, preserves conflict sources and declared precedence or unresolved escalation.',
        'response.md atomic75 initial workers +10 coordinator +15 recovery=100, with settled spend + outstanding reservations≤100 and unknown usage reconciled before release. Up to eight workers, two model/six reads per worker,60s attempt/10-minute job, one reconciliation round and at most one reconciled retry per set; additional attempts require funded reservations. Failed work counts and repeated unchanged evidence stops.',
        'response.md effect broker owns writes and stable operation IDs/idempotency across retries. Timeout is unknown rather than failure, requires authoritative reconciliation before retry and holds set if unresolved. Cancellation invalidates lease epoch, late results audited but rejected from fan-in/delayed effects, committed past effect cannot be undone. Missing coverage remains partial; stale attempts rejected.',
        'response.md explicitly prohibits recursive delegation, autonomous personas and mutual chat; typed contract delegationAllowed=false and no worker writes. Voting cannot establish truth; coordinator validates evidence/current policy and broker alone effects, so consensus cannot grant authority.'
    ],
    (4, 'with_skill'): [
        'response.md transition table routes typed stale source directly READY->REFRESH via authorized current-version fetch, invalidates dependent old claims, then ASSESS. Only material contradictory prose with ambiguous useful check leads CHOOSE; fixed metadata rules stay code-owned. Model choice constrained to available evidence actions cannot override stale guard or broaden access.',
        'response.md table specifies guards and typed states/read/check/ask/escalate actions; proposals need gap/target/expected gain/stopping condition, validated for scope/prerequisites/duplicate/capability/budget. Proposed12 transitions/four model/six read-check/one retry/one verification round/45s/10 shared units reserved atomically include draft/check/fallback. Two no-progress or invalid actions terminate; cancellation/late results/resume retain counters and fallback cannot reset budget.',
        'response.md rejects planner/critic/router/reviewer roles and unlimited messages as unsupported coordination; starts ordinary functions/state machine under single controller. Proposed comparison among deterministic workflow, one model routing and bounded single agent measures grounded answer/action rate/latency/cost/no-progress. Workers need separable useful context/verification evidence; framework only demonstrated durable/scheduling/maintainability needs. No results invented.'
    ],
    (4, 'old_skill'): [
        'response.md typed freshness drives deterministic current-version fetch before relying on stale source; failed fetch stays unresolved. Model step only chooses useful action for conflicting prose from finite authorized read/check menu, proposing target/gain/clarified decision/stopping. Runtime owns scope/permission/budget; untrusted prose cannot change control.',
        'response.md state table defines Inspect/Refresh/Select/Execute/Answer/Ask-Stop-Complete with current-version/scope/usefulness/evidence guards, one bounded recovery and answer repair. Four model/eight reads/two ambiguity rounds/one fetch retry per source/30s/configured spend cap jointly bound invocation; validation/repair count against totals. Two consecutive unchanged rounds stop; identity/digests/issues track actual progress, cancellation/epoch checks reject late reads. A separate overall numeric transition maximum is absent, but finite rounds/calls/reads/retries plus this guarded graph bound substantive steps.',
        'response.md rejects unlimited persona messages/workers/framework for this task and selects one controller plus ordinary functions/state machine/adapters. Framework only if durability/scheduling/tracing exceed simpler implementation; same owner/limits must persist. Proposed comparison to single-agent baseline measures supported answers/conflict visibility/calls/spend/latency/no-progress before expanding coordination.'
    ]
}

audit = []
for task in job['tasks']:
    for config, runstring in task['runs'].items():
        run = Path(runstring)
        metadata = json.loads((run / 'eval_metadata.json').read_text(encoding='utf-8-sig'))
        evidence = proofs[(task['id'], config)]
        assert len(evidence) == len(metadata['assertions'])
        expectations = [dict(text=text, passed=True, evidence=item) for text, item in zip(metadata['assertions'], evidence)]
        suggestions = []
        claims = [
            dict(claim='This is a proposed design; no worker execution, live effects or benchmark results occurred.', type='process', verified=True, evidence='Transcript and response explicitly mark design-only work and proposed/unexecuted comparisons/limits; outputs contains only response.md.'),
            dict(claim='Role/persona consensus does not provide evidence truth or action authority.', type='quality', verified=True, evidence='One deterministic controller owns acceptance; admitted source support, capability/policy checks and effect owner replace voting; mutual/unlimited messages rejected.')
        ]
        if task['id'] == 2:
            allocation = Decimal('10') + Decimal(60)*Decimal('1.3') + Decimal('12') if config == 'with_skill' else Decimal('75') + Decimal('10') + Decimal('15')
            assert allocation == Decimal('100')
            claims.append(dict(claim='Shared allocations total 100 budget units and reservations count toward the cap.', type='factual', verified=True, evidence=f'Independent decimal sum is {allocation}; response requires worst-case/atomic or settled+outstanding accounting, failed/unknown work included. This verifies design arithmetic, not implemented concurrency safety.'))
            suggestions.append(dict(assertion=metadata['assertions'][0], reason='Wording measures net benefit implies executed evidence although the user only requested design. Replace with defines a measurable baseline/ablation decision (quality, latency and total overhead/cost), and use a separate runnable eval to check actual measurements. These outputs honestly propose experiments rather than claiming them.'))
            if config == 'with_skill':
                assert 60 + 8 + 2 == 70 and 60*2 + 8 + 4 == 132
                claims.append(dict(claim='Global 70 model calls/132 tools include comparison, coordinator and verification ceilings.', type='factual', verified=True, evidence='Independent arithmetic: 60×1+8+2=70; 60×2+8+4=132. Per-comparison limits explicitly cumulative across attempts; not performance measurements.'))
                claims.append(dict(claim='The broker records status and receipt before dispatch.', type='quality', verified=False, evidence='Exact response wording groups receipt with key/hash/status before dispatch, but no executed receipt exists yet. An intent or placeholder can be durable before dispatch; a confirmed execution receipt must be obtained after effect/reconciliation. Design does not clearly distinguish these records, so actual receipt timing is unsupported.'))
                suggestions.append(dict(assertion=metadata['assertions'][3], reason='Clarify request intent versus confirmed execution receipt: the proposed broker sentence says records ... status and receipt before dispatch. Persist intent/key/hash first, then actual effect receipt; check that an intent-only record cannot be treated as a confirmed outcome during reconciliation. Existing unknown-effect design otherwise satisfies assertion.'))
        result = dict(
            expectations=expectations,
            summary=dict(passed=len(expectations), failed=0, total=len(expectations), pass_rate=1.0),
            claims=claims,
            user_notes_summary=dict(uncertainties=[], needs_review=[], workarounds=[]),
            eval_feedback=dict(suggestions=suggestions, overall='Meaningful design coverage; clarify proposed measurements and pre-dispatch intent versus actual execution receipt.' if suggestions else 'No suggestions, evals look solid for this design task.'),
            grading_context=dict(independent=True, comparison_blinded=False, configuration_visibility='with_skill/old_skill names and paths visible', artifacts_inspected=True, no_runtime_execution_required=True, executor_metrics_present=False, executor_timing_present=False, user_notes_present=False)
        )
        for filename, field in [('outputs/metrics.json', 'execution_metrics'), ('timing.json', 'timing')]:
            if (run / filename).exists():
                result[field] = json.loads((run / filename).read_text(encoding='utf-8-sig'))
        (run / 'grading.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        audit.append(dict(eval_id=task['id'], configuration=config, word_count=len((run/'outputs/response.md').read_text(encoding='utf-8-sig').split()), outputs=[str(p.relative_to(run/'outputs')) for p in (run/'outputs').rglob('*') if p.is_file()], runtime_execution_required=False))
        print(f'{task["id"]} {config}: {len(expectations)}/{len(expectations)}; {run / "grading.json"}')
(workspace/'work/v2/independent-verification/workflow/orchestration-artifact-audit.json').write_text(json.dumps(audit, indent=2) + '\n', encoding='utf-8')
