import json
from pathlib import Path

workspace = Path(r'~/Documents/Codex/2026-10-03/i-want-you-to-build-a')
job = json.loads((workspace / 'work/v2/job-agent-development-workflow.json').read_text(encoding='utf-8-sig'))
logroot = workspace / 'work/v2/independent-verification/workflow'

def claim(text, kind, verified, evidence):
    return dict(claim=text, type=kind, verified=verified, evidence=evidence)

evidence = {
    (1, 'with_skill'): [
        (True, 'response.md Contract and uncertainty ownership assigns bounded model receipt interpretation and source-span fallback, integer minor units/decimal parsing to code, and human approval plus trusted executor to payments. It calls regex-only semantic parsing an unvalidated hypothesis and five agents unsupported until matched ablation.'),
        (True, 'response.md Baseline and release gates compares the prototype and regex implementation under identical inputs/budgets before substantial implementation, with held-out versioned fixtures and separate authority/arithmetic/provenance, interpretation, failure, latency/cost gates. First vertical slice uses scripted extractor and fake payment; final paragraph explicitly requires PLAN -> diff -> actual command/output -> debug/correction -> rerun -> KEEP/REVISE/ROLLBACK.'),
        (True, 'response.md distinguishes retrieved candidates from used support, validates ID existence/sufficiency and explanation amounts, records evidence/decision/approval digests, bounds candidate search to two, handles timeout/invalid-output/no-candidate outcomes, uses injection fixtures and approval/idempotency/reconciliation. Opening and proposed command explicitly say nothing was executed; transcript confirms design-only task.'),
        (True, 'response.md Decision and defence table marks three material decisions PROPOSED, records hypotheses/alternatives, rationale, limitation/fallback and reconsideration trigger. It states one happy example establishes feasibility only for that example, and production release lacks executed evidence.')
    ],
    (1, 'without_skill'): [
        (True, 'response.md opening chooses one bounded service: extraction proposes facts and deterministic code calculates reimbursement/governs payment; regex-only is a challenger baseline and the five-agent framework is deferred pending measured need. Uncertainty map and contracts cover ambiguous totals, source validation, exact minor-unit arithmetic and approval.'),
        (False, 'response.md supplies held-out baselines and multidimensional release gates plus a local fixture -> calculation -> cited answer -> approval -> fake ledger slice. However it stops at First execute this locally, then replace the fake adapter and a suggested failure review with corrective action. It does not define the asserted repeatable run/debug/correct/rerun/review path or specify review decisions after rerunning a correction. Gates/slice alone cannot satisfy the whole bundled assertion.'),
        (True, 'response.md immutable receipt IDs/hashes and source locators feed validated facts and code-derived numbers; invented IDs and explanation mismatches fail validation. Receipt contents cannot change policy/tool permissions; authorization is rechecked and unknown payment outcomes reconciled. Timeout, duplicate, missing/contradictory evidence and sensitive logs are addressed. All gates are explicitly unexecuted and transcript confirms no dataset/provider tests.'),
        (True, 'response.md globally labels Everything below is proposed; ADR-01 chooses deterministic financial authority and single orchestrator because they reduce unsupported monetary decisions, with measured-ablation revisit; ADR-02 chooses versioned raw-source citations for reproducibility and rejects unresolvable citations. Unresolved evidence/review and unknown-effect reconciliation are fallbacks, and the opening rejects production reliability from one receipt. These are concrete proposed decision/defence records despite their compact format.')
    ],
    (2, 'with_skill'): [
        (True, 'plan.md states boundary/authority invariant; preserved vertical_slice_buggy.py contains supplied >=20 predicate. bug-run-initial.log shows 3 failures/1 error, bug-run.log 4 failures, debug.md diagnoses reversed upper bound and independent approval protection; correction.diff changes only admit to 0 < amount <= POLICY_CAP. Independent bundled-Python rerun of preserved buggy snapshot reproduces 4 failures exit 1, corrected suite 15/15 exit 0; logs in independent-verification/workflow/with_skill-{buggy,corrected}-suite.log.'),
        (True, 'Inspected vertical_slice.py/test_vertical_slice.py; validators reject 30 for policy_cap, unknown R9, unequal explanation, unsupported total/currency/schema and denied authority before effects. Independent corrected suite passes 15 tests; independent CLI log records unchanged 30 rejection, separate R1/USD 20 fresh admission, exactly one fake effect and consistent answer/citation. Both code and tests verify second candidate under same facts and authorization.'),
        (True, 'MAX_CANDIDATES=2, TimeoutError returns timeout after one call, exhaustion returns no_valid_candidate; tests prove third candidate unconsumed/no effect. run trace records rejected proposal/reason and admitted proposal/used_support receipt:R1#total; independent CLI records source marker, admitted decision, matching R1/USD/20 effect, answer citation, and two calls. Timeout is a scripted exception, explicitly not wall-clock cancellation.'),
        (True, 'response.md REVIEW and KEEP cite inspected one-line diff, fixture outcomes and exact unchanged proposals; decision table is VALIDATED for local fixtures only. Limits explicitly list scripted sources/whole units, injected timeout, identity/expiry/signatures/persistent state/idempotency/payment recovery unimplemented and no latency/cost/extraction claims. Code imports only json/copy and uses returned in-memory effects; independent executions used no provider.')
    ],
    (2, 'without_skill'): [
        (True, 'plan.md states exact min(30,20) policy and no invalid effects; starter_slice.py preserves >=20. before-fix.log has 11 tests/3 failures; response.md diagnoses reversed predicate selecting 30 before fallback. slice.py corrects cap and deterministic expected amount. after-fix.log shows 11/11; independent buggy import rerun reproduces 3 failures exit 1 and corrected suite 11/11 exit 0 in independent-verification/workflow/without_skill-{buggy,corrected}-suite.log.'),
        (True, 'slice.py choose validates source, currency and explanation, rejects policy amount 30 and freshly validates 20. FakeLedger.commit revalidates evidence/admission/authorized_max and permits one request entry. Passing literal fixture tests plus independent without_skill-behavior-probe.log show 30->20 second-call success with one entry, R9/inconsistent/timeout/no candidate yielding no entries. Replay test verifies one in-memory entry and authorization test denies maximum19.'),
        (False, 'Bounded search and terminal statuses are verified: MAX_CANDIDATES=2; timeout one call; two invalid candidates no_valid_candidate and no effect, also independently probed. But no source/decision/effect evidence trace is implemented or saved: Decision stores only final proposal, unassociated reason strings and attempt count; FakeLedger stores request->proposal. Rejected candidate payloads, source evidence/version or used-support marker, admission event and linked execution receipt are absent. A final receipt_id and test success are insufficient evidence for the bundled trace requirement.'),
        (True, 'response.md reviews contract checks, fresh supported proposal, bounded exhaustion and effect revalidation, tying correction to actual before/after logs. Limits explicitly confine results to local fixture, trusted constants, integer units and in-memory replay; real OCR, provider timeouts, concurrency, reconciliation, authenticated approval/expiry and live adapters remain untested. slice.py imports dataclasses only; no provider/network/payment code exists.')
    ],
    (3, 'with_skill'): [
        (True, 'Inspected outputs/response.md: exactly Return insufficient_evidence when facts are absent. with a trailing newline. Correct token and original sentence preserved.'),
        (True, 'Only response.md exists in outputs for this task and contains the corrected sentence only. Transcript explicitly excludes tiny edits from lifecycle workflow; no architecture, approval, eval or lifecycle documentation is imposed on the response.')
    ],
    (3, 'without_skill'): [
        (True, 'Inspected outputs/response.md: exactly Return insufficient_evidence when facts are absent. with a trailing newline. Correct token and original sentence preserved.'),
        (True, 'Only response.md exists in outputs for this task; sentence has no added commentary, architecture/approval/evaluation/lifecycle instructions. Transcript documents a one-token text correction without execution or provider.')
    ]
}

for task in job['tasks']:
    for config, runstring in task['runs'].items():
        run = Path(runstring)
        metadata = json.loads((run / 'eval_metadata.json').read_text(encoding='utf-8-sig'))
        judgements = evidence[(task['id'], config)]
        assert len(judgements) == len(metadata['assertions'])
        expectations = [dict(text=text, passed=passed, evidence=proof) for text, (passed, proof) in zip(metadata['assertions'], judgements)]
        passed = sum(item['passed'] for item in expectations)
        claims = []
        suggestions = []
        if task['id'] == 1:
            claims = [
                claim('This design has no executed parsing/evaluation/payment evidence.', 'process', True, 'Opening limitations and proposed/unexecuted gate labels align with factual transcript; only response.md was produced.'),
                claim('One happy example does not establish production reliability.', 'quality', True, 'No independent corpus, measured failures, authority/payment recovery results or held-out tests are supplied; output accurately gates future production release.')
            ]
            suggestions.append(dict(assertion=metadata['assertions'][1], reason='This bundles baselines, critical gates, development lifecycle and slice into one verdict. Separate measurable gates from explicit correction/rerun/review protocol so a strong design with an omitted lifecycle is diagnosed accurately.'))
        elif task['id'] == 2:
            count = 15 if config == 'with_skill' else 11
            failures = 4 if config == 'with_skill' else 3
            claims = [
                claim(f'The corrected complete local suite passes {count} tests.', 'factual', True, f'Independent bundled Python -X utf8 -B rerun in output directory reproduced {count} tests OK exit 0; {config}-corrected-suite.log.'),
                claim(f'The preserved starter code exposes the reversal with {failures} failures.', 'factual', True, f'Independent unittest import of preserved buggy module reproduced {failures} failures exit 1 without modifying executor artifacts; {config}-buggy-suite.log.'),
                claim('The valid second amount20 candidate produces one fake effect; invalid candidates do not produce effects.', 'quality', True, 'Inspected mutation path and fixture assertions; independent CLI/behavior probe verifies same-fact 30 rejection and supported20 success plus invalid cases.'),
                claim('There are no provider/network/live payment effects in this implementation.', 'factual', True, 'All executable Python inspected before execution; imports are standard library only and effects are lists/dictionaries in memory.'),
                claim('The injected timeout validates wall-clock cancellation or provider reliability.', 'quality', False, 'No such production claim is made; this is explicitly a coverage limitation. TimeoutError fixture validates only response to a scripted exception, with no real deadline/cancellation or provider.')
            ]
            # Record actual claims, not an invented claim that the response explicitly disavows.
            claims[-1] = claim('Timeout is simulated; provider and production reliability remain untested.', 'quality', True, 'Tests inject TimeoutError and output explicitly limits claims to the local fake; no real timing/cancellation mechanism or provider exists.')
            suggestions.extend([
                dict(reason='Specify whether reimbursement is any supported positive amount<=cap (with-skill accepts19) or exactly min(observed,cap) (baseline rejects19). Prompt only authorizes any amount<=20 and supplies candidate20, so both choose different plausible fixture semantics outside the main path; a hand-labelled policy/boundary assertion should settle this.'),
                dict(assertion=metadata['assertions'][2], reason='Split bounded terminal behavior from provenance trace and define minimum trace fields (candidate ID/payload, source evidence, admission result, and effect link). Current bundle makes a safe local flow fail for absent trace; bare reason strings should not silently pass provenance.'),
                dict(assertion=metadata['assertions'][2], reason='Clarify that injected timeout handling is the intended fixture requirement. If real elapsed-time boundedness is intended, add a blocking-adapter/deadline test; these tests cannot establish cancellation of a stalled call.')
            ])
        else:
            claims = [claim('Only the misspelled insufficient_evidence token was corrected.', 'factual', True, 'Compared exact output sentence to eval prompt: all other words/punctuation unchanged; newline only.')]
        result = dict(
            expectations=expectations,
            summary=dict(passed=passed, failed=len(expectations)-passed, total=len(expectations), pass_rate=passed/len(expectations)),
            claims=claims,
            user_notes_summary=dict(uncertainties=[], needs_review=[], workarounds=[]),
            eval_feedback=dict(suggestions=suggestions, overall='Substantive assertions; identified bundled lifecycle/trace checks and policy/timeout specification gaps.' if suggestions else 'No suggestions, evals look solid.'),
            grading_context=dict(independent=True, comparison_blinded=False, configuration_visibility='with_skill/without_skill names and job paths visible', artifacts_inspected=True, executor_metrics_present=False, executor_timing_present=False, user_notes_present=False)
        )
        for filename, field in [('outputs/metrics.json', 'execution_metrics'), ('timing.json', 'timing')]:
            if (run / filename).exists():
                result[field] = json.loads((run / filename).read_text(encoding='utf-8-sig'))
        (run / 'grading.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        print(f'{task["id"]} {config}: {passed}/{len(expectations)}; {run / "grading.json"}')
