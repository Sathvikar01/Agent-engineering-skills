"""Additional independent behavior probes, copied source and fresh local ledgers only."""
import importlib.util
import json
import sqlite3
import sys
from dataclasses import replace
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "behavior-ledgers"
DATA.mkdir(exist_ok=True)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


revised = load("cost_revised_probe", ROOT / "eval2-with_skill/workload.py")
baseline = load("cost_old_probe", ROOT / "eval2-old_skill/fake_workload.py")
checks = []


def record(name, passed, observed):
    checks.append({"name": name, "passed": bool(passed), "observed": observed})


def is_denied(exception, call):
    try:
        call()
    except exception:
        return True
    return False


cache, scope, authority = revised.Cache(), revised.Scope(), revised.Authority()
cache.put(scope, revised.ImmutableRead("private immutable data"))
scoped = cache.get(replace(scope, tenant="other"), authority) is None and cache.get(replace(scope, principal="other"), authority) is None
authority.read_allowed = False
record("revised_cache_key_isolation_and_current_access", scoped and is_denied(PermissionError, lambda: cache.get(scope, authority)), {"other_scopes_miss": scoped, "revoked_read_blocks_warm_hit": True})
record("revised_cache_cannot_hold_approval", is_denied(TypeError, lambda: cache.put(scope, {"approved": True})), "Mutable approval dictionary rejected")
ledger = revised.Ledger(DATA / "revised-order.sqlite")
ledger.reserve("task")
authority = revised.Authority()
task = revised.FakeTask("task", ledger, authority, revised.Scope())
before = ledger.snapshot()
rejected_order = is_denied(ValueError, lambda: task.mutate("B"))
authority.mutation_allowed = False
rejected_permission = is_denied(PermissionError, lambda: task.mutate("A"))
record("revised_admission_denial_has_no_action_charge_or_time", rejected_order and rejected_permission and before == ledger.snapshot() and task.clock == 0 and ledger.actions("task") == [], {"snapshot": ledger.snapshot(), "clock": task.clock, "actions": ledger.actions("task")})
authority.mutation_allowed = True
task.mutate("A")
authority.mutation_allowed = False
before = ledger.snapshot()
denied_b = is_denied(PermissionError, lambda: task.mutate("B"))
record("revised_B_rechecks_permission_after_A", denied_b and ledger.snapshot() == before and ledger.actions("task") == ["A"], {"actions": ledger.actions("task"), "clock": task.clock})
ledger = revised.Ledger(DATA / "revised-restart.sqlite", cap="15")
ledger.reserve("spent-and-pending")
ledger.charge("spent-and-pending", "spent-and-pending:1", "cold_read", "1", 10, "transient_failure")
ledger.reserve("other-worker", "5")
resumed = revised.Ledger(DATA / "revised-restart.sqlite", cap="15")
restored_task = revised.FakeTask("spent-and-pending", resumed, revised.Authority(), revised.Scope())
changed_cap = is_denied(ValueError, lambda: revised.Ledger(DATA / "revised-restart.sqlite", cap="250"))
over = is_denied(revised.BudgetDenied, lambda: resumed.reserve("new-worker", "1"))
record("revised_restart_preserves_spent_pending_clock_and_limits", Decimal(resumed.snapshot()["spent"]) == 1 and Decimal(resumed.snapshot()["pending"]) == 14 and restored_task.clock == 10 and restored_task.attempt == 1 and changed_cap and over,
       {"snapshot": resumed.snapshot(), "restored_clock": restored_task.clock, "restored_attempts": restored_task.attempt, "cap_change_denied": changed_cap, "extra_worker_denied": over})
result = revised.execute_task("unreliable-claim", "permanent_failure", revised.Ledger(DATA / "revised-claim.sqlite"), revised.Cache())
record("revised_success_prose_does_not_admit_B_or_pass_verifier", result["verified_success"] is False and result["attempts"] == 3 and result["cost"] == "3.2", result)

cache, key = baseline.ReadCache(), baseline.cache_key("input")
cache.put(key, baseline.ImmutableRead("input", "private immutable data"), 100)
scoped = cache.get(replace(key, tenant="other"), 0, True) is None and cache.get(replace(key, prompt_version="other"), 0, True) is None
record("baseline_cache_isolation_current_access_no_approval", scoped and is_denied(baseline.Denied, lambda: cache.get(key, 0, False)) and is_denied(TypeError, lambda: cache.put(key, {"approved": True}, 100)), {"other_scopes_miss": scoped})
ledger = baseline.Ledger(DATA / "baseline-order.sqlite3")
ledger.admit("task", "worker")
before = ledger.snapshot()
order = is_denied(baseline.DependencyError, lambda: ledger.mutate("task", "B"))
ledger.set_permissions("task", mutate_allowed=False)
permission = is_denied(baseline.Denied, lambda: ledger.mutate("task", "A"))
record("baseline_denial_no_charge_or_action", order and permission and before == ledger.snapshot() and ledger.task_events("task") == [], {"snapshot": ledger.snapshot(), "attempt_events": ledger.task_events("task")})
ledger.set_permissions("task", mutate_allowed=True)
ledger.mutate("task", "A")
ledger.set_permissions("task", mutate_allowed=False)
before = ledger.snapshot()
denied = is_denied(baseline.Denied, lambda: ledger.mutate("task", "B"))
record("baseline_B_rechecks_current_permission", denied and before == ledger.snapshot() and [r[0] for r in ledger.task_events("task")] == ["A"], {"events": ledger.task_events("task")})
ledger = baseline.Ledger(DATA / "baseline-restart.sqlite3", cap=15000)
ledger.admit("spent-and-pending", "worker")
ledger.bill("spent-and-pending", "read_cold", "transient_failure", 1000, 10)
ledger.admit("other-worker", "worker2", 5000)
resumed = baseline.Ledger(DATA / "baseline-restart.sqlite3", cap=15000)
changed = is_denied(ValueError, lambda: baseline.Ledger(DATA / "baseline-restart.sqlite3", cap=250000))
over = is_denied(baseline.BudgetError, lambda: resumed.admit("new-worker", "worker3", 1000))
record("baseline_restart_preserves_spent_pending_clock_limits", resumed.snapshot()["spent"] == 1 and resumed.snapshot()["pending"] == 14 and baseline.logical_clock(resumed, "spent-and-pending") == 10 and changed and over, {"snapshot": resumed.snapshot(), "restored_clock": baseline.logical_clock(resumed, "spent-and-pending"), "cap_change_denied": changed, "extra_worker_denied": over})
ledger = baseline.Ledger(DATA / "baseline-claim.sqlite3")
result = baseline.run_task(ledger, baseline.ReadCache(), "unreliable-claim", "permanent-failure", "worker")
record("baseline_model_claim_ignored_for_B_and_success", result["model_claimed_success"] is True and result["verified_success"] is False and [r[0] for r in ledger.task_events("unreliable-claim")] == ["read_cold", "A", "verify"], result)

new_arithmetic = json.loads((ROOT / "eval4-with_skill/rerun-arithmetic-results.json").read_text(encoding="utf-8-sig"))
old_arithmetic = json.loads((ROOT / "eval4-old_skill/rerun-arithmetic-results.json").read_text(encoding="utf-8-sig"))
record("revised_supplied_arithmetic_independently_checked", Fraction(new_arithmetic["variants"]["S"]["cost_per_verified_success_exact"]) == Fraction(1, 4) and Fraction(new_arithmetic["variants"]["S_plus_V"]["cost_per_verified_success_exact"]) == Fraction(15, 41) and not new_arithmetic["variants"]["S_plus_V"]["passes_supplied_p95_gate"] and not new_arithmetic["model_experiments_executed"], {"S": "1/4", "V": "15/41", "V_p95": 8, "required_p95": 5})
record("baseline_supplied_arithmetic_independently_checked", Decimal(old_arithmetic["S"]["cost_per_success_units"]) == Decimal("0.25") and abs(Decimal(old_arithmetic["V"]["cost_per_success_units"]) - Decimal(30) / 82) < Decimal("1e-26") and not old_arithmetic["V"]["p95_feasible"] and not old_arithmetic["routing_ablations_executed"], {"S": old_arithmetic["S"]["cost_per_success_units"], "V": old_arithmetic["V"]["cost_per_success_units"], "routing_experiments_executed": False})

report = {"passed": all(row["passed"] for row in checks), "check_count": len(checks), "checks": checks,
          "scope": "Independent behavior probes on inspected copied local fake sources and fresh SQLite only; synthetic economics and supplied cohort arithmetic; no live effects/provider/performance gain claim."}
(ROOT / "behavior-probe-actual.json").write_text(json.dumps(report, indent=2, default=str) + "\n", encoding="utf-8")
print(json.dumps({"passed": report["passed"], "checks": len(checks)}))
if not report["passed"]:
    raise SystemExit(1)
