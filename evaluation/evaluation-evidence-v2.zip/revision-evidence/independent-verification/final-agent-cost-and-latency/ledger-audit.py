"""Independent immutable SQL audit; never trust reported/model success booleans."""
import json
import math
import sqlite3
from collections import Counter
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[3]
ITERATION = WORKSPACE / "work/v2/agent-cost-and-latency-workspace/iteration-2"
REFERENCE = json.loads((WORKSPACE / "work/v2/cost-workload-reference.json").read_text(encoding="utf-8-sig"))
D = Decimal


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def audit(database, revised, label):
    # immutable read-only URI avoids journals, sidecars, migrations or any writes.
    db = sqlite3.connect(database.resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
    db.row_factory = sqlite3.Row
    tasks = db.execute("SELECT * FROM tasks").fetchall()
    if revised:
        events = db.execute("SELECT * FROM charges").fetchall()
        limits = db.execute("SELECT cap,task_cap FROM limits WHERE id=1").fetchone()
        cap, task_cap = map(D, limits)
    else:
        events = db.execute("SELECT * FROM events ORDER BY event_id").fetchall()
        limits = db.execute("SELECT cap,task_cap,spent FROM config WHERE id=1").fetchone()
        cap, task_cap = D(limits[0]) / 1000, D(limits[1]) / 1000
    details, success_latencies = [], []
    total = D(0)
    for task in tasks:
        task_id = task["id"] if revised else task["task_id"]
        if revised:
            attempts = sorted([e for e in events if e["task_id"] == task_id], key=lambda e: int(e["attempt_id"].rsplit(":", 1)[1]))
            action_rows = db.execute("SELECT op FROM actions WHERE task_id=? ORDER BY sequence", (task_id,)).fetchall()
            actions = [r[0] for r in action_rows]
            independently_successful = actions == ["A", "B"]
        else:
            attempts = [e for e in events if e["task_id"] == task_id]
            actions = [e["operation"] for e in attempts if e["operation"] in {"A", "B"} and e["outcome"] == "success"]
            state = db.execute("SELECT a_ok,b_ok FROM state WHERE task_id=?", (task_id,)).fetchone()
            independently_successful = bool(state[0] and state[1] and actions == ["A", "B"])
        canonical = []
        for event in attempts:
            op = event["op"] if revised else event["operation"]
            op = {"read_cold": "cold_read", "read_warm": "warm_read"}.get(op, op)
            cost = D(event["cost"]) if revised else D(event["charge"]) / 1000
            expected_cost, expected_duration = {"cold_read": (D("1"), 10), "warm_read": (D("0.1"), 2), "A": (D("2"), 20), "B": (D("3"), 30), "verify": (D("0.2"), 5)}[op]
            assert (cost, event["duration"]) == (expected_cost, expected_duration), (label, task_id, "price/duration mismatch")
            canonical.append({"operation": op, "outcome": event["outcome"], "cost": str(cost), "duration_ms": event["duration"]})
        task_cost = sum((D(e["cost"]) for e in canonical), D(0))
        latency = sum(e["duration_ms"] for e in canonical)
        recorded_cost = D(task["spent"]) if revised else D(task["spent"]) / 1000
        assert task_cost == recorded_cost <= task_cap
        assert D(task["remaining"] if revised else task["pending"]) == 0
        fixture = next(name for name in REFERENCE["groups"] if name.replace("_", "-") in task_id.replace("_", "-"))
        expected = REFERENCE["groups"][fixture]
        expected_ops = {
            "cold_success": ["cold_read", "A", "B", "verify"],
            "warm_success": ["warm_read", "A", "B", "verify"],
            "retry_success": ["cold_read", "cold_read", "A", "B", "verify"],
            "permanent_failure": ["cold_read", "A", "verify"],
        }[fixture]
        assert [e["operation"] for e in canonical] == expected_ops, (label, task_id, "ordered trajectory")
        assert task_cost == D(str(expected["cost_per_task"])) and latency == expected["latency_ms"]
        assert independently_successful == expected["verified_success"]
        if fixture == "retry_success":
            assert canonical[0]["outcome"] == "transient_failure" and canonical[1]["outcome"] == "success"
        if fixture == "permanent_failure":
            assert canonical[1]["outcome"] == "permanent_failure" and actions == []
        if independently_successful:
            success_latencies.append(latency)
        details.append({"task_id": task_id, "fixture": fixture, "actual_attempts": canonical,
                        "authoritative_ordered_actions": actions, "independently_verified_success": independently_successful,
                        "cost_synthetic_units": str(task_cost), "logical_completion_ms": latency})
        total += task_cost
    task_count, success_count = len(details), len(success_latencies)
    latencies = sorted(d["logical_completion_ms"] for d in details)
    rank = math.ceil(D("0.95") * task_count)
    success_rank = math.ceil(D("0.95") * success_count)
    success_latency = sorted(success_latencies)[success_rank - 1]
    assert task_count == REFERENCE["logical_tasks"] == 40
    assert len({d["task_id"] for d in details}) == task_count
    assert Counter(d["fixture"] for d in details) == {key: 10 for key in REFERENCE["groups"]}
    assert total == D(str(REFERENCE["expected_cost_units"])) == D("219")
    assert success_count == REFERENCE["expected_verified_successes"] == 30
    assert total / success_count == D(str(REFERENCE["expected_cost_per_verified_success"])) == D("7.3")
    assert rank == 38 and latencies[rank - 1] == REFERENCE["nearest_rank_p95_terminal_latency_ms"] == 75
    assert success_rank == 29 and success_latency == 75
    assert sum(len(d["actual_attempts"]) for d in details) == 160
    if revised:
        assert D(db.execute("SELECT peak FROM stats WHERE id=1").fetchone()[0]) <= cap == D("250")
    else:
        assert D(limits[2]) / 1000 == total <= cap == D("250")
    db.close()
    return {"label": label, "database": str(database), "passed": True,
            "success_source": "Independent ordered action records plus baseline state flags; no task-result verified_success/model_claimed_success/status fields used",
            "task_count": task_count, "charged_attempts": 160, "failed_attempts": sum(e["outcome"] in {"transient_failure", "permanent_failure"} for d in details for e in d["actual_attempts"]),
            "cost_synthetic_units": str(total), "verified_successes": success_count, "cost_per_verified_success": str(total / success_count),
            "all_terminal_sorted_latencies_ms": latencies, "terminal_p95_rank": rank, "terminal_p95_ms": latencies[rank - 1],
            "success_only_denominator": success_count, "success_only_p95_rank": success_rank, "success_only_p95_ms": success_latency,
            "logical_duration_sum_ms": sum(latencies), "all_task_details": details}


audits = [
    audit(ITERATION / "eval-2-adversarial/with_skill/run-1/outputs/workload-ledger.sqlite", True, "original_with_skill"),
    audit(ROOT / "eval2-with_skill/execution/workload-ledger.sqlite", True, "copied_rerun_with_skill"),
    audit(ITERATION / "eval-2-adversarial/old_skill/run-1/outputs/execution-1/workload.sqlite3", False, "original_old_skill"),
    audit(ROOT / "eval2-old_skill/execution/workload.sqlite3", False, "copied_rerun_old_skill"),
]
result = {"passed": all(a["passed"] for a in audits), "audits": audits,
          "scope": "Independent read-only immutable SQL plus exact Decimal billing and all 40 logical latencies per original/copied run. Acceptance ledgers excluded. Synthetic fixture only, no provider measurement or before/after improvement claim.",
          "reference": "work/v2/cost-workload-reference.json; fixed before executor trials, arithmetic reference not itself execution evidence"}
(ROOT / "ledger-audit-actual.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"passed": result["passed"], "audits": [{key: a[key] for key in ["label", "task_count", "charged_attempts", "cost_synthetic_units", "verified_successes", "cost_per_verified_success", "terminal_p95_rank", "terminal_p95_ms"]} for a in audits]}))
