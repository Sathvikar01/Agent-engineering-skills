Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$workspace=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$python='~/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
if(!(Test-Path -LiteralPath $python)){throw 'Documented bundled Python unavailable'}
$cases=@(
    @{Name='eval2-with_skill';Run='eval-2-adversarial/with_skill';File='workload.py'},
    @{Name='eval2-old_skill';Run='eval-2-adversarial/old_skill';File='fake_workload.py'},
    @{Name='eval4-with_skill';Run='eval-4-v2-targeted/with_skill';File='arithmetic.py'},
    @{Name='eval4-old_skill';Run='eval-4-v2-targeted/old_skill';File='supplied_arithmetic.py'}
)
$manifest=@()
foreach($case in $cases){
    $original=Join-Path $workspace ('work/v2/agent-cost-and-latency-workspace/iteration-2/'+$case.Run+'/run-1/outputs/'+$case.File)
    $dir=Join-Path $PSScriptRoot $case.Name
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $copy=Join-Path $dir $case.File
    Copy-Item -LiteralPath $original -Destination $copy
    $hash=(Get-FileHash -LiteralPath $original).Hash
    $output=Join-Path $dir 'execution'
    if($case.Name -eq 'eval2-with_skill'){
        & $python $copy workload --output $output *> (Join-Path $dir 'rerun-workload-command.log')
        $code=$LASTEXITCODE
        if($code -ne 0){throw 'Revised copied workload failed'}
        & $python $copy acceptance --output $output *> (Join-Path $dir 'rerun-acceptance-command.log')
        $acceptanceCode=$LASTEXITCODE
        if($acceptanceCode -ne 0){throw 'Revised copied acceptance failed'}
    }elseif($case.Name -eq 'eval2-old_skill'){
        & $python $copy --output-dir $output *> (Join-Path $dir 'rerun-command.log')
        $code=$LASTEXITCODE
        if($code -ne 0){throw 'Baseline copied workload/acceptance failed'}
    }else{
        & $python $copy > (Join-Path $dir 'rerun-arithmetic-results.json') 2> (Join-Path $dir 'rerun-stderr.log')
        $code=$LASTEXITCODE
        if($code -ne 0){throw 'Copied arithmetic failed'}
    }
    if((Get-FileHash -LiteralPath $original).Hash -ne $hash -or (Get-FileHash -LiteralPath $copy).Hash -ne $hash){throw 'Source hash changed'}
    $manifest+=[pscustomobject]@{Case=$case.Name;OriginalSource=$original;CopiedSource=$copy;SHA256=$hash;OriginalUnchanged=$true;ExitCode=$code;Output=$output;Python=$python;Scope='Inspected standard-library copied source; local SQLite/in-memory/synthetic-clock effects only'}
}
$manifest | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'rerun-manifest.json') -Encoding UTF8
$manifest | Select-Object Case,ExitCode,OriginalUnchanged | ConvertTo-Json
