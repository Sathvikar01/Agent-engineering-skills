"""Independent static/hash/JSON checks only; no prompt behavior is measured."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
BASE=ROOT/"work/v2/prompt-engineering-workspace/iteration-1"
DEST=Path(__file__).resolve().parent
for ident,name in ((2,"eval-2-adversarial"),(4,"eval-4-v2-targeted")):
    for config in ("with_skill","old_skill"):
        run=BASE/name/config/"run-1"
        outputs=run/"outputs"
        prompt=outputs/("prompt.md" if config=="with_skill" else "prompt.txt")
        response=outputs/"response.md"
        meta=json.loads((outputs/"metadata.json").read_text(encoding="utf-8-sig"))
        calculated=hashlib.sha256(prompt.read_bytes()).hexdigest()
        assert calculated==meta["prompt_sha256"].lower()
        words=len(response.read_text(encoding="utf-8-sig").split())
        if config=="with_skill":
            assert words==meta["response_word_count"]
            cases=json.loads((outputs/"eval-cases.json").read_text(encoding="utf-8-sig"))
            assert cases["status"]=="proposed_unexecuted"
            assert len(cases["cases"])==(9 if ident==2 else 3)
            assert meta["model"] is None and meta["comparison"] is None
            case_count=len(cases["cases"])
        else:
            expected_skill=hashlib.sha256((ROOT/"work/v2/v1-snapshot/prompt-engineering/SKILL.md").read_bytes()).hexdigest()
            assert expected_skill==meta["baseline_skill_sha256"].lower()
            assert meta["comparison"]=="not measured"
            case_count=3 if ident==4 else None
        note={"grader_identity":"/root/v2_grade_remaining","comparison_blinded":False,"run":str(run),"prompt_sha256_verified":calculated,"response_words":words,"prompt_words":len(prompt.read_text(encoding="utf-8-sig").split()),"parsed_metadata":True,"proposed_case_count":case_count,"static_checks_passed":True,"behavioral_evaluation_executed":False,"no_live_effects":True,"review":"Complete transcript, prompt, response, metadata and actual artifact-check logs reviewed. Current JSON case counts/status independently verified; baseline three task4 cases reviewed in response. Hash/file checks do not establish deployed role/schema compatibility, model behavior, semantic support or enforcement."}
        (DEST/("eval-"+str(ident)+"-"+config+".json")).write_text(json.dumps(note,indent=2)+"\n",encoding="utf-8")
        print(str(ident)+"/"+config+": hash/metadata/word checks PASS; behavioral eval not executed")
