"""Offline reviewed telemetry fixtures; preserve original executor artifacts."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parents[4]
JOB=json.loads((ROOT/"work/v2/job-agent-observability-iteration-1.json").read_text(encoding="utf-8-sig"))
DEST=Path(__file__).resolve().parent
FILES={(2,"with_skill"):"reconstruct_test.py",(2,"old_skill"):"reconstruction_test.py",(4,"with_skill"):"signal_contracts.py",(4,"old_skill"):"validate_contracts.py"}
for task in JOB["tasks"]:
    for config,run in task["runs"].items():
        source=Path(run)/"outputs"/FILES[task["id"],config]
        spec=importlib.util.spec_from_file_location("obs_"+str(task["id"])+"_"+config,source)
        module=importlib.util.module_from_spec(spec)
        stream=io.StringIO()
        with contextlib.redirect_stdout(stream):
            spec.loader.exec_module(module)
        if not(task["id"]==4 and config=="old_skill"):
            result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
            assert result.wasSuccessful()
        probes=[]
        if task["id"]==2:
            current=config=="with_skill"
            rows=module.fixture() if current else module.history()
            encoded=json.dumps(rows)
            markers=[module.SECRET,module.PRIVATE] if current else ["SECRET-CREDENTIAL","SECRET-OUTPUT","PRIVATE-REASONING"]
            assert all(m not in encoded for m in markers)
            report=module.reconstruct(rows)
            denied_field="denied_operations"
            assert report[denied_field]==(["denied-delete"] if current else ["write-1"])
            probes.append("PASS: sanitized fixture contains no raw credential/private-reasoning markers and retains denied operation alongside final answer status")
            missing=[e for e in rows if not((e.get("kind")=="policy.decision" and e.get("decision")=="deny") if current else (e.get("event_type")=="admission.decided" and e.get("decision")=="deny"))]
            missing_report=module.reconstruct(missing)
            assert (not missing_report["complete"]) if current else missing_report["audit_status"]=="incomplete"
            probes.append("PASS: removed denial event yields incomplete reconstruction: "+json.dumps(missing_report,sort_keys=True))
            changed=copy.deepcopy(rows)
            if current:
                attempt=next(e for e in changed if e["kind"]=="tool.attempt")
                attempt["operation_id"]="denied-delete"
                assert "attempt_after_denial" in module.reconstruct(changed)["issues"]
            else:
                attempt=next(e for e in changed if e["event_type"]=="tool.attempt")
                attempt.update(logical_operation_id="write-1",admission_ref="e12")
                assert "denied_operation_dispatched" in module.reconstruct(changed)["problems"]
            probes.append("PASS: injected dispatch for denied operation is detected by offline reconstruction; no action executed")
            marker="NEW_SYNTHETIC_CREDENTIAL_NOT_REAL"
            if current:
                sample=module.safe_event({"versions":{"api_credentials":marker}})
                assert marker in json.dumps(sample)
                changed=copy.deepcopy(rows)
                child=next(e for e in changed if e["kind"]=="worker.started")
                child["parent_span_id"]="absent-parent"
                bad_join=module.reconstruct(changed)
                assert bad_join["complete"]
                probes.append("LIMITATION CONFIRMED: current reconstruct accepts orphan parent_span_id despite complete=true; fixture nested-worker test only checks prebuilt values")
            else:
                sample=module.project({"reason_code":marker})
                assert marker in json.dumps(sample)
                assert "run_id" not in module.METRIC_LABELS
            probes.append("LIMITATION CONFIRMED: arbitrary synthetic credential text in an allowlisted field is not generically scanned/typed; controlled fixture field removal is not universal privacy assurance")
        elif config=="with_skill":
            assert len(module.CONTRACTS)==8
            for c in module.CONTRACTS:
                assert c["baseline"]["value"] is None and c["threshold_status"]=="provisional_unvalidated"
                assert all(c[k] for k in ["threshold","observation_window","denominator","severity","owner","response"])
            bad=module.evidence_record("probe",["D3","D4"],["D3"],["D3"],["D4"],"unsupported")
            assert bad["reference_violation"] and bad["support_verdict"]=="unsupported"
            joined=module.evidence_record("probe2",["D3"],["D3"],["D3"],["D3"],"unsupported")
            assert not joined["reference_violation"] and joined["support_verdict"]=="unsupported"
            assert module.baseline_drift(.12,None)["value"] is None
            assert module.ratio(0,1,100)["value"] is None
            probes.append("PASS: eight actionable provisional contracts; unused/invisible citation rejected, valid ID join does not overwrite unsupported verdict, missing baseline/small sample are unavailable not zero")
        else:
            document=module.document
            assert len(document["contracts"])==7 and document["historical_numeric_baseline"] is None
            absent={c["name"]:[k for k in ["threshold","severity","owner"] if k not in c] for c in document["contracts"]}
            assert all(v==["threshold","severity","owner"] for v in absent.values())
            probes.append("ACTIONABLE CONTRACT GAP OBSERVED: "+json.dumps(absent,sort_keys=True))
            probes.append("PASS is structural only: numeric thresholds explicitly unset; baseline=null; no three complete threshold/severity/owner contracts exist in JSON or response")
        log=DEST/("eval-"+str(task["id"])+"-"+config+".log")
        log.write_text("runtime="+sys.executable+"\nflags=-X utf8 -B\nreviewed_source="+str(source)+"\n"+stream.getvalue()+"\n"+"\n".join(probes)+"\nverification_process_exit_code=0\nNo live effects. Scripts loaded without their artifact-writing main blocks; original fixture/log files preserved.\n",encoding="utf-8")
        print(str(task["id"])+"/"+config+": local suite/validator and independent probes completed; "+str(log))
