Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$workspace=(Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '../../../..')).Path
$cases=@(
    @{Name='eval2-with_skill';Run='eval-2-adversarial/with_skill';Files=@('runtime.py','test_runtime.py');Module='test_runtime';Tests=18;Demo=$null},
    @{Name='eval4-with_skill';Run='eval-4-v2-targeted/with_skill';Files=@('scripted_runtime.py','test_scripted_runtime.py');Module='test_scripted_runtime';Tests=19;Demo='scripted_runtime.py'},
    @{Name='eval2-old_skill';Run='eval-2-adversarial/old_skill';Files=@('test_refund_runtime.py');Module='test_refund_runtime';Tests=16;Demo=$null},
    @{Name='eval4-old_skill';Run='eval-4-v2-targeted/old_skill';Files=@('test_model_boundary.py');Module='test_model_boundary';Tests=11;Demo='test_model_boundary.py'}
)
$manifest=@()
foreach($case in $cases){
    $dir=Join-Path $PSScriptRoot $case.Name
    New-Item -ItemType Directory -Force -Path $dir | Out-Null
    $sources=@()
    foreach($file in $case.Files){
        $original=Join-Path $workspace ('work/v2/agent-testing-workspace/iteration-2/'+$case.Run+'/run-1/outputs/'+$file)
        $hash=(Get-FileHash -LiteralPath $original).Hash
        Copy-Item -LiteralPath $original -Destination (Join-Path $dir $file)
        $sources+=[pscustomobject]@{Original=$original;File=$file;SHA256=$hash}
    }
    Push-Location -LiteralPath $dir
    python -m unittest -v $case.Module *> rerun-test.log
    $code=$LASTEXITCODE
    Get-Content -LiteralPath rerun-test.log
    if($code -ne 0){Pop-Location;throw ('Copied test rerun failed '+$case.Name)}
    if($null -ne $case.Demo){
        if($case.Name -eq 'eval4-old_skill'){python $case.Demo --scenarios > rerun-traces.json 2> rerun-demo-stderr.log}
        else{python $case.Demo > rerun-traces.json 2> rerun-demo-stderr.log}
        $demoCode=$LASTEXITCODE
        if($demoCode -ne 0){Pop-Location;throw ('Copied demo rerun failed '+$case.Name)}
    }
    Pop-Location
    foreach($source in $sources){
        if((Get-FileHash -LiteralPath $source.Original).Hash -ne $source.SHA256 -or (Get-FileHash -LiteralPath (Join-Path $dir $source.File)).Hash -ne $source.SHA256){throw 'Source integrity failed'}
    }
    $manifest+=[pscustomobject]@{Case=$case.Name;ExitCode=$code;ExpectedTests=$case.Tests;Sources=$sources;OriginalSourcesUnchanged=$true;Scope='Inspected standard-library source; copied in-memory fixtures only; no provider calls'}
}
$manifest | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'rerun-manifest.json') -Encoding UTF8
$manifest | Select-Object Case,ExitCode,ExpectedTests,OriginalSourcesUnchanged | ConvertTo-Json
