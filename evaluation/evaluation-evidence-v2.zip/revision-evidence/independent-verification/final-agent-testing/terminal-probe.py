"""Independent terminal/controller checkpoint probes on inspected copied fakes."""
import copy
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


refund = load("refund_revised_probe", "eval2-with_skill/runtime.py")
scripted = load("scripted_revised_probe", "eval4-with_skill/scripted_runtime.py")
old_refund = load("refund_old_probe", "eval2-old_skill/test_refund_runtime.py")
old_scripted = load("scripted_old_probe", "eval4-old_skill/test_model_boundary.py")
checks, comparison = [], []


def record(name, passed, observed):
    checks.append({"name": name, "passed": bool(passed), "observed": observed})


terminal_scripts = {
    "accepted": [scripted.proposal(5)],
    "refusal": [{"refusal": "stop"}],
    "unsupported_tool": [{"tool_call": {"name": "not-supported"}}],
    "no_progress": [{"output": "not-json"}] * 2,
    "exhausted": [scripted.proposal(11), scripted.proposal(12), scripted.proposal(13)],
}
for status, responses in terminal_scripts.items():
    store = scripted.Store()
    model = scripted.ScriptedModel(responses)
    controller = scripted.Controller(store)
    first = controller.run("logical-original", model)
    before = copy.deepcopy(store)
    calls = model.calls
    again = controller.run("logical-original", model)
    record("same_controller_" + status + "_no_dispatch_or_effect", first["status"] == status and again == first and model.calls == calls and store == before,
           {"status": first["status"], "calls_before": calls, "calls_after": model.calls, "effects_before": len(before.effects), "effects_after": len(store.effects)})
    resumed_store = copy.deepcopy(before)
    fresh_model = scripted.ScriptedModel([scripted.proposal(10)])
    resumed = scripted.Controller(resumed_store, max_steps=999, max_retries=999).run("logical-original", fresh_model)
    record("restored_terminal_checkpoint_" + status + "_no_dispatch_or_effect", resumed == first and fresh_model.calls == 0 and resumed_store == before,
           {"outcome": resumed, "new_model_calls": fresh_model.calls, "effects": len(resumed_store.effects), "checkpoint_unchanged": resumed_store == before})

store = scripted.Store()
first_model = scripted.ScriptedModel([scripted.proposal(5)])
scripted.Controller(store).run("first-logical-task", first_model)
same_model = scripted.ScriptedModel([scripted.proposal(6)])
scripted.Controller(store).run("first-logical-task", same_model)
record("changed_new_script_same_task_does_not_create_new_work", same_model.calls == 0 and len(store.effects) == 1,
       {"model_calls": same_model.calls, "effects": store.effects})
new_model = scripted.ScriptedModel([scripted.proposal(6)])
scripted.Controller(store).run("distinct-logical-task", new_model)
record("distinct_logical_task_permits_distinct_work", new_model.calls == 1 and len(store.effects) == 2 and {e["task_id"] for e in store.effects} == {"first-logical-task", "distinct-logical-task"},
       {"model_calls": new_model.calls, "effects": store.effects})

state = refund.DurableState(accounts={"account": refund.Account("tenant", 20)},
                            approvals={"grant": refund.Approval("tenant", "task1", "account", 5, 0, 20)})
provider = refund.FakeProvider(state)
request = refund.Request("tenant", "task1", "account", "grant", 5)
runtime = refund.Runtime(state, provider, lambda: 1)
first = runtime.execute("tenant", request)
before = state.snapshot()
again = runtime.execute("tenant", request)
record("refund_terminal_reentry_no_second_dispatch_effect", first == again and state == before and provider.dispatches == 1 and len(state.effects) == 1,
       {"receipt": again, "dispatches": provider.dispatches, "effects": len(state.effects)})
restored = copy.deepcopy(state)
restored_provider = refund.FakeProvider(restored)
def dispatch_forbidden(*args, **kwargs):
    raise AssertionError("Terminal replay tried to dispatch/lookup")
restored_provider.dispatch = dispatch_forbidden
restored_provider.lookup = dispatch_forbidden
receipt = refund.Runtime(restored, restored_provider, lambda: 999, dispatch_budget=999).execute("tenant", request)
record("refund_restored_terminal_checkpoint_uses_receipt_without_adapter", receipt == first and restored == before,
       {"receipt": receipt, "state_unchanged": restored == before, "dispatches": restored_provider.dispatches, "lookups": restored_provider.lookups})
changed = refund.Request("tenant", "task1", "account", "new-grant", 6)
denied = False
try:
    runtime.execute("tenant", changed)
except refund.Denied:
    denied = True
record("refund_new_work_cannot_reuse_terminal_task_payload", denied and state == before and provider.dispatches == 1,
       {"denied": denied, "dispatches": provider.dispatches, "effects": len(state.effects)})
state.approvals["new-grant"] = refund.Approval("tenant", "task2", "account", 6, 1, 20)
receipt = runtime.execute("tenant", refund.Request("tenant", "task2", "account", "new-grant", 6))
record("refund_distinct_task_with_fresh_grant_executes_new_work", provider.dispatches == 2 and len(state.effects) == 2 and receipt["task_id"] == "task2" and state.accounts["account"].refundable == 9,
       {"receipt": receipt, "dispatches": provider.dispatches, "effects": state.effects, "balance": state.accounts["account"].refundable})

# Baseline acceptance comparison is kept separate; never modifies official scores.
old_model = old_scripted.ScriptedModel([old_scripted.proposal(4), old_scripted.proposal(6)])
old_controller = old_scripted.Controller(old_model)
old_first = old_controller.run()
old_before = {"calls": old_model.calls, "effects": copy.deepcopy(old_controller.effects)}
old_again = old_controller.run()
comparison.append({"name": "baseline_scripted_terminal_success_reentry", "passed": old_model.calls == old_before["calls"] and old_controller.effects == old_before["effects"],
                   "observed": {"first": old_first, "again": old_again, "calls_before": old_before["calls"], "calls_after": old_model.calls, "effects_before": old_before["effects"], "effects_after": old_controller.effects}})
old_model = old_scripted.ScriptedModel([{"refusal": "stop"}, old_scripted.proposal(4)])
old_controller = old_scripted.Controller(old_model)
old_controller.run()
old_before = {"calls": old_model.calls, "effects": copy.deepcopy(old_controller.effects)}
old_controller.run()
comparison.append({"name": "baseline_scripted_terminal_refusal_reentry", "passed": old_model.calls == old_before["calls"] and old_controller.effects == old_before["effects"],
                   "observed": {"calls_before": old_before["calls"], "calls_after": old_model.calls, "effects_before": old_before["effects"], "effects_after": old_controller.effects}})
comparison.append({"name": "baseline_scripted_checkpoint_restore", "passed": False,
                   "observed": "No checkpoint/logical-task store or terminal-outcome restore exists in source; response explicitly lists cross-run persistence/budgets unverified."})
old_store = old_refund.Store(accounts={"account": old_refund.Account("tenant", 20)})
old_request = old_refund.Request("tenant", "account", 5, "task1", "grant")
old_store.approvals["grant"] = old_refund.Approval(old_request.payload(), 0, 20)
old_provider = old_refund.FakeProvider(old_store)
old_runtime = old_refund.Runtime(old_store, old_provider)
old_receipt = old_runtime.execute(old_request)
old_again = old_refund.Runtime(old_store, old_provider).execute(old_request, now=999)
comparison.append({"name": "baseline_refund_terminal_restart", "passed": old_again == old_receipt and old_provider.commit_calls == 1 and len(old_provider.effects) == 1,
                   "observed": {"commit_calls": old_provider.commit_calls, "effect_count": len(old_provider.effects), "receipt": old_again}})

result = {"passed": all(c["passed"] for c in checks),
          "contract": "Reentering a terminal controller or resuming its terminal checkpoint does not dispatch or append another effect; new work uses a distinct logical task.",
          "check_count": len(checks), "checks": checks, "baseline_comparison": comparison,
          "scope": "Inspected identical copied in-memory sources; deterministic call/effect/checkpoint evidence; no live model or provider.",
          "limitations": ["Deep-copied in-memory checkpoints are not process/database durability", "No concurrency or transactional provider replay is verified"],
          "official_scores_unchanged": True}
(ROOT / "terminal-probe-actual.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"passed": result["passed"], "checks": result["check_count"], "baseline": [{"name": r["name"], "passed": r["passed"]} for r in comparison]}))
if not result["passed"]:
    raise SystemExit(1)
