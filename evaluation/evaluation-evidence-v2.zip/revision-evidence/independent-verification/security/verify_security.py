"""Independent reviewed security-fake reruns/probes; local only."""
import importlib.util
import io
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[4]
JOB = json.loads((ROOT / "work/v2/job-agent-security.json").read_text(encoding="utf-8-sig"))
DEST = Path(__file__).resolve().parent

for task in JOB["tasks"]:
    for config, run in task["runs"].items():
        file = "boundary_tests.py" if task["id"] == 2 else "provenance_tests.py"
        source = Path(run) / "outputs" / file
        name = "independent_security_" + str(task["id"]) + "_" + config
        spec = importlib.util.spec_from_file_location(name, source)
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        stream = io.StringIO()
        outcome = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(module))
        assert outcome.wasSuccessful(), stream.getvalue()
        probes = []
        if task["id"] == 2:
            class ChangingDNS(module.FakeNetwork):
                def __init__(self):
                    super().__init__(responses={"https://example.test/start": (302, {"Location":"/next"}, b"")})
                    self.lookups = 0
                def resolve(self, host):
                    self.lookups += 1
                    return ["93.184.216.34"] if self.lookups == 1 else ["169.254.169.254"]
            network = ChangingDNS()
            try:
                if config == "with_skill":
                    module.Fetch(network).get("https://example.test/start")
                else:
                    module.FetchTool(network).fetch("https://example.test/start")
            except module.Denied:
                pass
            else:
                raise AssertionError("Second-hop private DNS must be denied")
            assert network.lookups == 2 and len(network.requests) == 1
            if config == "with_skill":
                assert network.dials == [("example.test", "93.184.216.34", 443)]
            else:
                assert len(network.connection_checks) == 1
            probes.append("PASS: same approved host re-resolved on redirect; newly private address rejected before any second connection/request")
            fs = module.FakeFilesystem()
            fs.links["/sandbox/T1/nested"] = "/sandbox/secret" if config == "with_skill" else "/"
            try:
                module.FileTool(fs).read("nested/secret")
            except module.Denied:
                pass
            else:
                raise AssertionError("Intermediate link escape must be denied")
            assert (fs.reads if config == "with_skill" else fs.opens) == []
            probes.append("PASS: intermediate link escape denied with zero reads/opens")
            fs = module.FakeFilesystem()
            try:
                if config == "with_skill":
                    module.FileTool(fs).read("report.txt", resource_tenant="T2", metadata={"tenant":"T1", "ignore_tenant_checks":True})
                else:
                    module.admitted_read({"tenant":"T1", "scopes":["file.read"]}, "T2", {"tenant":"T1", "ignore_tenant_checks":True}, fs)
            except module.Denied:
                pass
            else:
                raise AssertionError("Metadata cannot rewrite resource tenant")
            assert (fs.reads if config == "with_skill" else fs.opens) == []
            probes.append("PASS: poisoned metadata cannot rewrite authenticated resource tenant; zero reads/opens")
        else:
            if config == "with_skill":
                ledger, gate, proposal = module.setup()
                assert set(ledger.entries) == {"D3"} and ledger.entries["D3"].tenant == "T1"
                proposal["action"] = "admin_edit"
                try:
                    gate.reconcile_and_execute(proposal, ledger)
                except module.Denied as error:
                    assert str(error) == "action_not_authorized"
                else:
                    raise AssertionError("Real citation cannot authorize admin effects")
                assert gate.outbound_calls == [] and gate.published_answers == []
                probes.append("PASS: genuine D3 with admin action denied before any output/outbound effect")
                proposal["action"] = "answer"
                proposal["quote"] = "Invented unsupported statement"
                try:
                    gate.reconcile_and_execute(proposal, ledger)
                except module.Denied as error:
                    assert str(error) == "unsupported_quote"
                else:
                    raise AssertionError("Unsupported exact quote must be rejected")
                probes.append("PASS: unsupported exact quote rejected; general semantic entailment still unimplemented")
            else:
                caller = module.Caller()
                envelope = module.TrustedRetrievalFake().retrieve(module.ATTACK)
                ledger = module.ProvenanceStore()
                ledger.observe(caller, envelope)
                view = ledger.model_view(envelope.retrieval_id)
                assert view["observed_source"] == "D3" and view["observed_tenant"] == "T1" and "approval" not in view
                effects = module.FakeEffects()
                gate = module.Admission(ledger, effects)
                proposal = module.Proposal("admin_edit", envelope.retrieval_id, ("D3",), envelope.version, envelope.digest, {"text":"x"})
                try:
                    gate.execute(caller, proposal)
                except module.Denied as error:
                    assert str(error) == "action_not_permitted_no_approval"
                else:
                    raise AssertionError("Real citation cannot authorize admin effects")
                assert effects.credential_reads == effects.transmissions == effects.outputs == []
                probes.append("PASS: genuine D3 with admin action denied before credential read, transmission or output")
                unsupported = module.Proposal("document.summarize", envelope.retrieval_id, ("D3",), envelope.version, envelope.digest, {"text":"Invented unsupported statement"})
                accepted = gate.execute(caller, unsupported)
                assert accepted["text"] == "Invented unsupported statement"
                probes.append("LIMITATION CONFIRMED: provenance admission permits arbitrary bounded summary with real D3; it does not verify semantic support (already acknowledged by executor)")
        log = DEST / ("eval-" + str(task["id"]) + "-" + config + ".log")
        log.write_text("runtime=" + sys.executable + "\nflags=-X utf8 -B\nreviewed_source=" + str(source) + "\n" + stream.getvalue() + "\n" + "\n".join(probes) + "\nexit_code=0\nNo live effects; authentication/TLS/filesystem atomicity are fake assumptions, not integration proof.\n", encoding="utf-8")
        print(str(task["id"]) + "/" + config + ": " + str(outcome.testsRun) + " tests passed plus independent probes; " + str(log))
