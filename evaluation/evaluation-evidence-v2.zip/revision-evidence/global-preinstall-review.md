# Global installation helper review

Before mutation, inspected actual Codex/Claude custom exposures. Existing architecture and obsolete orchestration paths are junctions targeting central CC Switch storage; `.agents/skills/multi-agent-orchestration` is absent. Central v1 custom files still match the immutable snapshot.

The actual root PowerShell host returns junction `Target` as `System.String`. Direct `[0]` indexing would select its first character. Normalize with `[string](@($item.Target)[0])` to support string and array representations before comparing the full expected path. The actual obsolete junction normalization equals `~/.cc-switch/skills/multi-agent-orchestration` (Windows separators in the live value).

Added preflight checks for every retained custom junction, in addition to obsolete-name and collision guards. Parsed the installation script with PowerShell's native parser: zero errors. No global mutation occurred during these checks. Final copied content and junction targets will be audited after installation.
