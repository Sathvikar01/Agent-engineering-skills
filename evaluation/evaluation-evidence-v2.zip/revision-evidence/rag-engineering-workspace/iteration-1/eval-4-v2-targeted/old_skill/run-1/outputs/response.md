# Diagnose and reconcile the evidence chain

The provided trace identifies two clear failures: normalization loses A's provenance, and final output both misstates the validated total and attaches unsupported citations. Repair that evidence chain before considering additional retrieval components. A is already retrieved, included in context, and used by the decision.

| Stage | Observed behavior | Diagnosis |
|---|---|---|
| Search | Retrieves current rule A, total=100, and unrelated archived marketing B | Required evidence is available. B is irrelevant noise; this trace alone does not establish recall or an index failure. |
| Normalization | Converts A into N1, dropping its source pointer | Provenance loss. N1 cannot independently establish which document, version and span support its content. |
| Context assembly | Contains both A and B | A survived assembly. B adds irrelevant context and possible attribution confusion; actual attention or token displacement is unknown. |
| Decision | Uses A to validate total | A is used evidence. B's mere inclusion does not make it decision support. Record the validated value 100 with A's anchor. |
| Final generation/output | Says 120 and cites B plus guessed Z | Incorrect factual output and broken claim support. B does not support the rule; Z lacks a verified source. |

Because the final answer changes 100 to 120, this is more than a citation-formatting defect. The trace does not reveal whether generation, response mapping, or a later rendering step introduced that value; compare the structured decision artifact with the serialized response at each boundary. Likewise, losing N1's pointer creates a provenance defect but does not prove it caused this wrong total: original A remained in context and was used. Instrument the boundaries before asserting causality.

Maintain separate records for **retrieved**, **assembled**, **used**, and **cited** evidence. Here retrieved and assembled are {A,B}; decision-used is {A}; final-cited is {B,Z}. Those sets serve different purposes. Do not mechanically force every retrieved source into the answer, or demand that every used source always appear regardless of which claims survive final editing. Reconcile each published claim to the evidence actually used to establish it.

A minimal contract can carry the following conceptual records; exact span and version identifiers must come from actual source ingestion, not be guessed:

```text
source A: current rule, total=100, source/version/span anchor
source B: archived marketing, no support for the total claim
N1: normalized total=100, derived_from=[A's source/version/span anchor]
decision total: value=100, used_evidence=[A's supporting anchor]
final total claim: value=100, citations=[A's supporting anchor]
```

Preserve origin anchors through normalization, splitting, deduplication and summarization. If a summary combines sources, retain a claim-to-span mapping rather than one arbitrary parent ID. Detect a missing mapping at that boundary; rebuild it from the verified original span or re-normalize A. If it cannot be reconstructed, mark the normalized item unsuitable for grounded claims and use verified original A or abstain.

Before release, reconcile the final structured claims against the decision and evidence ledger. For this claim, require numeric equality to 100, an anchor resolving to A's supporting current-rule span, and applicable source access/version checks. Reject 120. Reject B as a support citation and reject guessed Z because it is not a verified source anchor. Repair by constructing the claim from the validated decision value and its stored supporting anchor, then recheck the rendered output. If support is missing or conflicting, omit/qualify the claim or abstain instead of substituting a plausible citation.

Proposed checks, **not executed**, include provenance retention from A to N1; rejection of missing, invented or stale anchors; numeric drift from decision to final output; archived-source mismatch; and exact source-span support. Also compare actual context with oracle A-only context and repeat stochastic generation to determine whether B's inclusion measurably harms answers. Test one correction at a time with fixed corpus, query set and budgets, measuring final correctness and citation support separately from retrieval quality. No pipeline, model or corpus was supplied, so no experimental gains, latency or reliability results are claimed. Do not add reranking or another model unless a matched, held-out ablation demonstrates a benefit that justifies its cost and complexity.
