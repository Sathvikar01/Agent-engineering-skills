The pipeline had the needed evidence and used it in the decision, but lost provenance during normalization and failed to reconcile the final answer with the decision. The grounded result is **total=100, citing A's current-rule span/version**. The emitted 120, citation B and guessed Z must fail validation before release.

| Stage | Supplied observation | Diagnosis |
|---|---|---|
| Search | Retrieved A and B | Relevant evidence was retrieved. B is irrelevant noise; this does not establish insufficient recall or a need for reranking. |
| Normalization | A became N1 without its source pointer | Transformation lineage was broken. N1 cannot independently establish attributable support until its A linkage is restored and verified. |
| Context assembly | Contains A and B | A was retained at document level. A's exact supporting span/version still needs recording; B's presence does not make it supporting evidence. |
| Decision | Uses A to validate total | A is used evidence for the validated fact. Preserve this association in an application-owned decision record. |
| Output | Says 120; cites B and Z | Structured-fact/explanation drift plus unsupported citation B and fabricated/unobserved citation Z. Finalization and reconciliation failed. |

Coverage, retrieval loss and document-level context loss are not demonstrated here. The first known provenance failure is normalization; the known fact/citation failures occur later. The decision's use of A is given in the scenario. In an implemented system, validate that association against observed spans rather than trusting a model's self-reported “used sources.” The unrelated archived B should not determine the current rule, even though it was retrieved and context-visible. No evidence is provided that Z was ever observed.

Use three distinct sets: `retrieved={A,B}`, `context_visible={A,B}`, and `used_for_total={A}`. A normalized item is a derived node, not a new independent source. Reconstruct N1 from A, or discard N1 and rely on the observed A span; do not retroactively invent a pointer merely because its summary sounds plausible. Track whether a source is accessible, current and claim-supporting separately from whether it entered context.

The evidence ledger should carry source ID, canonical locator, source version, span offsets or stable span ID, content digest, retrieval/context membership, and access/freshness status. Every derived fact needs a transformation ID, parent source/span/version, and the source text necessary to verify the extraction. For this example, record `N1.total=100 → A:<verified rule span>@<observed version>`. Placeholders here are schema examples, not discovered identifiers. A decision record should contain the canonical fact, validation rule, support span IDs and decision outcome. Keep retrieval ranks outside the factual support relation.

Reconcile in application code before rendering:

1. Resolve each proposed source ID through the observed, accessible ledger. Z fails membership; B passes observation but fails relevance and entailment for total.
2. Resolve each transformation's lineage. N1 fails until its actual A parent and span are recovered or N1 is replaced.
3. Check that the cited span/version supports the exact emitted claim and the applicable current rule. A supporting a different version or neighboring claim would also fail.
4. Compare emitted structured total against the decision's validated total: `120 != 100`, so reject the output. Render the numeric fact and its explanation from the canonical decision record, then verify that their meaning agrees. Numeric equality alone does not verify unrestricted prose.
5. Require the total claim's citations to resolve to used supporting evidence. Do not attach every retrieved candidate. Unknown citations, missing lineage and contradictory facts trigger bounded repair or abstention, never release of the invalid draft.

Use existing spans and deterministic field checks first. A general schema validator establishes shape and identifiers, not semantic support. Free-text entailment and ambiguous rule applicability remain separate verification needs; this symbolic scenario supplies the support relationship but no real source text to test it.

Proposed, unexecuted checks include: A remains retrieved but its span is omitted; N1 loses lineage; B is retrieved but unused; Z is guessed; the output changes 100 to 120; A has a stale version; and the structured value is 100 while prose says 120. Log evidence retention, lineage completeness, decision-to-output fact agreement, citation support precision and unknown-source rejection separately. Run controlled ablations fixing lineage and final rendering one at a time, holding corpus, queries and budgets fixed. Add no reranker or extra model without measured residual failures and a matched ablation demonstrating benefit. No experimental quality, cost or latency results were measured here.
