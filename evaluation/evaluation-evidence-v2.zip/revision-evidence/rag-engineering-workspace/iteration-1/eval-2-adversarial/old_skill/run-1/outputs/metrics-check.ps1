$ErrorActionPreference = 'Stop'
$goldDocs = @('A', 'C')
$rankedDocs = @('B', 'A', 'A', 'C')
$cutoff = 3
$rawCutoff = @($rankedDocs | Select-Object -First $cutoff)
$rawHits = @($rawCutoff | Select-Object -Unique | Where-Object { $_ -in $goldDocs })
$rawRecall = $rawHits.Count / [double]$goldDocs.Count
$uniqueRanking = @($rankedDocs | Select-Object -Unique)
$uniqueCutoff = @($uniqueRanking | Select-Object -First $cutoff)
$uniqueHits = @($uniqueCutoff | Where-Object { $_ -in $goldDocs })
$uniqueRecall = $uniqueHits.Count / [double]$goldDocs.Count
$firstRank = 0
for ($index = 0; $index -lt $rankedDocs.Count; $index++) {
    if ($rankedDocs[$index] -in $goldDocs) { $firstRank = $index + 1; break }
}
$reciprocalRank = if ($firstRank -gt 0) { 1.0 / $firstRank } else { 0.0 }
if ($rawRecall -ne 0.5 -or $uniqueRecall -ne 1.0 -or $reciprocalRank -ne 0.5) {
    throw 'Metric arithmetic check failed.'
}
'Raw cutoff: ' + ($rawCutoff -join ',')
'Unique relevant hits at raw cutoff: ' + ($rawHits -join ',')
'Raw-cutoff-first document Recall@3: ' + $rawRecall
'Stable unique ranking: ' + ($uniqueRanking -join ',')
'Dedup-first document Recall@3: ' + $uniqueRecall
'First relevant raw rank: ' + $firstRank
'Reciprocal rank: ' + $reciprocalRank
'Arithmetic checks passed. No model, retriever, security, or export test was run.'
