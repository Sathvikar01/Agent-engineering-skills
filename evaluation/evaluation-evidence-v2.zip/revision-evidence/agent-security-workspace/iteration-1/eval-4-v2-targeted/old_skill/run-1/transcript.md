# Factual execution transcript

Configuration: old_skill; task 4, executed after task 2. Read its exact prompt from the assigned job JSON. Used only the already-read frozen baseline skill, not v2 source, hidden assertions/grades, or other configuration outputs. Initial inventory of this assigned run showed no implementation, response, log, or transcript; eval metadata was not read.

Created `outputs/provenance_tests.py` with standard-library unittest, immutable trusted-observation fixtures, a separate provenance registry, scripted proposals, server-owned admission, safe denial logs and local fake effect recording. No live provider, model, filesystem content, external transport, credential broker, or real secret was used. The authenticated retrieval transport is explicitly a trusted fake.

Actual command with the assigned absolute path in `$runDir`:

```powershell
python "$runDir\outputs\provenance_tests.py" 2>&1 | Tee-Object -FilePath "$runDir\outputs\execution.log"
$runExit = $LASTEXITCODE
"EXIT_CODE=$runExit" | Tee-Object -Append -FilePath "$runDir\outputs\execution.log"
exit $runExit
```

Python environment was previously observed as 3.11.9. Actual result: 14 unittest tests, OK, exit 0. Runner reported 0.001 seconds, not an independent performance metric. No failed command or test occurred. No prior log existed, and no prior execution was asserted.

Reviewed the code and results, then saved `outputs/response.md`. The exact malicious payload and forged citation were exercised. Tests separately checked valid D3 citation with forbidden transmission, and the valid D3/T1 benign summary. Denials assert no credential read, no transmission and no local output; the benign case asserts canonical D3 and no credential/transmission effects.

Review limitations recorded in response: this is an executable contract fake rather than a cryptographic transport verifier or model evaluation. It assumes trusted caller/envelope construction, does not prove semantic support for arbitrary summaries, and does not supply complete production JSON/schema validation. Production approvals and allowed credential transmissions are outside this fixture; the fake policy grants neither.
