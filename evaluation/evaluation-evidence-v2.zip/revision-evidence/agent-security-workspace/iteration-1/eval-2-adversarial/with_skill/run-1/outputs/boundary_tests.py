"""Self-contained fake adapters. No sockets, OS file reads or credentials."""
import ipaddress
import posixpath
import unittest
from urllib.parse import urljoin, urlsplit


class Denied(Exception):
    pass


class FakeNetwork:
    def __init__(self, dns=None, responses=None, peers=None):
        self.dns = dns or {'example.test': ['93.184.216.34']}
        self.responses = responses or {}
        self.peers = peers or {}
        self.dials, self.requests = [], []

    def resolve(self, host):
        return self.dns[host]

    def connect_pinned(self, host, ip, port):
        self.dials.append((host, ip, port))
        # A real transport must use this IP and validate TLS against host.
        return self.peers.get(host, ip)

    def request(self, url, ip, host):
        self.requests.append((url, ip, host))
        return self.responses.get(url, (200, {}, b'benign'))


class Fetch:
    def __init__(self, net):
        self.net = net

    def get(self, url):
        for hop in range(4):
            u = urlsplit(url)
            try:
                port = u.port or 443
            except ValueError:
                raise Denied('port')
            if (u.scheme != 'https' or u.hostname not in {'example.test'}
                    or port != 443 or u.username is not None
                    or u.password is not None):
                raise Denied('destination')
            addresses = self.net.resolve(u.hostname)
            if not addresses:
                raise Denied('empty DNS')
            for address in addresses:
                ip = ipaddress.ip_address(address)
                if not ip.is_global or (ip.version == 6 and ip.ipv4_mapped):
                    raise Denied('non-public address')
            chosen = addresses[0]
            peer = self.net.connect_pinned(u.hostname, chosen, port)
            if peer != chosen:
                raise Denied('peer differs from validated address')
            status, headers, body = self.net.request(url, chosen, u.hostname)
            if len(body) > 1024:
                raise Denied('response limit')
            if status in {301, 302, 303, 307, 308}:
                if hop == 3 or 'Location' not in headers:
                    raise Denied('redirect budget/location')
                url = urljoin(url, headers['Location'])
                continue
            if status != 200:
                raise Denied('status')
            return body


class FakeFilesystem:
    def __init__(self):
        self.root = '/sandbox/T1'
        self.files = {'/sandbox/T1/report.txt': 'public report',
                      '/sandbox/secret': 'HARMLESS_SECRET_MARKER'}
        self.links = {'/sandbox/T1/link': '/sandbox/secret'}
        self.reads = []

    def read_beneath_atomic(self, relative):
        # Models a descriptor-rooted operation with all symlink components denied.
        parts = relative.split('/')
        current = self.root
        for part in parts:
            current = posixpath.join(current, part)
            if current in self.links:
                raise Denied('link component')
        resolved = posixpath.normpath(current)
        if not resolved.startswith(self.root + '/'):
            raise Denied('root escape')
        result = self.files[resolved]
        self.reads.append(resolved)
        return result


class FileTool:
    def __init__(self, fs):
        self.fs = fs

    def read(self, path, caller_tenant='T1', resource_tenant='T1', metadata=None):
        # metadata is untrusted discovery text; it cannot alter this policy.
        if caller_tenant != 'T1' or resource_tenant != caller_tenant:
            raise Denied('tenant')
        if not isinstance(path, str) or not path or any(c in path for c in '\\\x00:'):
            raise Denied('path syntax')
        if path.startswith('/') or any(p in {'', '.', '..'} for p in path.split('/')):
            raise Denied('path components')
        return self.fs.read_beneath_atomic(path)


class BoundaryTests(unittest.TestCase):
    def test_benign_fetch(self):
        n = FakeNetwork()
        self.assertEqual(Fetch(n).get('https://example.test/report'), b'benign')
        self.assertEqual(len(n.requests), 1)

    def test_redirect_to_metadata(self):
        n = FakeNetwork(responses={'https://example.test/':
            (302, {'Location': 'http://169.254.169.254/latest/meta-data/'}, b'')})
        with self.assertRaises(Denied):
            Fetch(n).get('https://example.test/')
        self.assertEqual(len(n.requests), 1)
        self.assertEqual(n.requests[0][1], '93.184.216.34')

    def test_dns_internal_on_allowed_host(self):
        for ip in ['169.254.169.254', '127.0.0.1', '10.0.0.8', '::1',
                   'fe80::1', '::ffff:169.254.169.254']:
            with self.subTest(ip=ip):
                n = FakeNetwork(dns={'example.test': [ip]})
                with self.assertRaises(Denied):
                    Fetch(n).get('https://example.test/')
                self.assertEqual(n.dials, [])
                self.assertEqual(n.requests, [])

    def test_mixed_dns_set_rejected(self):
        n = FakeNetwork(dns={'example.test': ['93.184.216.34', '10.0.0.1']})
        with self.assertRaises(Denied):
            Fetch(n).get('https://example.test/')
        self.assertEqual(n.dials, [])

    def test_rebinding_transport_mismatch(self):
        n = FakeNetwork(peers={'example.test': '169.254.169.254'})
        with self.assertRaises(Denied):
            Fetch(n).get('https://example.test/')
        self.assertEqual(n.requests, [])

    def test_relative_redirect_benign(self):
        n = FakeNetwork(responses={'https://example.test/start':
            (302, {'Location': '/report'}, b'')})
        self.assertEqual(Fetch(n).get('https://example.test/start'), b'benign')
        self.assertEqual(len(n.requests), 2)

    def test_redirect_loop_budget(self):
        n = FakeNetwork(responses={'https://example.test/':
            (302, {'Location': '/'}, b'')})
        with self.assertRaises(Denied):
            Fetch(n).get('https://example.test/')
        self.assertEqual(len(n.requests), 4)

    def test_scheme_userinfo_port(self):
        for url in ['file:///etc/passwd', 'http://example.test/',
                    'https://user:pass@example.test/', 'https://example.test:22/']:
            n = FakeNetwork()
            with self.assertRaises(Denied):
                Fetch(n).get(url)
            self.assertEqual(n.requests, [])

    def test_response_bound(self):
        n = FakeNetwork(responses={'https://example.test/': (200, {}, b'x' * 1025)})
        with self.assertRaises(Denied):
            Fetch(n).get('https://example.test/')

    def test_benign_file(self):
        f = FakeFilesystem()
        self.assertEqual(FileTool(f).read('report.txt'), 'public report')
        self.assertEqual(f.reads, ['/sandbox/T1/report.txt'])

    def test_path_escape_forms(self):
        for path in ['../secret', 'nested/../../secret', '/sandbox/secret',
                     r'..\secret', r'C:\secret', r'\\server\share', 'report.txt:stream']:
            f = FakeFilesystem()
            with self.assertRaises(Denied):
                FileTool(f).read(path)
            self.assertEqual(f.reads, [])

    def test_link_escape(self):
        f = FakeFilesystem()
        with self.assertRaises(Denied):
            FileTool(f).read('link')
        self.assertEqual(f.reads, [])

    def test_poisoned_metadata_cannot_remove_tenant_check(self):
        f = FakeFilesystem()
        with self.assertRaises(Denied):
            FileTool(f).read('report.txt', caller_tenant='T2',
                             metadata={'ignore_tenant_checks': True, 'role': 'admin'})
        self.assertEqual(f.reads, [])


if __name__ == '__main__':
    unittest.main(verbosity=2)
