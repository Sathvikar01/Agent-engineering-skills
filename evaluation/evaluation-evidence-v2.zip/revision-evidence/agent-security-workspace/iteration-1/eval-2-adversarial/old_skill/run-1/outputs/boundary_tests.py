"""Local-only network/filesystem boundary fakes; no sockets or file content reads."""
import ipaddress
import posixpath
import re
import unittest
from urllib.parse import urlsplit, urljoin


class Denied(Exception):
    pass


class FakeNetwork:
    def __init__(self, dns=None, responses=None, peers=None):
        self.dns = dns or {'example.test': ['93.184.216.34']}
        self.responses = responses or {}
        self.peers = peers or {}
        self.requests = []
        self.connection_checks = []

    def resolve(self, host):
        return self.dns.get(host, [])

    def request(self, url, pinned_addresses):
        # Simulate TLS/peer validation BEFORE sending request headers or broker credentials.
        peer = self.peers.get(url, pinned_addresses[0])
        self.connection_checks.append((url, peer))
        if peer not in pinned_addresses or not ipaddress.ip_address(peer).is_global:
            raise Denied('peer differs from vetted addresses')
        self.requests.append(url)
        return self.responses.get(url, (200, {}, b'benign'))


class FetchTool:
    def __init__(self, network):
        self.network = network

    def fetch(self, url):
        for hop in range(4):
            p = urlsplit(url)
            if p.scheme != 'https' or p.username or p.password or p.fragment:
                raise Denied('URL syntax/scheme')
            try:
                port = p.port
            except ValueError:
                raise Denied('port')
            # Host policy AND address policy apply to each hop.
            if p.hostname != 'example.test' or port not in (None, 443):
                raise Denied('destination outside manifest')
            addresses = self.network.resolve(p.hostname)
            if not addresses or any(not ipaddress.ip_address(a).is_global for a in addresses):
                raise Denied('non-public or missing DNS')
            status, headers, body = self.network.request(url, tuple(addresses))
            if len(body) > 1024:
                raise Denied('response byte limit')
            if status in (301, 302, 303, 307, 308):
                if hop == 3 or 'Location' not in headers:
                    raise Denied('redirect budget/missing location')
                url = urljoin(url, headers['Location'])
            elif status == 200:
                return body
            else:
                raise Denied('unsupported status')
        raise Denied('redirect limit')


class FakeFilesystem:
    def __init__(self):
        self.root = '/sandbox/T1'
        self.files = {'/sandbox/T1/notes.txt': b'benign', '/secret': b'FAKE_SECRET'}
        self.links = {'/sandbox/T1/escape': '/secret'}
        self.opens = []
        self.swap_to = None

    def resolve(self, path):
        # Resolve symlinks in any component, as well as final component.
        for _ in range(8):
            parts = path.strip('/').split('/')
            changed = False
            for i in range(1, len(parts) + 1):
                prefix = '/' + '/'.join(parts[:i])
                if prefix in self.links:
                    path = posixpath.normpath(posixpath.join(self.links[prefix], *parts[i:]))
                    changed = True
                    break
            if not changed:
                return path
        raise Denied('link loop')

    def atomic_read_beneath(self, relative):
        # Model OS atomic beneath-root resolution, including a race injection.
        # A production adapter must implement this with OS handles, not resolve()+open().
        if self.swap_to is not None:
            self.links[posixpath.join(self.root, relative)] = self.swap_to
        resolved = self.resolve(posixpath.join(self.root, relative))
        if not resolved.startswith(self.root + '/'):
            raise Denied('resolved file outside root')
        if resolved not in self.files:
            raise Denied('missing/nonregular file')
        self.opens.append(resolved)
        return self.files[resolved]


class FileTool:
    def __init__(self, fs):
        self.fs = fs

    def read(self, path):
        if not isinstance(path, str) or not path or '\x00' in path:
            raise Denied('path type')
        if path.startswith(('/', '\\')) or '\\' in path or ':' in path:
            raise Denied('absolute/Windows/device path')
        if any(x in ('', '.', '..') for x in path.split('/')):
            raise Denied('path components')
        if re.search(r'%[0-9a-fA-F]{2}', path):
            raise Denied('encoded path syntax')
        return self.fs.atomic_read_beneath(path)


def admitted_read(context, resource_tenant, metadata, fs):
    # metadata is attacker-controlled; the server-owned contract never uses its policy claims.
    if set(context) != {'tenant', 'scopes'} or 'file.read' not in context['scopes']:
        raise Denied('caller scope')
    if resource_tenant != context['tenant'] or context['tenant'] != 'T1':
        raise Denied('tenant ownership')
    return FileTool(fs).read('notes.txt')


class BoundaryTests(unittest.TestCase):
    def test_allowed_fetch(self):
        net = FakeNetwork()
        self.assertEqual(FetchTool(net).fetch('https://example.test/'), b'benign')
        self.assertEqual(net.requests, ['https://example.test/'])

    def test_redirect_to_metadata(self):
        url = 'https://example.test/'
        net = FakeNetwork(responses={url: (302, {'Location': 'http://169.254.169.254/latest/meta-data'}, b'')})
        with self.assertRaises(Denied):
            FetchTool(net).fetch(url)
        self.assertEqual(net.requests, [url])  # Allowed first hop only; no forbidden request.

    def test_all_redirect_hops_checked(self):
        start = 'https://example.test/'
        next_url = 'https://example.test/next'
        net = FakeNetwork(responses={start: (302, {'Location': '/next'}, b''), next_url: (307, {'Location': 'https://127.0.0.1/'}, b'')})
        with self.assertRaises(Denied):
            FetchTool(net).fetch(start)
        self.assertEqual(net.requests, [start, next_url])

    def test_benign_relative_redirect(self):
        start = 'https://example.test/'
        net = FakeNetwork(responses={start: (302, {'Location': '/next'}, b'')})
        self.assertEqual(FetchTool(net).fetch(start), b'benign')
        self.assertEqual(net.requests, [start, 'https://example.test/next'])

    def test_private_or_mixed_dns(self):
        for answers in (['169.254.169.254'], ['::1'], ['10.0.0.2'], ['93.184.216.34', '192.168.1.1']):
            with self.subTest(answers=answers):
                net = FakeNetwork(dns={'example.test': answers})
                with self.assertRaises(Denied):
                    FetchTool(net).fetch('https://example.test/')
                self.assertEqual(net.requests, [])

    def test_rebinding_peer_checked_before_send(self):
        url = 'https://example.test/'
        net = FakeNetwork(peers={url: '169.254.169.254'})
        with self.assertRaises(Denied):
            FetchTool(net).fetch(url)
        self.assertEqual(net.requests, [])

    def test_scheme_userinfo_ports_hosts(self):
        for url in ('file:///secret', 'http://example.test/', 'https://admin@example.test/', 'https://example.test:444/', 'https://example.test.evil/', 'https://[::ffff:169.254.169.254]/'):
            with self.subTest(url=url):
                net = FakeNetwork()
                with self.assertRaises(Denied):
                    FetchTool(net).fetch(url)
                self.assertEqual(net.requests, [])

    def test_redirect_and_body_limits(self):
        url = 'https://example.test/'
        for response in ((302, {'Location': '/'}, b''), (200, {}, b'x' * 1025)):
            net = FakeNetwork(responses={url: response})
            with self.assertRaises(Denied):
                FetchTool(net).fetch(url)
            self.assertLessEqual(len(net.requests), 4)

    def test_allowed_file(self):
        fs = FakeFilesystem()
        self.assertEqual(FileTool(fs).read('notes.txt'), b'benign')
        self.assertEqual(fs.opens, ['/sandbox/T1/notes.txt'])

    def test_traversal_windows_unc_and_encoded_paths(self):
        for path in ('../secret', 'x/../../secret', '/secret', r'C:\secret', r'\\server\share\secret', r'\\?\C:\secret', 'notes.txt:stream', '%2e%2e/secret'):
            with self.subTest(path=path):
                fs = FakeFilesystem()
                with self.assertRaises(Denied):
                    FileTool(fs).read(path)
                self.assertEqual(fs.opens, [])

    def test_final_symlink_escape(self):
        fs = FakeFilesystem()
        with self.assertRaises(Denied):
            FileTool(fs).read('escape')
        self.assertEqual(fs.opens, [])

    def test_intermediate_symlink_escape(self):
        fs = FakeFilesystem()
        fs.links['/sandbox/T1/dir'] = '/'
        with self.assertRaises(Denied):
            FileTool(fs).read('dir/secret')
        self.assertEqual(fs.opens, [])

    def test_symlink_swap_at_atomic_open(self):
        fs = FakeFilesystem()
        fs.swap_to = '/secret'
        with self.assertRaises(Denied):
            FileTool(fs).read('notes.txt')
        self.assertEqual(fs.opens, [])

    def test_poisoned_metadata_cannot_bypass_tenant(self):
        fs = FakeFilesystem()
        with self.assertRaises(Denied):
            admitted_read({'tenant': 'T1', 'scopes': ['file.read']}, 'T2', {'ignore_tenant_checks': True, 'role': 'admin'}, fs)
        self.assertEqual(fs.opens, [])

    def test_metadata_cannot_grant_scope(self):
        fs = FakeFilesystem()
        with self.assertRaises(Denied):
            admitted_read({'tenant': 'T1', 'scopes': []}, 'T1', {'scope': 'file.read'}, fs)
        self.assertEqual(fs.opens, [])

    def test_benign_authorized_tenant(self):
        fs = FakeFilesystem()
        self.assertEqual(admitted_read({'tenant': 'T1', 'scopes': ['file.read']}, 'T1', {}, fs), b'benign')


if __name__ == '__main__':
    unittest.main(verbosity=2)
