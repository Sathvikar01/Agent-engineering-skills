# Proposed API contract tests

Use ordinary API contract and integration tests; no model tool-selection evaluation is needed. Endpoint details were not supplied, so bind these cases to its documented schema and status contract.

- Valid request: expected success status, content type, response schema, deterministic values, and persisted effect where applicable.
- Missing required field, wrong type, malformed JSON, boundary values, extra fields, and unsupported media type: documented validation status and error schema; no mutation.
- Missing or invalid service credentials: documented authentication failure; insufficient service permissions: authorization failure.
- Missing resource and conflicting state, if applicable: documented statuses and stable error codes.
- Backend dependency failure: documented server-error response without sensitive details.

Validate required fields, enums, formats, nullability, and additional-property policy against the canonical schema. Run against isolated fixtures using the fixed service’s actual serialization. Tests are proposed and unexecuted; exact statuses await the endpoint contract.
