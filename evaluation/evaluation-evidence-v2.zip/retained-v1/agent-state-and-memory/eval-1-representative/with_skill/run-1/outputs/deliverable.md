| Storage category | Owner, scope and authority | Lifecycle |
|---|---|---|
| Conversation context | Session service; tenant/user/run; untrusted input and evidence | Bounded retention; source message IDs; redact unnecessary personal data |
| Working memory | Run worker; tenant/run; advisory plan | Delete at run closure; no raw private reasoning |
| Persisted runtime state | Orchestrator; tenant/run; typed transitions | Versioned checkpoints and receipts; retain through correction/audit window |
| Episodic memory | Memory service; tenant/user; historical outcomes | Evidence pointers, verified/asserted status; expire or revalidate consequential claims |
| Semantic memory | Knowledge service; tenant/document ACL; provenance-bound knowledge | Source revision, sensitivity and expiry; delete on source/access removal |
| User preferences | Profile service; tenant/user; consented style defaults | Consent source/time; review/expiry date; user edit/delete; never grants authority |
| Authoritative application state | Order service and identity service; tenant/order/user | Current order version, committed effects and permissions govern execution |

Every persistent record carries tenant and owner IDs, provenance, source timestamp/version, sensitivity, expiry and deletion route. Persist order identifiers and necessary correction details, excluding credentials and unrelated personal data. A memory write is a validated, deduplicated proposal; a model statement that a correction succeeded remains asserted until a trusted receipt confirms it. Conflicting memories retain source/status instead of replacing current order facts. Preference writes require user confirmation or an explicit preference statement under policy; inferred style is temporary.

Use states `draft → awaiting_authorization → ready → executing → reconciling → completed`, with `failed` and `cancelled` permitted by explicit events. The transition handler validates expected run version, current actor permissions, order version and required evidence atomically. Compare-and-set rejects concurrent stale writers. Append immutable action receipts; partial completion is represented per action, never as rewritten summary prose.

Checkpoint at durable boundaries, for example:

```json
{"run":"R17","tenant":"T1","user":"U1","version":8,"state":"reconciling","order":"O7","orderVersion":24,"completedEffects":[{"action":"A1","receipt":"receipt-91","idempotencyKey":"R17-A1"}],"pending":[{"action":"A2","status":"unknown","idempotencyKey":"R17-A2"}],"remainingBudget":{"actions":2,"tokens":4000},"policyVersion":"p3","promptVersion":"s2","schemaVersion":1,"evidence":["message-12","order-event-24"],"expiresAt":"configured retention deadline"}
```

Compaction preserves claims with source pointers and uncertainty, unresolved questions, pending IDs, completed receipts and cumulative budgets. It omits obsolete approval language as an authorization grant. Retrieval applies tenant and current permission filters before candidate exposure, then relevance/freshness ranking within a context budget. Re-fetch critical order evidence before execution. Expired style preferences revert to defaults; revoked access invalidates retrieval and caches.

Resume validates checkpoint schema/version, identity, access and expiry, then checks trusted stores. A crash before commit permits retry with the same idempotency key; after commit, the receipt advances state. Unknown outcomes require reconciliation before retry. Reauthorize pending actions and preserve consumed budgets across sessions. Deletion removes scoped memory, checkpoints and caches, subject to separately disclosed mandatory receipt retention.

Proposed, unexecuted tests: stale success versus current failure; simultaneous writers; expired preference; cross-tenant retrieval; revoked cached access; deletion propagation; and restart after unknown commit without duplicate effects or budget reset.
