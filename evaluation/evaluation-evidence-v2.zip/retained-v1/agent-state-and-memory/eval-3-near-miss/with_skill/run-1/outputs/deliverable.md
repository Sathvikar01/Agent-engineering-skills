This is developer-session context preparation; the agent-state-and-memory runtime skill does not apply. Use these templates, replacing placeholders with verified repository details.

AGENTS.md:

```markdown
# Repository guidance
- Purpose: [product and primary workflow].
- Structure: [key directories and responsibilities].
- Setup: [verified dependency/setup commands].
- Validation: [verified build, lint and relevant test commands].
- Conventions: [existing patterns and constraints].
- Changes: preserve unrelated edits; inspect applicable nested guidance.
- Completion: report changes, checks performed and unresolved limitations.
```

Context summary:

```markdown
Objective: [requested outcome and acceptance criteria].
Current state: [branch, relevant files, existing edits].
Decisions: [constraints and rationale].
Evidence: [file/line pointers and observed command results].
Remaining work: [next concrete steps and blockers].
Validation: [executed results; distinguish planned checks].
```

Keep stable repository instructions in AGENTS.md and temporary task progress in the summary. Exclude secrets and avoid inventing commands or completed checks. No runtime memory store or checkpoint system is needed.
