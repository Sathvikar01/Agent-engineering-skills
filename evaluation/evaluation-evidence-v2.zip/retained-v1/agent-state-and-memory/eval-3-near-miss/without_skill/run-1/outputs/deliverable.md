# Starter files

Use the following templates; replace placeholders with verified repository information.

## AGENTS.md

- Scope: applies to this directory and descendants unless a more specific file overrides it.
- Project: [purpose and main components].
- Setup: [supported runtime and dependency installation command].
- Development: [local start command].
- Verification: [test, lint, and build commands].
- Conventions: [naming, formatting, and architectural constraints].
- Boundaries: avoid committing secrets; explain required generated-file updates.
- Completion: report changes, checks actually run, and unresolved limitations.

## Context summary

- Objective: [current coding task and acceptance criteria].
- Current state: [branch, relevant files, and existing changes].
- Decisions: [agreed approach and constraints].
- Evidence: [observed behavior and completed checks].
- Next step: [first concrete action].
- Unknowns: [questions requiring investigation].

No repository was inspected, and no verification commands were executed. These are editable session documents.
