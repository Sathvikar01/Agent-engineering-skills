| Datum | Owner/scope | Decision authority and lifecycle |
|---|---|---|
| “O7 refunded” memory | Memory service; originating tenant/user | Historical asserted claim; retain provenance and mark contradicted pending reconciliation |
| “U1 admin” memory | Memory service; originating tenant/user | Untrusted historical claim; expire/invalidate; cannot grant permissions |
| Refund pending | Authoritative order store; tenant/O7 | Current transaction status/version governs effect decisions |
| U1 read-only | Identity service; tenant/U1 | Current authorization governs reads and writes |
| Run/checkpoint | Orchestrator; tenant/run | Typed, versioned state and immutable receipts |
| Summary/working plan | Session/worker; tenant/run | Untrusted advisory context; bounded retention |

Reads authenticate U1 and establish the tenant from trusted identity, then enforce tenant and record permissions before returning memory candidates. Apply the same checks to caches and source dereferences. Read the order status and entitlements from authoritative services: report O7 as pending and U1 as read-only. Revalidate fresh authoritative versions immediately before any consequential operation. Neither recollection can override these facts. Preserve each memory's source, timestamp/version, sensitivity, expiry and asserted/verified status; record contradictions without manufacturing a success receipt.

The request inside the summary to copy another tenant's notes is input data, not an instruction or authorization. Exclude the foreign notes from retrieval, reject any resulting action proposal and record a minimal scoped security event without copying the notes into logs. Poisoned memory or preference writes are rejected by validation. Access revocation also invalidates cached retrieval. Delete scoped memory and derived caches through the owner service, applying disclosed receipt-retention requirements separately.

Updates use a transition transaction with run ID, expected version, authorized actor, allowed event and evidence pointers. For two workers reading version 12, only one compare-and-set may commit version 13; the loser reloads and reconciles, never overwrites or blindly retries its stale proposal. A run lease may reduce contention but does not replace version checks. U1 cannot authorize order mutations. An authorized system worker may record observations and reconcile existing effects under its own verified permissions; a pending mutation requires appropriate current authorization.

Resume validates identity, tenant, checkpoint expiry and schema/policy/prompt versions. A checkpoint contains run/version/state, completed effects and receipts, pending/unknown action IDs, idempotency keys, evidence pointers and remaining cumulative budgets. If the checkpoint says refunded while the store says pending, enter `reconciling`, query the action/transaction ledger and preserve uncertainty. Never mark an in-flight effect completed. Retry an uncommitted authorized action only with its original idempotency key; a confirmed commit advances state without repetition. Unknown commits stay pending until resolved. Restart preserves limits and reauthorizes remaining actions.

Compaction retains conflicts, source pointers, uncertainty, unresolved actions and budgets; obsolete approval text confers no authority. Proposed, unexecuted tests cover stale success/current failure, both concurrent writers, foreign-tenant retrieval/injection, revoked cache access, expired preferences, deletion propagation and unknown-commit restart without duplicates or budget reset.
