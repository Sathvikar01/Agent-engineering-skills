# human-in-the-loop — behavioral smoke comparison


With skill: 9/9 expectations. Baseline: 9/9.

One run per case/configuration. Standard deviation in the JSON is across cases, not repeated-run variance.

- Fresh executor per skill/configuration; 3 cases sequential in each executor. One run per case/configuration; no repeated-run variance estimate.
- Token counts and comparable per-case latency were not supplied uniformly; omitted rather than estimated from characters.
- Actual Claude automatic-trigger checks unavailable: not logged in and Windows subprocess select error. Human review remains pending.
- Observed assertion scores tie; this suite does not establish incremental skill benefit.
