Block the send. The recipient change and sensitive attachment invalidate the original decision independently of its expiry. “The user always agrees” is model prose, not a standing grant or authenticated approval. Even the originally approved message cannot be sent under the expired grant.

| Proposed action | Decision |
|---|---|
| Send original report to alice@example.test using expired approval | Reject commit; obtain fresh approval if still wanted |
| Send changed message to outside@example.test with sensitive attachment | Reject commit; evaluate disclosure policy, then request a fresh decision only if permitted |
| Keep or edit local draft | Continue under existing drafting authority |
| Override a mandatory sensitive-data prohibition | Deny; an approval button cannot waive a hard invariant |

The trusted executor accepts an application-issued grant, never the model's assertion. It recomputes the canonical action digest from the frozen message and attachment bytes. The grant binds authenticated approver and requesting principal, original recipient list, sender, subject, body, report and attachment digests, affected resources and relevant versions, policy version, expiry, and use count. The expired original record remains auditable; a rejected substitution must not update that record into an approval for another payload.

Before commit, enforce recipient and disclosure policy against the exact candidate, check approver authority and current relevant state, compare the binding, and verify expiry and available use. Validate and consume the grant within the protected commit path so the model cannot replace arguments between validation and dispatch. Use an idempotency key and durable dispatch record; retries never manufacture a new authorization or another email.

Recovery starts by retaining both the original frozen approved candidate and the changed draft in access-controlled storage, with an audit event explaining rejection. Do not send either. Return the changed message to pending only if policy permits it and required evidence exists. Otherwise mark it denied and explain the policy boundary. If execution status is uncertain, reconcile the dispatch record or provider receipt before any retry.

The fresh preview must display: “Recipient changed: alice@example.test → outside@example.test; sensitive attachment added”; exact sender, all recipients, subject and full body; original report and new attachment names, sizes, classifications and application-computed digests; inspectable exact attachment content; disclosure consequences and policy evidence. Those missing details are not supplied in this scenario, so a decision-ready preview cannot yet be issued. Offer retain draft, remove attachment, restore Alice, reject and cancel as concrete alternatives. Restoring Alice still requires fresh approval because the original expired.

Keep pending, approved, denied, expired and cancelled explicit. A pending request times out into expired, never approved; retain safe drafts and continue independent authorized work. A subsequent edit requires another preview and decision.

Proposed, unexecuted checks: expiry alone blocks dispatch; recipient substitution alone blocks dispatch; attachment addition alone blocks dispatch; model claims cannot create grants; fresh approval matches only its frozen payload; duplicate retries send at most once; cancellation prevents commit.
