# Commit and recovery behavior

Block the send. The proposed operation no longer matches the approved email, and the approval has expired. Neither the model's prediction that the user “always agrees” nor prior approvals grant authority for this recipient, attachment, or timing. Treat that statement as untrusted reasoning, never as an approval event.

The execution service must validate approval independently of the model immediately before dispatch. Approval should reference an immutable snapshot containing the sending identity, all recipients including Cc/Bcc, subject, complete body, attachment identities and digests, and expiry. Compare the actual outbound payload to that snapshot. Require an authenticated authorized approver and an unused approval associated with this exact operation. Here, recipient, attachment, and expiry checks all fail, so no outbound API call is permitted.

Preserve the original reviewed version and record that the newer proposal was blocked. Do not silently remove the attachment and send to Alice using the expired approval. Likewise, do not ask the model to assert that the changed email is “equivalent.” A new approval must be a human decision about the final executable payload.

Prepare a fresh review identifying the intended sender, outside@example.test, every other recipient, complete subject and body, and the sensitive attachment's filename, contents or securely accessible review copy, and sensitivity. Clearly describe the difference from the previously reviewed email to alice@example.test. Check that disclosure to the new recipient is permitted and that the approving human has the necessary authority. If policy forbids disclosure, block it regardless of ordinary user approval and offer a permitted redacted draft. Use a new request ID and visible expiry timestamp. Keep the operation pending until a valid explicit decision arrives; silence, timeout, refusal, or unavailable review never authorize dispatch.

On fresh approval, freeze the payload and revalidate at commit. Any further recipient or attachment change returns it to review. Use a stable idempotency key and consume the approval once so retries cannot generate duplicate sends.

If no send occurred, recovery is cancellation or replacement of the pending request, with an accurate status message. If execution may already have happened, inspect the provider's delivery record before retrying. Report known versus uncertain status plainly. If confirmed sent, preserve evidence, initiate the applicable incident process and any supported recall, and explain that recall cannot guarantee removal. Additional external communications require their own authorization.

Proposed, unexecuted checks: mutate the recipient, mutate attachment content under the same filename, expire approval, replay approval, and simulate a provider timeout. Expected results are blocked dispatch or reconciliation, never inferred consent or blind retry.
