# Proportional approval design

Continue the authorized searches and drafting immediately. Ask for approval only when a concrete consequential operation is ready for review. An authorization to draft an email does not authorize sending it; each other operation below also requires its own scoped authorization unless the user has already provided an applicable one.

| Action | Behavior | Required review |
|---|---|---|
| Search records | Execute under existing authorization | Show results and material search limitations; do not interrupt for confirmation. |
| Draft email | Prepare and save draft under existing authorization | Present editable content. |
| Send externally | Hold until explicit approval | Exact sender, To/Cc/Bcc, subject, complete body, attachment filenames and contents, and delivery destination. |
| Delete 500 records | Require explicit, separate destructive-action approval | Exact record IDs, count, selection criteria, environment, dependencies, whether deletion is reversible, and recovery plan. |
| Transfer funds | Require explicit transaction approval | Source and beneficiary accounts, amount, currency, fees, total debit, timing, and transaction reference. |
| Change access roles | Require explicit security-change approval | Exact principals and resources, current and proposed roles, permissions gained/lost, and duration. |

Do not combine these into one vague “approve everything” control. Where policy requires additional authorization, verify the approver has the required authority; the model cannot waive that requirement. A rejected or inaccessible gate remains closed.

Each review is an immutable operation snapshot with a unique request ID and expiry time. For example, an email preview identifies request EMAIL-042, sender reports@example.test, recipient alice@example.test, subject “September report,” the literal final message body, and the actual reviewed report attachment. Those are illustrative values, not an executable request. In implementation, display the real payload and bind approval to its canonical digest, attachment digests, acting identity, destination, and relevant resource versions. Any change to these invalidates approval.

While pending, permit editing, cancellation, and independent authorized searches or drafting. Do not execute the held operation, imply approval from silence, or repeatedly pressure the user. An approval response must unambiguously identify the request. Configure expiry according to risk and show an absolute timestamp with timezone; reject late approval and create a fresh review. Cancellation and denial are terminal for that request.

At commit, verify authority, unexpired unused approval, unchanged payload, and applicable resource state. Atomically consume approval with dispatch; use an operation idempotency key. Record approval, validation, and execution outcome without unnecessarily logging sensitive contents. If dispatch status is uncertain, reconcile with the provider before retrying. Report completion only after confirmation.

Proposed, unexecuted checks: recipient edits invalidate approval; expired and cancelled requests cannot dispatch; duplicate clicks produce one operation; partial deletion reports exact outcomes; ambiguous transfer status causes reconciliation rather than a second transfer.
