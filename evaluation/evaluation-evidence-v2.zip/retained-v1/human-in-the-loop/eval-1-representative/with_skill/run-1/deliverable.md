Proceed with the authorized searches and drafting. Prepare consequential actions completely enough for an authorized human to review their exact effects, then gate execution through application policy. No approval can override a hard prohibition.

| Action | Impact and reversibility | Approval behavior |
|---|---|---|
| Search records | Read-only; validate permitted datasets and user access | Execute under existing authorization; no repeat prompt |
| Draft email | Reversible local preparation | Execute; retain draft without sending |
| Send externally | Discloses information to specified recipients; difficult to recall | Require recipient, content and attachment approval from an authorized sender |
| Delete 500 records | Destructive; recovery depends on available backup | Require data-owner approval of an immutable 500-ID manifest, recovery evidence and retention-policy result |
| Transfer funds | Financial commitment; reversal may be unavailable | Require authorized financial approver for exact account, beneficiary, currency, amount and fees; enforce limits independently |
| Change access roles | Changes others' authority and data access | Require authorized administrator for exact principal/resource role diff; deny prohibited privilege escalation |

Missing amounts, targets, recovery evidence or authority prevent a decision-ready approval request. Fetch authorized evidence and prepare previews first. Independent drafts can continue while another action awaits approval. These different effects should have separate decisions; any bounded related batch must expose every item and permit individual rejection.

Exact preview example, with illustrative values rather than live records:

> SEND EMAIL — From: reports@company.example.test. To: alice@partner.example.test. CC/BCC: none. Subject: “October report”. Body: “Hi Alice, attached is the approved October summary. Regards, Reporting”. Attachment: october-summary.pdf, 84,321 bytes; the application displays its stored SHA-256 digest and opens the exact frozen file for inspection. Effect: one external email, including this attachment, will leave the organization. Evidence: application content classification and recipient-policy checks passed for the frozen payload. Alternative: retain the draft or edit and request a new decision. Approver: authorized sender. Approval expires 15 minutes after issuance and allows one send. Controls: Approve send / Reject / Cancel.

The application stores pending, approved, denied, expired and cancelled states outside model prose. An approval record binds authenticated approver, requesting principal, action type, canonical arguments and digest, resource IDs, relevant resource versions, policy version, expiry and single-use limit. The model cannot issue its own grant. Silence and timeout never authorize execution; expiry retains the safe draft and permits a fresh request.

At commit, trusted enforcement checks authority, policy, current relevant state, payload binding, expiry and unused grant atomically with an idempotent operation record. Material edits invalidate approval. Retries use the same operation key; uncertain completion is reconciled before retrying.

Proposed, unexecuted checks: denied and expired approvals produce zero effects; changed recipients, deletion manifests, amounts or role diffs require fresh approval; duplicate commits produce one effect; authorized reads and drafts proceed without prompts. Record approval frequency, abandonment, review duration and erroneous-approval outcomes after deployment; no measurements exist here.
