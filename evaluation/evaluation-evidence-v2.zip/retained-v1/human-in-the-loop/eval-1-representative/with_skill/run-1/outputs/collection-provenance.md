Original run-root output files copied unchanged into the official outputs directory; originals and transcript preserved.
