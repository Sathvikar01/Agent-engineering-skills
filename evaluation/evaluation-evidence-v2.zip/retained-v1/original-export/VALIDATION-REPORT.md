# Sathvik — Agent Engineering: validation report

Author: Sathvik
Report date: 4 October 2026

## Installed files

Seventeen original skill directories are installed at `~\.cc-switch\skills`. Codex and Claude global directories expose the same physical implementations through 17 junctions each. Collection catalogues are hardlinks. CC Switch settings/database and existing third-party skills were not edited.

This is a filesystem installation. CC Switch UI registration was not performed through an unsupported database edit. Start a new coding-agent session if its skill list is cached. Actual automatic activation remains unverified.

## Structural and integrity checks

Anthropic quick_validate passes all 17 installed skills. Names match directories; author/collection metadata, specific trigger descriptions, behavioral/trigger schemas, local reference resolution, and exact duplicate-body/name-collision checks pass. All 5,313 inventoried third-party files retain their original SHA-256. Installed files match staged content, and both sets of junction targets are verified.

The pack contains 17 SKILL.md files, 17 behavioral suites, 17 trigger suites and four justified reference files. No production skill scripts or additional skills were introduced. Official .skill packages are also generated; the official packager excludes evals, so the full collection ZIP retains the evaluation suites.

## Behavioral smoke comparisons

51 final cases were executed in both configurations: 102 selected case/configuration runs. Independent model grading records **166/166** expectations with skills and **149/166** without this pack. 9 skills show higher observed case scores, 8 tie, and 0 regress. A tie does not establish incremental benefit.

| Skill | With skill | Baseline | Observed result | Routing proxy |
|---|---:|---:|---|---:|
| agent-architecture | 10/10 | 10/10 | Tie; benefit unproven | 20/20 |
| agent-cost-and-latency | 10/10 | 7/10 | Improved smoke score | 19/20 |
| agent-evals | 10/10 | 9/10 | Improved smoke score | 20/20 |
| agent-failure-recovery | 10/10 | 10/10 | Tie; benefit unproven | 20/20 |
| agent-guardrails | 10/10 | 8/10 | Improved smoke score | 20/20 |
| agent-observability | 10/10 | 7/10 | Improved smoke score | 20/20 |
| agent-security | 10/10 | 10/10 | Tie; benefit unproven | 20/20 |
| agent-state-and-memory | 10/10 | 9/10 | Improved smoke score | 20/20 |
| agent-testing | 10/10 | 10/10 | Tie; benefit unproven | 20/20 |
| deterministic-authority | 9/9 | 9/9 | Tie; benefit unproven | 20/20 |
| human-in-the-loop | 9/9 | 9/9 | Tie; benefit unproven | 20/20 |
| multi-agent-orchestration | 10/10 | 7/10 | Improved smoke score | 20/20 |
| prompt-engineering | 10/10 | 9/10 | Improved smoke score | 20/20 |
| rag-engineering | 10/10 | 9/10 | Improved smoke score | 20/20 |
| structured-output-design | 10/10 | 10/10 | Tie; benefit unproven | 20/20 |
| tool-design | 9/9 | 9/9 | Tie; benefit unproven | 20/20 |
| tool-evals | 9/9 | 7/9 | Improved smoke score | 20/20 |

Rubrics assess concrete design decisions, authority/effect semantics and verification evidence rather than keyword counts. Executable local fakes were used where requested; graders independently reran relevant artifacts. Design-only cases are not represented as executed systems. Read per-run grading/transcripts for test counts and limitations.

## Failures, refinements and reruns

An original recovery near-miss asked for a parser fix without supplying source. The with-skill response appropriately declined to claim an unperformed fix, but failed its finite-test expectation. The revised prompt supplies the buggy parser; expectations are unchanged, both configurations were rerun, and the parser suites passed (four and six test methods). Original outputs/grades are retained.
Cross-skill review clarified leakage prevention: exclude held-out answer keys and grader annotations while retaining legitimate accessible source evidence. The first clarification still missed explicit test-time exclusion. The final skill now requires a runtime exposure manifest and leakage assertion, then received another fresh three-case paired rerun. Prior source snapshots/results remain in the evidence.
Two additional near-miss fixtures were clarified: invitation editing now supplies the invitation text, and parallel checks now supply exact temporary files/checks and require execution. Both configurations were rerun with unchanged assertions; original failures are retained.
The one routing miss selected multi-agent-orchestration for aggregate worker budgeting instead of additionally selecting agent-cost-and-latency. The cost skill scores 9/10 positives and 10/10 negatives, meeting the predeclared minimum of nine in each class. The case and result were retained without relabeling.
Grader feedback also records post-retention idempotency coverage, negative-only near-miss assertions, focused rather than general schema checks, and fake/provider/storage limits. Passing immediate scenarios do not certify these omitted deployment behaviors.

## Description routing

One independent Codex catalogue-selection pass matched **339/340** expected decisions across 170 positives and 170 negatives, with zero tested false positives. The catalogue contained these 17 new descriptions plus 16 adjacent existing descriptions. This is a metadata routing proxy, not an actual harness invocation, statistical accuracy estimate, or Claude trigger optimization.

## Exact remaining verification gaps

- Official Claude automatic-trigger evaluation/description optimization could not execute: Claude CLI reports Not logged in, and the installed runner uses select.select on ordinary Windows subprocess pipes, producing WinError 10038. The bounded failed attempts are preserved. Third-party scripts were not patched.
- Actual Codex/Claude auto-loading and activation after a fresh session have not been observed. Filesystem exposure and metadata validation are verified.
- One final sample per case/configuration provides smoke evidence. Repeated stochastic variance, held-out generalization, human semantic calibration and stable incremental benefit—especially tied skills—remain unverified.
- Exact inherited model identifier/sampling settings and uniform token/latency telemetry are unavailable in this collaboration runtime. They are marked unavailable rather than invented.
- Human review of the official viewers is pending. Graders are independent of executors, but supplied transcripts disclose configuration; grading is not claimed to be fully blinded.
- Local fakes and design artifacts do not establish real-provider idempotency, durable distributed storage, full JSON Schema/provider-subset compatibility, production browsers or a deployed system. Those require target-specific verification.

## Methodology and reproducibility

The installed Anthropic skill-creator and all 18 supporting files were inspected, including schemas, grader/comparator/analyzer guidance, validation, packaging, benchmark, trigger/description tooling and review templates. Existing overlap review covered the global inventory and the 14 relevant engineering workflow skills in full.
Fresh independent executors were used per skill/configuration, with three tasks sequentially per executor; fixture-specific reruns executed one case per configuration. Expectations were withheld from executors. Independent graders used the official grading schema and evidence. Every selected run has a deliverable, factual transcript and grading record.
Untouched official aggregation and static-viewer tools ran. Generated benchmark metadata corrects the aggregator’s hardcoded run count/model placeholders and removes unavailable character-based token estimates. Standard deviation across cases is not presented as repeated-run variance.
An account usage limit interrupted tool approval on 3 October; continuation on 4 October used the normal approval path and preserved completed artifacts. A Windows encoding failure was resolved by supported Python UTF-8 mode.
Cross-skill review verified terminology, scope ownership, deterministic authority, proportional approval, durable budgets, unknown-effect reconciliation, source provenance and optional integrations. File hashes and per-run artifacts are retained in the evidence archive.

This report establishes installation, structural conformance and bounded smoke results. It does not certify production readiness or universal reliability.
