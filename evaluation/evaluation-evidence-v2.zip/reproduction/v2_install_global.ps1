$ErrorActionPreference = 'Stop'
$taskWorkspace = '~\Documents\Codex\2026-10-03\i-want-you-to-build-a'
$taskRevision = Join-Path $taskWorkspace 'work\v2'
$taskSource = Join-Path $taskRevision 'pack'
$taskCentral = '~\.cc-switch\skills'
$taskCodex = '~\.codex\skills'
$taskClaude = '~\.claude\skills'
$taskNames = @('agent-development-workflow','agent-architecture','agent-orchestration','agent-evals','tool-design','tool-evals','structured-output-design','deterministic-authority','evidence-provenance','agent-state-and-memory','human-in-the-loop','agent-security','agent-failure-recovery','agent-observability','agent-testing','prompt-engineering','rag-engineering','agent-cost-and-latency','agent-guardrails')
$taskNewNames = @('agent-development-workflow','agent-orchestration','evidence-provenance')
$taskBehavior = Get-Content -Raw -LiteralPath (Join-Path $taskRevision 'behavior-summary.json') | ConvertFrom-Json
$taskAudit = Get-Content -Raw -LiteralPath (Join-Path $taskRevision 'staging-audit.json') | ConvertFrom-Json
$taskRouting = Get-Content -Raw -LiteralPath (Join-Path $taskRevision 'routing-summary.json') | ConvertFrom-Json
$taskRefinement = Get-Content -Raw -LiteralPath (Join-Path $taskRevision 'refinement-probe-results.json') | ConvertFrom-Json
if (-not $taskBehavior.smoke_gate_passed -or -not $taskAudit.passed -or -not $taskRouting.smoke_gate_passed -or -not $taskRefinement.passed) { throw 'Revision smoke/structural/refinement gates have not passed.' }
$taskSettings = Get-Content -Raw -LiteralPath '~\.cc-switch\settings.json' | ConvertFrom-Json
if ($taskSettings.skillStorageLocation -ne 'cc_switch') { throw 'Storage changed; repeat discovery.' }
$taskSnapshot = Join-Path $taskRevision 'v1-snapshot'
foreach ($taskFile in (Get-ChildItem -LiteralPath $taskSnapshot -File -Recurse)) {
    $taskRelative = $taskFile.FullName.Substring($taskSnapshot.Length + 1)
    $taskLiveFile = Join-Path $taskCentral $taskRelative
    if (-not (Test-Path -LiteralPath $taskLiveFile)) { throw "Live v1 file disappeared: $taskRelative" }
    if ((Get-FileHash -LiteralPath $taskLiveFile).Hash -ne (Get-FileHash -LiteralPath $taskFile.FullName).Hash) { throw "Refusing to overwrite changed v1: $taskRelative" }
}
foreach ($taskName in $taskNewNames) {
    foreach ($taskRoot in @($taskCentral,$taskCodex,$taskClaude,'~\.agents\skills')) {
        if (Test-Path -LiteralPath (Join-Path $taskRoot $taskName)) { throw "New skill collision: $taskRoot/$taskName" }
    }
}
$taskOldCentral = Join-Path $taskCentral 'multi-agent-orchestration'
$taskOldCodex = Join-Path $taskCodex 'multi-agent-orchestration'
$taskOldClaude = Join-Path $taskClaude 'multi-agent-orchestration'
foreach ($taskOldLink in @($taskOldCodex,$taskOldClaude)) {
    $taskItem = Get-Item -LiteralPath $taskOldLink -Force
    $taskLinkTarget = [string](@($taskItem.Target)[0])
    if ($taskItem.LinkType -ne 'Junction' -or $taskLinkTarget -ne $taskOldCentral) { throw 'Old custom exposure is not the expected junction.' }
}
foreach ($taskName in ($taskNames | Where-Object { $_ -notin $taskNewNames })) {
    foreach ($taskRoot in @($taskCodex,$taskClaude)) {
        $taskItem = Get-Item -LiteralPath (Join-Path $taskRoot $taskName) -Force
        $taskLinkTarget = [string](@($taskItem.Target)[0])
        if ($taskItem.LinkType -ne 'Junction' -or $taskLinkTarget -ne (Join-Path $taskCentral $taskName)) { throw "Unexpected existing custom exposure: $taskRoot/$taskName" }
    }
}
# Check all staging references/eval names before creating the renamed live skill.
if ((Get-ChildItem -LiteralPath $taskSource -File -Recurse | Where-Object { $_.Name -eq 'SKILL.md' -or $_.Name -eq 'evals.json' } | Select-String -SimpleMatch 'multi-agent-orchestration')) { throw 'Obsolete local reference remains in staged pack.' }
foreach ($taskName in $taskNames) {
    $taskDraft = Join-Path $taskSource $taskName
    $taskDestination = Join-Path $taskCentral $taskName
    if (-not (Test-Path -LiteralPath (Join-Path $taskDraft 'SKILL.md'))) { throw "Missing staged skill $taskName" }
    if ($taskName -in $taskNewNames) {
        Copy-Item -LiteralPath $taskDraft -Destination $taskDestination -Recurse
        New-Item -ItemType Junction -Path (Join-Path $taskCodex $taskName) -Target $taskDestination | Out-Null
        New-Item -ItemType Junction -Path (Join-Path $taskClaude $taskName) -Target $taskDestination | Out-Null
    } else {
        foreach ($taskFile in (Get-ChildItem -LiteralPath $taskDraft -File -Recurse)) {
            $taskRelative = $taskFile.FullName.Substring($taskDraft.Length + 1)
            $taskTarget = Join-Path $taskDestination $taskRelative
            $taskParent = Split-Path -Parent $taskTarget
            if (-not (Test-Path -LiteralPath $taskParent)) { New-Item -ItemType Directory -Path $taskParent | Out-Null }
            Copy-Item -LiteralPath $taskFile.FullName -Destination $taskTarget -Force
        }
    }
    foreach ($taskFile in (Get-ChildItem -LiteralPath $taskDraft -File -Recurse)) {
        $taskRelative = $taskFile.FullName.Substring($taskDraft.Length + 1)
        if ((Get-FileHash -LiteralPath $taskFile.FullName).Hash -ne (Get-FileHash -LiteralPath (Join-Path $taskDestination $taskRelative)).Hash) { throw "Installed mismatch: $taskName/$taskRelative" }
    }
}
# Retire only verified junctions; Directory.Delete removes the link itself, not its target.
[System.IO.Directory]::Delete($taskOldCodex)
[System.IO.Directory]::Delete($taskOldClaude)
$taskRetiredParent = Join-Path $taskRevision 'retired-v1'
$taskRetired = [System.IO.Path]::GetFullPath((Join-Path $taskRetiredParent 'multi-agent-orchestration'))
$taskRevisionAbsolute = [System.IO.Path]::GetFullPath($taskRevision) + '\'
if (-not $taskRetired.StartsWith($taskRevisionAbsolute,[System.StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe retirement target.' }
if ([System.IO.Path]::GetFullPath($taskOldCentral) -ne '~\.cc-switch\skills\multi-agent-orchestration') { throw 'Unsafe retirement source.' }
New-Item -ItemType Directory -Path $taskRetiredParent | Out-Null
Move-Item -LiteralPath $taskOldCentral -Destination $taskRetired
# Existing catalogue hardlinks update together; do not replace links or edit CC Switch DB.
$taskCatalogue = Join-Path $taskCentral 'AGENT-ENGINEERING-SKILLS.md'
[System.IO.File]::WriteAllText($taskCatalogue,[System.IO.File]::ReadAllText((Join-Path $taskSource 'AGENT-ENGINEERING-SKILLS.md')),[System.Text.UTF8Encoding]::new($false))
$taskRecord = [ordered]@{ skills = $taskNames; central = $taskCentral; codex = $taskCodex; claude = $taskClaude; physicalDirectories = 19; codexJunctions = 19; claudeJunctions = 19; retiredV1 = $taskRetired; oldNameRemoved = $true; ccSwitchDatabaseModified = $false; thirdPartyWritesByThisTask = $false; priorThirdPartyDriftRecorded = $true; fullSessionThirdPartyHashStability = $false }
$taskRecord | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $taskRevision 'global-installation.json') -Encoding utf8
$taskRecord | ConvertTo-Json -Depth 4
