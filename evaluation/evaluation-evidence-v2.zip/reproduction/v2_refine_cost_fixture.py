from pathlib import Path
import json, shutil

V = Path(__file__).resolve().parent / 'v2'
name = 'agent-cost-and-latency'
job_path = V / f'job-{name}.json'
job = json.loads(job_path.read_text(encoding='utf-8'))
assert not (V / f'job-{name}-iteration-1.json').exists()
for task in job['tasks']:
    for run in task['runs'].values():
        assert 'iteration-1' in run and (Path(run) / 'grading.json').is_file()
        assert not Path(run.replace('iteration-1', 'iteration-2')).exists()

prompt = '''A shared response cache omits tenant and prompt versions. Two dependent mutation tools run in parallel to save latency. Workers each spend up to the full run cap, and restarts reset it. Correct the optimization and acceptance tests.

Build and actually run a small local Python fake workload; no live models, external calls or mutations. Supply safe cache isolation, ordered permissioned mutations, and one durable shared reservation/spend ledger across workers and restart. Use a deterministic fake clock and billing ledger: each attempt advances the logical task clock and incurs the stated charge, including failed attempts. The read is immutable cacheable data; cached responses never grant permission/approval or replace current authoritative state. Every logical task has a distinct ID; mutation B requires successful A. Both require current fake permission. Independently verify the ordered outcome, not the model's success claim.

Execute 40 logical tasks, 10 of each fixture below. Each task starts its own logical clock at zero. Costs are synthetic units; durations are simulated milliseconds. Cold successful read costs1/duration10; warm authorized cache hit costs0.1/duration2; mutation A costs2/duration20; mutation B costs3/duration30; final deterministic verification costs0.2/duration5.
- Cold-success: cold read, successful A, successful B, verification.
- Warm-success: scoped preloaded cache hit, successful A, successful B, verification.
- Retry-success: one transient failed cold read charged1/duration10, one successful cold read charged1/duration10, then successful A, successful B, verification. Exactly one eligible retry.
- Permanent-failure: cold read, A returns permanent failure charged2/duration20, no B, verification reports unsuccessful. Do not retry A.

Measure executed ledger totals across all40 tasks, count independently verified successes, compute total cost divided by those successes (include all failed tasks/retries), and nearest-rank p95 logical completion latency across all40 terminal tasks. Also state the success-only latency denominator if reported. Do not fabricate a pre-change benchmark or claim simulated fees/durations measure a real provider. The workload's shared cost cap is250 units and per-task cap10; admission must reserve conservatively so multiple workers cannot each take the whole cap. Include separate deterministic acceptance tests for cross-tenant/access/version/freshness cache isolation, permission denial/no mutation, B-before-A rejection, aggregate budget contention, and resumed spent/pending reservations; keep those tests out of workload metric totals. Save code, actual command logs and a concise report of measurements and limitations.'''

shutil.copy2(job_path, V / f'job-{name}-iteration-1.json')
suite_path = V / 'pack' / name / 'evals' / 'evals.json'
suite = json.loads(suite_path.read_text(encoding='utf-8'))
case = next(x for x in suite['evals'] if x['id'] == 2)
original_prompt = case['prompt']
case['prompt'] = prompt
suite_path.write_text(json.dumps(suite, indent=2, ensure_ascii=False), encoding='utf-8')
for task in job['tasks']:
    if task['id'] == 2:
        task['prompt'] = prompt
    for config, old in list(task['runs'].items()):
        dest = Path(old.replace('iteration-1', 'iteration-2'))
        (dest / 'outputs').mkdir(parents=True)
        metadata = json.loads((Path(old) / 'eval_metadata.json').read_text(encoding='utf-8'))
        metadata['prompt'] = task['prompt']
        (dest / 'eval_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
        task['runs'][config] = str(dest)
job_path.write_text(json.dumps(job, indent=2), encoding='utf-8')
jobs_path = V / 'eval-jobs.json'
jobs = json.loads(jobs_path.read_text(encoding='utf-8'))
jobs_path.write_text(json.dumps([job if x['skill'] == name else x for x in jobs], indent=2), encoding='utf-8')
(V / 'cost-fixture-refinement.json').write_text(json.dumps({
    'reason': 'Both original configurations correctly declined to invent measurements without a workload; the unchanged literal fourth assertion failed.',
    'original_prompt': original_prompt,
    'revised_prompt': prompt,
    'assertions_changed': False,
    'skill_instructions_changed': False,
    'measurement_scope': 'Executed deterministic fake clock/billing fixtures, not provider performance or live side effects.',
    'original_failed_grades_preserved': True,
}, indent=2), encoding='utf-8')
print('Cost iteration-2 executable fixture prepared; original failures and assertion contract preserved.')
