from pathlib import Path
import hashlib,json,os,sys,shutil,zipfile,io,contextlib
W=Path(__file__).resolve().parent; V=W/'v2'; O=W.parent/'outputs/v2'; P=V/'pack'; C=Path('~/.cc-switch/skills/skill-creator')
sys.path.insert(0,str(W/'validation-deps')); sys.path.insert(0,str(C)); from scripts.package_skill import package_skill
b=json.loads((V/'behavior-summary.json').read_text(encoding='utf-8')); r=json.loads((V/'routing-summary.json').read_text(encoding='utf-8')); a=json.loads((V/'global-audit.json').read_text(encoding='utf-8')); installation=json.loads((V/'global-installation.json').read_text(encoding='utf-8-sig'))
refinement=json.loads((V/'refinement-probe-results.json').read_text(encoding='utf-8'))
assert b['smoke_gate_passed'] and r['smoke_gate_passed'] and a['passed'] and refinement['passed'] is True
contract=json.loads((V/'refinement-probe-contract.json').read_text(encoding='utf-8'))
assert set(refinement['checks'])==set(contract['required_checks'])
assert all(x['passed'] is True and x['evidence'] for x in refinement['checks'].values())
status=json.loads((V/'change-status.json').read_text(encoding='utf-8'))
names=sorted(d.name for d in P.iterdir() if d.is_dir()); assert len(names)==19
historical_runs=sum(1 for d in V.glob('*-workspace') for p in d.rglob('grading.json'))
historical_failures=[]
for d in sorted(V.glob('*-workspace')):
    for p in sorted(d.rglob('grading.json')):
        g=json.loads(p.read_text(encoding='utf-8'))
        for e in g['expectations']:
            if e['passed'] is False:
                historical_failures.append((p.relative_to(V).as_posix(),e['text'],e['evidence']))
improved=[n for n,x in b['skills'].items() if x['delta']>0]; tied=[n for n,x in b['skills'].items() if x['delta']==0]; regressed=[n for n,x in b['skills'].items() if x['delta']<0]
notes=['# Sathvik — Agent Engineering: revision 2 validation report','','Author: Sathvik. Date: 5 October 2026.','',
'## Installation and acceptance','',
'19 physical global skills are installed in `~/.cc-switch/skills`, exposed through 19 verified junctions each in Codex and Claude global roots. Catalogue hardlinks expose the same content. CC Switch database/settings were not edited; UI toggle registration is unverified. The old orchestration live name is removed, with its original physical directory retired into the workspace and an immutable v1 snapshot retained.',
'', '**Bounded structural/behavior/routing-proxy gates passed. The full acceptance gate is NOT completely verified:** actual automatic invocation/official description optimization, repeated held-out variance and human review remain unresolved. No production-readiness certification is claimed.',
'', '## Audit, changes and scope','',
'Read every v1 custom SKILL.md, all 51 behavioral cases, all 340 trigger queries and four references; no custom production scripts existed. Read all 18 installed Anthropic creator files and 22 relevant third-party SKILL.md files, plus three newly visible architecture/interview command files after the inventory refresh. Their explicitly invoked general refactor/interview workflows remain complementary; no additional agent specialist was discovered. Preserve v1 files/evaluation history. Rules are motivated by the user-supplied Orchestrate observations; original reports/article were not provided and no external statistics or causality are claimed.',
'', 'Third-party bodies inspected: brainstorming, writing-plans, planning-and-task-breakdown, incremental-implementation, spec-driven-development, context-engineering, source-driven-development, systematic-debugging, debugging-and-error-recovery, verification-before-completion, test-driven-development, subagent-driven-development, dispatching-parallel-agents, doubt-driven-development, documentation-and-adrs, api-and-interface-design, mcp-builder, security-and-hardening, observability-and-instrumentation, performance-optimization, research and citation-management. Later command inspection: grill-me, grill-with-docs and improve-codebase-architecture. Exact paths and original source hashes are retained in the methodology/overlap audit; the current inventory contains 514 skill metadata records.',
'', 'Modified existing skills: '+', '.join(n for n in status['modified'] if n!='agent-orchestration')+'.',
'', 'Created: agent-development-workflow and evidence-provenance. Renamed/refactored: multi-agent-orchestration → agent-orchestration. Kept unchanged: '+', '.join(status['unchanged'])+'.',
'', 'No model-selection-and-routing skill: architecture owns role requirements, orchestration owns route control, evals owns comparisons and cost/latency owns economics. Technical defence stays inside lifecycle completion.',
'', 'Major additions:',
'', '- Simplest architecture that correctly handles uncertainty; reject both unnecessary agentification and fragile semantic heuristics.',
'- Complete PLAN → IMPLEMENT → RUN → DEBUG → CORRECT → REVIEW loop; actual vertical slice, decision log, human ownership and direct technical defence.',
'- Model fallibility and CONSTRUCT → VERIFY → ADMIT; bounded supported repair under unchanged rules, authority and task intent, then honest terminal failure when no admissible candidate exists.',
'- Source/normalization/ledger/decision/claim lineage; retrieved ≠ visible ≠ used support; reject invented or unrelated IDs and contradictory explanation.',
'- Semantic consistency beyond JSON/schema, role-specific model experiments, tool use/non-use and pre/postconditions, contract-preserving fallback and actionable telemetry.',
'- Baseline/variant metric-specific gates, repeatable evaluation path and component ablations; no framework/multi-agent/extra-model benefit without evidence.',
'', '## Behavioral evidence','',
f"Fresh V2 evaluation: {b['selected_cases']} selected cases in two configurations, {b['selected_runs']} runs over 16 modified/new skills. Independently graded expectations: **{b['with_passed']}/{b['with_total']}** with revisions versus **{b['baseline_passed']}/{b['baseline_total']}** baseline. {len(improved)} skills improve observed case scores, {len(tied)} tie and {len(regressed)} regress. Modified skills use frozen v1; new skills use no-skill baselines. Configurations are visible to graders, not blinded.",
'', f'Across preserved revision iterations, {historical_runs} graded runs are archived; the selected final comparison contains {b["selected_runs"]}. Each modified skill has its original adversarial regression and new targeted case executed; each new skill has all three cases executed. Three unchanged procedures retain labeled v1 evidence. The global bundle has 71 stored cases; not every retained v1 case was rerun against v2. Expectations are withheld from executors. Fresh per-skill/configuration executors handle cases sequentially. Interrupted security runs were resumed by fresh executors within their assigned configuration, with existing artifacts disclosed; this is a continuity exception. One sample per case does not measure repeated-run variance or statistical benefit; tied cases do not demonstrate material improvement.',
'', '| Skill | V2 | Baseline | Comparison |','|---|---:|---:|---|']
for name,x in b['skills'].items(): notes.append(f"| {name} | {x['with_passed']}/{x['with_total']} | {x['baseline_passed']}/{x['baseline_total']} ({x['baseline']}) | {'Improved smoke score' if x['delta']>0 else 'Tie; incremental benefit unproven' if x['delta']==0 else 'Regression'} |")
notes += ['', 'Executable local fakes/tests are preserved with actual command logs. Graders inspect source and rerun relevant code under bundled Python; some executors also used system Python 3.11.9. Proposed design checks are labeled unexecuted. Local tests do not certify distributed storage, provider adapters, full JSON Schema support or general entailment.',
'', '## Failed evals and corrections','']
for failure in b['failures']: notes.append(f"- {failure['skill']} case {failure['case']} {failure['configuration']}: {failure['expectation']} Evidence: {failure['evidence']}")
notes += ['', 'All preserved failed assertions by exact run (including superseded iterations):', '']
for path,expectation,evidence in historical_failures:
    notes.append(f'- `{path}`: {expectation} Evidence: {evidence}')
notes += ['', 'Starter-bug failures in the lifecycle case are intentional fixtures, preserved before correction. Infrastructure command-discovery failures are retained separately from assertion failures. Any revision iterations and old grades remain in the evidence archive; tests were not relabeled to manufacture success.',
'', 'The first cost/latency task required measured end-to-end economics without providing a workload. Both configurations correctly left that experiment unexecuted and failed the literal measurement assertion. Preserved those failures; revised only that eval prompt to supply a local executable 40-task fake clock/billing workload, keeping all four assertions and skill instructions unchanged. Iteration-2 measurements include failure and retry charges, independently verified successes and nearest-rank p95 terminal latency. These synthetic measurements do not establish real provider performance or a pre-change improvement. Initial baseline SQLite cleanup errors and a guardrails PowerShell StrictMode empty-pipeline Count failure remain archived beside corrected reruns.',
'', 'Source review corrected architecture-table cells that still described escalation to another architecture. Both selected cases/configurations were rerun in iteration-2; iteration-1 remains archived. Independent grading also found inferred raw success counts from undefined quality percentages in eval-design output. Agent-evals now preserves metric definitions/units/denominators and was rerun in iteration-2 without changing assertions. Original unsupported claims are retained. Independent provenance probing found that the no-skill fake records a source version but does not bind its decision to that version; the revised-skill fake rejects a changed version. The original assertion did not require that binding, so the passing rubric is preserved and the uncovered gap is reported separately. Orchestration output review flags ambiguous receipt-before-dispatch phrasing: an intent can precede dispatch, but an actual receipt follows an observed effect. The skill source uses the correct ordering.',
'', 'Independent security probes also reproduce a baseline fake accepting an arbitrary bounded summary under genuine D3. The revised fake checks an exact quote, which is a narrower fixture check and still does not prove general entailment. This is preserved as a semantic-support coverage limitation, not invented as a failing provenance-identity assertion.',
'', 'Supplemental probes found the first revised observability fake accepting an orphan parent span as complete and the first revised testing controller admitting another effect after terminal reentry. Their bounded rubric scores are preserved. Added explicit orphan/cyclic/missing-event reconstruction faults and terminal-controller/checkpoint reentry properties, then reran both paired jobs in iteration-2 and separately reprobed those behaviors. Both original synthetic redactors also permit arbitrary credential-like text in allowlisted fields. Source and fixture refinements do not establish universal trace completeness, provider semantics or privacy enforcement.',
'', 'The observability iteration-2 signal executor corrected a safety denominator and extended 14 checks to 15. Its intermediate raw 14-check log was overwritten; a correction record and final 15-check execution are retained. Independent copied-source reruns and closure probes use the saved final source; missing intermediate logs are not fabricated.',
'', 'A separate refinement contract was frozen before those iteration-2 runs: metric definitions, trace closure faults and terminal reentry must pass with actual artifact/probe evidence. All three revised checks pass; their results are archived separately and are not added to original assertion denominators.',
'', 'A bundled PowerShell startup threw OutOfMemoryException before a file-read command executed. A later retry with login=false succeeded; no configuration was changed. Although the shell argument requested the built-in executable, fresh process inspection identifies the root command host as bundled pwsh 7.6.5. This environment failure and actual runtime distinction are preserved separately from skill assertions.',
'', '## Trigger evidence','',
f"380 balanced queries (190 positive, 190 negative), with 35 descriptions (19 custom plus 16 adjacent existing). Independent catalogue-selection proxy: **{r['passed']}/{r['total']}**. All skills meet the predeclared >=9/10 gate in each class. This is not automatic harness activation or the official Claude optimizer.",
'', 'The one miss selected orchestration/state/guardrails for centrally reserved worker budgets rather than additionally cost-and-latency. Kept as a scope ambiguity, without relabeling or overfitting descriptions. New lifecycle, provenance and broadened orchestration pass all their proxy cases.',
'', 'Official tooling preflight was repeated in a separate evidence directory on 5 October 2026: `claude -p` still reports Not logged in; untouched `scripts.run_eval` still raises WinError10038 on Windows subprocess pipes. Its generated 0/1 result is an infrastructure failure, not a measured negative activation. Official description optimization cannot run in this environment; neither authentication nor third-party code was modified. Both attempts and all 19 official-template trigger review pages are available.',
'', '## Validation commands and integrity','',
'Runtime: bundled Python invoked with `-X utf8 -B`; locally staged PyYAML dependencies only. Governing tools are untouched.',
'', '- `python -X utf8 -B work/v2_audit.py`: official quick_validate for each staged skill plus frontmatter/name/author/scope, suite schemas, references, duplicates, snapshot and third-party hashes.',
'- `python -X utf8 -B work/v2_finish_evidence.py`: exact assertion contract checks, official aggregate_benchmark and generate_review.py; generated metadata corrected to actual run count and unavailable usage, with raw official output retained.',
'- `python -X utf8 -B work/v2_score_routes.py`: coverage/name checks and predeclared per-class proxy scoring.',
'- `work/v2_install_global.ps1`: snapshot equality/collision guards, scoped copy/junction migration, per-file hash verification, safe old-name retirement.',
'- `python -X utf8 -B work/v2_audit.py --installed`: actual installed content/frontmatter/references, all 19 junction targets and obsolete-name absence verified.',
'- Official package_skill creates 19 .skill archives; official packages omit evals, so the full collection ZIP retains them.',
'', f"The current pre-install third-party inventory contains {a['third_party_files_checked']:,} files; its hashes match after installation. The initial V2 audit failed against 414 obsolete bundled-plugin paths from v1. A later continuation detected 194 paths differing from the earlier v2 snapshot (91 changed, 103 absent), including third-party design skills and one plugin configuration, plus 441 newly inventoried files. Both failed audits, prior inventories and exact differences are preserved. No task write targeted those paths; hashes alone do not establish the cause. A read-only baseline refresh precedes installation, so post-refresh integrity is verified but full-session third-party hash stability is NOT claimed. V1 custom snapshot hashes remain unchanged.",
'', '## Cross-skill adversarial review','',
'Audited autonomy/semantic uncertainty, framework/workers benefit, proposal-to-state admission, unsupported support/semantic contradictions, premature refusal, retry/step ceilings, reconstructable runs, restart state/unknown effects, high-impact permissions, eval versus telemetry, tool choice guidance and evidence-based design defence. Worker routes are optional after fixed/single-agent routing. No mandatory dependency cycle; repeated principles remain contextual to their enforcement boundary.',
'', '## Exact unresolved risks','',
'- Actual Codex/Claude automatic invocation and official optimizer unavailable. V1 skills appeared in the refreshed Codex catalogue, but that does not establish V2 activation. CC Switch UI registration was not performed.',
'- Third-party files drifted between snapshots during this continuing task. Exact changes and missing paths are recorded; full-session third-party stability is unverified despite unchanged hashes across the final installation boundary.',
'- Human review of official viewers, calibrated human semantic labels, repeated same-version stochastic runs and broader held-out generalization remain unverified.',
'- Exact inherited model/sampling identifiers and uniform token/latency usage are not supplied; omitted, not zero or character-derived tokens.',
'- Fresh evaluation targets modifications; retained v1 cases and unchanged-skill evidence are labeled. Smoke ties do not prove added benefit.',
'- Fakes, typed comparisons and design artifacts do not prove production provider idempotency, durable distributed storage, general natural-language entailment, browser/E2E coverage or full schema dialect/provider support.',
'- Original cost fakes also exposed strict bool/integer validation, pending-reservation return semantics and cross-tool idempotency-key scoping gaps outside their literal assertions. Recorded probes are coverage limitations; passing smoke rubrics do not certify the generated fake as a production implementation.',
'', '## Final list, tree and workflow','',
'The collection catalogue lists all 19 skills, author, purpose, triggers/non-triggers, relationships, eval/validation status, actual files, shared terminology and the complete recommended build flow. It is included beside the skill folders in the full ZIP.',
'', 'Final workflow: understand → map uncertainty → choose task-fit architecture → baseline/evals → freeze contracts → model/code boundary and authority → evidence flow → necessary tools/retrieval/state → bounded control → vertical slice → plan/implement/run/debug/correct/review → semantic and evidence reconciliation → failure tests → matched evals/ablations → retain/revise/rollback → technical defence → verification → authorized release.', '', '```text', 'skills/', '  AGENT-ENGINEERING-SKILLS.md']
for name in names:
    notes.append('  '+name+'/')
    for p in sorted((P/name).rglob('*')):
        if p.is_file(): notes.append('    '+p.relative_to(P/name).as_posix())
notes += ['```','']
O.mkdir(exist_ok=True,parents=True); report='\n'.join(notes); (O/'VALIDATION-REPORT.md').write_text(report,encoding='utf-8')
bundle=O/'agent-engineering-pack'; shutil.copytree(P,bundle,dirs_exist_ok=True); (bundle/'VALIDATION-REPORT.md').write_text(report,encoding='utf-8')
log=io.StringIO()
with contextlib.redirect_stdout(log):
    for name in names: assert package_skill(bundle/name,O/'packages')
(O/'official-packaging.log').write_text(log.getvalue(),encoding='utf-8')
manifest={p.relative_to(bundle).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in bundle.rglob('*') if p.is_file()}
(O/'SHA256-MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
with zipfile.ZipFile(O/'sathvik-agent-engineering-v2.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in bundle.rglob('*'):
        if p.is_file(): z.write(p,p.relative_to(bundle))
with zipfile.ZipFile(O/'evaluation-evidence-v2.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in V.rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc' or 'pack' in p.relative_to(V).parts: continue
        z.write(p,Path('revision-evidence')/p.relative_to(V))
    for name in ['v2_gap_map.md','v2-methodology-overlap.md','v2-trigger-audit.md']:
        z.write(W/name,Path('audits')/name)
    for p in sorted(W.glob('v2_*')):
        if p.is_file() and p.suffix in ('.py','.ps1'): z.write(p,Path('reproduction')/p.name)
    z.write(W/'behavior-summary.json',Path('retained-v1')/'behavior-summary.json')
    for filename in ['agent-engineering-evaluation-evidence.zip','VALIDATION-REPORT.md','EXPORT-INTEGRITY.json']:
        z.write(W.parent/'outputs'/filename,Path('retained-v1/original-export')/filename)
    for name in status['unchanged']:
        prior=W/f'{name}-workspace'/'iteration-1'
        for p in prior.rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':
                z.write(p,Path('retained-v1')/name/p.relative_to(prior))
    for p in O.rglob('*.html'): z.write(p,Path('reviews')/p.relative_to(O))
    for name in ['ANTHROPIC-SKILL-CREATOR-LICENSE.txt','ANTHROPIC-ATTRIBUTION.md']:
        shutil.copy2(W.parent/'outputs'/name,O/name); z.write(O/name,name)
    z.write(O/'VALIDATION-REPORT.md','VALIDATION-REPORT.md')
print(json.dumps(dict(installed_skills=19,bundle_files=len(manifest),fresh_runs=b['selected_runs'],with_score=f"{b['with_passed']}/{b['with_total']}",baseline_score=f"{b['baseline_passed']}/{b['baseline_total']}",routing_score=f"{r['passed']}/{r['total']}",full_acceptance_verified=False),indent=2))
