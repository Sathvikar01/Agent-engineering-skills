from pathlib import Path
import hashlib,json,sys,shutil
W=Path(__file__).resolve().parent; V=W/'v2'; O=W.parent/'outputs/v2'
C=Path('~/.cc-switch/skills/skill-creator')
sys.path.insert(0,str(W/'validation-deps')); import yaml
template=(C/'assets/eval_review.html').read_text(encoding='utf-8')
dest=O/'trigger-reviews'; dest.mkdir(parents=True,exist_ok=True)
for d in sorted((V/'pack').iterdir()):
    if not d.is_dir(): continue
    fm=yaml.safe_load((d/'SKILL.md').read_text(encoding='utf-8').split('---',2)[1])
    queries=json.loads((d/'evals/trigger-evals.json').read_text(encoding='utf-8'))
    html=template.replace('__EVAL_DATA_PLACEHOLDER__',json.dumps(queries,ensure_ascii=False)).replace('__SKILL_NAME_PLACEHOLDER__',d.name).replace('__SKILL_DESCRIPTION_PLACEHOLDER__',fm['description'])
    (dest/f'{d.name}.html').write_text(html,encoding='utf-8')
jobs=json.loads((V/'eval-jobs.json').read_text(encoding='utf-8')); hashes={}
for job in jobs:
    name=job['skill']; iteration=Path(job['tasks'][0]['runs']['with_skill']).parents[2]; snapshot=iteration/'tested-skill'
    if not snapshot.exists(): shutil.copytree(Path(job['skill_path']),snapshot)
    hashes[name]={p.relative_to(snapshot).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in snapshot.rglob('*') if p.is_file()}
(V/'tested-source-sha256.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
print('Created 19 official-template trigger review pages and 16 tested-source snapshots.')
