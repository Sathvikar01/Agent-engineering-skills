from pathlib import Path
import hashlib,json,re,sys,argparse
W=Path(__file__).resolve().parent; V=W/'v2'
sys.path.insert(0,str(W/'validation-deps')); sys.path.insert(0,'~/.cc-switch/skills/skill-creator')
import yaml
from scripts.quick_validate import validate_skill
oldnames=json.loads((W/'global-installation.json').read_text(encoding='utf-8-sig'))['skills']
names=sorted((set(oldnames)-{'multi-agent-orchestration'})|{'agent-orchestration','agent-development-workflow','evidence-provenance'})
def audit(root,installed=False):
    errors=[]; rows=[]; count=triggers=0; bodies=[]
    def check(c,msg):
        if not c: errors.append(msg)
    for name in names:
        d=root/name; valid,msg=validate_skill(d); check(valid,f'{name}: official validator: {msg}')
        if not (d/'SKILL.md').is_file(): continue
        text=(d/'SKILL.md').read_text(encoding='utf-8'); fm=yaml.safe_load(text.split('---',2)[1])
        check(fm['name']==name,f'{name}: name mismatch'); check(fm.get('metadata',{}).get('author')=='Sathvik',f'{name}: author')
        check(fm.get('metadata',{}).get('collection')=='Sathvik — Agent Engineering',f'{name}: collection')
        check('Use when ' in fm['description'] and 'Do not use for ' in fm['description'],f'{name}: trigger scope')
        check(len(text.splitlines())<500,f'{name}: concise'); check('multi-agent-orchestration' not in text,f'{name}: obsolete instruction reference')
        check(not re.search(r'\b(Tracer|SansRAG|Conductor)\b',text,re.I),f'{name}: project specificity')
        for p in d.rglob('*.md'):
            for target in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
                if '://' in target or target.startswith('#'): continue
                q=(p.parent/target.split('#')[0]).resolve(); check(q.is_file() and q.is_relative_to(d.resolve()),f'{name}: broken/escaping {target}')
        suite=json.loads((d/'evals/evals.json').read_text(encoding='utf-8')); cases=suite['evals']; count+=len(cases)
        check(suite['skill_name']==name,f'{name}: eval name'); ids=[]
        for c in cases:
            ids.append(c['id']); check(isinstance(c['id'],int) and bool(c['prompt']) and bool(c['expected_output']) and isinstance(c['files'],list) and len(c.get('expectations',[]))>=2,f'{name}: eval schema')
            for ref in c['files']: check((d/ref).is_file(),f'{name}: missing fixture {ref}')
        check(len(cases)>=3 and len(ids)==len(set(ids)),f'{name}: cases')
        qs=json.loads((d/'evals/trigger-evals.json').read_text(encoding='utf-8')); triggers+=len(qs)
        check(len(qs)==20 and sum(q['should_trigger'] for q in qs)==10,f'{name}: trigger balance')
        check(all(set(q)=={'query','should_trigger'} and isinstance(q['should_trigger'],bool) and isinstance(q['query'],str) for q in qs),f'{name}: trigger schema')
        bodies.append(hashlib.sha256(text.split('---',2)[2].encode()).hexdigest()); rows.append(dict(name=name,lines=len(text.splitlines()),behavior_cases=len(cases),trigger_cases=len(qs),version=fm['metadata']['version']))
    check(len(set(bodies))==19,'duplicate bodies')
    tested=json.loads((V/'tested-source-sha256.json').read_text(encoding='utf-8'))
    for name, hashes in tested.items():
        actual={p.relative_to(root/name).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/name).rglob('*') if p.is_file()}
        check(actual==hashes,f'{name}: current source differs from tested snapshot')
    catalogue=root/'AGENT-ENGINEERING-SKILLS.md'
    check(catalogue.is_file(),'collection catalogue missing')
    if catalogue.is_file():
        for target in re.findall(r'\]\(([^)]+)\)',catalogue.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'): continue
            q=(catalogue.parent/target.split('#')[0]).resolve()
            check(q.is_file() and q.is_relative_to(root.resolve()),f'collection: broken/escaping {target}')
    baseline=V/'third-party-before.json'
    before=json.loads((baseline if baseline.exists() else W/'installation-before.json').read_text(encoding='utf-8')); changes=[]
    for raw,digest in before['files'].items():
        p=Path(raw)
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest: changes.append(raw)
    check(not changes,'third-party drift from active integrity baseline')
    snapshots=json.loads((V/'v1-snapshot-sha256.json').read_text(encoding='utf-8'))
    check(all(hashlib.sha256((V/'v1-snapshot'/p).read_bytes()).hexdigest()==h for p,h in snapshots.items()),'v1 snapshot changed')
    # The old live name is allowed while staged; reject it after successful migration.
    if installed:
        for r in [root,Path('~/.codex/skills'),Path('~/.claude/skills')]: check(not (r/'multi-agent-orchestration').exists(),f'old live name remains at {r}')
        for name in names:
            staged={p.relative_to(V/'pack'/name).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (V/'pack'/name).rglob('*') if p.is_file()}
            live={p.relative_to(root/name).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/name).rglob('*') if p.is_file()}
            check(live==staged,f'{name}: installed file set/content mismatch')
            for r in [Path('~/.codex/skills'),Path('~/.claude/skills')]: check((r/name).is_junction() and (r/name).resolve()==(root/name).resolve(),f'{name}: exposure junction')
    result=dict(passed=not errors,skills_checked=len(rows),expected_skills=19,behavior_cases=count,trigger_cases=triggers,third_party_files_checked=len(before['files']),third_party_changes=changes,failures=errors,skills=rows,installed=installed)
    return result
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--installed',action='store_true'); args=ap.parse_args()
    root=Path('~/.cc-switch/skills') if args.installed else V/'pack'
    result=audit(root,args.installed); (V/('global-audit.json' if args.installed else 'staging-audit.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('skills','third_party_changes')},indent=2)); sys.exit(0 if result['passed'] else 1)
