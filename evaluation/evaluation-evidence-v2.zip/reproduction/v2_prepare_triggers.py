from pathlib import Path
import json, random, sys
W=Path(__file__).resolve().parent; V=W/'v2'; P=V/'pack'
sys.path.insert(0,str(W/'validation-deps')); import yaml
def suite(name,positive,negative):
    assert len(positive)==len(negative)==10
    queries=[dict(query=q,should_trigger=True) for q in positive]+[dict(query=q,should_trigger=False) for q in negative]
    (P/name/'evals/trigger-evals.json').write_text(json.dumps(queries,indent=2),encoding='utf-8')
suite('agent-development-workflow',[
'Our receipt assistant works on one image. Help turn it into a reliable system that interprets messy receipts, validates reimbursements and emits supported explanations; build and test the whole path.',
'build me a support agent that can find orders and make authorized changes. I want the architecture, working implementation and evidence it behaves safely.',
'We have a chatbot prototype; productionize it with real state, tools and restart behavior rather than just a better prompt.',
'Substantially redesign our document agent: it loses evidence and loops. Audit architecture, implement a small corrected path, run failures and compare it to the old system.',
'Add retrieval, durable state and tool execution to the current one-call assistant. Work through the full engineering lifecycle and verify it.',
'I need an end-to-end hardening review of our agent, from model uncertainty and permissions to recovery, evals, traces and release evidence.',
'Create a semi-autonomous workflow for interpreting requests and preparing approvals. Need a measured baseline, vertical slice, implementation and failure tests.',
'Our autonomous research prototype is becoming a product. Plan and carry out its engineering upgrade, then explain why the final design survived evals.',
'The claims assistant needs a major capability addition: new evidence tools, persisted tasks and bounded routing. Coordinate design, implementation, execution and review.',
'Can you architect and build a complete model-assisted pipeline for messy invoices? Code controls money and approval; show actual verification before accepting it.'
],[
'Fix the misspelling insufficent_evidence in our agent prompt.',
'The agent parser raises ValueError for an empty integer argument; fix that one bug and run the parser test.',
'Add evidence_version as an optional field to this existing proposal schema; leave other contracts alone.',
'Write one REST endpoint to list saved orders for our browser UI.',
'What is an AI agent? Explain it briefly to a beginner.',
'Make a deterministic cents-to-currency utility and its unit tests.',
'Tune just the search tool description so the LLM stops confusing it with delete_order.',
'Only compare latency and cost for these two existing model routes using the supplied numbers.',
'We already have our runtime; specify an exact email approval preview and expiry binding, no broader redesign.',
'Design the evidence ledger reconciliation for our existing answer service; retrieval, controller and release pipeline are fixed.'
])
suite('evidence-provenance',[
'Our answer cites message IDs the model guessed. Design the runtime ledger and check every claim against observed messages before output.',
'Retrieval returned A and B but only A supported the decision. The final answer cites both. Fix the used-support reconciliation contract.',
'A summary loses document/span/version when passed between models. Preserve transformation ancestry through decision and explanation.',
'The model emits WAIT in JSON but its explanation says approved. Reconcile facts, source support, decision and output before emission.',
'A tool result claims source_id=trusted-1, but that ID never appeared in an observed envelope. Prevent spoofed provenance reaching the decision.',
'Our computed decision uses receipt rows and a versioned rule. Define how calculation inputs and source IDs support each emitted claim.',
'On checkpoint resume the agent cites a document whose access was revoked. Design freshness/access checks for persisted evidence pointers.',
'Build a ledger validator that rejects unknown and known-but-unrelated citation IDs, and accepts genuinely supported claims.',
'The pipeline records retrieved documents but cannot show what supported the final answer. Add source-to-claim support lineage across stages.',
'We want honest unsupported status when evidence cannot be reconciled, with bounded repair instead of inventing citations after generation.'
],[
'Compare Recall@10 for sparse and dense search over our labeled manual queries; leave downstream citation reconciliation fixed.',
'Format these supplied references in APA style for my paper.',
'Add span correlation IDs and redaction to ordinary service event logs, no evidence-support decision path.',
'Find the current official documentation for this framework method and cite it in your coding explanation.',
'Choose a chunk size for retrieval and ablate reranking, with claim provenance already implemented.',
'Design expiry and deletion for remembered user response-style preferences.',
'Validate required field names, numeric types and enum values for this model JSON contract; support rules are unchanged.',
'Implement request duration counters for our normal API server.',
'Rename the evidence_ids JSON field to source_ids using a backwards-compatible serialization adapter; no support evaluation changes.',
'Locate a source file in the repository and explain the deterministic function in it.'
])
path=P/'agent-orchestration/evals/trigger-evals.json'; qs=json.loads(path.read_text(encoding='utf-8'))
positives=[q for q in qs if q['should_trigger']]; negatives=[q for q in qs if not q['should_trigger']]
newpos=[
'Our single tool-using agent sometimes needs another read to resolve conflicting text. Design who controls next steps, guards and stop limits.',
'A known stale-document status always means refetch; a semantic contradiction may need a model-selected check. Build bounded routing for these paths.',
'The planner repeats the same action after no progress. Define admissible next actions and controller termination across fallback and resume.',
'Should a model choose when to retrieve again, verify or escalate in this runtime? Compare it with a fixed state machine using task evidence.',
'We need bounded next-tool selection for one deployed agent, with max calls and a shared deadline; do we need a framework?'
]
for i,q in enumerate(newpos): positives[i]['query']=q
negatives[-1]['query']='Productionize the entire receipt agent across architecture, implementation, evals, security and release; coordinate the lifecycle without specifying controller transitions here.'
path.write_text(json.dumps(positives+negatives,indent=2),encoding='utf-8')
path=P/'agent-architecture/evals/trigger-evals.json'; qs=json.loads(path.read_text(encoding='utf-8'))
next(q for q in qs if q['should_trigger'])['query']='Our policy-document pipeline uses brittle regex for negation and exceptions just to avoid models. Decide the correct uncertainty boundary and architecture; step order is fixed.'
path.write_text(json.dumps(qs,indent=2),encoding='utf-8')
path=P/'rag-engineering/evals/trigger-evals.json'; qs=json.loads(path.read_text(encoding='utf-8'))
[q for q in qs if not q['should_trigger']][-1]['query']='Retrieval and context assembly are already fixed. Only design a generic evidence ledger that joins receipts, calculations, decisions and emitted claim IDs.'
path.write_text(json.dumps(qs,indent=2),encoding='utf-8')

catalog=[]
for path in sorted(P.glob('*/SKILL.md')):
    fm=yaml.safe_load(path.read_text(encoding='utf-8').split('---',2)[1]); catalog.append(dict(name=fm['name'],description=fm['description']))
previous=json.loads((W/'routing-proxy-catalogue.json').read_text(encoding='utf-8'))
oldnames=set(json.loads((W/'global-installation.json').read_text(encoding='utf-8-sig'))['skills'])
catalog += [c for c in previous if c['name'] not in oldnames]
data=[]
for path in sorted(P.glob('*/evals/trigger-evals.json')):
    for q in json.loads(path.read_text(encoding='utf-8')): data.append(dict(skill=path.parent.parent.name,**q))
random.Random(85173).shuffle(data)
assert len({q['query'] for q in data})==380
key={}; queries=[]
for i,q in enumerate(data,1):
    id=f'q{i:04d}'; key[id]=dict(skill=q['skill'],should_trigger=q['should_trigger']); queries.append(dict(id=id,query=q['query']))
for filename,value in [('routing-catalogue.json',catalog),('routing-queries.json',queries),('routing-key.json',key)]: (V/filename).write_text(json.dumps(value,indent=2),encoding='utf-8')
(V/'routing-gate.json').write_text(json.dumps(dict(minimum_per_class=9,positives_per_skill=10,negatives_per_skill=10,actual_activation=False,gate_set_before_classifier=True),indent=2),encoding='utf-8')
print('Prepared 380 trigger cases and 35 catalogue descriptions; labels withheld from classifier.')
