from pathlib import Path
import hashlib,json,re,zipfile,os
W=Path(__file__).resolve().parent; V=W/'v2'; O=W.parent/'outputs/v2'; B=O/'agent-engineering-pack'
names=sorted(p.name for p in B.iterdir() if p.is_dir()); assert len(names)==19 and 'multi-agent-orchestration' not in names
assert {p.stem for p in (O/'packages').glob('*.skill')}==set(names)
manifest=json.loads((O/'SHA256-MANIFEST.json').read_text(encoding='utf-8'))
assert set(manifest)=={p.relative_to(B).as_posix() for p in B.rglob('*') if p.is_file()}
for relative,h in manifest.items(): assert hashlib.sha256((B/relative).read_bytes()).hexdigest()==h
cases=triggers=0
for name in names:
    cases+=len(json.loads((B/name/'evals/evals.json').read_text(encoding='utf-8'))['evals'])
    triggers+=len(json.loads((B/name/'evals/trigger-evals.json').read_text(encoding='utf-8')))
    with zipfile.ZipFile(O/'packages'/f'{name}.skill') as z:
        assert z.testzip() is None
        assert f'{name}/SKILL.md' in z.namelist()
        for member in z.namelist(): assert '/evals/' not in member and z.read(member)==(B/member).read_bytes()
assert cases==71 and triggers==380
for filename in ['agent-engineering-v2.zip','evaluation-evidence-v2.zip']:
    with zipfile.ZipFile(O/filename) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
        if filename.startswith('agent-engineering-v2'):
            assert set(z.namelist())==set(manifest)
            for relative,h in manifest.items(): assert hashlib.sha256(z.read(relative)).hexdigest()==h
for path in B.rglob('*.md'):
    for target in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
        if '://' not in target and not target.startswith('#'): assert (path.parent/target.split('#')[0]).is_file(),f'Broken link {target}'
c=Path('~/.cc-switch/skills/AGENT-ENGINEERING-SKILLS.md')
for p in [Path('~/.codex/skills/AGENT-ENGINEERING-SKILLS.md'),Path('~/.claude/skills/AGENT-ENGINEERING-SKILLS.md')]: assert os.path.samefile(c,p)
assert c.read_bytes()==(B/'AGENT-ENGINEERING-SKILLS.md').read_bytes()
retired=V/'retired-v1/multi-agent-orchestration'; original=V/'v1-snapshot/multi-agent-orchestration'
assert {p.relative_to(retired).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in retired.rglob('*') if p.is_file()}=={p.relative_to(original).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in original.rglob('*') if p.is_file()}
result=dict(passed=True,skills=19,behavior_cases=cases,trigger_cases=triggers,packages=19,bundle_files=len(manifest),hashes_and_crc_verified=True,links_resolve=True,catalogue_hardlinks_verified=True,retired_v1_unchanged=True,full_acceptance_verified=False)
(O/'EXPORT-INTEGRITY.json').write_text(json.dumps(result,indent=2),encoding='utf-8'); print(json.dumps(result,indent=2))
