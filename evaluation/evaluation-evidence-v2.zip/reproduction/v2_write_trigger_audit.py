import hashlib, json, sys
from pathlib import Path

workspace = Path.cwd()
sys.path.insert(0, str(workspace / 'work/validation-deps'))
import yaml

install = json.loads((workspace / 'work/global-installation.json').read_text(encoding='utf-8-sig'))
central = Path(install['central'])
rows, files, queries = [], [], []
for name in install['skills']:
    folder = central / name
    meta = yaml.safe_load((folder/'SKILL.md').read_text(encoding='utf-8').split('---',2)[1])
    behavioral = json.loads((folder/'evals/evals.json').read_text(encoding='utf-8'))
    triggers = json.loads((folder/'evals/trigger-evals.json').read_text(encoding='utf-8'))
    assert meta['name'] == name == behavioral['skill_name']
    assert len({c['id'] for c in behavioral['evals']}) == len(behavioral['evals'])
    for case in behavioral['evals']:
        assert type(case['id']) is int
        for key in ['prompt','expected_output']:
            assert isinstance(case[key],str) and case[key].strip()
        assert isinstance(case.get('files',[]),list)
        assert isinstance(case['expectations'],list) and case['expectations']
        assert all(isinstance(x,str) and x.strip() for x in case['expectations'])
        for rel in case.get('files',[]):
            assert (folder/rel).is_file()
    for case in triggers:
        assert set(case) == {'query','should_trigger'}
        assert isinstance(case['query'],str) and case['query'].strip()
        assert type(case['should_trigger']) is bool
        queries.append(case['query'])
    refs = [p for p in (folder/'references').rglob('*') if p.is_file()] if (folder/'references').exists() else []
    scripts = [p for p in (folder/'scripts').rglob('*') if p.is_file()] if (folder/'scripts').exists() else []
    rows.append((name,len(behavioral['evals']),sum(t['should_trigger'] for t in triggers),sum(not t['should_trigger'] for t in triggers),len(refs),len(scripts)))
    files.extend((str(p),hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(folder.rglob('*')) if p.is_file())
assert len(queries)==len(set(queries))

report = '''# V2 trigger and resource audit

This read-only audit inspected the 17 installed Sathvik skill directories discovered through work/global-installation.json. It did not change any global skill, reference or evaluation suite.

## Inspection and methodology

- Fully read all 17 frontmatter descriptions and all 340 trigger queries, the complete user's v2 request, installed Anthropic skill-creator/SKILL.md and references/schemas.md.
- Structurally inspected all 17 behavioral suites against the official creator schema: matching skill_name, unique integer IDs, nonempty prompts/expected_output/expectations and existing input files. These focused assertions passed. This is not a full JSON Schema implementation or a behavioral test.
- Inventoried all 55 actual custom files: 17 SKILL.md, 17 evals.json, 17 trigger-evals.json, four reference files. No custom scripts or installed input fixtures exist.
- Root separately read all SKILL.md bodies, behavioral prompts/assertions and four references. Reference bodies were inventoried, not independently semantically reread by this trigger auditor.
- Every trigger suite follows the creator's exact query/should_trigger object array and has 10 positive and 10 negative cases. All 340 query texts are unique.
- No classifier, automatic activation test, description optimizer or behavioral evaluator was executed in this audit. V1 results cannot certify v2.

## Necessary boundary changes

1. **agent-architecture**: replace the generic smallest reliable architecture promise with the simplest architecture that correctly handles uncertainty. Include model-worthy semantic ambiguity and brittle regex-only overcorrection cases alongside anti-agentification. Architecture owns component/control/trust choices; the lifecycle skill owns execution and review across disciplines.
2. **agent-orchestration**: rename and broaden the multiple-worker-only description. Add single-agent contextual next-tool choice, additional retrieval, verifier/escalation, deterministic routing comparison and explicit stopping. Retain useful worker fan-in/authority/budget tests and development-session coding delegation negatives. Old negative index14 asks for system-class selection and remains architecture-focused; construct a separate next-step-controller positive instead of silently relabeling it. Old negative index15 is performance-only parallel reads/caching, which remains cost-focused when routing design is fixed.
3. **agent-development-workflow**: the new description must require meaningful build, productionization, substantial redesign, major tools/RAG/state changes or end-to-end hardening. Add negatives for a tiny prompt change, one agent bug, one schema field, focused provenance reconciliation, one tool description or retry policy, ordinary endpoint, deterministic utility and conceptual explanation. Permit lifecycle plus specialists together when scope warrants it; do not require one-skill-only classification. Behavior must demonstrate sequencing, actual execution, correction and evidence-based review, not mere terminology.
4. **evidence-provenance**: existing descriptions mention provenance but do not own source-to-decision/claim ledger reconciliation. New positives should span tool receipts, computed decisions, normalization lineage, source versions, unsupported IDs, explanation contradictions and retrieved-but-unused citations. Negatives should isolate retrieval recall/reranking, event instrumentation, memory lifecycle, routine source-finding and syntax/schema-only work. This skill owns support lineage and reconciliation; RAG owns candidate/context/generation quality, structured output owns contract/validation stages, observability owns safe correlated events. Spoofed provenance attack containment can also require security; multiple applicable specialists are valid.
5. **rag-engineering**: its existing description can stay because retrieval-grounded generation is a clear purpose. Add a ledger-only fixed-retrieval negative against provenance and a pipeline-loss positive involving chunking/reranking/context assembly. Preserve existing citation-support pipeline positives rather than relabeling them to force distinctness.
6. **Other descriptions**: no concrete scope flaw warrants rewriting them. Content additions on semantic consistency, construct/verify/admit, recovery, tool selection guidance, testing, actionable signals and cost fit existing scopes. Test new boundaries if responsibilities expand, but preserve good metadata otherwise.
7. **model-selection-and-routing**: a separate skill currently duplicates architecture role assignment, orchestration contextual control, evals measurement and cost routing/escalation. Fold role-specific comparison into these unless observed cases establish a distinct reusable procedure.

## Evaluation weaknesses and recommendations

- Existing queries are mostly polished and negatives often announce that an adjacent scope is fixed or outside this request. Keep them, but add casual, shorter and genuinely ambiguous examples for the new/broadened skills. Avoid all positives embedding the exact desired procedure.
- Old architecture looping/termination positives overlap orchestration legitimately. Distinguish requested artifact: architecture boundaries versus next-step state machine. Lifecycle coordinates specialists instead of replacing them.
- V1 suites lack sufficient direct behavioral coverage for deterministic overcorrection, first-solution acceptance, construct/verify/admit and evidence ledger reconciliation. Keyword-based trigger scores cannot establish these behaviors.
- Test provenance against RAG/output/observability/state/security in catalog-wide routing. Do not pretend one definitive owner is required when a prompt truly requests two artifacts.
- Follow creator improvement methodology: freeze old skill snapshots, execute paired new-versus-old runs for changed skills, use no-skill baselines for new skills, preserve prior failures, and create fresh eval metadata for altered prompts.
- Preserve documented Claude authentication and Windows subprocess limitations unless a fresh preflight disproves them. A catalog classifier is a proxy, not actual invocation evidence.

## Structural inventory

| Skill | Behavior cases | Positive triggers | Negative triggers | References | Scripts |
|---|---:|---:|---:|---:|---:|
'''
for row in rows:
    report += '| '+' | '.join(map(str,row))+' |\n'
report += '\n## File hashes at audit time\n\nPaths below were inventoried. SHA-256 identifies installed pre-change bytes; it does not assert independent semantic review of every body.\n\n| File | SHA-256 |\n|---|---|\n'
for path,digest in files:
    report += f'| `{path}` | `{digest}` |\n'
report += '\n## Governing files read\n\n'
for path in [central/'skill-creator/SKILL.md',central/'skill-creator/references/schemas.md']:
    report += f'- `{path}` — SHA-256 `{hashlib.sha256(path.read_bytes()).hexdigest()}`\n'
out = workspace/'work/v2-trigger-audit.md'
out.write_text(report,encoding='utf-8')
print(json.dumps({'report':str(out),'skills':len(rows),'files':len(files),'trigger_queries':len(queries),'behavior_cases':sum(r[1] for r in rows),'structural_checks':'passed'}))
