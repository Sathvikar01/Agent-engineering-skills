from pathlib import Path
import hashlib,json,os,subprocess,sys,shutil
W=Path(__file__).resolve().parent; V=W/'v2'; OUT=W.parent/'outputs/v2'; C=Path('~/.cc-switch/skills/skill-creator')
sys.path.insert(0,str(C)); from scripts.aggregate_benchmark import calculate_stats
env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
jobs=json.loads((V/'eval-jobs.json').read_text(encoding='utf-8')); summaries={}; failures=[]; allruns=[]
for job in jobs:
    name=job['skill']; gradepaths=[Path(t['runs'][config])/'grading.json' for t in job['tasks'] for config in ('with_skill',job['baseline'])]
    if not all(p.is_file() for p in gradepaths): continue
    iteration=Path(job['tasks'][0]['runs']['with_skill']).parents[2]
    for task in job['tasks']:
        for config in ('with_skill',job['baseline']):
            run=Path(task['runs'][config]); meta=json.loads((run/'eval_metadata.json').read_text(encoding='utf-8')); grade=json.loads((run/'grading.json').read_text(encoding='utf-8'))
            assert [e['text'] for e in grade['expectations']]==meta['assertions'], f'Changed assertion contract: {name}'
            assert all(isinstance(e['passed'],bool) and e['evidence'] for e in grade['expectations'])
            p=sum(e['passed'] for e in grade['expectations']); grade['summary']=dict(passed=p,failed=len(grade['expectations'])-p,total=len(grade['expectations']),pass_rate=p/len(grade['expectations']))
            grade.pop('timing',None); grade.pop('execution_metrics',None)
            (run/'grading.json').write_text(json.dumps(grade,indent=2),encoding='utf-8')
            for e in grade['expectations']:
                if not e['passed']: failures.append(dict(skill=name,case=task['id'],configuration=config,expectation=e['text'],evidence=e['evidence']))
    result=subprocess.run([sys.executable,'-X','utf8','-B','-m','scripts.aggregate_benchmark',str(iteration),'--skill-name',name,'--skill-path',job['skill_path']],cwd=C,env=env,capture_output=True,text=True,encoding='utf-8',check=True)
    bp=iteration/'benchmark.json'; b=json.loads(bp.read_text(encoding='utf-8'))
    (iteration/'benchmark-official-raw.json').write_text(json.dumps(b,indent=2),encoding='utf-8')
    b['metadata'].update(executor_model='Inherited Codex collaboration model; exact identifier not exposed',analyzer_model='Independent Codex grader; configuration visible',runs_per_configuration=1)
    b['notes']=['One sample per selected case/configuration; across-case variation is not stochastic repeat-run variance.','Token/latency metadata unavailable; character-based token estimates and missing-as-zero values removed.','Modified skills compare against frozen v1; new skills compare against no skill. Targeted V2 cases plus adversarial regression; stored suites have additional retained V1 coverage.','Actual Claude trigger tests blocked by authentication/Windows pipes; routing proxy and human review are separate.']
    for r in b['runs']:
        for key in ('tokens','time_seconds','tool_calls','errors'): r['result'].pop(key,None)
    b['runs'].sort(key=lambda r:(r['configuration']!='with_skill',r['eval_id']))
    cfg={c:[r for r in b['runs'] if r['configuration']==c] for c in ('with_skill',job['baseline'])}
    stats={c:{'pass_rate':calculate_stats([r['result']['pass_rate'] for r in rs])} for c,rs in cfg.items()}
    delta=stats['with_skill']['pass_rate']['mean']-stats[job['baseline']]['pass_rate']['mean']; stats['delta']={'pass_rate':f'{delta:+.4f}'}; b['run_summary']=stats
    bp.write_text(json.dumps(b,indent=2),encoding='utf-8')
    reviews=OUT/'reviews'; reviews.mkdir(parents=True,exist_ok=True)
    viewer_args=[sys.executable,'-X','utf8','-B',str(C/'eval-viewer/generate_review.py'),str(iteration),'--skill-name',name,'--benchmark',str(bp),'--static',str(reviews/f'{name}.html')]
    iteration_number=int(iteration.name.split('-')[-1])
    previous=iteration.with_name(f'iteration-{iteration_number-1}')
    if iteration_number>1 and previous.exists():
        viewer_args.extend(['--previous-workspace',str(previous)])
    subprocess.run(viewer_args,env=env,capture_output=True,check=True)
    counts={c:dict(passed=sum(r['result']['passed'] for r in rs),total=sum(r['result']['total'] for r in rs)) for c,rs in cfg.items()}
    summaries[name]=dict(with_passed=counts['with_skill']['passed'],with_total=counts['with_skill']['total'],baseline_passed=counts[job['baseline']]['passed'],baseline_total=counts[job['baseline']]['total'],baseline=job['baseline'],cases=len(job['tasks']),delta=delta,smoke_gate_passed=counts['with_skill']['passed']==counts['with_skill']['total'])
    allruns.extend(b['runs'])
report=dict(complete_skills=len(summaries),expected_fresh_skills=16,selected_cases=sum(x['cases'] for x in summaries.values()),selected_runs=2*sum(x['cases'] for x in summaries.values()),with_passed=sum(x['with_passed'] for x in summaries.values()),with_total=sum(x['with_total'] for x in summaries.values()),baseline_passed=sum(x['baseline_passed'] for x in summaries.values()),baseline_total=sum(x['baseline_total'] for x in summaries.values()),skills=summaries,failures=failures,smoke_gate_passed=len(summaries)==16 and all(x['smoke_gate_passed'] for x in summaries.values()))
(V/'behavior-summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8'); print(json.dumps({k:v for k,v in report.items() if k not in ('skills','failures')},indent=2)); print(json.dumps(failures,indent=2))
