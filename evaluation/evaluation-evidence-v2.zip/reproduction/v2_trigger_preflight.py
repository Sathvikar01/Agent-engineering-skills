from pathlib import Path
import os,sys,subprocess,json,argparse,re
ap=argparse.ArgumentParser(); ap.add_argument('--label',default='tooling-preflight'); args=ap.parse_args()
assert re.fullmatch(r'[a-z0-9-]+',args.label)
W=Path(__file__).resolve().parent; V=W/'v2'; D=V/args.label; D.mkdir(exist_ok=True); (D/'.claude').mkdir(exist_ok=True)
C=Path('~/.cc-switch/skills/skill-creator')
env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(C))
records=[]
commands=[('claude', ['~/.local/bin/claude.exe','-p','Reply with OK only.','--max-turns','1'])]
q=[dict(query='Productionize a receipt agent across architecture, implementation, failure tests and measured evaluation.',should_trigger=True)]
(D/'trigger-smoke.json').write_text(json.dumps(q),encoding='utf-8')
commands.append(('official-trigger',[sys.executable,'-X','utf8','-B','-m','scripts.run_eval','--eval-set',str(D/'trigger-smoke.json'),'--skill-path',str(V/'pack/agent-development-workflow'),'--num-workers','1','--runs-per-query','1','--timeout','8','--verbose']))
for name,cmd in commands:
    try:
        p=subprocess.run(cmd,cwd=D,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=35)
        result=dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
    except subprocess.TimeoutExpired as e: result=dict(command=cmd,timeout=True,error=str(e))
    (D/f'{name}.json').write_text(json.dumps(result,indent=2),encoding='utf-8'); records.append(result)
print(json.dumps(records,indent=2))
