from pathlib import Path
import json, shutil
V=Path(__file__).resolve().parent/'v2'
J=V/'job-agent-architecture.json'
job=json.loads(J.read_text(encoding='utf-8'))
assert 'iteration-1' in job['tasks'][0]['runs']['with_skill']
shutil.copy2(J,V/'job-agent-architecture-iteration-1.json')
shutil.copy2(V/'tested-source-sha256.json',V/'tested-source-sha256-before-architecture-correction.json')
for task in job['tasks']:
    for config, old in task['runs'].items():
        new=old.replace('iteration-1','iteration-2')
        dest=Path(new); (dest/'outputs').mkdir(parents=True)
        shutil.copy2(Path(old)/'eval_metadata.json',dest/'eval_metadata.json')
        task['runs'][config]=new
J.write_text(json.dumps(job,indent=2),encoding='utf-8')
jobs=json.loads((V/'eval-jobs.json').read_text(encoding='utf-8'))
jobs=[job if j['skill']=='agent-architecture' else j for j in jobs]
(V/'eval-jobs.json').write_text(json.dumps(jobs,indent=2),encoding='utf-8')
(V/'architecture-correction.md').write_text('Cross-skill review found two rows whose former escalation evidence contradicted the task-fit table. Replaced those cells with validation of the chosen hypothesis; corrected the tool-agent cell as well. Descriptions and assertion contracts are unchanged. Preserve iteration-1 artifacts and rerun both selected cases/configurations in iteration-2. This is a source-review correction, not a failed behavior assertion.\n',encoding='utf-8')
print('Architecture iteration-2 prepared; original runs and assertions preserved.')
