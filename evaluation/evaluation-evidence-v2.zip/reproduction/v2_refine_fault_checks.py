from pathlib import Path
import json,shutil
V=Path(__file__).resolve().parent/'v2'
names=['agent-observability','agent-testing']
jobs=json.loads((V/'eval-jobs.json').read_text(encoding='utf-8'))
selected={name:json.loads((V/f'job-{name}.json').read_text(encoding='utf-8')) for name in names}
for name,job in selected.items():
    for task in job['tasks']:
        for old in task['runs'].values():
            assert 'iteration-1' in old and (Path(old)/'grading.json').is_file()
            assert not Path(old.replace('iteration-1','iteration-2')).exists()
shutil.copy2(V/'tested-source-sha256.json',V/'tested-source-sha256-before-fault-check-refinement.json')
for name,job in selected.items():
    shutil.copy2(V/f'job-{name}.json',V/f'job-{name}-iteration-1.json')
    for task in job['tasks']:
        for config,old in task['runs'].items():
            dest=Path(old.replace('iteration-1','iteration-2')); (dest/'outputs').mkdir(parents=True)
            shutil.copy2(Path(old)/'eval_metadata.json',dest/'eval_metadata.json')
            task['runs'][config]=str(dest)
    (V/f'job-{name}.json').write_text(json.dumps(job,indent=2),encoding='utf-8')
(V/'eval-jobs.json').write_text(json.dumps([selected.get(j['skill'],j) for j in jobs],indent=2),encoding='utf-8')
(V/'fault-check-refinement.md').write_text('Independent supplemental probes found revised observability fake accepting an orphan parent and revised testing fake permitting another effect after terminal controller reentry. Original bounded assertions pass and are preserved; add focused general fault-check procedures to source and rerun both selected cases/configurations with unchanged assertion contracts. Grade those original contracts and separately reproduce the supplemental checks, without inflating scores or replacing old outputs.\n',encoding='utf-8')
print('Observability/testing iteration-2 prepared, original evidence preserved.')
