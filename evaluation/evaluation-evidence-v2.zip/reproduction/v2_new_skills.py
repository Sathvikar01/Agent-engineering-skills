from pathlib import Path
P=Path(__file__).resolve().parent/'v2/pack'
def create(name,description,body,refname,ref):
    d=P/name; d.mkdir(); (d/'evals').mkdir(); (d/'references').mkdir()
    front=f'---\nname: {name}\ndescription: >-\n  {description}\nmetadata:\n  author: Sathvik\n  collection: "Sathvik — Agent Engineering"\n  version: "2.0.0"\n---\n\n'
    (d/'SKILL.md').write_text(front+body.strip()+'\n',encoding='utf-8')
    (d/'references'/refname).write_text(ref.strip()+'\n',encoding='utf-8')

create('agent-development-workflow','Coordinate the complete engineering lifecycle for substantial AI-agent or model-assisted workflow builds. Use when building, productionizing or substantially redesigning an agent, adding major tools/state/RAG/orchestration, or evaluating and hardening a whole agent system. Do not use for one bug, tiny prompt/schema/API changes, ordinary app work, simple deterministic utilities, conceptual agent explanations, or a narrow task owned by one specialist.', '''# Agent Development Workflow

Models handle uncertainty; trusted code handles specifiable correctness and authority; evidence decides what survives. Coordinate specialists at relevant boundaries without copying their procedures or loading the whole collection.

## Understand and establish the contract

1. Before coding, identify goal, required behavior, inputs/outputs, system boundary, environment, constraints, safety requirements and success criteria. Inspect an existing implementation/evidence before proposing a rewrite.
2. Map important components: deterministic? model needed? why? failure consequence? validation? Avoid needless autonomy and brittle heuristics for semantic ambiguity. Use agent-architecture to choose the simplest architecture that correctly handles uncertainty; model-assisted pipeline, single tool/RAG agent and hybrid are hypotheses, not ranked defaults.
3. Use agent-evals before large implementation: baseline, representative/hard/adversarial cases, failure taxonomy, task/safety/tool/provenance/latency/cost metrics, slice thresholds and invariants. Provide one obvious project-appropriate rerun command. Average gains cannot cancel critical regressions.
4. Freeze input/output/state/tool/model schemas, error semantics, stop conditions, budgets and permissions. Use structured-output-design and tool-design at those interfaces; agent-state-and-memory for persistence. Version actual contracts/assumptions rather than speculative infrastructure.

## Draw boundaries and prove a vertical slice

5. Classify decisions as deterministic, model-assisted, proposal-plus-validation or human-gated. Use deterministic-authority for permissions/calculations/state transitions and human-in-the-loop for warranted review. Model output is fallible; define what happens when it is wrong.
6. Use evidence-provenance for source → retrieval → normalization → ledger → decision → claim → reconciliation. Retrieved evidence differs from used support. Validate shape, semantics, fact/explanation consistency and cited IDs before promoting output/state.
7. Design necessary tools/retrieval/state with tool-design, rag-engineering and agent-state-and-memory. Use agent-orchestration to decide whether a model controls next steps; bound actions, calls, retries, time, cost and termination. Multiple roles/models/workers or a framework require measured benefit.
8. Build one complete safe path: input → evidence → model/logic → proposed tool action → validation → authority → effect/receipt → output → trace. Security, recovery and observability start here before real effects. Use agent-security, agent-guardrails, agent-failure-recovery and agent-observability at actual risk boundaries.

## Execute the inner loop for each material change

9. PLAN: change, reason, expected behavior, invariant and success check. IMPLEMENT: smallest coherent diff. RUN: execute relevant unit/integration/eval/CLI/browser/runtime checks. DEBUG: reproduce mismatch, inspect evidence, localize and state a root-cause hypothesis; use installed systematic-debugging. CORRECT: fix the cause. REVIEW: inspect diff, results, regressions, complexity and unintended behavior; choose KEEP, REVISE or ROLLBACK. Repeat as needed; generation or one successful example is insufficient.
10. Construct → verify → admit when safe valid candidates may exist. Bound repair/alternative search under unchanged facts, policy and approval; fail closed when none can be established. Do not fabricate evidence or quietly change the requested operation.
11. Use agent-testing for deterministic semantic/authority/provenance checks, contracts, trajectories, failure injection and restart tests. Simulate malformed/empty/refused/timed-out/contradictory outputs, invented IDs, repeated answers and unsupported tools. Verify predictable degradation and no forbidden effects.
12. Run matched baseline/variant evals and inspect critical metrics; ablate uncertain extra verification, models, routing or retrieval. Record versions/configuration, quality/safety/latency/cost and failure classes. Use agent-cost-and-latency for cost per verified success and completion latency. Keep, revise or roll back from evidence; unexecuted checks remain unverified.

## Review, defend and complete

13. For material decisions record DECISION, HYPOTHESIS, ALTERNATIVES, WHY CHOSEN, EVIDENCE, LIMITATION, FALLBACK and PROPOSED/VALIDATED/REJECTED/SUPERSEDED status. Preserve important AI proposals and engineer selections/modifications/test outcomes, without labeling every line. Human engineers retain responsibility. Read [decision and defence templates](references/decision-and-defence.md) for substantial systems.
14. Answer technical questions directly: answer → implementation location/detail → reason/trade-off → evidence → limitation/fallback. At completion explain boundaries, rejected alternatives, quantified tests/evals where available, failure paths, unresolved risks and next step. Do not invent measurements or conflate telemetry with controlled evals.
15. Use installed verification-before-completion for the final evidence check. Ship through the authorized release path after required gates; record unavailable checks and gaps. A generated first implementation is a candidate, not completion.

Expected artifacts: uncertainty/ownership map, architecture decision, eval baseline/rerun command, contracts/invariants, executed vertical slice, evidence/trace, tested failure policy, comparison/ablation decision and concise defence. Scale to consequence. Existing brainstorming/planning/TDD/debugging retain mechanics; this skill owns lifecycle coordination.''','decision-and-defence.md', '''# Material decisions and technical defence

Use for architecture, trust, quality or operational choices, not tiny edits.

| Decision | Hypothesis | Alternatives | Why chosen | Evidence | Limitation | Fallback | Status |
|---|---|---|---|---|---|---|---|
| Bounded model extraction, deterministic payment arithmetic | Document variants need interpretation | Regex-only; autonomous finance agent | Interpretation uncertain; arithmetic specified | Actual fixture/eval result or proposed experiment | Unseen layouts | Typed review-needed result | PROPOSED/VALIDATED/REJECTED/SUPERSEDED |

Do not mark proposed experiments VALIDATED. Track important AI proposals and engineer choices/tests without per-line attribution.

For “Why this architecture?”, lead with choice/boundary, then implementation, alternatives/trade-offs, observed comparisons, limits/fallback. A substantial completion defence covers what was built, boundaries, key code locations, why choices survived, test/eval versions/counts, failure modes, fallback, risks and next improvement.

Inner-loop record: planned invariant/check → diff → actual command/output → reproduced failure/root cause when present → correction → rerun/regression result → retain/revert decision. Do not manufacture a failure to fill DEBUG; if no mismatch occurred, report checks and that observation.
''')
create('evidence-provenance','Design and verify source-to-decision-to-output evidence lineage for AI systems. Use when implementing evidence ledgers, distinguishing retrieved from used support, reconciling decision/explanation/citation IDs, or preventing fabricated, stale or spoofed provenance across tools and model stages. Do not use for retrieval ranking/chunking alone, ordinary bibliography formatting, general logging, coding-source lookup, or answers with no evidence-lineage contract.', '''# Evidence Provenance

Provenance is an application-owned record of observed sources/transformations, not citations appended after generation. Known IDs are necessary but do not prove support.

## Establish observed evidence

1. Define evidence for the task: accessible source/span/version, typed observation, deterministic computation or committed receipt. Assign IDs through trusted ingestion; source text/model output cannot mint authoritative entries. Record tenant/access scope, origin/time/version, digest, retrieval/tool/run ID and status. Bound retention/payloads under privacy policy.
2. Preserve source → retrieval → normalization → ledger lineage. Record transformation input/output IDs, versions and digest/span mappings. Summaries are derived claims with parent support, not replacements for source identity. Recheck consequential facts against fresh authoritative state; history does not prove current validity.
3. Distinguish retrieved candidates, model-visible context, used support and rejected/conflicting evidence. Record discarded/truncated status. A model’s used-ID list is a proposal; verify visibility and claim support without collecting private reasoning. Ledger membership alone cannot establish genuine use or entailment.

## Bind decisions and claims

4. Bind structured facts/decisions to observed evidence or computation inputs/rule/version. Bind emitted claims to supporting decisions/facts/source spans; label inference, uncertainty and gaps. Preserve contradictory sources rather than deleting inconvenient evidence.
5. Reconcile before emission: decision ↔ facts ↔ explanation ↔ ledger ↔ cited IDs. Enforce emitted IDs ⊆ accessible ledger AND supported used IDs for the relevant claim. Reject guessed IDs, unrelated known IDs, cross-tenant/stale versions and unobserved citations. Do not append provenance to conceal an unsupported decision.
6. Encode decidable checks in code: ID existence/scope/version, source visibility, transform ancestry, arithmetic and cross-field relations. For semantic entailment/support use evidence-based review or calibrated grader when needed; an ID whitelist is insufficient. A hash does not prove truth. Explanation cannot invent facts absent from the admitted structured path.

## Recover without laundering evidence

7. When support is missing, retrieve/construct a supported candidate or revise/remove the claim within finite budgets, then reconcile under unchanged rules. If none can be established, return explicit unsupported/insufficient-evidence status or fail the required output gate. Critical unsupported decisions fail closed; never fabricate entries or hide uncertainty behind citations.
8. Carry pointers through tools, compaction, checkpoints and resume. Recheck access/freshness at use; historical IDs may be unauthorized now. Log IDs and validation safely for reconstruction without duplicating sensitive content everywhere.

Deliver ledger/lineage contract, claim-support mapping, reconciliation validator/checker, supported/rejected examples and tests. Read [ledger example](references/ledger-and-reconciliation.md) when implementing records. Verify unknown IDs, retrieved-but-unused/irrelevant citations, spoofed envelopes, lost transform parents, contradictory explanation, revoked access and valid support.

RAG owns retrieval/ranking; this skill owns lineage/reconciliation across evidence-producing stages. Observability records decisions, structured-output-design owns proposal shape/semantics, deterministic-authority owns effect admission. No mandatory dependency chain.''','ledger-and-reconciliation.md', '''# Ledger and reconciliation example

Application-created records can be small typed rows:

```
E1: source=manual, span=12:18, version=4, digest=..., tenant=T1,
    observed_by=tool-call-7, run=R1, retrieved=true, visible=true
E2: source=appendix, span=1:3, version=4, tenant=T1,
    observed_by=tool-call-7, run=R1, retrieved=true, visible=false (budget)
C1: computation=approved-total, inputs=[E1], rule=totals-v2, value=100
D1: decision=WAIT, facts=[C1], used_support=[E1], missing=[approval]
claim-1: text="Approval is still required", decision=D1, support=[E1]
```

Check ID, access/freshness, visibility and lineage first; actual support next. E2 exists but cannot support this claim merely because retrieved. Unknown E9 is rejected. “Approved now” contradicts D1=WAIT even with valid E1. Source text claiming E9 cannot issue a record. Visible means supplied to this model call, not dropped during assembly.

Compare deterministic typed facts with authorized observations. For natural-language inference provide source span and calibrated support assessment; string equality is not a general entailment engine. Keep supported/unsupported/contradicted/unresolved distinct. Model-proposed support must be checked.

Retain restricted source pointers/transform mappings. Revoked or expired evidence requires rebuilding support or unsupported status. Receipts prove observed effects under adapter semantics, not universal system correctness.
''')
print('Created two narrowly scoped skills and two justified references.')
