from pathlib import Path
import json, shutil
V=Path(__file__).resolve().parent/'v2'
J=V/'job-agent-evals.json'
job=json.loads(J.read_text(encoding='utf-8'))
assert 'iteration-1' in job['tasks'][0]['runs']['with_skill']
shutil.copy2(J,V/'job-agent-evals-iteration-1.json')
shutil.copy2(V/'tested-source-sha256.json',V/'tested-source-sha256-before-eval-metric-correction.json')
for task in job['tasks']:
    for config, old in task['runs'].items():
        assert (Path(old)/'grading.json').is_file()
        new=old.replace('iteration-1','iteration-2')
        dest=Path(new); (dest/'outputs').mkdir(parents=True)
        shutil.copy2(Path(old)/'eval_metadata.json',dest/'eval_metadata.json')
        task['runs'][config]=new
J.write_text(json.dumps(job,indent=2),encoding='utf-8')
jobs=json.loads((V/'eval-jobs.json').read_text(encoding='utf-8'))
(V/'eval-jobs.json').write_text(json.dumps([job if j['skill']=='agent-evals' else j for j in jobs],indent=2),encoding='utf-8')
(V/'eval-metric-correction.md').write_text('Independent grading preserved original assertion passes but flagged inferred binary-success counts from undefined quality percentages in both v2 cases. Added preserving metric definitions/units/denominators before count conversion. Rerun the original selected prompts and unchanged assertions in iteration-2 with fresh paired executors; preserve all original claims and grades. This refinement addresses an observed output claim rather than relabeling an assertion.\n',encoding='utf-8')
print('Agent-evals iteration-2 prepared; original grades and assertions preserved.')
