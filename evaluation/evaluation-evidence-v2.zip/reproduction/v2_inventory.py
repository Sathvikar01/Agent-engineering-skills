from pathlib import Path
import hashlib,json,sys
W=Path(__file__).resolve().parent; V=W/'v2'
baseline=V/'third-party-before.json'; assert not baseline.exists()
previous=json.loads((W/'installation-before.json').read_text(encoding='utf-8'))
old=json.loads((W/'global-installation.json').read_text(encoding='utf-8-sig'))['skills']
custom=set(old)|{'agent-orchestration','agent-development-workflow','evidence-provenance'}
files={}; metadata=[]
for rawroot in previous['roots']:
    root=Path(rawroot)
    for p in root.rglob('*'):
        if not p.is_file() or '.git' in p.parts or '__pycache__' in p.parts: continue
        relative=p.relative_to(root)
        if relative.parts[0] in custom or p.name=='AGENT-ENGINEERING-SKILLS.md': continue
        files[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
        if p.name=='SKILL.md': metadata.append(dict(path=str(p),frontmatter=p.read_text(encoding='utf-8-sig',errors='replace').split('---',2)[1]))
prior_diff=[]
for p,h in previous['files'].items():
    if p not in files: prior_diff.append(dict(path=p,status='missing_from_current_inventory'))
    elif files[p]!=h: prior_diff.append(dict(path=p,status='changed_since_v1'))
data=dict(files=files,skills=metadata,prior_v1_differences=prior_diff,note='Fresh pre-install third-party inventory. V1 baseline included obsolete bundled plugin versions removed by the changed desktop environment; no task writes target those paths. Initial V2 audit failure retained.')
baseline.write_text(json.dumps(data,indent=2),encoding='utf-8')
print(json.dumps(dict(current_files=len(files),metadata_records=len(metadata),prior_v1_differences=len(prior_diff),prior_difference_roots=sorted({str(Path(p['path']).parts[6:9]) for p in prior_diff})),indent=2))
