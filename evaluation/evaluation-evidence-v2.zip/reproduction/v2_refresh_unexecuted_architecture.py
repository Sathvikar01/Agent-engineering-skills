from pathlib import Path
import hashlib,json,shutil
V=Path(__file__).resolve().parent/'v2'
iteration=V/'agent-architecture-workspace/iteration-2'
assert not list(iteration.rglob('response.md')) and not list(iteration.rglob('grading.json'))
source=V/'pack/agent-architecture/SKILL.md'; snapshot=iteration/'tested-skill'
shutil.copy2(source,snapshot/'SKILL.md')
hashes=json.loads((V/'tested-source-sha256.json').read_text(encoding='utf-8'))
hashes['agent-architecture']={p.relative_to(snapshot).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in snapshot.rglob('*') if p.is_file()}
(V/'tested-source-sha256.json').write_text(json.dumps(hashes,indent=2),encoding='utf-8')
print('Updated only the unexecuted architecture iteration-2 snapshot.')
