from pathlib import Path
import json,sys
W=Path(__file__).resolve().parent; V=W/'v2'; P=V/'pack'
sys.path.insert(0,str(W/'validation-deps')); import yaml
design=json.loads((W/'pack-design.json').read_text(encoding='utf-8')); oldresults=json.loads((W/'behavior-summary.json').read_text(encoding='utf-8'))['skills']
behavior=json.loads((V/'behavior-summary.json').read_text(encoding='utf-8')) if (V/'behavior-summary.json').exists() else {'skills':{}}
routes=json.loads((V/'routing-summary.json').read_text(encoding='utf-8'))['skills']
relations={
'agent-development-workflow':'Lifecycle coordination; optional specialist use; installed planning/TDD/debugging/verification retain mechanics',
'agent-architecture':'Uncertainty/component boundaries; workflow coordinates lifecycle; orchestration owns next-step controller',
'agent-orchestration':'Fixed/adaptive control; optional justified workers; coding-subagent dispatch stays in Superpowers',
'evidence-provenance':'Source/transform/decision/claim reconciliation; RAG retrieves, observability records, authority admits',
'agent-evals':'Population/scoring/release experiment; testing owns implementation checks; tool-evals isolates interaction',
'tool-design':'Model-facing capability contracts; existing API/MCP skills own protocol/backend mechanics',
'tool-evals':'Discovery/selection/argument/chain usability; agent-evals owns whole-task quality',
'structured-output-design':'Generated proposal shape/semantics; provenance reconciles support; authority authorizes effects',
'deterministic-authority':'Executable admission/invariants; approval UX and layered composition remain separate',
'agent-state-and-memory':'Runtime persistence/source of truth; context-engineering owns coding-session packing',
'human-in-the-loop':'Proportional human review and bound grants; authority enforces and cannot waive hard rules',
'agent-security':'Model-mediated attacker-to-effect paths; existing hardening remains baseline application security',
'agent-failure-recovery':'Bounded recovery/unknown effects; state owns checkpoint representation, debugging diagnoses defects',
'agent-observability':'Reconstructable events/actionable signals; evals defines scoring, provenance defines support',
'agent-testing':'Runtime test pyramid/CI and fault fixtures; TDD mechanics and gold evaluation remain separate',
'prompt-engineering':'Shipped model responsibilities/outputs; prompts guide, code enforces; context-engineering owns sessions',
'rag-engineering':'Retrieval/assembly/grounded-generation pipeline; provenance owns end-to-end ledger; source-driven owns docs lookup',
'agent-cost-and-latency':'Outcome economics/role-routing experiments; orchestration controls transitions, evals owns rigor',
'agent-guardrails':'Layer composition/bypass/false blocking; security threats, admission and approvals have separate owners'}
lines=['# Sathvik — Agent Engineering','','Author: **Sathvik**. Collection revision: **2.0.0**. Nineteen global, framework-agnostic skills. Three unchanged skill implementations retain version 1.0.0; modified/new implementations use 2.0.0.','','Models handle uncertainty. Deterministic software handles authority wherever correctness can be specified. Evidence decides whether changes survive. The engineering loop continues beyond generation. Choose the simplest architecture that correctly handles uncertainty; avoid both agentification and brittle deterministic overcorrection.','','## Recommended Full Agent Build Flow','',
'UNDERSTAND → MAP UNCERTAINTY → CLASSIFY ARCHITECTURE → BASELINE + EVALS → FREEZE CONTRACTS + INVARIANTS → MODEL/DETERMINISTIC BOUNDARY → AUTHORITY → EVIDENCE FLOW → TOOLS/RETRIEVAL/STATE → BOUNDED ORCHESTRATION → SMALLEST VERTICAL SLICE.',
'', 'For each material change: **PLAN → IMPLEMENT → RUN → DEBUG → CORRECT → REVIEW**. Reconcile syntax/schema/semantics and evidence; test failures; run matched evals; compare baseline; ablate uncertain complexity; KEEP / REVISE / ROLLBACK. Security, recovery and observability begin in the first slice. Finish with technical defence, verification-before-completion and the authorized release path.','','When safe candidates may exist: CONSTRUCT → VERIFY → ADMIT. Bound reconstruction and never weaken constraints, invent support or silently change the authorized task. No admissible candidate or missing required authority ends in honest failure/unsupported status.','','## Terminology','',
'| Term | Meaning |','|---|---|',
'| Agent | Runtime component adaptively choosing actions from observations inside explicit boundaries. |',
'| Workflow | Software-controlled sequence/graph with known transitions; may include model-powered steps. |',
'| Tool | Bounded observation/action capability with strict contracts and explicit side effects. |',
'| State | Typed application-owned facts/status changed through deterministic validated transitions. |',
'| Memory | Scoped recall with provenance/lifecycle; not authorization or proof of current critical facts. |',
'| Authority | Trusted right and mechanism to admit actions or commit transitions. |',
'| Policy | Versioned permissions, invariants and approval rules enforced by trusted software. |',
'| Guardrail | Boundary control; distinguish probabilistic guidance from deterministic enforcement. |',
'| Approval | Application-recorded authorized human decision bound to exact action/scope and validity. |',
'| Evaluation | Observed outputs/effects/trajectories compared with predeclared criteria. |',
'| Trajectory | Observable proposals/decisions/calls/results/transitions; not private reasoning. |',
'| Run | Logical task identity with cumulative budgets across attempts/resume. |',
'| Checkpoint | Durable versioned progress, evidence, pending effects and remaining budgets for safe resume. |',
'| Evidence ledger | Application-owned observed sources/transformations/computations/receipts with access and lineage; not an automatic truth guarantee. |',
'| Used support | Observed, accessible evidence checked as support for a particular decision/claim, distinct from retrieval candidates. |',
'| Uncertainty map | Component-specific model need, reason, consequence and validation before architecture choice. |','',
'## Global installation and methodology','',
'Discovered central storage: `~/.cc-switch/skills` (`skillStorageLocation=cc_switch`, `skillSyncMethod=auto`). Codex/Claude expose central implementations through junctions in their global skills roots. CC Switch database/settings are not edited; UI toggle registration is not inferred from file presence. A fresh session may be needed for catalogue refresh.',
'', 'Anthropic creator at `~/.cc-switch/skills/skill-creator` governs snapshots, progressive disclosure, official eval/trigger/grading schemas, validator, aggregator and review templates. Audit read all 17 v1 custom skills, all suites/resources, 18 creator files and 22 relevant third-party SKILL.md files. This task did not write third-party source. Third-party files drifted between session snapshots; the report preserves differences and verifies the final installation against a current read-only baseline.',
'', 'User-supplied Orchestrate observations motivate rules, not statistical/causal claims. Original reports/article were not supplied. No provider choice is prescribed from participation counts. No separate model-selection-and-routing or technical-defence skill: existing owners cover those workflows.',
'', '## Skills, scope and evidence','',
'| Skill | Author | Purpose | Triggers | Non-triggers | Relationships | Eval status | Validation | Files |',
'|---|---|---|---|---|---|---|---|---|']
for d in sorted(P.iterdir()):
    if not d.is_dir(): continue
    name=d.name; fm=yaml.safe_load((d/'SKILL.md').read_text(encoding='utf-8').split('---',2)[1]); desc=fm['description']
    purpose,rest=desc.split('Use when ',1); trigger,negative=rest.split('Do not use for ',1)
    r=routes[name]; x=behavior['skills'].get(name)
    if x: status=f"Fresh targeted v2 {x['with_passed']}/{x['with_total']}; {x['baseline']} {x['baseline_passed']}/{x['baseline_total']}"
    elif name in ('tool-evals','agent-state-and-memory','human-in-the-loop'):
        x=oldresults[name]; status=f"Unchanged instructions: retained v1 {x['with_passed']}/{x['with_total']}; no fresh v2 behavior run"
    else: status='Fresh paired v2 grading pending'
    status+=f"; routing proxy {r['passed']}/20, actual invocation unverified"
    files=', '.join(f'[{p.relative_to(d).as_posix()}]({p.relative_to(P).as_posix()})' for p in sorted(d.rglob('*')) if p.is_file())
    row=[f'[{name}]({name}/SKILL.md)','Sathvik',purpose.strip(),trigger.strip(),negative.strip(),relations[name],status,'Official validator + local structural checks passed on stage; installed audit in report',files]
    lines.append('| '+' | '.join(v.replace('|','\\|') for v in row)+' |')
lines += ['', '## Responsibilities and verification limits','',
'Lifecycle coordinates boundaries, without importing all specialists on every task. Optional companion names are discoverability hints, not mandatory circular dependencies. No custom production scripts were added. Evidence membership is necessary, not sufficient for support; semantic review is distinguished from deterministic predicates.',
'', 'Behavior suites retain v1 coverage and add targeted revision cases. Sixteen modified/new skills have fresh paired targeted/adversarial runs; unchanged state/memory, approval and tool-usability procedures retain clearly labeled v1 evidence. Not every stored v1 case was re-executed against v2. Single samples are smoke evidence, not repeated-run reliability. Baseline ties do not establish incremental benefit.',
'', 'Current Claude CLI preflight is not logged in; untouched official trigger runner fails with WinError 10038 on Windows pipes. Infrastructure failure is not a valid negative trigger result. The 380-case metadata-selection proxy is separate from actual automatic invocation/optimization. Human review and repeated held-out variance remain outstanding. See revision validation report and official review HTML.',
'', '## Directory structure','', '```text', 'skills/', '  AGENT-ENGINEERING-SKILLS.md']
for d in sorted(P.iterdir()):
    if not d.is_dir(): continue
    lines.append(f'  {d.name}/')
    for p in sorted(d.rglob('*')):
        if p.is_file(): lines.append('    '+p.relative_to(d).as_posix())
lines += ['```','']
(P/'AGENT-ENGINEERING-SKILLS.md').write_text('\n'.join(lines),encoding='utf-8')
print('Wrote v2 catalogue with 19 scopes, evidence states, lifecycle and actual file tree.')
