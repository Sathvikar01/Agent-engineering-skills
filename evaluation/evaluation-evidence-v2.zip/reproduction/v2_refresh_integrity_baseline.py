from pathlib import Path
import hashlib, json, shutil

W = Path(__file__).resolve().parent
V = W / 'v2'
baseline = V / 'third-party-before.json'
archive = V / 'third-party-before-2026-10-04.json'
assert baseline.is_file() and not archive.exists()
old = json.loads(baseline.read_text(encoding='utf-8'))
roots = json.loads((W / 'installation-before.json').read_text(encoding='utf-8'))['roots']
custom = set(json.loads((W / 'global-installation.json').read_text(encoding='utf-8-sig'))['skills']) | {'agent-orchestration', 'agent-development-workflow', 'evidence-provenance'}
files, metadata = {}, []
for raw in roots:
    root = Path(raw)
    for p in root.rglob('*'):
        if not p.is_file() or '.git' in p.parts or '__pycache__' in p.parts:
            continue
        relative = p.relative_to(root)
        if relative.parts[0] in custom or p.name == 'AGENT-ENGINEERING-SKILLS.md':
            continue
        files[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
        if p.name == 'SKILL.md':
            metadata.append(dict(path=str(p), frontmatter=p.read_text(encoding='utf-8-sig', errors='replace').split('---', 2)[1]))
drift = [{'path':p, 'status':'missing' if p not in files else 'changed', 'before_sha256':h, 'current_sha256':files.get(p)} for p,h in old['files'].items() if files.get(p) != h]
added = sorted(set(files) - set(old['files']))
shutil.copy2(baseline, archive)
shutil.copy2(V / 'staging-audit.json', V / 'staging-audit-drift-failure-2026-10-05.json')
data = dict(files=files, skills=metadata, prior_v1_differences=old.get('prior_v1_differences',[]), resumed_snapshot_drift=drift, added_paths_since_prior_snapshot=added,
            note='Current pre-install read-only baseline after continued work. Prior baseline, failed audit and all differences are retained. No task write targeted third-party sources; cause of environmental drift is not established by hashes. Full-session third-party hash stability cannot be claimed.')
baseline.write_text(json.dumps(data, indent=2), encoding='utf-8')
report = dict(client_date='2026-10-05', current_files=len(files), current_skill_metadata=len(metadata), changed=sum(x['status']=='changed' for x in drift), missing=sum(x['status']=='missing' for x in drift), added=len(added), differences=drift, added_paths=added, prior_baseline=archive.name, full_session_stability=False)
(V / 'integrity-baseline-refresh.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('differences','added_paths')}, indent=2))
