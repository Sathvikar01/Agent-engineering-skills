from pathlib import Path
import json
V=Path(__file__).resolve().parent/'v2'
key=json.loads((V/'routing-key.json').read_text(encoding='utf-8'))
queries={q['id']:q['query'] for q in json.loads((V/'routing-queries.json').read_text(encoding='utf-8'))}
raw=json.loads((V/'routing-selection.json').read_text(encoding='utf-8'))
allowed={q['name'] for q in json.loads((V/'routing-catalogue.json').read_text(encoding='utf-8'))}
assert len(raw)==380 and {x['id'] for x in raw}==set(key) and len({x['id'] for x in raw})==380
rows={}; failures=[]
for x in raw:
    assert isinstance(x['selected_skills'],list) and set(x['selected_skills'])<=allowed and len(x['selected_skills'])==len(set(x['selected_skills']))
    target=key[x['id']]; predicted=target['skill'] in x['selected_skills']; correct=predicted==target['should_trigger']
    row=rows.setdefault(target['skill'],dict(passed=0,total=0,positive_passed=0,positive_total=0,negative_passed=0,negative_total=0))
    group='positive' if target['should_trigger'] else 'negative'; row['total']+=1; row['passed']+=correct; row[group+'_total']+=1; row[group+'_passed']+=correct
    if not correct: failures.append(dict(id=x['id'],skill=target['skill'],query=queries[x['id']],should_trigger=target['should_trigger'],selected=x['selected_skills']))
for row in rows.values(): row['smoke_gate_passed']=row['positive_passed']>=9 and row['negative_passed']>=9
report=dict(protocol='Independent metadata routing proxy: 19 custom and 16 adjacent descriptions; not actual invocation',skills=rows,passed=sum(r['passed'] for r in rows.values()),total=380,failures=failures,smoke_gate_passed=all(r['smoke_gate_passed'] for r in rows.values()),actual_activation_verified=False)
(V/'routing-summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8'); print(json.dumps({k:v for k,v in report.items() if k!='skills'},indent=2))
